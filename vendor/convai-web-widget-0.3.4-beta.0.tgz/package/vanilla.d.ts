/**
 * `@convai/web-widget/vanilla` — the chat UI without a framework.
 *
 * This moved here from `@convai/web-sdk/vanilla`, which keeps the client side:
 * `ConvaiClient`, `AudioRenderer` and the WebSocket transport. Take the client
 * from there and the interface from here:
 *
 * ```ts
 * import { ConvaiClient } from '@convai/web-sdk/core'
 * import { createConvaiWidget } from '@convai/web-widget/vanilla'
 *
 * const client = new ConvaiClient({ apiKey, characterId })
 * createConvaiWidget(document.body, { convaiClient: client })
 * ```
 *
 * No React, no styled-components, no framer-motion: the vanilla widget is
 * hand-written DOM and CSS, so this entry pulls in none of the React UI's
 * dependencies. Importing it has no side effects.
 */
export { createConvaiWidget, destroyConvaiWidget } from './ui/vanilla/ConvaiWidget';
export type { VanillaWidget, VanillaWidgetOptions, WidgetPlacement } from './ui/vanilla/types';
