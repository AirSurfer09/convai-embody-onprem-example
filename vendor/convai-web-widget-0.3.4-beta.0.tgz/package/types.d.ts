export type ErrorCode = 'config' | 'auth' | 'network' | 'runtime' | 'mic-permission';
export type Placement = 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left' | 'inline';
export type Preload = 'none' | 'hover' | 'idle';
export interface WidgetConfig {
    /**
     * Absent in publication mode and only there. A published integration names
     * a publication and nothing else — the character id stays server-side,
     * which is the whole privacy property `publicationId` exists to preserve.
     * Every other mode requires it, and `readConfig` enforces that.
     */
    characterId?: string;
    /**
     * Publication mode. When set, the widget resolves its session from the
     * Character API's chat-publication endpoints instead of from any
     * credential on this page, and `tokenEndpoint`/`connectEndpoint`/`apiKey`
     * are neither required nor read.
     */
    publicationId?: string;
    /** Character API origin serving the publication. Defaults to api.convai.com. */
    publicationApiUrl?: string;
    /** Core/realtime origin override for the published connect exchange. */
    coreUrl?: string;
    tokenEndpoint?: string;
    connectEndpoint?: string;
    apiKey?: string;
    endUserId?: string;
    endUserMetadata?: Record<string, unknown>;
    placement: Placement;
    preload: Preload;
    startOpen: boolean;
    startWithAudio: boolean;
    accent?: string;
    greeting?: string;
    launcherLabel?: string;
    avatarSrc?: string;
    disabled: boolean;
    debug: boolean;
}
export type ConfigResult = {
    ok: true;
    config: WidgetConfig;
} | {
    ok: false;
    message: string;
};
/** What runtime.mount() hands back to the loader. */
export interface RuntimeController {
    open(): void;
    close(): void;
    toggle(): void;
    sendMessage(text: string): void;
    destroy(): void;
    readonly client: unknown;
}
export interface MessageDetail {
    sender: 'user' | 'bot';
    content: string;
}
export interface ErrorDetail {
    code: ErrorCode;
    message: string;
}
