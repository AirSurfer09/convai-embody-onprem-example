const VERSION = "0.3.4-beta.0";
export {
  VERSION
};
