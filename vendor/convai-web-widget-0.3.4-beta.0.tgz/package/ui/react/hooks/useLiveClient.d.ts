import type { IConvaiClient } from "@convai/web-sdk/core";
/** The fields `useConvaiClient` adds on top of the client. */
export interface LiveClientFields {
    activity: string;
    isAudioMuted: boolean;
    isVideoEnabled: boolean;
    isScreenShareActive: boolean;
}
/** True for a `useConvaiClient` result, which carries the UI fields itself. */
export declare function isManagedClient(client: object): boolean;
/**
 * The four UI fields for `client`: its own when `useConvaiClient` supplied
 * them, otherwise read live from the client, re-rendering on every change.
 */
export declare function useLiveClient(client: IConvaiClient & Partial<LiveClientFields>): LiveClientFields;
/**
 * The client as the widget should see it: a `useConvaiClient` result as-is,
 * otherwise a view that adds the four UI fields and changes identity on every
 * client event — exactly how a `useConvaiClient` result behaves, so the widget
 * and its children re-render and re-run their effects the same way.
 *
 * A Proxy, not a copy: reads, writes and `this` inside methods all reach the
 * real client, and only the four fields are answered here. The app's own
 * reference to the client is never modified.
 */
export declare function useLiveClientView<C extends IConvaiClient & Partial<LiveClientFields>>(client: C): C & LiveClientFields;
