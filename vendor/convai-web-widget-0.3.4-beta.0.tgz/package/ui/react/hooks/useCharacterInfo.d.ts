import { type CharacterInfo } from "@convai/web-sdk/core";
/**
 * Fetch a character's display name and avatar for the widget header.
 *
 * The request itself lives in `core/characterInfo` so the vanilla widget runs
 * the same code rather than a hand-synced copy of it.
 *
 * @param characterId - Character to look up
 * @param apiKey - Convai API key, sent as `CONVAI-API-KEY`
 * @param authToken - Preferred over `apiKey`, sent as `API-AUTH-TOKEN`
 * @param baseUrl - Origin to ask; defaults to `https://api.convai.com`. Pass
 *   `client.characterInfoUrl` so a non-SaaS deployment is not asked to send
 *   its credential to Convai's public API.
 */
export declare const useCharacterInfo: (characterId?: string, apiKey?: string, authToken?: string, baseUrl?: string | null) => CharacterInfo & {
    isLoading: boolean;
    error: Error | null;
};
