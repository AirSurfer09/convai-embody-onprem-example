/**
 * The icons the React widget draws, as inline SVG.
 *
 * These were the only 15 icons `react-icons` supplied, and that package is an
 * 84 MB install — every icon set it ships — for 9 KB of bundled output. Each
 * entry below is the exact element tree react-icons 5.6.0 generates for that
 * icon, and `IconBase` reproduces its renderer: the same default
 * `stroke`/`fill`/`strokeWidth`, `size` -> `height`/`width`, `color` both as
 * an attribute and in `style`, and the `xmlns`. `__tests__/icons.test.tsx`
 * pins that equivalence against the server-rendered markup of the original
 * components, so a change here that alters a single attribute fails a test.
 *
 * Only the props the widget passes are supported — `size` and `color`, plus
 * ordinary SVG attributes. react-icons' `IconContext` is not: nothing in this
 * package ever provided one.
 */
import React from "react";
export interface IconProps extends React.SVGAttributes<SVGElement> {
    size?: string | number;
    color?: string;
    title?: string;
}
export declare const FaUser: (props: IconProps) => React.ReactElement;
export declare const FiMoreVertical: (props: IconProps) => React.ReactElement;
export declare const FiMic: (props: IconProps) => React.ReactElement;
export declare const FiSend: (props: IconProps) => React.ReactElement;
export declare const FiPhoneOff: (props: IconProps) => React.ReactElement;
export declare const IoClose: (props: IconProps) => React.ReactElement;
export declare const IoVideocam: (props: IconProps) => React.ReactElement;
export declare const IoVideocamOff: (props: IconProps) => React.ReactElement;
export declare const IoVolumeMute: (props: IconProps) => React.ReactElement;
export declare const IoVolumeHigh: (props: IconProps) => React.ReactElement;
export declare const LiaRedoAltSolid: (props: IconProps) => React.ReactElement;
export declare const MdDragIndicator: (props: IconProps) => React.ReactElement;
export declare const MdScreenShare: (props: IconProps) => React.ReactElement;
export declare const MdStopScreenShare: (props: IconProps) => React.ReactElement;
export declare const PiWaveform: (props: IconProps) => React.ReactElement;
