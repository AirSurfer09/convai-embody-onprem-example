export declare const iosTransitions: {
    snappy: {
        type: "spring";
        stiffness: number;
        damping: number;
    };
    fadePop: {
        type: "spring";
        stiffness: number;
        damping: number;
    };
    layoutMorph: {
        type: "spring";
        stiffness: number;
        damping: number;
    };
    modalSlide: {
        type: "spring";
        stiffness: number;
        damping: number;
    };
    scale: {
        type: "spring";
        stiffness: number;
        damping: number;
    };
    slide: {
        type: "spring";
        stiffness: number;
        damping: number;
    };
};
export declare const animationVariants: {
    fadeIn: {
        initial: {
            opacity: number;
        };
        animate: {
            opacity: number;
        };
        exit: {
            opacity: number;
        };
    };
    slideUp: {
        initial: {
            y: number;
            opacity: number;
        };
        animate: {
            y: number;
            opacity: number;
        };
        exit: {
            y: number;
            opacity: number;
        };
    };
    slideDown: {
        initial: {
            y: number;
            opacity: number;
        };
        animate: {
            y: number;
            opacity: number;
        };
        exit: {
            y: number;
            opacity: number;
        };
    };
    scaleIn: {
        initial: {
            scale: number;
            opacity: number;
        };
        animate: {
            scale: number;
            opacity: number;
        };
        exit: {
            scale: number;
            opacity: number;
        };
    };
    slideInFromRight: {
        initial: {
            x: string;
            opacity: number;
        };
        animate: {
            x: number;
            opacity: number;
        };
        exit: {
            x: string;
            opacity: number;
        };
    };
    slideInFromLeft: {
        initial: {
            x: string;
            opacity: number;
        };
        animate: {
            x: number;
            opacity: number;
        };
        exit: {
            x: string;
            opacity: number;
        };
    };
};
