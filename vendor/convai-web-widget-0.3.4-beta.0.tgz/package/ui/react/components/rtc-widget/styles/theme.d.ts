export declare const aeroTheme: {
    colors: {
        primary: {
            50: string;
            100: string;
            200: string;
            300: string;
            400: string;
            500: string;
            600: string;
            700: string;
            800: string;
            900: string;
        };
        convai: {
            light: string;
            medium: string;
            dark: string;
        };
        neutral: {
            50: string;
            100: string;
            200: string;
            300: string;
            400: string;
            500: string;
            600: string;
            700: string;
            800: string;
            900: string;
        };
        glass: {
            light: string;
            medium: string;
            dark: string;
            backdrop: string;
            card: string;
            backdropLight: string;
            borderLight: string;
        };
        accent: {
            purple: string;
            green: string;
            blue: string;
            orange: string;
            red: string;
        };
        error: {
            50: string;
            100: string;
            200: string;
            300: string;
            400: string;
            500: string;
            600: string;
            700: string;
            800: string;
            900: string;
        };
        text: {
            primary: string;
            secondary: string;
            tertiary: string;
            inverse: string;
        };
    };
    typography: {
        fontFamily: {
            primary: string;
            title: string;
            header: string;
            body: string;
            mono: string;
        };
        fontSize: {
            xs: string;
            sm: string;
            base: string;
            lg: string;
            xl: string;
            "2xl": string;
            "3xl": string;
            "4xl": string;
        };
        sizes: {
            xs: string;
            sm: string;
            body: string;
            lg: string;
            xl: string;
            "2xl": string;
            "3xl": string;
            "4xl": string;
            caption: string;
        };
        fontWeight: {
            normal: number;
            medium: number;
            semibold: number;
            bold: number;
        };
        lineHeight: {
            tight: number;
            normal: number;
            relaxed: number;
        };
    };
    spacing: {
        xs: string;
        sm: string;
        md: string;
        lg: string;
        xl: string;
        "2xl": string;
        "3xl": string;
    };
    borderRadius: {
        none: string;
        sm: string;
        md: string;
        lg: string;
        xl: string;
        "2xl": string;
        full: string;
    };
    shadows: {
        sm: string;
        md: string;
        lg: string;
        xl: string;
        glass: string;
    };
    glass: {
        backdrop: string;
        backdropLight: string;
        backdropHeavy: string;
        border: string;
        borderLight: string;
    };
    transitions: {
        fast: string;
        normal: string;
        slow: string;
        spring: string;
        snappy: string;
    };
    zIndex: {
        base: number;
        dropdown: number;
        sticky: number;
        fixed: number;
        modal: number;
        popover: number;
        tooltip: number;
    };
};
export declare const glassStyles: {
    container: string;
    overlay: string;
    card: string;
    input: string;
    button: string;
};
export declare const iconSizes: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    "2xl": string;
};
export declare const variants: {
    button: {
        primary: string;
        secondary: string;
        ghost: string;
    };
    input: {
        default: string;
        search: string;
    };
    card: {
        default: string;
        elevated: string;
        interactive: string;
    };
};
