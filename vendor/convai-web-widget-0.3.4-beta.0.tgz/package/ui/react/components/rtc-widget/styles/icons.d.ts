import { iconSizes } from "./theme";
export type LogoState = "idle" | "connecting" | "connected" | "disconnected" | "typing" | "listening" | "processing";
export declare const AeroIcons: {
    ChevronDown: ({ size, color, }: {
        size?: keyof typeof iconSizes;
        color?: string;
    }) => import("react").JSX.Element;
    ConvaiLogo: ({ size, color, animate, state, }: {
        size?: keyof typeof iconSizes;
        color?: string;
        animate?: boolean;
        state?: LogoState;
    }) => import("react").JSX.Element;
};
export declare const IconButton: import("styled-components/dist/types").IStyledComponentBase<"web", import("styled-components/dist/types").Substitute<import("react").DetailedHTMLProps<import("react").ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, {
    $size?: keyof typeof iconSizes;
    $variant?: "ghost" | "glass";
}>> & string;
export declare const ChevronDown: ({ size, color, }: {
    size?: keyof typeof iconSizes;
    color?: string;
}) => import("react").JSX.Element, ConvaiLogo: ({ size, color, animate, state, }: {
    size?: keyof typeof iconSizes;
    color?: string;
    animate?: boolean;
    state?: LogoState;
}) => import("react").JSX.Element;
