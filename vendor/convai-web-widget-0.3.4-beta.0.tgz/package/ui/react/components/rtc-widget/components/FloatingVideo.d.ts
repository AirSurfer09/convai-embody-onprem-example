import React from "react";
interface FloatingVideoProps {
    isVisible: boolean;
    onClose: () => void;
    mirror?: boolean;
}
export declare const FloatingVideo: React.FC<FloatingVideoProps>;
export {};
