import React from "react";
import { Room } from "livekit-client";
interface VoiceModeOverlayProps {
    isActive: boolean;
    isTalking: boolean;
    /** When true (user is speaking, from server), show "Listening..." label */
    isListening?: boolean;
    convaiClient?: any;
    characterImage?: string;
    characterName?: string;
    room?: Room | null;
}
export declare const VoiceModeOverlay: ({ isActive, isTalking, isListening, convaiClient, characterImage, characterName, room, }: VoiceModeOverlayProps) => React.JSX.Element;
export {};
