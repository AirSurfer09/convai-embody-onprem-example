import React from "react";
import type { LinkPreviewResolver } from "@convai/web-sdk/core";
import { RTCChatMessage } from "../types";
type Message = RTCChatMessage;
interface MessageListProps {
    messages: Message[];
    className?: string;
    isStreaming?: boolean;
    forceToBottomToken?: string | number | boolean;
    /** Open Graph lookup for plain web links in bot bubbles. */
    linkPreviewResolver?: LinkPreviewResolver;
}
export declare const MessageList: ({ messages, className, isStreaming, forceToBottomToken, linkPreviewResolver, }: MessageListProps) => React.JSX.Element;
export {};
