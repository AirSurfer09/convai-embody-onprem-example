import React from "react";
import { AudioSettings } from "@convai/web-sdk/core";
interface AudioSettingsPanelProps {
    currentSettings: AudioSettings;
    onUpdateSettings: (settings: Partial<AudioSettings>) => Promise<void>;
    isConnected: boolean;
}
export declare const AudioSettingsPanel: React.FC<AudioSettingsPanelProps>;
export {};
