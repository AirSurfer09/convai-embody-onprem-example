import React from "react";
interface MessageBubbleProps {
    children: React.ReactNode;
    isUser?: boolean;
    timestamp?: string;
    className?: string;
}
export declare const MessageBubble: ({ children, isUser, timestamp, className, }: MessageBubbleProps) => React.JSX.Element;
export {};
