import React from "react";
interface UserMessageProps {
    message: string;
    timestamp?: string;
    className?: string;
    sender?: string;
}
export declare const UserMessage: ({ message, timestamp, className, sender, }: UserMessageProps) => React.JSX.Element;
export {};
