import React from "react";
interface ConviButtonProps {
    isOpen: boolean;
}
export declare const ConviButton: ({ isOpen }: ConviButtonProps) => React.JSX.Element;
export {};
