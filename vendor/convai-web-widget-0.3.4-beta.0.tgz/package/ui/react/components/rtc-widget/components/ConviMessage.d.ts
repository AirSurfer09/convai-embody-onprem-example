import React from "react";
import type { LinkPreviewResolver } from "@convai/web-sdk/core";
interface ConviMessageProps {
    message: string;
    timestamp?: string;
    className?: string;
    showLogo?: boolean;
    sender?: string;
    /** Open Graph lookup for plain web links; see MarkdownRenderer. */
    resolveLinkPreview?: LinkPreviewResolver;
}
export declare const ConviMessage: ({ message, timestamp, className, showLogo, sender, resolveLinkPreview, }: ConviMessageProps) => React.JSX.Element;
export {};
