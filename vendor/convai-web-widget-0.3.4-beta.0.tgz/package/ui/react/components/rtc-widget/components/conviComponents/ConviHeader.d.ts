import React from "react";
interface ConviHeaderProps {
    isOpen: boolean;
    isSpeakerEditMode: boolean;
    isVoiceMode: boolean;
    isVerbosityMode: boolean;
    isMuted: boolean;
    characterImage?: string;
    characterName?: string;
    onClose: () => void;
    onSettingsToggle: () => void;
    onToggleMute: () => void;
    settingsButtonRef: React.RefObject<HTMLButtonElement>;
}
export declare const ConviHeader: ({ isOpen, isSpeakerEditMode, isVoiceMode, isVerbosityMode, isMuted, characterImage, characterName, onClose, onSettingsToggle, onToggleMute, settingsButtonRef, }: ConviHeaderProps) => React.JSX.Element;
export {};
