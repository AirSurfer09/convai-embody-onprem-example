import React from "react";
interface ConviFooterProps {
    inputMode: "conversation" | "speaker" | "voice" | "verbosity";
    inputValue: string;
    liveUserText: string;
    chatbotMic: boolean;
    localIsTyping: boolean;
    convaiIsTyping: boolean;
    isCreatingSpeaker: boolean;
    isPressingMic: boolean;
    isSettingsOpen: boolean;
    isVoiceMode: boolean;
    onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onKeyPress: (e: React.KeyboardEvent) => void;
    onSend: () => void;
    onMicPress: () => void;
    onMicRelease: () => void;
    setIsPressingMic: (value: boolean) => void;
    onToggleVoiceMode: () => void;
    verbosityChanged?: boolean;
    onContinue?: () => void;
}
export declare const ConviFooter: ({ inputMode, inputValue, liveUserText, chatbotMic, localIsTyping, convaiIsTyping, isCreatingSpeaker, isPressingMic, isSettingsOpen, isVoiceMode, onInputChange, onKeyPress, onSend, onMicPress, onMicRelease, setIsPressingMic, onToggleVoiceMode, verbosityChanged, onContinue, }: ConviFooterProps) => React.JSX.Element;
export {};
