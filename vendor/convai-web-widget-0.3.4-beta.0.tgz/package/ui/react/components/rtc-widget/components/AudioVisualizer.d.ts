import { Room } from 'livekit-client';
interface AudioVisualizerProps {
    /** LiveKit room instance containing the remote participant's audio track */
    room: Room | null;
    /** Canvas size in pixels (width and height) */
    size?: number;
    /** CSS color value for the bars */
    color?: string;
    /** Base opacity of the bars (0-1), actual opacity varies with audio intensity */
    opacity?: number;
    /** Radius of the circular visualization area in pixels */
    avatarRadius?: number;
    /** Number of radial bars to display around the circle */
    barCount?: number;
    /** Callback function called when speaking state changes */
    onSpeakingChange?: (isSpeaking: boolean) => void;
}
/**
 * Circular Audio Visualizer Component
 *
 * A real-time circular audio visualization component that displays radial bars arranged
 * in a circle around an avatar. The visualization reacts to the remote participant's
 * (bot) audio output from a LiveKit room, using logarithmic frequency bands and a
 * traveling wave animation effect.
 *
 * Features:
 * - Circular radial bar visualization with configurable bar count
 * - Logarithmic frequency band distribution (low frequencies distributed around the ring)
 * - Traveling wave animation that propagates around the circle
 * - Speaking detection with callback support
 * - Automatic track detection and reconnection
 * - Canvas-based rendering for smooth animations
 */
export declare const AudioVisualizer: React.FC<AudioVisualizerProps>;
export {};
