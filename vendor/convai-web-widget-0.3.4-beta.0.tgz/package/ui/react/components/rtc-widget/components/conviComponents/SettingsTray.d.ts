import React from "react";
interface SettingsTrayProps {
    isOpen: boolean;
    isVideoVisible?: boolean;
    isScreenShareActive?: boolean;
    onReset?: () => void;
    onDisconnect?: () => void;
    onToggleVideo?: () => void;
    onToggleScreenShare?: () => void;
}
export declare const SettingsTray: ({ isOpen, isVideoVisible, isScreenShareActive, onReset, onDisconnect, onToggleVideo, onToggleScreenShare, }: SettingsTrayProps) => React.JSX.Element | null;
export {};
