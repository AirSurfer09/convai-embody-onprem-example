import React from "react";
import type { LinkPreviewResolver } from "@convai/web-sdk/core";
/**
 * The widget's bubble renderer. Everything visual comes from
 * utils/linkPresentation so this file and the vanilla widget cannot drift;
 * this file only maps tokenizer nodes onto JSX.
 *
 * `data-convai-part` mirrors the vanilla widget's `part` names. React renders
 * in light DOM where `part` means nothing, but the same names let tests and
 * host CSS target both renderers with one vocabulary.
 */
interface MarkdownRendererProps {
    text: string;
    /**
     * Render cards and chips under links. Bot messages want them; the user's
     * own bubble does not — you already know what you typed, and a preview
     * there would let a URL a user pasted embed remote media into the
     * transcript. Links stay clickable either way.
     */
    media?: boolean;
    /** Test seam for mixed-content detection. Defaults to the page's protocol. */
    pageProtocol?: string;
    /**
     * Host-supplied Open Graph lookup. With it, a plain web link in a bot
     * bubble gets a site card once the lookup settles; without it, nothing
     * changes. See docs/convai_link_previews.md, "Site cards".
     */
    resolveLinkPreview?: LinkPreviewResolver;
}
export declare const MarkdownRenderer: React.FC<MarkdownRendererProps>;
export {};
