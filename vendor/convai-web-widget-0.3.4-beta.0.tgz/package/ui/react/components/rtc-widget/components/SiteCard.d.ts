import React from "react";
import { type LinkPreviewResolver } from "@convai/web-sdk/core";
/**
 * Open Graph card under a plain web link. Renders nothing until the host's
 * resolver settles and nothing at all unless the result has a title or an
 * image: most links resolve to nothing card-worthy, and a placeholder that
 * then vanishes reads worse than a card that appears.
 *
 * Everything from the resolver lands in text nodes or an `img` src that
 * `resolveLinkPreviewCached` already restricted to http(s). Never markup.
 */
export declare const SiteCard: ({ href, resolver }: {
    href: string;
    resolver: LinkPreviewResolver;
}) => React.JSX.Element | null;
