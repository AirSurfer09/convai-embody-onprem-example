export interface RTCChatMessage {
    id: string;
    text: string;
    isUser: boolean;
    timestamp: string;
    sender: string;
    showLogo?: boolean;
}
export interface CharacterVerbosityConfig {
    characterId: string;
    label?: string;
}
export interface ConviUIProps {
    isOpen: boolean;
    backgroundOpacity?: number;
    alwaysExpanded?: boolean;
    characterName?: string;
    characterImage?: string;
    verbosityLevels?: Array<{
        index: number;
        characterId: string;
        label?: string;
    }>;
    currentVerbosityIndex?: number;
    onVerbosityChange?: (index: number, characterId: string) => void;
    verbosityChanged?: boolean;
    messages: RTCChatMessage[];
    isStreaming?: boolean;
    inputMode?: "conversation" | "speaker" | "voice" | "verbosity";
    inputValue: string;
    liveUserText?: string;
    localIsTyping: boolean;
    convaiIsTyping: boolean;
    chatbotMic: boolean;
    isPressingMic: boolean;
    isTalking: boolean;
    isMuted: boolean;
    isVoiceMode: boolean;
    isSettingsOpen: boolean;
    isSpeakerEditMode: boolean;
    isVerbosityMode: boolean;
    isCreatingSpeaker?: boolean;
    onToggle: () => void;
    onClose: () => void;
    onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onKeyPress: (e: React.KeyboardEvent) => void;
    onSend: () => void;
    onMicPress: () => void;
    onMicRelease: () => void;
    setIsPressingMic: (value: boolean) => void;
    onToggleMute: () => void;
    onToggleVoiceMode: () => void;
    onSettingsToggle: () => void;
    onReset: () => void;
    onToggleVerbosityMode: () => void;
    onContinue?: () => void;
    settingsButtonRef?: React.RefObject<HTMLButtonElement>;
    convaiClient?: any;
}
