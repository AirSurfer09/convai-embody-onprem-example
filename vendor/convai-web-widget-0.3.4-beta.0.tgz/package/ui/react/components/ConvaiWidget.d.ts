import { type LiveClientFields } from "../hooks/useLiveClient";
import type { LinkPreviewResolver } from "@convai/web-sdk/core";
import type { IConvaiClient, PublishedChatConnectOptions } from "@convai/web-sdk/core";
import type { PublishedChatDescriptor } from "@convai/web-sdk/embed";
interface ConvaiWidgetProps {
    /**
     * The Convai client (required). Either `useConvaiClient`'s result, or any
     * `ConvaiClient` — one built with `new ConvaiClient(...)`, or the character's
     * own client from `@convai/embody`. The widget subscribes to a bare client's
     * events itself and never opens a second connection.
     */
    convaiClient: IConvaiClient & Partial<LiveClientFields>;
    /**
     * Show video toggle button in settings (default: true).
     * Only works if connection type is "video". If false, hides the video button.
     */
    showVideo?: boolean;
    /**
     * Show screen share toggle button in settings (default: true).
     * Only works if connection type is "video". If false, hides the screen share button.
     */
    showScreenShare?: boolean;
    /**
     * Start in voice mode by default when widget opens (default: true).
     * When true, the widget will open directly in voice mode with microphone enabled.
     */
    defaultVoiceMode?: boolean;
    /**
     * Mint a fresh single-use grant when a published-chat session is reopened.
     * Required when using this widget with connectWithPublicationGrant().
     */
    requestPublicationGrant?: () => Promise<string>;
    /** Core endpoint override used with requestPublicationGrant. */
    publishedChatConnectOptions?: PublishedChatConnectOptions;
    /**
     * Open Graph lookup for plain web links the character sends. Supply a
     * function that asks your backend for a page's metadata and each such link
     * gets a site card (favicon, site name, title, description, image) once it
     * resolves. Omit it and links render as before. See
     * docs/convai_link_previews.md, "Site cards".
     */
    linkPreviewResolver?: LinkPreviewResolver;
    /** Public descriptor used to label a credential-free published session. */
    publishedChatDescriptor?: Pick<PublishedChatDescriptor, "display_name" | "image_url">;
}
/**
 * ConvaiWidget - A consolidated chat widget component for real-time conversations
 *
 * This component provides a complete UI for interacting with Convai characters.
 * Connection configuration should be handled via useConvaiClient.connect().
 *
 * Features:
 * - Collapsed circular button with status indicator
 * - Expandable/collapsible chat interface
 * - Voice mode support
 * - Real-time message streaming
 * - Audio controls (mute/unmute)
 * - Settings tray with session reset
 * - Optional video and screen share (when connection type supports it)
 *
 * @param {ConvaiWidgetProps} props - Component props
 * @param {ConvaiClient} props.convaiClient - Convai client instance (required)
 * @param {boolean} props.showVideo - Show video toggle in settings (default: true)
 * @param {boolean} props.showScreenShare - Show screen share toggle in settings (default: true)
 * @param {boolean} props.defaultVoiceMode - Start in voice mode when widget opens (default: true)
 *
 * @example
 * ```tsx
 * function App() {
 *   const convaiClient = useConvaiClient({
 *     apiKey: 'your-api-key',
 *     characterId: 'your-character-id',
 *     enableVideo: true,
 *   });
 *
 *   return (
 *     <ConvaiWidget
 *       convaiClient={convaiClient}
 *       showVideo={true}
 *       showScreenShare={true}
 *     />
 *   );
 * }
 * ```
 */
export declare const ConvaiWidget: React.FC<ConvaiWidgetProps>;
export {};
