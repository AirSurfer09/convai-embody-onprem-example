/**
 * Vanilla JS Icons
 * Reuses the same icons from the React example
 * Uses inline SVG for consistency and no external dependencies
 */
export type IconSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
export type LogoState = 'idle' | 'connecting' | 'connected' | 'disconnected' | 'typing' | 'listening' | 'processing';
/**
 * Icons object with all icon creation functions
 * Matches the icons from react-icons used in the React example
 */
export declare const Icons: {
    ConvaiLogo: (size?: IconSize, state?: LogoState, className?: string) => SVGSVGElement;
    ChevronDown: (size?: IconSize, className?: string) => SVGSVGElement;
    Close: (size?: IconSize, className?: string) => SVGSVGElement;
    Send: (size?: IconSize, className?: string) => SVGSVGElement;
    Mic: (size?: IconSize, className?: string) => SVGSVGElement;
    Waveform: (size?: IconSize, className?: string) => SVGSVGElement;
    PhoneOff: (size?: IconSize, className?: string) => SVGSVGElement;
    Video: (size?: IconSize, className?: string) => SVGSVGElement;
    VideoOff: (size?: IconSize, className?: string) => SVGSVGElement;
    VolumeMute: (size?: IconSize, className?: string) => SVGSVGElement;
    VolumeHigh: (size?: IconSize, className?: string) => SVGSVGElement;
    MoreVertical: (size?: IconSize, className?: string) => SVGSVGElement;
    ScreenShare: (size?: IconSize, className?: string) => SVGSVGElement;
    StopScreenShare: (size?: IconSize, className?: string) => SVGSVGElement;
    Redo: (size?: IconSize, className?: string) => SVGSVGElement;
    DragIndicator: (size?: IconSize, className?: string) => SVGSVGElement;
    User: (size?: IconSize, className?: string) => SVGSVGElement;
};
/**
 * Helper to create icon wrapper div
 */
export declare function createIconWrapper(icon: SVGSVGElement, size?: IconSize, color?: string, className?: string): HTMLDivElement;
