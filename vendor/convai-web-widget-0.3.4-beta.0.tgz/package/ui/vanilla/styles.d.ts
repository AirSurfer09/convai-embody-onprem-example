/**
 * Vanilla Styles - Port of React theme system for vanilla implementations
 */
export declare const aeroTheme: {
    colors: {
        primary: {
            50: string;
            100: string;
            200: string;
            300: string;
            400: string;
            500: string;
            600: string;
            700: string;
            800: string;
            900: string;
        };
        convai: {
            light: string;
            medium: string;
            dark: string;
        };
        neutral: {
            50: string;
            100: string;
            200: string;
            300: string;
            400: string;
            500: string;
            600: string;
            700: string;
            800: string;
            900: string;
        };
        glass: {
            light: string;
            medium: string;
            dark: string;
            backdrop: string;
            card: string;
            backdropLight: string;
            borderLight: string;
        };
        accent: {
            purple: string;
            green: string;
            blue: string;
            orange: string;
            red: string;
        };
        error: {
            50: string;
            100: string;
            200: string;
            300: string;
            400: string;
            500: string;
            600: string;
            700: string;
            800: string;
            900: string;
        };
        text: {
            primary: string;
            secondary: string;
            tertiary: string;
            inverse: string;
        };
    };
    typography: {
        fontFamily: {
            primary: string;
            body: string;
            mono: string;
        };
        fontSize: {
            xs: string;
            sm: string;
            base: string;
            lg: string;
            xl: string;
            "2xl": string;
            "3xl": string;
            "4xl": string;
        };
        fontWeight: {
            normal: number;
            medium: number;
            semibold: number;
            bold: number;
        };
    };
    spacing: {
        xs: string;
        sm: string;
        md: string;
        lg: string;
        xl: string;
        "2xl": string;
        "3xl": string;
    };
    borderRadius: {
        none: string;
        sm: string;
        md: string;
        lg: string;
        xl: string;
        "2xl": string;
        full: string;
    };
    shadows: {
        sm: string;
        md: string;
        lg: string;
        xl: string;
        glass: string;
    };
    glass: {
        backdrop: string;
        backdropLight: string;
        backdropHeavy: string;
        border: string;
        borderLight: string;
    };
    transitions: {
        fast: string;
        normal: string;
        slow: string;
        spring: string;
        snappy: string;
    };
    zIndex: {
        base: number;
        dropdown: number;
        sticky: number;
        fixed: number;
        modal: number;
        popover: number;
        tooltip: number;
    };
};
/**
 * Global CSS styles for the Convai widget
 * This should be injected once into the document head
 */
export declare const getGlobalStyles: () => string;
/**
 * A document (the default) or a shadow root the widget is mounted inside.
 * `@keyframes` and global styles must be injected per-target because
 * shadow trees do not resolve rules defined in the document head.
 */
export type StyleTarget = Document | ShadowRoot;
/**
 * Inject the widget's global styles into a document or a shadow root.
 * Defaults to the document, so existing callers are unaffected.
 */
export declare const injectGlobalStyles: (target?: StyleTarget) => void;
/**
 * Inject the widget's `@keyframes` (e.g. the settings tray's `popIn`)
 * into a document or a shadow root. `@keyframes` defined in the document
 * do not resolve for shadow content, so they must be injected into each
 * shadow root that uses them.
 */
export declare const injectKeyframes: (target?: StyleTarget) => void;
/**
 * Helper to create inline styles object from theme
 */
export declare const createStyles: (styles: Record<string, any>) => string;
