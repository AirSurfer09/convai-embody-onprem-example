type WidgetEventListener = (...args: unknown[]) => void;
type SubscribeToWidgetEvent = (listener: WidgetEventListener) => (() => void) | void;
/**
 * Owns widget event listeners so a destroyed widget cannot mutate detached DOM
 * or notify its host when a client event arrives late.
 */
export declare class WidgetEventSubscriptions {
    private readonly isDestroyed;
    private readonly unsubscribes;
    constructor(isDestroyed: () => boolean);
    register(subscribe: SubscribeToWidgetEvent, listener: WidgetEventListener): void;
    unsubscribeAll(): void;
}
export {};
