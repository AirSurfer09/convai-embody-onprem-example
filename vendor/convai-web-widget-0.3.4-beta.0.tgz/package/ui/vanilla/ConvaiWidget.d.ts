/**
 * Vanilla ConvaiWidget - Complete UI widget for Convai conversations
 * Ports the React ConvaiWidget to vanilla TypeScript with DOM manipulation
 */
import type { VanillaWidgetOptions, VanillaWidget } from "./types";
/**
 * Create a Convai chat widget in the specified container
 *
 * @param container - HTML element to attach the widget to
 * @param options - Widget configuration options
 * @returns VanillaWidget instance with destroy method
 *
 * @example Simple usage with config
 * ```typescript
 * import { createConvaiWidget } from '@convai/web-sdk/vanilla';
 *
 * const widget = createConvaiWidget(document.body, {
 *   apiKey: 'your-api-key',
 *   characterId: 'your-character-id',
 *   enableVideo: false
 * });
 * ```
 *
 * @example Advanced usage with client instance
 * ```typescript
 * import { ConvaiClient, createConvaiWidget } from '@convai/web-sdk/vanilla';
 *
 * const client = new ConvaiClient({
 *   apiKey: 'your-api-key',
 *   characterId: 'your-character-id'
 * });
 *
 * const widget = createConvaiWidget(document.body, {
 *   convaiClient: client,
 *   showVideo: true,
 *   showScreenShare: true,
 *   defaultVoiceMode: true
 * });
 * ```
 */
export declare function createConvaiWidget(container: HTMLElement, options: VanillaWidgetOptions): VanillaWidget;
/**
 * Destroy a Convai widget instance
 * @param widget - Widget instance to destroy
 */
export declare function destroyConvaiWidget(widget: VanillaWidget): void;
