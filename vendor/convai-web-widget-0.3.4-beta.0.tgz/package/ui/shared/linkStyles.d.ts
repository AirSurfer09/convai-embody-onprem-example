/**
 * How a link in the chat panel LOOKS: glyph SVGs, the style objects both
 * renderers apply, the cssText serialiser the vanilla widget uses, and the
 * card budget.
 *
 * This is the rendering half of what used to be one module in
 * @convai/web-sdk. The other half — what a link IS and how it is labelled
 * (`linkKindForUrl`, `describeUrl`, `fileNameOf`, `hoverTitle`, …) — is pure
 * functions with no presentation in them, and stays public in the SDK so a
 * hand-built UI labels links the same way this one does. Import those from
 * `@convai/web-sdk/core`, not from here.
 */
/** How long a card may shimmer before it is treated as failed. */
export declare const PREVIEW_TIMEOUT_MS = 12000;
/** Cards beyond this in one message render as plain anchors. */
export declare const MAX_CARDS_PER_MESSAGE = 6;
export type GlyphName = "document" | "email" | "phone" | "sms" | "ftp" | "zoom" | "close" | "external";
/** Inline SVG for a glyph. Strings, not elements, so both renderers can use them. */
export declare function glyph(name: GlyphName): string;
export type StyleObject = Record<string, string | number>;
/** `{ marginTop: 6 }` → `margin-top: 6px;` — the vanilla widget authors cssText. */
export declare function toCssText(style: StyleObject): string;
/**
 * Every visual the link layer draws, as one style object per element. React
 * spreads these; vanilla serialises them with `toCssText`. Chrome derives from
 * `currentColor` because the widget sits on a host page whose background it
 * cannot know.
 */
export declare const presentationStyles: {
    link: StyleObject;
    /** Applied on focus-visible by the renderer; kept here so both agree. */
    linkFocus: StyleObject;
    blocked: StyleObject;
    card: StyleObject;
    cardButton: StyleObject;
    zoom: StyleObject;
    media: StyleObject;
    videoMedia: StyleObject;
    skeleton: StyleObject;
    caption: StyleObject;
    unavailable: StyleObject;
    fileCard: StyleObject;
    fileIcon: StyleObject;
    fileBody: StyleObject;
    fileName: StyleObject;
    fileMeta: StyleObject;
    contact: StyleObject;
    contactGlyph: StyleObject;
    badge: StyleObject;
    lightboxBackdrop: StyleObject;
    lightbox: StyleObject;
    lightboxImage: StyleObject;
    lightboxCaption: StyleObject;
    lightboxControls: StyleObject;
    lightboxButton: StyleObject;
    lightboxFallback: StyleObject;
    siteCard: StyleObject;
    siteHeader: StyleObject;
    siteFavicon: StyleObject;
    siteName: StyleObject;
    siteTitle: StyleObject;
    siteDescription: StyleObject;
    siteImage: StyleObject;
};
