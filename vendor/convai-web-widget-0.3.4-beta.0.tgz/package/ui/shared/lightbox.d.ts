export interface LightboxOptions {
    src: string;
    alt: string;
    /** Shown under the image; normally `describeUrl(src)`. */
    caption: string;
    /** Target of "Open original". */
    href: string;
    root: Document | ShadowRoot;
    /** Where focus goes back to on close. Defaults to whatever was focused on open. */
    returnFocusTo?: HTMLElement | null;
}
export interface LightboxHandle {
    close(): void;
}
export declare function openLightbox(opts: LightboxOptions): LightboxHandle;
