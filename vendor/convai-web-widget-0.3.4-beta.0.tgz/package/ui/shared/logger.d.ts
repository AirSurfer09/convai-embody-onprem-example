/**
 * Copied verbatim from @convai/web-sdk rather than imported: it is internal
 * there, and keeping it identical means the one `window.__CONVAI_DEBUG__` flag
 * still turns on the SDK's logs and this package's together.
 *
 * Logger utility that only logs in development mode (or when debug is enabled at runtime).
 * Completely silent in production builds unless explicitly enabled.
 *
 * To see logs after a production build, enable at runtime in the browser console:
 *   window.__CONVAI_DEBUG__ = true
 * Then refresh the page. Logs will appear with the [Convai] prefix.
 *
 * To test logger behavior:
 * - Development: Set NODE_ENV=development or run on localhost
 * - Production: Set NODE_ENV=production or deploy to production
 * - Production + debug: Set window.__CONVAI_DEBUG__ = true before/during use
 */
export declare const logger: {
    log: (...args: unknown[]) => void;
    warn: (...args: unknown[]) => void;
    error: (...args: unknown[]) => void;
    info: (...args: unknown[]) => void;
    debug: (...args: unknown[]) => void;
    trace: (...args: unknown[]) => void;
};
export declare const loggerConfig: {
    environment: string;
    isDevelopment: boolean;
    isProduction: boolean;
};
