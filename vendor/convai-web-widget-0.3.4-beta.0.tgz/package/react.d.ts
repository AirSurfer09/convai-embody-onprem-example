/**
 * `@convai/web-widget/react` — the chat UI as React components.
 *
 * This moved here from `@convai/web-sdk/react`. The SDK now creates clients and
 * exports the functions other packages need; it ships no UI. So a React app
 * takes the client from the SDK and the interface from here:
 *
 * ```tsx
 * import { useConvaiClient } from '@convai/web-sdk/react'
 * import { ConvaiWidget } from '@convai/web-widget/react'
 *
 * const client = useConvaiClient({ apiKey, characterId })
 * return <ConvaiWidget convaiClient={client} />
 * ```
 *
 * React, `@convai/web-sdk` and `livekit-client` are peers: one copy each, the
 * app's own. Importing this entry has no side effects.
 */
export { ConvaiWidget } from './ui/react/components/ConvaiWidget';
export { MarkdownRenderer } from './ui/react/components/rtc-widget/components/MarkdownRenderer';
export { useCharacterInfo } from './ui/react/hooks/useCharacterInfo';
export { useLocalCameraTrack } from './ui/react/hooks/useLocalCameraTrack';
export { RoomAudioRenderer as AudioRenderer, RoomContext as AudioContext, } from '@livekit/components-react';
