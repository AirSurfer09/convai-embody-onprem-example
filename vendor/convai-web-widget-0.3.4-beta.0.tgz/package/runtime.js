var va = (n) => {
  throw TypeError(n);
};
var ba = (n, e, t) => e.has(n) || va("Cannot " + t);
var ms = (n, e, t) => (ba(n, e, "read from private field"), t ? t.call(n) : e.get(n)), ya = (n, e, t) => e.has(n) ? va("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(n) : e.set(n, t), fs = (n, e, t, i) => (ba(n, e, "write to private field"), i ? i.call(n, t) : e.set(n, t), t);
function Ol(n, e) {
  return e.forEach(function(t) {
    t && typeof t != "string" && !Array.isArray(t) && Object.keys(t).forEach(function(i) {
      if (i !== "default" && !(i in n)) {
        var s = Object.getOwnPropertyDescriptor(t, i);
        Object.defineProperty(n, i, s.get ? s : { enumerable: !0, get: function() {
          return t[i];
        } });
      }
    });
  }), Object.freeze(n);
}
var Dl = Object.defineProperty, Ll = (n, e, t) => e in n ? Dl(n, e, {
  enumerable: !0,
  configurable: !0,
  writable: !0,
  value: t
}) : n[e] = t, Sa = (n, e, t) => Ll(n, typeof e != "symbol" ? e + "" : e, t);
class Ze {
  constructor() {
    Sa(this, "_locking"), Sa(this, "_locks"), this._locking = Promise.resolve(), this._locks = 0;
  }
  isLocked() {
    return this._locks > 0;
  }
  lock() {
    this._locks += 1;
    let e;
    const t = new Promise((s) => e = () => {
      this._locks -= 1, s();
    }), i = this._locking.then(() => e);
    return this._locking = this._locking.then(() => t), i;
  }
}
function Ae(n, e) {
  if (!n)
    throw new Error(e);
}
const Nl = 34028234663852886e22, Ul = -34028234663852886e22, Fl = 4294967295, Vl = 2147483647, Bl = -2147483648;
function _n(n) {
  if (typeof n != "number") throw new Error("invalid int 32: " + typeof n);
  if (!Number.isInteger(n) || n > Vl || n < Bl) throw new Error("invalid int 32: " + n);
}
function Ks(n) {
  if (typeof n != "number") throw new Error("invalid uint 32: " + typeof n);
  if (!Number.isInteger(n) || n > Fl || n < 0) throw new Error("invalid uint 32: " + n);
}
function ec(n) {
  if (typeof n != "number") throw new Error("invalid float 32: " + typeof n);
  if (Number.isFinite(n) && (n > Nl || n < Ul))
    throw new Error("invalid float 32: " + n);
}
const tc = Symbol("@bufbuild/protobuf/enum-type");
function jl(n) {
  const e = n[tc];
  return Ae(e, "missing enum type on enum object"), e;
}
function ic(n, e, t, i) {
  n[tc] = nc(e, t.map((s) => ({
    no: s.no,
    name: s.name,
    localName: n[s.no]
  })));
}
function nc(n, e, t) {
  const i = /* @__PURE__ */ Object.create(null), s = /* @__PURE__ */ Object.create(null), r = [];
  for (const o of e) {
    const a = sc(o);
    r.push(a), i[o.name] = a, s[o.no] = a;
  }
  return {
    typeName: n,
    values: r,
    // We do not surface options at this time
    // options: opt?.options ?? Object.create(null),
    findName(o) {
      return i[o];
    },
    findNumber(o) {
      return s[o];
    }
  };
}
function ql(n, e, t) {
  const i = {};
  for (const s of e) {
    const r = sc(s);
    i[r.localName] = r.no, i[r.no] = r.localName;
  }
  return ic(i, n, e), i;
}
function sc(n) {
  return "localName" in n ? n : Object.assign(Object.assign({}, n), {
    localName: n.name
  });
}
class Rr {
  /**
   * Compare with a message of the same type.
   * Note that this function disregards extensions and unknown fields.
   */
  equals(e) {
    return this.getType().runtime.util.equals(this.getType(), this, e);
  }
  /**
   * Create a deep copy.
   */
  clone() {
    return this.getType().runtime.util.clone(this);
  }
  /**
   * Parse from binary data, merging fields.
   *
   * Repeated fields are appended. Map entries are added, overwriting
   * existing keys.
   *
   * If a message field is already present, it will be merged with the
   * new data.
   */
  fromBinary(e, t) {
    const i = this.getType(), s = i.runtime.bin, r = s.makeReadOptions(t);
    return s.readMessage(this, r.readerFactory(e), e.byteLength, r), this;
  }
  /**
   * Parse a message from a JSON value.
   */
  fromJson(e, t) {
    const i = this.getType(), s = i.runtime.json, r = s.makeReadOptions(t);
    return s.readMessage(i, e, r, this), this;
  }
  /**
   * Parse a message from a JSON string.
   */
  fromJsonString(e, t) {
    let i;
    try {
      i = JSON.parse(e);
    } catch (s) {
      throw new Error("cannot decode ".concat(this.getType().typeName, " from JSON: ").concat(s instanceof Error ? s.message : String(s)));
    }
    return this.fromJson(i, t);
  }
  /**
   * Serialize the message to binary data.
   */
  toBinary(e) {
    const t = this.getType(), i = t.runtime.bin, s = i.makeWriteOptions(e), r = s.writerFactory();
    return i.writeMessage(this, r, s), r.finish();
  }
  /**
   * Serialize the message to a JSON value, a JavaScript value that can be
   * passed to JSON.stringify().
   */
  toJson(e) {
    const t = this.getType(), i = t.runtime.json, s = i.makeWriteOptions(e);
    return i.writeMessage(this, s);
  }
  /**
   * Serialize the message to a JSON string.
   */
  toJsonString(e) {
    var t;
    const i = this.toJson(e);
    return JSON.stringify(i, null, (t = e == null ? void 0 : e.prettySpaces) !== null && t !== void 0 ? t : 0);
  }
  /**
   * Override for serialization behavior. This will be invoked when calling
   * JSON.stringify on this message (i.e. JSON.stringify(msg)).
   *
   * Note that this will not serialize google.protobuf.Any with a packed
   * message because the protobuf JSON format specifies that it needs to be
   * unpacked, and this is only possible with a type registry to look up the
   * message type.  As a result, attempting to serialize a message with this
   * type will throw an Error.
   *
   * This method is protected because you should not need to invoke it
   * directly -- instead use JSON.stringify or toJsonString for
   * stringified JSON.  Alternatively, if actual JSON is desired, you should
   * use toJson.
   */
  toJSON() {
    return this.toJson({
      emitDefaultValues: !0
    });
  }
  /**
   * Retrieve the MessageType of this message - a singleton that represents
   * the protobuf message declaration and provides metadata for reflection-
   * based operations.
   */
  getType() {
    return Object.getPrototypeOf(this).constructor;
  }
}
function Hl(n, e, t, i) {
  var s;
  const r = (s = i == null ? void 0 : i.localName) !== null && s !== void 0 ? s : e.substring(e.lastIndexOf(".") + 1), o = {
    [r]: function(a) {
      n.util.initFields(this), n.util.initPartial(a, this);
    }
  }[r];
  return Object.setPrototypeOf(o.prototype, new Rr()), Object.assign(o, {
    runtime: n,
    typeName: e,
    fields: n.util.newFieldList(t),
    fromBinary(a, c) {
      return new o().fromBinary(a, c);
    },
    fromJson(a, c) {
      return new o().fromJson(a, c);
    },
    fromJsonString(a, c) {
      return new o().fromJsonString(a, c);
    },
    equals(a, c) {
      return n.util.equals(o, a, c);
    }
  }), o;
}
function Wl() {
  let n = 0, e = 0;
  for (let i = 0; i < 28; i += 7) {
    let s = this.buf[this.pos++];
    if (n |= (s & 127) << i, (s & 128) == 0)
      return this.assertBounds(), [n, e];
  }
  let t = this.buf[this.pos++];
  if (n |= (t & 15) << 28, e = (t & 112) >> 4, (t & 128) == 0)
    return this.assertBounds(), [n, e];
  for (let i = 3; i <= 31; i += 7) {
    let s = this.buf[this.pos++];
    if (e |= (s & 127) << i, (s & 128) == 0)
      return this.assertBounds(), [n, e];
  }
  throw new Error("invalid varint");
}
function gs(n, e, t) {
  for (let r = 0; r < 28; r = r + 7) {
    const o = n >>> r, a = !(!(o >>> 7) && e == 0), c = (a ? o | 128 : o) & 255;
    if (t.push(c), !a)
      return;
  }
  const i = n >>> 28 & 15 | (e & 7) << 4, s = e >> 3 != 0;
  if (t.push((s ? i | 128 : i) & 255), !!s) {
    for (let r = 3; r < 31; r = r + 7) {
      const o = e >>> r, a = !!(o >>> 7), c = (a ? o | 128 : o) & 255;
      if (t.push(c), !a)
        return;
    }
    t.push(e >>> 31 & 1);
  }
}
const wn = 4294967296;
function ka(n) {
  const e = n[0] === "-";
  e && (n = n.slice(1));
  const t = 1e6;
  let i = 0, s = 0;
  function r(o, a) {
    const c = Number(n.slice(o, a));
    s *= t, i = i * t + c, i >= wn && (s = s + (i / wn | 0), i = i % wn);
  }
  return r(-24, -18), r(-18, -12), r(-12, -6), r(-6), e ? ac(i, s) : Ir(i, s);
}
function $l(n, e) {
  let t = Ir(n, e);
  const i = t.hi & 2147483648;
  i && (t = ac(t.lo, t.hi));
  const s = rc(t.lo, t.hi);
  return i ? "-" + s : s;
}
function rc(n, e) {
  if ({
    lo: n,
    hi: e
  } = zl(n, e), e <= 2097151)
    return String(wn * e + n);
  const t = n & 16777215, i = (n >>> 24 | e << 8) & 16777215, s = e >> 16 & 65535;
  let r = t + i * 6777216 + s * 6710656, o = i + s * 8147497, a = s * 2;
  const c = 1e7;
  return r >= c && (o += Math.floor(r / c), r %= c), o >= c && (a += Math.floor(o / c), o %= c), a.toString() + Ta(o) + Ta(r);
}
function zl(n, e) {
  return {
    lo: n >>> 0,
    hi: e >>> 0
  };
}
function Ir(n, e) {
  return {
    lo: n | 0,
    hi: e | 0
  };
}
function ac(n, e) {
  return e = ~e, n ? n = ~n + 1 : e += 1, Ir(n, e);
}
const Ta = (n) => {
  const e = String(n);
  return "0000000".slice(e.length) + e;
};
function Ca(n, e) {
  if (n >= 0) {
    for (; n > 127; )
      e.push(n & 127 | 128), n = n >>> 7;
    e.push(n);
  } else {
    for (let t = 0; t < 9; t++)
      e.push(n & 127 | 128), n = n >> 7;
    e.push(1);
  }
}
function Kl() {
  let n = this.buf[this.pos++], e = n & 127;
  if ((n & 128) == 0)
    return this.assertBounds(), e;
  if (n = this.buf[this.pos++], e |= (n & 127) << 7, (n & 128) == 0)
    return this.assertBounds(), e;
  if (n = this.buf[this.pos++], e |= (n & 127) << 14, (n & 128) == 0)
    return this.assertBounds(), e;
  if (n = this.buf[this.pos++], e |= (n & 127) << 21, (n & 128) == 0)
    return this.assertBounds(), e;
  n = this.buf[this.pos++], e |= (n & 15) << 28;
  for (let t = 5; (n & 128) !== 0 && t < 10; t++) n = this.buf[this.pos++];
  if ((n & 128) != 0) throw new Error("invalid varint");
  return this.assertBounds(), e >>> 0;
}
function Gl() {
  const n = new DataView(new ArrayBuffer(8));
  if (typeof BigInt == "function" && typeof n.getBigInt64 == "function" && typeof n.getBigUint64 == "function" && typeof n.setBigInt64 == "function" && typeof n.setBigUint64 == "function" && (typeof process != "object" || typeof process.env != "object" || process.env.BUF_BIGINT_DISABLE !== "1")) {
    const s = BigInt("-9223372036854775808"), r = BigInt("9223372036854775807"), o = BigInt("0"), a = BigInt("18446744073709551615");
    return {
      zero: BigInt(0),
      supported: !0,
      parse(c) {
        const d = typeof c == "bigint" ? c : BigInt(c);
        if (d > r || d < s)
          throw new Error("int64 invalid: ".concat(c));
        return d;
      },
      uParse(c) {
        const d = typeof c == "bigint" ? c : BigInt(c);
        if (d > a || d < o)
          throw new Error("uint64 invalid: ".concat(c));
        return d;
      },
      enc(c) {
        return n.setBigInt64(0, this.parse(c), !0), {
          lo: n.getInt32(0, !0),
          hi: n.getInt32(4, !0)
        };
      },
      uEnc(c) {
        return n.setBigInt64(0, this.uParse(c), !0), {
          lo: n.getInt32(0, !0),
          hi: n.getInt32(4, !0)
        };
      },
      dec(c, d) {
        return n.setInt32(0, c, !0), n.setInt32(4, d, !0), n.getBigInt64(0, !0);
      },
      uDec(c, d) {
        return n.setInt32(0, c, !0), n.setInt32(4, d, !0), n.getBigUint64(0, !0);
      }
    };
  }
  const t = (s) => Ae(/^-?[0-9]+$/.test(s), "int64 invalid: ".concat(s)), i = (s) => Ae(/^[0-9]+$/.test(s), "uint64 invalid: ".concat(s));
  return {
    zero: "0",
    supported: !1,
    parse(s) {
      return typeof s != "string" && (s = s.toString()), t(s), s;
    },
    uParse(s) {
      return typeof s != "string" && (s = s.toString()), i(s), s;
    },
    enc(s) {
      return typeof s != "string" && (s = s.toString()), t(s), ka(s);
    },
    uEnc(s) {
      return typeof s != "string" && (s = s.toString()), i(s), ka(s);
    },
    dec(s, r) {
      return $l(s, r);
    },
    uDec(s, r) {
      return rc(s, r);
    }
  };
}
const Pe = Gl();
var I;
(function(n) {
  n[n.DOUBLE = 1] = "DOUBLE", n[n.FLOAT = 2] = "FLOAT", n[n.INT64 = 3] = "INT64", n[n.UINT64 = 4] = "UINT64", n[n.INT32 = 5] = "INT32", n[n.FIXED64 = 6] = "FIXED64", n[n.FIXED32 = 7] = "FIXED32", n[n.BOOL = 8] = "BOOL", n[n.STRING = 9] = "STRING", n[n.BYTES = 12] = "BYTES", n[n.UINT32 = 13] = "UINT32", n[n.SFIXED32 = 15] = "SFIXED32", n[n.SFIXED64 = 16] = "SFIXED64", n[n.SINT32 = 17] = "SINT32", n[n.SINT64 = 18] = "SINT64";
})(I || (I = {}));
var Yt;
(function(n) {
  n[n.BIGINT = 0] = "BIGINT", n[n.STRING = 1] = "STRING";
})(Yt || (Yt = {}));
function Bt(n, e, t) {
  if (e === t)
    return !0;
  if (n == I.BYTES) {
    if (!(e instanceof Uint8Array) || !(t instanceof Uint8Array) || e.length !== t.length)
      return !1;
    for (let i = 0; i < e.length; i++)
      if (e[i] !== t[i])
        return !1;
    return !0;
  }
  switch (n) {
    case I.UINT64:
    case I.FIXED64:
    case I.INT64:
    case I.SFIXED64:
    case I.SINT64:
      return e == t;
  }
  return !1;
}
function Fi(n, e) {
  switch (n) {
    case I.BOOL:
      return !1;
    case I.UINT64:
    case I.FIXED64:
    case I.INT64:
    case I.SFIXED64:
    case I.SINT64:
      return e == 0 ? Pe.zero : "0";
    case I.DOUBLE:
    case I.FLOAT:
      return 0;
    case I.BYTES:
      return new Uint8Array(0);
    case I.STRING:
      return "";
    default:
      return 0;
  }
}
function oc(n, e) {
  switch (n) {
    case I.BOOL:
      return e === !1;
    case I.STRING:
      return e === "";
    case I.BYTES:
      return e instanceof Uint8Array && !e.byteLength;
    default:
      return e == 0;
  }
}
var Le;
(function(n) {
  n[n.Varint = 0] = "Varint", n[n.Bit64 = 1] = "Bit64", n[n.LengthDelimited = 2] = "LengthDelimited", n[n.StartGroup = 3] = "StartGroup", n[n.EndGroup = 4] = "EndGroup", n[n.Bit32 = 5] = "Bit32";
})(Le || (Le = {}));
class Jl {
  constructor(e) {
    this.stack = [], this.textEncoder = e != null ? e : new TextEncoder(), this.chunks = [], this.buf = [];
  }
  /**
   * Return all bytes written and reset this writer.
   */
  finish() {
    this.chunks.push(new Uint8Array(this.buf));
    let e = 0;
    for (let s = 0; s < this.chunks.length; s++) e += this.chunks[s].length;
    let t = new Uint8Array(e), i = 0;
    for (let s = 0; s < this.chunks.length; s++)
      t.set(this.chunks[s], i), i += this.chunks[s].length;
    return this.chunks = [], t;
  }
  /**
   * Start a new fork for length-delimited data like a message
   * or a packed repeated field.
   *
   * Must be joined later with `join()`.
   */
  fork() {
    return this.stack.push({
      chunks: this.chunks,
      buf: this.buf
    }), this.chunks = [], this.buf = [], this;
  }
  /**
   * Join the last fork. Write its length and bytes, then
   * return to the previous state.
   */
  join() {
    let e = this.finish(), t = this.stack.pop();
    if (!t) throw new Error("invalid state, fork stack empty");
    return this.chunks = t.chunks, this.buf = t.buf, this.uint32(e.byteLength), this.raw(e);
  }
  /**
   * Writes a tag (field number and wire type).
   *
   * Equivalent to `uint32( (fieldNo << 3 | type) >>> 0 )`.
   *
   * Generated code should compute the tag ahead of time and call `uint32()`.
   */
  tag(e, t) {
    return this.uint32((e << 3 | t) >>> 0);
  }
  /**
   * Write a chunk of raw bytes.
   */
  raw(e) {
    return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(e), this;
  }
  /**
   * Write a `uint32` value, an unsigned 32 bit varint.
   */
  uint32(e) {
    for (Ks(e); e > 127; )
      this.buf.push(e & 127 | 128), e = e >>> 7;
    return this.buf.push(e), this;
  }
  /**
   * Write a `int32` value, a signed 32 bit varint.
   */
  int32(e) {
    return _n(e), Ca(e, this.buf), this;
  }
  /**
   * Write a `bool` value, a variant.
   */
  bool(e) {
    return this.buf.push(e ? 1 : 0), this;
  }
  /**
   * Write a `bytes` value, length-delimited arbitrary data.
   */
  bytes(e) {
    return this.uint32(e.byteLength), this.raw(e);
  }
  /**
   * Write a `string` value, length-delimited data converted to UTF-8 text.
   */
  string(e) {
    let t = this.textEncoder.encode(e);
    return this.uint32(t.byteLength), this.raw(t);
  }
  /**
   * Write a `float` value, 32-bit floating point number.
   */
  float(e) {
    ec(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setFloat32(0, e, !0), this.raw(t);
  }
  /**
   * Write a `double` value, a 64-bit floating point number.
   */
  double(e) {
    let t = new Uint8Array(8);
    return new DataView(t.buffer).setFloat64(0, e, !0), this.raw(t);
  }
  /**
   * Write a `fixed32` value, an unsigned, fixed-length 32-bit integer.
   */
  fixed32(e) {
    Ks(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setUint32(0, e, !0), this.raw(t);
  }
  /**
   * Write a `sfixed32` value, a signed, fixed-length 32-bit integer.
   */
  sfixed32(e) {
    _n(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setInt32(0, e, !0), this.raw(t);
  }
  /**
   * Write a `sint32` value, a signed, zigzag-encoded 32-bit varint.
   */
  sint32(e) {
    return _n(e), e = (e << 1 ^ e >> 31) >>> 0, Ca(e, this.buf), this;
  }
  /**
   * Write a `fixed64` value, a signed, fixed-length 64-bit integer.
   */
  sfixed64(e) {
    let t = new Uint8Array(8), i = new DataView(t.buffer), s = Pe.enc(e);
    return i.setInt32(0, s.lo, !0), i.setInt32(4, s.hi, !0), this.raw(t);
  }
  /**
   * Write a `fixed64` value, an unsigned, fixed-length 64 bit integer.
   */
  fixed64(e) {
    let t = new Uint8Array(8), i = new DataView(t.buffer), s = Pe.uEnc(e);
    return i.setInt32(0, s.lo, !0), i.setInt32(4, s.hi, !0), this.raw(t);
  }
  /**
   * Write a `int64` value, a signed 64-bit varint.
   */
  int64(e) {
    let t = Pe.enc(e);
    return gs(t.lo, t.hi, this.buf), this;
  }
  /**
   * Write a `sint64` value, a signed, zig-zag-encoded 64-bit varint.
   */
  sint64(e) {
    let t = Pe.enc(e), i = t.hi >> 31, s = t.lo << 1 ^ i, r = (t.hi << 1 | t.lo >>> 31) ^ i;
    return gs(s, r, this.buf), this;
  }
  /**
   * Write a `uint64` value, an unsigned 64-bit varint.
   */
  uint64(e) {
    let t = Pe.uEnc(e);
    return gs(t.lo, t.hi, this.buf), this;
  }
}
class Yl {
  constructor(e, t) {
    this.varint64 = Wl, this.uint32 = Kl, this.buf = e, this.len = e.length, this.pos = 0, this.view = new DataView(e.buffer, e.byteOffset, e.byteLength), this.textDecoder = t != null ? t : new TextDecoder();
  }
  /**
   * Reads a tag - field number and wire type.
   */
  tag() {
    let e = this.uint32(), t = e >>> 3, i = e & 7;
    if (t <= 0 || i < 0 || i > 5) throw new Error("illegal tag: field no " + t + " wire type " + i);
    return [t, i];
  }
  /**
   * Skip one element and return the skipped data.
   *
   * When skipping StartGroup, provide the tags field number to check for
   * matching field number in the EndGroup tag.
   */
  skip(e, t) {
    let i = this.pos;
    switch (e) {
      case Le.Varint:
        for (; this.buf[this.pos++] & 128; )
          ;
        break;
      // eslint-disable-next-line
      // @ts-ignore TS7029: Fallthrough case in switch
      case Le.Bit64:
        this.pos += 4;
      // eslint-disable-next-line
      // @ts-ignore TS7029: Fallthrough case in switch
      case Le.Bit32:
        this.pos += 4;
        break;
      case Le.LengthDelimited:
        let s = this.uint32();
        this.pos += s;
        break;
      case Le.StartGroup:
        for (; ; ) {
          const [r, o] = this.tag();
          if (o === Le.EndGroup) {
            if (t !== void 0 && r !== t)
              throw new Error("invalid end group tag");
            break;
          }
          this.skip(o, r);
        }
        break;
      default:
        throw new Error("cant skip wire type " + e);
    }
    return this.assertBounds(), this.buf.subarray(i, this.pos);
  }
  /**
   * Throws error if position in byte array is out of range.
   */
  assertBounds() {
    if (this.pos > this.len) throw new RangeError("premature EOF");
  }
  /**
   * Read a `int32` field, a signed 32 bit varint.
   */
  int32() {
    return this.uint32() | 0;
  }
  /**
   * Read a `sint32` field, a signed, zigzag-encoded 32-bit varint.
   */
  sint32() {
    let e = this.uint32();
    return e >>> 1 ^ -(e & 1);
  }
  /**
   * Read a `int64` field, a signed 64-bit varint.
   */
  int64() {
    return Pe.dec(...this.varint64());
  }
  /**
   * Read a `uint64` field, an unsigned 64-bit varint.
   */
  uint64() {
    return Pe.uDec(...this.varint64());
  }
  /**
   * Read a `sint64` field, a signed, zig-zag-encoded 64-bit varint.
   */
  sint64() {
    let [e, t] = this.varint64(), i = -(e & 1);
    return e = (e >>> 1 | (t & 1) << 31) ^ i, t = t >>> 1 ^ i, Pe.dec(e, t);
  }
  /**
   * Read a `bool` field, a variant.
   */
  bool() {
    let [e, t] = this.varint64();
    return e !== 0 || t !== 0;
  }
  /**
   * Read a `fixed32` field, an unsigned, fixed-length 32-bit integer.
   */
  fixed32() {
    return this.view.getUint32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `sfixed32` field, a signed, fixed-length 32-bit integer.
   */
  sfixed32() {
    return this.view.getInt32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `fixed64` field, an unsigned, fixed-length 64 bit integer.
   */
  fixed64() {
    return Pe.uDec(this.sfixed32(), this.sfixed32());
  }
  /**
   * Read a `fixed64` field, a signed, fixed-length 64-bit integer.
   */
  sfixed64() {
    return Pe.dec(this.sfixed32(), this.sfixed32());
  }
  /**
   * Read a `float` field, 32-bit floating point number.
   */
  float() {
    return this.view.getFloat32((this.pos += 4) - 4, !0);
  }
  /**
   * Read a `double` field, a 64-bit floating point number.
   */
  double() {
    return this.view.getFloat64((this.pos += 8) - 8, !0);
  }
  /**
   * Read a `bytes` field, length-delimited arbitrary data.
   */
  bytes() {
    let e = this.uint32(), t = this.pos;
    return this.pos += e, this.assertBounds(), this.buf.subarray(t, t + e);
  }
  /**
   * Read a `string` field, length-delimited data converted to UTF-8 text.
   */
  string() {
    return this.textDecoder.decode(this.bytes());
  }
}
function Ql(n, e, t, i) {
  let s;
  return {
    typeName: e,
    extendee: t,
    get field() {
      if (!s) {
        const r = typeof i == "function" ? i() : i;
        r.name = e.split(".").pop(), r.jsonName = "[".concat(e, "]"), s = n.util.newFieldList([r]).list()[0];
      }
      return s;
    },
    runtime: n
  };
}
function cc(n) {
  const e = n.field.localName, t = /* @__PURE__ */ Object.create(null);
  return t[e] = Xl(n), [t, () => t[e]];
}
function Xl(n) {
  const e = n.field;
  if (e.repeated)
    return [];
  if (e.default !== void 0)
    return e.default;
  switch (e.kind) {
    case "enum":
      return e.T.values[0].no;
    case "scalar":
      return Fi(e.T, e.L);
    case "message":
      const t = e.T, i = new t();
      return t.fieldWrapper ? t.fieldWrapper.unwrapField(i) : i;
    case "map":
      throw "map fields are not allowed to be extensions";
  }
}
function Zl(n, e) {
  if (!e.repeated && (e.kind == "enum" || e.kind == "scalar")) {
    for (let t = n.length - 1; t >= 0; --t)
      if (n[t].no == e.no)
        return [n[t]];
    return [];
  }
  return n.filter((t) => t.no === e.no);
}
let Dt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""), is = [];
for (let n = 0; n < Dt.length; n++) is[Dt[n].charCodeAt(0)] = n;
is[45] = Dt.indexOf("+");
is[95] = Dt.indexOf("/");
const dc = {
  /**
   * Decodes a base64 string to a byte array.
   *
   * - ignores white-space, including line breaks and tabs
   * - allows inner padding (can decode concatenated base64 strings)
   * - does not require padding
   * - understands base64url encoding:
   *   "-" instead of "+",
   *   "_" instead of "/",
   *   no padding
   */
  dec(n) {
    let e = n.length * 3 / 4;
    n[n.length - 2] == "=" ? e -= 2 : n[n.length - 1] == "=" && (e -= 1);
    let t = new Uint8Array(e), i = 0, s = 0, r, o = 0;
    for (let a = 0; a < n.length; a++) {
      if (r = is[n.charCodeAt(a)], r === void 0)
        switch (n[a]) {
          // @ts-ignore TS7029: Fallthrough case in switch
          case "=":
            s = 0;
          // reset state when padding found
          // @ts-ignore TS7029: Fallthrough case in switch
          case `
`:
          case "\r":
          case "	":
          case " ":
            continue;
          // skip white-space, and padding
          default:
            throw Error("invalid base64 string.");
        }
      switch (s) {
        case 0:
          o = r, s = 1;
          break;
        case 1:
          t[i++] = o << 2 | (r & 48) >> 4, o = r, s = 2;
          break;
        case 2:
          t[i++] = (o & 15) << 4 | (r & 60) >> 2, o = r, s = 3;
          break;
        case 3:
          t[i++] = (o & 3) << 6 | r, s = 0;
          break;
      }
    }
    if (s == 1) throw Error("invalid base64 string.");
    return t.subarray(0, i);
  },
  /**
   * Encode a byte array to a base64 string.
   */
  enc(n) {
    let e = "", t = 0, i, s = 0;
    for (let r = 0; r < n.length; r++)
      switch (i = n[r], t) {
        case 0:
          e += Dt[i >> 2], s = (i & 3) << 4, t = 1;
          break;
        case 1:
          e += Dt[s | i >> 4], s = (i & 15) << 2, t = 2;
          break;
        case 2:
          e += Dt[s | i >> 6], e += Dt[i & 63], t = 0;
          break;
      }
    return t && (e += Dt[s], e += "=", t == 1 && (e += "=")), e;
  }
};
function eu(n, e, t) {
  uc(e, n);
  const i = e.runtime.bin.makeReadOptions(t), s = Zl(n.getType().runtime.bin.listUnknownFields(n), e.field), [r, o] = cc(e);
  for (const a of s)
    e.runtime.bin.readField(r, i.readerFactory(a.data), e.field, a.wireType, i);
  return o();
}
function tu(n, e, t, i) {
  uc(e, n);
  const s = e.runtime.bin.makeReadOptions(i), r = e.runtime.bin.makeWriteOptions(i);
  if (lc(n, e)) {
    const d = n.getType().runtime.bin.listUnknownFields(n).filter((l) => l.no != e.field.no);
    n.getType().runtime.bin.discardUnknownFields(n);
    for (const l of d)
      n.getType().runtime.bin.onUnknownField(n, l.no, l.wireType, l.data);
  }
  const o = r.writerFactory();
  let a = e.field;
  !a.opt && !a.repeated && (a.kind == "enum" || a.kind == "scalar") && (a = Object.assign(Object.assign({}, e.field), {
    opt: !0
  })), e.runtime.bin.writeField(a, t, o, r);
  const c = s.readerFactory(o.finish());
  for (; c.pos < c.len; ) {
    const [d, l] = c.tag(), u = c.skip(l, d);
    n.getType().runtime.bin.onUnknownField(n, d, l, u);
  }
}
function lc(n, e) {
  const t = n.getType();
  return e.extendee.typeName === t.typeName && !!t.runtime.bin.listUnknownFields(n).find((i) => i.no == e.field.no);
}
function uc(n, e) {
  Ae(n.extendee.typeName == e.getType().typeName, "extension ".concat(n.typeName, " can only be applied to message ").concat(n.extendee.typeName));
}
function hc(n, e) {
  const t = n.localName;
  if (n.repeated)
    return e[t].length > 0;
  if (n.oneof)
    return e[n.oneof.localName].case === t;
  switch (n.kind) {
    case "enum":
    case "scalar":
      return n.opt || n.req ? e[t] !== void 0 : n.kind == "enum" ? e[t] !== n.T.values[0].no : !oc(n.T, e[t]);
    case "message":
      return e[t] !== void 0;
    case "map":
      return Object.keys(e[t]).length > 0;
  }
}
function _a(n, e) {
  const t = n.localName, i = !n.opt && !n.req;
  if (n.repeated)
    e[t] = [];
  else if (n.oneof)
    e[n.oneof.localName] = {
      case: void 0
    };
  else
    switch (n.kind) {
      case "map":
        e[t] = {};
        break;
      case "enum":
        e[t] = i ? n.T.values[0].no : void 0;
        break;
      case "scalar":
        e[t] = i ? Fi(n.T, n.L) : void 0;
        break;
      case "message":
        e[t] = void 0;
        break;
    }
}
function Lt(n, e) {
  if (n === null || typeof n != "object" || !Object.getOwnPropertyNames(Rr.prototype).every((i) => i in n && typeof n[i] == "function"))
    return !1;
  const t = n.getType();
  return t === null || typeof t != "function" || !("typeName" in t) || typeof t.typeName != "string" ? !1 : e === void 0 ? !0 : t.typeName == e.typeName;
}
function pc(n, e) {
  return Lt(e) || !n.fieldWrapper ? e : n.fieldWrapper.wrapField(e);
}
I.DOUBLE, I.FLOAT, I.INT64, I.UINT64, I.INT32, I.UINT32, I.BOOL, I.STRING, I.BYTES;
const wa = {
  ignoreUnknownFields: !1
}, Ea = {
  emitDefaultValues: !1,
  enumAsInteger: !1,
  useProtoFieldName: !1,
  prettySpaces: 0
};
function iu(n) {
  return n ? Object.assign(Object.assign({}, wa), n) : wa;
}
function nu(n) {
  return n ? Object.assign(Object.assign({}, Ea), n) : Ea;
}
const Bn = Symbol(), En = Symbol();
function su() {
  return {
    makeReadOptions: iu,
    makeWriteOptions: nu,
    readMessage(n, e, t, i) {
      if (e == null || Array.isArray(e) || typeof e != "object")
        throw new Error("cannot decode message ".concat(n.typeName, " from JSON: ").concat(_t(e)));
      i = i != null ? i : new n();
      const s = /* @__PURE__ */ new Map(), r = t.typeRegistry;
      for (const [o, a] of Object.entries(e)) {
        const c = n.fields.findJsonName(o);
        if (c) {
          if (c.oneof) {
            if (a === null && c.kind == "scalar")
              continue;
            const d = s.get(c.oneof);
            if (d !== void 0)
              throw new Error("cannot decode message ".concat(n.typeName, ' from JSON: multiple keys for oneof "').concat(c.oneof.name, '" present: "').concat(d, '", "').concat(o, '"'));
            s.set(c.oneof, o);
          }
          Ra(i, a, c, t, n);
        } else {
          let d = !1;
          if (r != null && r.findExtension && o.startsWith("[") && o.endsWith("]")) {
            const l = r.findExtension(o.substring(1, o.length - 1));
            if (l && l.extendee.typeName == n.typeName) {
              d = !0;
              const [u, h] = cc(l);
              Ra(u, a, l.field, t, l), tu(i, l, h(), t);
            }
          }
          if (!d && !t.ignoreUnknownFields)
            throw new Error("cannot decode message ".concat(n.typeName, ' from JSON: key "').concat(o, '" is unknown'));
        }
      }
      return i;
    },
    writeMessage(n, e) {
      const t = n.getType(), i = {};
      let s;
      try {
        for (s of t.fields.byNumber()) {
          if (!hc(s, n)) {
            if (s.req)
              throw "required field not set";
            if (!e.emitDefaultValues || !au(s))
              continue;
          }
          const o = s.oneof ? n[s.oneof.localName].value : n[s.localName], a = Ia(s, o, e);
          a !== void 0 && (i[e.useProtoFieldName ? s.name : s.jsonName] = a);
        }
        const r = e.typeRegistry;
        if (r != null && r.findExtensionFor)
          for (const o of t.runtime.bin.listUnknownFields(n)) {
            const a = r.findExtensionFor(t.typeName, o.no);
            if (a && lc(n, a)) {
              const c = eu(n, a, e), d = Ia(a.field, c, e);
              d !== void 0 && (i[a.field.jsonName] = d);
            }
          }
      } catch (r) {
        const o = s ? "cannot encode field ".concat(t.typeName, ".").concat(s.name, " to JSON") : "cannot encode message ".concat(t.typeName, " to JSON"), a = r instanceof Error ? r.message : String(r);
        throw new Error(o + (a.length > 0 ? ": ".concat(a) : ""));
      }
      return i;
    },
    readScalar(n, e, t) {
      return nn(n, e, t != null ? t : Yt.BIGINT, !0);
    },
    writeScalar(n, e, t) {
      if (e !== void 0 && (t || oc(n, e)))
        return Rn(n, e);
    },
    debug: _t
  };
}
function _t(n) {
  if (n === null)
    return "null";
  switch (typeof n) {
    case "object":
      return Array.isArray(n) ? "array" : "object";
    case "string":
      return n.length > 100 ? "string" : '"'.concat(n.split('"').join('\\"'), '"');
    default:
      return String(n);
  }
}
function Ra(n, e, t, i, s) {
  let r = t.localName;
  if (t.repeated) {
    if (Ae(t.kind != "map"), e === null)
      return;
    if (!Array.isArray(e))
      throw new Error("cannot decode field ".concat(s.typeName, ".").concat(t.name, " from JSON: ").concat(_t(e)));
    const o = n[r];
    for (const a of e) {
      if (a === null)
        throw new Error("cannot decode field ".concat(s.typeName, ".").concat(t.name, " from JSON: ").concat(_t(a)));
      switch (t.kind) {
        case "message":
          o.push(t.T.fromJson(a, i));
          break;
        case "enum":
          const c = vs(t.T, a, i.ignoreUnknownFields, !0);
          c !== En && o.push(c);
          break;
        case "scalar":
          try {
            o.push(nn(t.T, a, t.L, !0));
          } catch (d) {
            let l = "cannot decode field ".concat(s.typeName, ".").concat(t.name, " from JSON: ").concat(_t(a));
            throw d instanceof Error && d.message.length > 0 && (l += ": ".concat(d.message)), new Error(l);
          }
          break;
      }
    }
  } else if (t.kind == "map") {
    if (e === null)
      return;
    if (typeof e != "object" || Array.isArray(e))
      throw new Error("cannot decode field ".concat(s.typeName, ".").concat(t.name, " from JSON: ").concat(_t(e)));
    const o = n[r];
    for (const [a, c] of Object.entries(e)) {
      if (c === null)
        throw new Error("cannot decode field ".concat(s.typeName, ".").concat(t.name, " from JSON: map value null"));
      let d;
      try {
        d = ru(t.K, a);
      } catch (l) {
        let u = "cannot decode map key for field ".concat(s.typeName, ".").concat(t.name, " from JSON: ").concat(_t(e));
        throw l instanceof Error && l.message.length > 0 && (u += ": ".concat(l.message)), new Error(u);
      }
      switch (t.V.kind) {
        case "message":
          o[d] = t.V.T.fromJson(c, i);
          break;
        case "enum":
          const l = vs(t.V.T, c, i.ignoreUnknownFields, !0);
          l !== En && (o[d] = l);
          break;
        case "scalar":
          try {
            o[d] = nn(t.V.T, c, Yt.BIGINT, !0);
          } catch (u) {
            let h = "cannot decode map value for field ".concat(s.typeName, ".").concat(t.name, " from JSON: ").concat(_t(e));
            throw u instanceof Error && u.message.length > 0 && (h += ": ".concat(u.message)), new Error(h);
          }
          break;
      }
    }
  } else
    switch (t.oneof && (n = n[t.oneof.localName] = {
      case: r
    }, r = "value"), t.kind) {
      case "message":
        const o = t.T;
        if (e === null && o.typeName != "google.protobuf.Value")
          return;
        let a = n[r];
        Lt(a) ? a.fromJson(e, i) : (n[r] = a = o.fromJson(e, i), o.fieldWrapper && !t.oneof && (n[r] = o.fieldWrapper.unwrapField(a)));
        break;
      case "enum":
        const c = vs(t.T, e, i.ignoreUnknownFields, !1);
        switch (c) {
          case Bn:
            _a(t, n);
            break;
          case En:
            break;
          default:
            n[r] = c;
            break;
        }
        break;
      case "scalar":
        try {
          const d = nn(t.T, e, t.L, !1);
          switch (d) {
            case Bn:
              _a(t, n);
              break;
            default:
              n[r] = d;
              break;
          }
        } catch (d) {
          let l = "cannot decode field ".concat(s.typeName, ".").concat(t.name, " from JSON: ").concat(_t(e));
          throw d instanceof Error && d.message.length > 0 && (l += ": ".concat(d.message)), new Error(l);
        }
        break;
    }
}
function ru(n, e) {
  if (n === I.BOOL)
    switch (e) {
      case "true":
        e = !0;
        break;
      case "false":
        e = !1;
        break;
    }
  return nn(n, e, Yt.BIGINT, !0).toString();
}
function nn(n, e, t, i) {
  if (e === null)
    return i ? Fi(n, t) : Bn;
  switch (n) {
    // float, double: JSON value will be a number or one of the special string values "NaN", "Infinity", and "-Infinity".
    // Either numbers or strings are accepted. Exponent notation is also accepted.
    case I.DOUBLE:
    case I.FLOAT:
      if (e === "NaN") return Number.NaN;
      if (e === "Infinity") return Number.POSITIVE_INFINITY;
      if (e === "-Infinity") return Number.NEGATIVE_INFINITY;
      if (e === "" || typeof e == "string" && e.trim().length !== e.length || typeof e != "string" && typeof e != "number")
        break;
      const s = Number(e);
      if (Number.isNaN(s) || !Number.isFinite(s))
        break;
      return n == I.FLOAT && ec(s), s;
    // int32, fixed32, uint32: JSON value will be a decimal number. Either numbers or strings are accepted.
    case I.INT32:
    case I.FIXED32:
    case I.SFIXED32:
    case I.SINT32:
    case I.UINT32:
      let r;
      if (typeof e == "number" ? r = e : typeof e == "string" && e.length > 0 && e.trim().length === e.length && (r = Number(e)), r === void 0) break;
      return n == I.UINT32 || n == I.FIXED32 ? Ks(r) : _n(r), r;
    // int64, fixed64, uint64: JSON value will be a decimal string. Either numbers or strings are accepted.
    case I.INT64:
    case I.SFIXED64:
    case I.SINT64:
      if (typeof e != "number" && typeof e != "string") break;
      const o = Pe.parse(e);
      return t ? o.toString() : o;
    case I.FIXED64:
    case I.UINT64:
      if (typeof e != "number" && typeof e != "string") break;
      const a = Pe.uParse(e);
      return t ? a.toString() : a;
    // bool:
    case I.BOOL:
      if (typeof e != "boolean") break;
      return e;
    // string:
    case I.STRING:
      if (typeof e != "string")
        break;
      try {
        encodeURIComponent(e);
      } catch {
        throw new Error("invalid UTF8");
      }
      return e;
    // bytes: JSON value will be the data encoded as a string using standard base64 encoding with paddings.
    // Either standard or URL-safe base64 encoding with/without paddings are accepted.
    case I.BYTES:
      if (e === "") return new Uint8Array(0);
      if (typeof e != "string") break;
      return dc.dec(e);
  }
  throw new Error();
}
function vs(n, e, t, i) {
  if (e === null)
    return n.typeName == "google.protobuf.NullValue" ? 0 : i ? n.values[0].no : Bn;
  switch (typeof e) {
    case "number":
      if (Number.isInteger(e))
        return e;
      break;
    case "string":
      const s = n.findName(e);
      if (s !== void 0)
        return s.no;
      if (t)
        return En;
      break;
  }
  throw new Error("cannot decode enum ".concat(n.typeName, " from JSON: ").concat(_t(e)));
}
function au(n) {
  return n.repeated || n.kind == "map" ? !0 : !(n.oneof || n.kind == "message" || n.opt || n.req);
}
function Ia(n, e, t) {
  if (n.kind == "map") {
    Ae(typeof e == "object" && e != null);
    const i = {}, s = Object.entries(e);
    switch (n.V.kind) {
      case "scalar":
        for (const [o, a] of s)
          i[o.toString()] = Rn(n.V.T, a);
        break;
      case "message":
        for (const [o, a] of s)
          i[o.toString()] = a.toJson(t);
        break;
      case "enum":
        const r = n.V.T;
        for (const [o, a] of s)
          i[o.toString()] = bs(r, a, t.enumAsInteger);
        break;
    }
    return t.emitDefaultValues || s.length > 0 ? i : void 0;
  }
  if (n.repeated) {
    Ae(Array.isArray(e));
    const i = [];
    switch (n.kind) {
      case "scalar":
        for (let s = 0; s < e.length; s++)
          i.push(Rn(n.T, e[s]));
        break;
      case "enum":
        for (let s = 0; s < e.length; s++)
          i.push(bs(n.T, e[s], t.enumAsInteger));
        break;
      case "message":
        for (let s = 0; s < e.length; s++)
          i.push(e[s].toJson(t));
        break;
    }
    return t.emitDefaultValues || i.length > 0 ? i : void 0;
  }
  switch (n.kind) {
    case "scalar":
      return Rn(n.T, e);
    case "enum":
      return bs(n.T, e, t.enumAsInteger);
    case "message":
      return pc(n.T, e).toJson(t);
  }
}
function bs(n, e, t) {
  var i;
  if (Ae(typeof e == "number"), n.typeName == "google.protobuf.NullValue")
    return null;
  if (t)
    return e;
  const s = n.findNumber(e);
  return (i = s == null ? void 0 : s.name) !== null && i !== void 0 ? i : e;
}
function Rn(n, e) {
  switch (n) {
    // int32, fixed32, uint32: JSON value will be a decimal number. Either numbers or strings are accepted.
    case I.INT32:
    case I.SFIXED32:
    case I.SINT32:
    case I.FIXED32:
    case I.UINT32:
      return Ae(typeof e == "number"), e;
    // float, double: JSON value will be a number or one of the special string values "NaN", "Infinity", and "-Infinity".
    // Either numbers or strings are accepted. Exponent notation is also accepted.
    case I.FLOAT:
    // assertFloat32(value);
    case I.DOUBLE:
      return Ae(typeof e == "number"), Number.isNaN(e) ? "NaN" : e === Number.POSITIVE_INFINITY ? "Infinity" : e === Number.NEGATIVE_INFINITY ? "-Infinity" : e;
    // string:
    case I.STRING:
      return Ae(typeof e == "string"), e;
    // bool:
    case I.BOOL:
      return Ae(typeof e == "boolean"), e;
    // JSON value will be a decimal string. Either numbers or strings are accepted.
    case I.UINT64:
    case I.FIXED64:
    case I.INT64:
    case I.SFIXED64:
    case I.SINT64:
      return Ae(typeof e == "bigint" || typeof e == "string" || typeof e == "number"), e.toString();
    // bytes: JSON value will be the data encoded as a string using standard base64 encoding with paddings.
    // Either standard or URL-safe base64 encoding with/without paddings are accepted.
    case I.BYTES:
      return Ae(e instanceof Uint8Array), dc.enc(e);
  }
}
const gi = Symbol("@bufbuild/protobuf/unknown-fields"), Pa = {
  readUnknownFields: !0,
  readerFactory: (n) => new Yl(n)
}, xa = {
  writeUnknownFields: !0,
  writerFactory: () => new Jl()
};
function ou(n) {
  return n ? Object.assign(Object.assign({}, Pa), n) : Pa;
}
function cu(n) {
  return n ? Object.assign(Object.assign({}, xa), n) : xa;
}
function du() {
  return {
    makeReadOptions: ou,
    makeWriteOptions: cu,
    listUnknownFields(n) {
      var e;
      return (e = n[gi]) !== null && e !== void 0 ? e : [];
    },
    discardUnknownFields(n) {
      delete n[gi];
    },
    writeUnknownFields(n, e) {
      const i = n[gi];
      if (i)
        for (const s of i)
          e.tag(s.no, s.wireType).raw(s.data);
    },
    onUnknownField(n, e, t, i) {
      const s = n;
      Array.isArray(s[gi]) || (s[gi] = []), s[gi].push({
        no: e,
        wireType: t,
        data: i
      });
    },
    readMessage(n, e, t, i, s) {
      const r = n.getType(), o = s ? e.len : e.pos + t;
      let a, c;
      for (; e.pos < o && ([a, c] = e.tag(), !(s === !0 && c == Le.EndGroup)); ) {
        const d = r.fields.find(a);
        if (!d) {
          const l = e.skip(c, a);
          i.readUnknownFields && this.onUnknownField(n, a, c, l);
          continue;
        }
        Ma(n, e, d, c, i);
      }
      if (s && // eslint-disable-line @typescript-eslint/strict-boolean-expressions
      (c != Le.EndGroup || a !== t))
        throw new Error("invalid end group tag");
    },
    readField: Ma,
    writeMessage(n, e, t) {
      const i = n.getType();
      for (const s of i.fields.byNumber()) {
        if (!hc(s, n)) {
          if (s.req)
            throw new Error("cannot encode field ".concat(i.typeName, ".").concat(s.name, " to binary: required field not set"));
          continue;
        }
        const r = s.oneof ? n[s.oneof.localName].value : n[s.localName];
        Aa(s, r, e, t);
      }
      return t.writeUnknownFields && this.writeUnknownFields(n, e), e;
    },
    writeField(n, e, t, i) {
      e !== void 0 && Aa(n, e, t, i);
    }
  };
}
function Ma(n, e, t, i, s) {
  let {
    repeated: r,
    localName: o
  } = t;
  switch (t.oneof && (n = n[t.oneof.localName], n.case != o && delete n.value, n.case = o, o = "value"), t.kind) {
    case "scalar":
    case "enum":
      const a = t.kind == "enum" ? I.INT32 : t.T;
      let c = jn;
      if (t.kind == "scalar" && t.L > 0 && (c = uu), r) {
        let h = n[o];
        if (i == Le.LengthDelimited && a != I.STRING && a != I.BYTES) {
          let b = e.uint32() + e.pos;
          for (; e.pos < b; )
            h.push(c(e, a));
        } else
          h.push(c(e, a));
      } else
        n[o] = c(e, a);
      break;
    case "message":
      const d = t.T;
      r ? n[o].push(In(e, new d(), s, t)) : Lt(n[o]) ? In(e, n[o], s, t) : (n[o] = In(e, new d(), s, t), d.fieldWrapper && !t.oneof && !t.repeated && (n[o] = d.fieldWrapper.unwrapField(n[o])));
      break;
    case "map":
      let [l, u] = lu(t, e, s);
      n[o][l] = u;
      break;
  }
}
function In(n, e, t, i) {
  const s = e.getType().runtime.bin, r = i == null ? void 0 : i.delimited;
  return s.readMessage(
    e,
    n,
    r ? i.no : n.uint32(),
    // eslint-disable-line @typescript-eslint/strict-boolean-expressions
    t,
    r
  ), e;
}
function lu(n, e, t) {
  const i = e.uint32(), s = e.pos + i;
  let r, o;
  for (; e.pos < s; ) {
    const [a] = e.tag();
    switch (a) {
      case 1:
        r = jn(e, n.K);
        break;
      case 2:
        switch (n.V.kind) {
          case "scalar":
            o = jn(e, n.V.T);
            break;
          case "enum":
            o = e.int32();
            break;
          case "message":
            o = In(e, new n.V.T(), t, void 0);
            break;
        }
        break;
    }
  }
  if (r === void 0 && (r = Fi(n.K, Yt.BIGINT)), typeof r != "string" && typeof r != "number" && (r = r.toString()), o === void 0)
    switch (n.V.kind) {
      case "scalar":
        o = Fi(n.V.T, Yt.BIGINT);
        break;
      case "enum":
        o = n.V.T.values[0].no;
        break;
      case "message":
        o = new n.V.T();
        break;
    }
  return [r, o];
}
function uu(n, e) {
  const t = jn(n, e);
  return typeof t == "bigint" ? t.toString() : t;
}
function jn(n, e) {
  switch (e) {
    case I.STRING:
      return n.string();
    case I.BOOL:
      return n.bool();
    case I.DOUBLE:
      return n.double();
    case I.FLOAT:
      return n.float();
    case I.INT32:
      return n.int32();
    case I.INT64:
      return n.int64();
    case I.UINT64:
      return n.uint64();
    case I.FIXED64:
      return n.fixed64();
    case I.BYTES:
      return n.bytes();
    case I.FIXED32:
      return n.fixed32();
    case I.SFIXED32:
      return n.sfixed32();
    case I.SFIXED64:
      return n.sfixed64();
    case I.SINT64:
      return n.sint64();
    case I.UINT32:
      return n.uint32();
    case I.SINT32:
      return n.sint32();
  }
}
function Aa(n, e, t, i) {
  Ae(e !== void 0);
  const s = n.repeated;
  switch (n.kind) {
    case "scalar":
    case "enum":
      let r = n.kind == "enum" ? I.INT32 : n.T;
      if (s)
        if (Ae(Array.isArray(e)), n.packed)
          pu(t, r, n.no, e);
        else
          for (const o of e)
            sn(t, r, n.no, o);
      else
        sn(t, r, n.no, e);
      break;
    case "message":
      if (s) {
        Ae(Array.isArray(e));
        for (const o of e)
          Oa(t, i, n, o);
      } else
        Oa(t, i, n, e);
      break;
    case "map":
      Ae(typeof e == "object" && e != null);
      for (const [o, a] of Object.entries(e))
        hu(t, i, n, o, a);
      break;
  }
}
function hu(n, e, t, i, s) {
  n.tag(t.no, Le.LengthDelimited), n.fork();
  let r = i;
  switch (t.K) {
    case I.INT32:
    case I.FIXED32:
    case I.UINT32:
    case I.SFIXED32:
    case I.SINT32:
      r = Number.parseInt(i);
      break;
    case I.BOOL:
      Ae(i == "true" || i == "false"), r = i == "true";
      break;
  }
  switch (sn(n, t.K, 1, r), t.V.kind) {
    case "scalar":
      sn(n, t.V.T, 2, s);
      break;
    case "enum":
      sn(n, I.INT32, 2, s);
      break;
    case "message":
      Ae(s !== void 0), n.tag(2, Le.LengthDelimited).bytes(s.toBinary(e));
      break;
  }
  n.join();
}
function Oa(n, e, t, i) {
  const s = pc(t.T, i);
  t.delimited ? n.tag(t.no, Le.StartGroup).raw(s.toBinary(e)).tag(t.no, Le.EndGroup) : n.tag(t.no, Le.LengthDelimited).bytes(s.toBinary(e));
}
function sn(n, e, t, i) {
  Ae(i !== void 0);
  let [s, r] = mc(e);
  n.tag(t, s)[r](i);
}
function pu(n, e, t, i) {
  if (!i.length)
    return;
  n.tag(t, Le.LengthDelimited).fork();
  let [, s] = mc(e);
  for (let r = 0; r < i.length; r++)
    n[s](i[r]);
  n.join();
}
function mc(n) {
  let e = Le.Varint;
  switch (n) {
    case I.BYTES:
    case I.STRING:
      e = Le.LengthDelimited;
      break;
    case I.DOUBLE:
    case I.FIXED64:
    case I.SFIXED64:
      e = Le.Bit64;
      break;
    case I.FIXED32:
    case I.SFIXED32:
    case I.FLOAT:
      e = Le.Bit32;
      break;
  }
  const t = I[n].toLowerCase();
  return [e, t];
}
function mu() {
  return {
    setEnumType: ic,
    initPartial(n, e) {
      if (n === void 0)
        return;
      const t = e.getType();
      for (const i of t.fields.byMember()) {
        const s = i.localName, r = e, o = n;
        if (o[s] != null)
          switch (i.kind) {
            case "oneof":
              const a = o[s].case;
              if (a === void 0)
                continue;
              const c = i.findField(a);
              let d = o[s].value;
              c && c.kind == "message" && !Lt(d, c.T) ? d = new c.T(d) : c && c.kind === "scalar" && c.T === I.BYTES && (d = Wi(d)), r[s] = {
                case: a,
                value: d
              };
              break;
            case "scalar":
            case "enum":
              let l = o[s];
              i.T === I.BYTES && (l = i.repeated ? l.map(Wi) : Wi(l)), r[s] = l;
              break;
            case "map":
              switch (i.V.kind) {
                case "scalar":
                case "enum":
                  if (i.V.T === I.BYTES)
                    for (const [p, b] of Object.entries(o[s]))
                      r[s][p] = Wi(b);
                  else
                    Object.assign(r[s], o[s]);
                  break;
                case "message":
                  const h = i.V.T;
                  for (const p of Object.keys(o[s])) {
                    let b = o[s][p];
                    h.fieldWrapper || (b = new h(b)), r[s][p] = b;
                  }
                  break;
              }
              break;
            case "message":
              const u = i.T;
              if (i.repeated)
                r[s] = o[s].map((h) => Lt(h, u) ? h : new u(h));
              else {
                const h = o[s];
                u.fieldWrapper ? /* We can't use BytesValue.typeName as that will create a circular import */ u.typeName === "google.protobuf.BytesValue" ? r[s] = Wi(h) : r[s] = h : r[s] = Lt(h, u) ? h : new u(h);
              }
              break;
          }
      }
    },
    // TODO use isFieldSet() here to support future field presence
    equals(n, e, t) {
      return e === t ? !0 : !e || !t ? !1 : n.fields.byMember().every((i) => {
        const s = e[i.localName], r = t[i.localName];
        if (i.repeated) {
          if (s.length !== r.length)
            return !1;
          switch (i.kind) {
            case "message":
              return s.every((o, a) => i.T.equals(o, r[a]));
            case "scalar":
              return s.every((o, a) => Bt(i.T, o, r[a]));
            case "enum":
              return s.every((o, a) => Bt(I.INT32, o, r[a]));
          }
          throw new Error("repeated cannot contain ".concat(i.kind));
        }
        switch (i.kind) {
          case "message":
            let o = s, a = r;
            return i.T.fieldWrapper && (o !== void 0 && !Lt(o) && (o = i.T.fieldWrapper.wrapField(o)), a !== void 0 && !Lt(a) && (a = i.T.fieldWrapper.wrapField(a))), i.T.equals(o, a);
          case "enum":
            return Bt(I.INT32, s, r);
          case "scalar":
            return Bt(i.T, s, r);
          case "oneof":
            if (s.case !== r.case)
              return !1;
            const c = i.findField(s.case);
            if (c === void 0)
              return !0;
            switch (c.kind) {
              case "message":
                return c.T.equals(s.value, r.value);
              case "enum":
                return Bt(I.INT32, s.value, r.value);
              case "scalar":
                return Bt(c.T, s.value, r.value);
            }
            throw new Error("oneof cannot contain ".concat(c.kind));
          case "map":
            const d = Object.keys(s).concat(Object.keys(r));
            switch (i.V.kind) {
              case "message":
                const l = i.V.T;
                return d.every((h) => l.equals(s[h], r[h]));
              case "enum":
                return d.every((h) => Bt(I.INT32, s[h], r[h]));
              case "scalar":
                const u = i.V.T;
                return d.every((h) => Bt(u, s[h], r[h]));
            }
            break;
        }
      });
    },
    // TODO use isFieldSet() here to support future field presence
    clone(n) {
      const e = n.getType(), t = new e(), i = t;
      for (const s of e.fields.byMember()) {
        const r = n[s.localName];
        let o;
        if (s.repeated)
          o = r.map(yn);
        else if (s.kind == "map") {
          o = i[s.localName];
          for (const [a, c] of Object.entries(r))
            o[a] = yn(c);
        } else s.kind == "oneof" ? o = s.findField(r.case) ? {
          case: r.case,
          value: yn(r.value)
        } : {
          case: void 0
        } : o = yn(r);
        i[s.localName] = o;
      }
      for (const s of e.runtime.bin.listUnknownFields(n))
        e.runtime.bin.onUnknownField(i, s.no, s.wireType, s.data);
      return t;
    }
  };
}
function yn(n) {
  if (n === void 0)
    return n;
  if (Lt(n))
    return n.clone();
  if (n instanceof Uint8Array) {
    const e = new Uint8Array(n.byteLength);
    return e.set(n), e;
  }
  return n;
}
function Wi(n) {
  return n instanceof Uint8Array ? n : new Uint8Array(n);
}
function fu(n, e, t) {
  return {
    syntax: n,
    json: su(),
    bin: du(),
    util: Object.assign(Object.assign({}, mu()), {
      newFieldList: e,
      initFields: t
    }),
    makeMessageType(i, s, r) {
      return Hl(this, i, s, r);
    },
    makeEnum: ql,
    makeEnumType: nc,
    getEnumType: jl,
    makeExtension(i, s, r) {
      return Ql(this, i, s, r);
    }
  };
}
class gu {
  constructor(e, t) {
    this._fields = e, this._normalizer = t;
  }
  findJsonName(e) {
    if (!this.jsonNames) {
      const t = {};
      for (const i of this.list())
        t[i.jsonName] = t[i.name] = i;
      this.jsonNames = t;
    }
    return this.jsonNames[e];
  }
  find(e) {
    if (!this.numbers) {
      const t = {};
      for (const i of this.list())
        t[i.no] = i;
      this.numbers = t;
    }
    return this.numbers[e];
  }
  list() {
    return this.all || (this.all = this._normalizer(this._fields)), this.all;
  }
  byNumber() {
    return this.numbersAsc || (this.numbersAsc = this.list().concat().sort((e, t) => e.no - t.no)), this.numbersAsc;
  }
  byMember() {
    if (!this.members) {
      this.members = [];
      const e = this.members;
      let t;
      for (const i of this.list())
        i.oneof ? i.oneof !== t && (t = i.oneof, e.push(t)) : e.push(i);
    }
    return this.members;
  }
}
function fc(n, e) {
  const t = gc(n);
  return e ? t : Tu(ku(t));
}
function vu(n) {
  return fc(n, !1);
}
const bu = gc;
function gc(n) {
  let e = !1;
  const t = [];
  for (let i = 0; i < n.length; i++) {
    let s = n.charAt(i);
    switch (s) {
      case "_":
        e = !0;
        break;
      case "0":
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9":
        t.push(s), e = !1;
        break;
      default:
        e && (e = !1, s = s.toUpperCase()), t.push(s);
        break;
    }
  }
  return t.join("");
}
const yu = /* @__PURE__ */ new Set([
  // names reserved by JavaScript
  "constructor",
  "toString",
  "toJSON",
  "valueOf"
]), Su = /* @__PURE__ */ new Set([
  // names reserved by the runtime
  "getType",
  "clone",
  "equals",
  "fromBinary",
  "fromJson",
  "fromJsonString",
  "toBinary",
  "toJson",
  "toJsonString",
  // names reserved by the runtime for the future
  "toObject"
]), vc = (n) => "".concat(n, "$"), ku = (n) => Su.has(n) ? vc(n) : n, Tu = (n) => yu.has(n) ? vc(n) : n;
class Cu {
  constructor(e) {
    this.kind = "oneof", this.repeated = !1, this.packed = !1, this.opt = !1, this.req = !1, this.default = void 0, this.fields = [], this.name = e, this.localName = vu(e);
  }
  addField(e) {
    Ae(e.oneof === this, "field ".concat(e.name, " not one of ").concat(this.name)), this.fields.push(e);
  }
  findField(e) {
    if (!this._lookup) {
      this._lookup = /* @__PURE__ */ Object.create(null);
      for (let t = 0; t < this.fields.length; t++)
        this._lookup[this.fields[t].localName] = this.fields[t];
    }
    return this._lookup[e];
  }
}
function _u(n, e) {
  var t, i, s, r, o, a;
  const c = [];
  let d;
  for (const l of typeof n == "function" ? n() : n) {
    const u = l;
    if (u.localName = fc(l.name, l.oneof !== void 0), u.jsonName = (t = l.jsonName) !== null && t !== void 0 ? t : bu(l.name), u.repeated = (i = l.repeated) !== null && i !== void 0 ? i : !1, l.kind == "scalar" && (u.L = (s = l.L) !== null && s !== void 0 ? s : Yt.BIGINT), u.delimited = (r = l.delimited) !== null && r !== void 0 ? r : !1, u.req = (o = l.req) !== null && o !== void 0 ? o : !1, u.opt = (a = l.opt) !== null && a !== void 0 ? a : !1, l.packed === void 0 && (u.packed = l.kind == "enum" || l.kind == "scalar" && l.T != I.BYTES && l.T != I.STRING), l.oneof !== void 0) {
      const h = typeof l.oneof == "string" ? l.oneof : l.oneof.name;
      (!d || d.name != h) && (d = new Cu(h)), u.oneof = d, d.addField(u);
    }
    c.push(u);
  }
  return c;
}
const S = fu(
  "proto3",
  (n) => new gu(n, (e) => _u(e)),
  // TODO merge with proto2 and initExtensionField, also see initPartial, equals, clone
  (n) => {
    for (const e of n.getType().fields.byMember()) {
      if (e.opt)
        continue;
      const t = e.localName, i = n;
      if (e.repeated) {
        i[t] = [];
        continue;
      }
      switch (e.kind) {
        case "oneof":
          i[t] = {
            case: void 0
          };
          break;
        case "enum":
          i[t] = 0;
          break;
        case "map":
          i[t] = {};
          break;
        case "scalar":
          i[t] = Fi(e.T, e.L);
          break;
      }
    }
  }
);
class tt extends Rr {
  constructor(e) {
    super(), this.seconds = Pe.zero, this.nanos = 0, S.util.initPartial(e, this);
  }
  fromJson(e, t) {
    if (typeof e != "string")
      throw new Error("cannot decode google.protobuf.Timestamp from JSON: ".concat(S.json.debug(e)));
    const i = e.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})(?:Z|\.([0-9]{3,9})Z|([+-][0-9][0-9]:[0-9][0-9]))$/);
    if (!i)
      throw new Error("cannot decode google.protobuf.Timestamp from JSON: invalid RFC 3339 string");
    const s = Date.parse(i[1] + "-" + i[2] + "-" + i[3] + "T" + i[4] + ":" + i[5] + ":" + i[6] + (i[8] ? i[8] : "Z"));
    if (Number.isNaN(s))
      throw new Error("cannot decode google.protobuf.Timestamp from JSON: invalid RFC 3339 string");
    if (s < Date.parse("0001-01-01T00:00:00Z") || s > Date.parse("9999-12-31T23:59:59Z"))
      throw new Error("cannot decode message google.protobuf.Timestamp from JSON: must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive");
    return this.seconds = Pe.parse(s / 1e3), this.nanos = 0, i[7] && (this.nanos = parseInt("1" + i[7] + "0".repeat(9 - i[7].length)) - 1e9), this;
  }
  toJson(e) {
    const t = Number(this.seconds) * 1e3;
    if (t < Date.parse("0001-01-01T00:00:00Z") || t > Date.parse("9999-12-31T23:59:59Z"))
      throw new Error("cannot encode google.protobuf.Timestamp to JSON: must be from 0001-01-01T00:00:00Z to 9999-12-31T23:59:59Z inclusive");
    if (this.nanos < 0)
      throw new Error("cannot encode google.protobuf.Timestamp to JSON: nanos must not be negative");
    let i = "Z";
    if (this.nanos > 0) {
      const s = (this.nanos + 1e9).toString().substring(1);
      s.substring(3) === "000000" ? i = "." + s.substring(0, 3) + "Z" : s.substring(6) === "000" ? i = "." + s.substring(0, 6) + "Z" : i = "." + s + "Z";
    }
    return new Date(t).toISOString().replace(".000Z", i);
  }
  toDate() {
    return new Date(Number(this.seconds) * 1e3 + Math.ceil(this.nanos / 1e6));
  }
  static now() {
    return tt.fromDate(/* @__PURE__ */ new Date());
  }
  static fromDate(e) {
    const t = e.getTime();
    return new tt({
      seconds: Pe.parse(Math.floor(t / 1e3)),
      nanos: t % 1e3 * 1e6
    });
  }
  static fromBinary(e, t) {
    return new tt().fromBinary(e, t);
  }
  static fromJson(e, t) {
    return new tt().fromJson(e, t);
  }
  static fromJsonString(e, t) {
    return new tt().fromJsonString(e, t);
  }
  static equals(e, t) {
    return S.util.equals(tt, e, t);
  }
}
tt.runtime = S;
tt.typeName = "google.protobuf.Timestamp";
tt.fields = S.util.newFieldList(() => [{
  no: 1,
  name: "seconds",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 2,
  name: "nanos",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}]);
const wu = /* @__PURE__ */ S.makeMessageType("livekit.MetricsBatch", () => [{
  no: 1,
  name: "timestamp_ms",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 2,
  name: "normalized_timestamp",
  kind: "message",
  T: tt
}, {
  no: 3,
  name: "str_data",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 4,
  name: "time_series",
  kind: "message",
  T: Eu,
  repeated: !0
}, {
  no: 5,
  name: "events",
  kind: "message",
  T: Iu,
  repeated: !0
}]), Eu = /* @__PURE__ */ S.makeMessageType("livekit.TimeSeriesMetric", () => [{
  no: 1,
  name: "label",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 2,
  name: "participant_identity",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 3,
  name: "track_sid",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 4,
  name: "samples",
  kind: "message",
  T: Ru,
  repeated: !0
}, {
  no: 5,
  name: "rid",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), Ru = /* @__PURE__ */ S.makeMessageType("livekit.MetricSample", () => [{
  no: 1,
  name: "timestamp_ms",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 2,
  name: "normalized_timestamp",
  kind: "message",
  T: tt
}, {
  no: 3,
  name: "value",
  kind: "scalar",
  T: 2
  /* ScalarType.FLOAT */
}]), Iu = /* @__PURE__ */ S.makeMessageType("livekit.EventMetric", () => [{
  no: 1,
  name: "label",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 2,
  name: "participant_identity",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 3,
  name: "track_sid",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 4,
  name: "start_timestamp_ms",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 5,
  name: "end_timestamp_ms",
  kind: "scalar",
  T: 3,
  opt: !0
}, {
  no: 6,
  name: "normalized_start_timestamp",
  kind: "message",
  T: tt
}, {
  no: 7,
  name: "normalized_end_timestamp",
  kind: "message",
  T: tt,
  opt: !0
}, {
  no: 8,
  name: "metadata",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 9,
  name: "rid",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), bc = /* @__PURE__ */ S.makeEnum("livekit.BackupCodecPolicy", [{
  no: 0,
  name: "PREFER_REGRESSION"
}, {
  no: 1,
  name: "SIMULCAST"
}, {
  no: 2,
  name: "REGRESSION"
}]), gt = /* @__PURE__ */ S.makeEnum("livekit.TrackType", [{
  no: 0,
  name: "AUDIO"
}, {
  no: 1,
  name: "VIDEO"
}, {
  no: 2,
  name: "DATA"
}]), Fe = /* @__PURE__ */ S.makeEnum("livekit.TrackSource", [{
  no: 0,
  name: "UNKNOWN"
}, {
  no: 1,
  name: "CAMERA"
}, {
  no: 2,
  name: "MICROPHONE"
}, {
  no: 3,
  name: "SCREEN_SHARE"
}, {
  no: 4,
  name: "SCREEN_SHARE_AUDIO"
}]), Pr = /* @__PURE__ */ S.makeEnum("livekit.VideoQuality", [{
  no: 0,
  name: "LOW"
}, {
  no: 1,
  name: "MEDIUM"
}, {
  no: 2,
  name: "HIGH"
}, {
  no: 3,
  name: "OFF"
}]), en = /* @__PURE__ */ S.makeEnum("livekit.ConnectionQuality", [{
  no: 0,
  name: "POOR"
}, {
  no: 1,
  name: "GOOD"
}, {
  no: 2,
  name: "EXCELLENT"
}, {
  no: 3,
  name: "LOST"
}]), on = /* @__PURE__ */ S.makeEnum("livekit.ClientConfigSetting", [{
  no: 0,
  name: "UNSET"
}, {
  no: 1,
  name: "DISABLED"
}, {
  no: 2,
  name: "ENABLED"
}]), yt = /* @__PURE__ */ S.makeEnum("livekit.DisconnectReason", [{
  no: 0,
  name: "UNKNOWN_REASON"
}, {
  no: 1,
  name: "CLIENT_INITIATED"
}, {
  no: 2,
  name: "DUPLICATE_IDENTITY"
}, {
  no: 3,
  name: "SERVER_SHUTDOWN"
}, {
  no: 4,
  name: "PARTICIPANT_REMOVED"
}, {
  no: 5,
  name: "ROOM_DELETED"
}, {
  no: 6,
  name: "STATE_MISMATCH"
}, {
  no: 7,
  name: "JOIN_FAILURE"
}, {
  no: 8,
  name: "MIGRATION"
}, {
  no: 9,
  name: "SIGNAL_CLOSE"
}, {
  no: 10,
  name: "ROOM_CLOSED"
}, {
  no: 11,
  name: "USER_UNAVAILABLE"
}, {
  no: 12,
  name: "USER_REJECTED"
}, {
  no: 13,
  name: "SIP_TRUNK_FAILURE"
}, {
  no: 14,
  name: "CONNECTION_TIMEOUT"
}, {
  no: 15,
  name: "MEDIA_FAILURE"
}]), si = /* @__PURE__ */ S.makeEnum("livekit.ReconnectReason", [{
  no: 0,
  name: "RR_UNKNOWN"
}, {
  no: 1,
  name: "RR_SIGNAL_DISCONNECTED"
}, {
  no: 2,
  name: "RR_PUBLISHER_FAILED"
}, {
  no: 3,
  name: "RR_SUBSCRIBER_FAILED"
}, {
  no: 4,
  name: "RR_SWITCH_CANDIDATE"
}]), Pu = /* @__PURE__ */ S.makeEnum("livekit.SubscriptionError", [{
  no: 0,
  name: "SE_UNKNOWN"
}, {
  no: 1,
  name: "SE_CODEC_UNSUPPORTED"
}, {
  no: 2,
  name: "SE_TRACK_NOTFOUND"
}]), He = /* @__PURE__ */ S.makeEnum("livekit.AudioTrackFeature", [{
  no: 0,
  name: "TF_STEREO"
}, {
  no: 1,
  name: "TF_NO_DTX"
}, {
  no: 2,
  name: "TF_AUTO_GAIN_CONTROL"
}, {
  no: 3,
  name: "TF_ECHO_CANCELLATION"
}, {
  no: 4,
  name: "TF_NOISE_SUPPRESSION"
}, {
  no: 5,
  name: "TF_ENHANCED_NOISE_CANCELLATION"
}, {
  no: 6,
  name: "TF_PRECONNECT_BUFFER"
}]), ns = /* @__PURE__ */ S.makeMessageType("livekit.Room", () => [{
  no: 1,
  name: "sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "name",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "empty_timeout",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 14,
  name: "departure_timeout",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 4,
  name: "max_participants",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 5,
  name: "creation_time",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 15,
  name: "creation_time_ms",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 6,
  name: "turn_password",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 7,
  name: "enabled_codecs",
  kind: "message",
  T: qn,
  repeated: !0
}, {
  no: 8,
  name: "metadata",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 9,
  name: "num_participants",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 11,
  name: "num_publishers",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 10,
  name: "active_recording",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 13,
  name: "version",
  kind: "message",
  T: Mc
}]), qn = /* @__PURE__ */ S.makeMessageType("livekit.Codec", () => [{
  no: 1,
  name: "mime",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "fmtp_line",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), xu = /* @__PURE__ */ S.makeMessageType("livekit.ParticipantPermission", () => [{
  no: 1,
  name: "can_subscribe",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 2,
  name: "can_publish",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 3,
  name: "can_publish_data",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 9,
  name: "can_publish_sources",
  kind: "enum",
  T: S.getEnumType(Fe),
  repeated: !0
}, {
  no: 7,
  name: "hidden",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 8,
  name: "recorder",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 10,
  name: "can_update_metadata",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 11,
  name: "agent",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 12,
  name: "can_subscribe_metrics",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), li = /* @__PURE__ */ S.makeMessageType("livekit.ParticipantInfo", () => [{
  no: 1,
  name: "sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "identity",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "state",
  kind: "enum",
  T: S.getEnumType(xi)
}, {
  no: 4,
  name: "tracks",
  kind: "message",
  T: Ei,
  repeated: !0
}, {
  no: 5,
  name: "metadata",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 6,
  name: "joined_at",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 17,
  name: "joined_at_ms",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 9,
  name: "name",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 10,
  name: "version",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 11,
  name: "permission",
  kind: "message",
  T: xu
}, {
  no: 12,
  name: "region",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 13,
  name: "is_publisher",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 14,
  name: "kind",
  kind: "enum",
  T: S.getEnumType(cn)
}, {
  no: 15,
  name: "attributes",
  kind: "map",
  K: 9,
  V: {
    kind: "scalar",
    T: 9
    /* ScalarType.STRING */
  }
}, {
  no: 16,
  name: "disconnect_reason",
  kind: "enum",
  T: S.getEnumType(yt)
}, {
  no: 18,
  name: "kind_details",
  kind: "enum",
  T: S.getEnumType(Mu),
  repeated: !0
}, {
  no: 19,
  name: "data_tracks",
  kind: "message",
  T: xr,
  repeated: !0
}]), xi = /* @__PURE__ */ S.makeEnum("livekit.ParticipantInfo.State", [{
  no: 0,
  name: "JOINING"
}, {
  no: 1,
  name: "JOINED"
}, {
  no: 2,
  name: "ACTIVE"
}, {
  no: 3,
  name: "DISCONNECTED"
}]), cn = /* @__PURE__ */ S.makeEnum("livekit.ParticipantInfo.Kind", [{
  no: 0,
  name: "STANDARD"
}, {
  no: 1,
  name: "INGRESS"
}, {
  no: 2,
  name: "EGRESS"
}, {
  no: 3,
  name: "SIP"
}, {
  no: 4,
  name: "AGENT"
}, {
  no: 7,
  name: "CONNECTOR"
}, {
  no: 8,
  name: "BRIDGE"
}]), Mu = /* @__PURE__ */ S.makeEnum("livekit.ParticipantInfo.KindDetail", [{
  no: 0,
  name: "CLOUD_AGENT"
}, {
  no: 1,
  name: "FORWARDED"
}, {
  no: 2,
  name: "CONNECTOR_WHATSAPP"
}, {
  no: 3,
  name: "CONNECTOR_TWILIO"
}, {
  no: 4,
  name: "BRIDGE_RTSP"
}]), Ne = /* @__PURE__ */ S.makeEnum("livekit.Encryption.Type", [{
  no: 0,
  name: "NONE"
}, {
  no: 1,
  name: "GCM"
}, {
  no: 2,
  name: "CUSTOM"
}]), Au = /* @__PURE__ */ S.makeMessageType("livekit.SimulcastCodecInfo", () => [{
  no: 1,
  name: "mime_type",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "mid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "cid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "layers",
  kind: "message",
  T: Kt,
  repeated: !0
}, {
  no: 5,
  name: "video_layer_mode",
  kind: "enum",
  T: S.getEnumType(yc)
}, {
  no: 6,
  name: "sdp_cid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), Ei = /* @__PURE__ */ S.makeMessageType("livekit.TrackInfo", () => [{
  no: 1,
  name: "sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "type",
  kind: "enum",
  T: S.getEnumType(gt)
}, {
  no: 3,
  name: "name",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "muted",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 5,
  name: "width",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 6,
  name: "height",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 7,
  name: "simulcast",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 8,
  name: "disable_dtx",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 9,
  name: "source",
  kind: "enum",
  T: S.getEnumType(Fe)
}, {
  no: 10,
  name: "layers",
  kind: "message",
  T: Kt,
  repeated: !0
}, {
  no: 11,
  name: "mime_type",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 12,
  name: "mid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 13,
  name: "codecs",
  kind: "message",
  T: Au,
  repeated: !0
}, {
  no: 14,
  name: "stereo",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 15,
  name: "disable_red",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 16,
  name: "encryption",
  kind: "enum",
  T: S.getEnumType(Ne)
}, {
  no: 17,
  name: "stream",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 18,
  name: "version",
  kind: "message",
  T: Mc
}, {
  no: 19,
  name: "audio_features",
  kind: "enum",
  T: S.getEnumType(He),
  repeated: !0
}, {
  no: 20,
  name: "backup_codec_policy",
  kind: "enum",
  T: S.getEnumType(bc)
}]), xr = /* @__PURE__ */ S.makeMessageType("livekit.DataTrackInfo", () => [{
  no: 1,
  name: "pub_handle",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 2,
  name: "sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "name",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "encryption",
  kind: "enum",
  T: S.getEnumType(Ne)
}]), Ou = /* @__PURE__ */ S.makeMessageType("livekit.DataTrackSubscriptionOptions", () => [{
  no: 1,
  name: "target_fps",
  kind: "scalar",
  T: 13,
  opt: !0
}]), Kt = /* @__PURE__ */ S.makeMessageType("livekit.VideoLayer", () => [{
  no: 1,
  name: "quality",
  kind: "enum",
  T: S.getEnumType(Pr)
}, {
  no: 2,
  name: "width",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 3,
  name: "height",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 4,
  name: "bitrate",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 5,
  name: "ssrc",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 6,
  name: "spatial_layer",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}, {
  no: 7,
  name: "rid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 8,
  name: "repair_ssrc",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), yc = /* @__PURE__ */ S.makeEnum("livekit.VideoLayer.Mode", [{
  no: 0,
  name: "MODE_UNUSED"
}, {
  no: 1,
  name: "ONE_SPATIAL_LAYER_PER_STREAM"
}, {
  no: 2,
  name: "MULTIPLE_SPATIAL_LAYERS_PER_STREAM"
}, {
  no: 3,
  name: "ONE_SPATIAL_LAYER_PER_STREAM_INCOMPLETE_RTCP_SR"
}]), Xe = /* @__PURE__ */ S.makeMessageType("livekit.DataPacket", () => [{
  no: 1,
  name: "kind",
  kind: "enum",
  T: S.getEnumType(oe)
}, {
  no: 4,
  name: "participant_identity",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 5,
  name: "destination_identities",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 2,
  name: "user",
  kind: "message",
  T: Mr,
  oneof: "value"
}, {
  no: 3,
  name: "speaker",
  kind: "message",
  T: Du,
  oneof: "value"
}, {
  no: 6,
  name: "sip_dtmf",
  kind: "message",
  T: Cc,
  oneof: "value"
}, {
  no: 7,
  name: "transcription",
  kind: "message",
  T: Lu,
  oneof: "value"
}, {
  no: 8,
  name: "metrics",
  kind: "message",
  T: wu,
  oneof: "value"
}, {
  no: 9,
  name: "chat_message",
  kind: "message",
  T: Hn,
  oneof: "value"
}, {
  no: 10,
  name: "rpc_request",
  kind: "message",
  T: Ar,
  oneof: "value"
}, {
  no: 11,
  name: "rpc_ack",
  kind: "message",
  T: Or,
  oneof: "value"
}, {
  no: 12,
  name: "rpc_response",
  kind: "message",
  T: Dr,
  oneof: "value"
}, {
  no: 13,
  name: "stream_header",
  kind: "message",
  T: Wn,
  oneof: "value"
}, {
  no: 14,
  name: "stream_chunk",
  kind: "message",
  T: $n,
  oneof: "value"
}, {
  no: 15,
  name: "stream_trailer",
  kind: "message",
  T: zn,
  oneof: "value"
}, {
  no: 18,
  name: "encrypted_packet",
  kind: "message",
  T: Sc,
  oneof: "value"
}, {
  no: 16,
  name: "sequence",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 17,
  name: "participant_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), oe = /* @__PURE__ */ S.makeEnum("livekit.DataPacket.Kind", [{
  no: 0,
  name: "RELIABLE"
}, {
  no: 1,
  name: "LOSSY"
}]), Sc = /* @__PURE__ */ S.makeMessageType("livekit.EncryptedPacket", () => [{
  no: 1,
  name: "encryption_type",
  kind: "enum",
  T: S.getEnumType(Ne)
}, {
  no: 2,
  name: "iv",
  kind: "scalar",
  T: 12
  /* ScalarType.BYTES */
}, {
  no: 3,
  name: "key_index",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 4,
  name: "encrypted_value",
  kind: "scalar",
  T: 12
  /* ScalarType.BYTES */
}]), kc = /* @__PURE__ */ S.makeMessageType("livekit.EncryptedPacketPayload", () => [{
  no: 1,
  name: "user",
  kind: "message",
  T: Mr,
  oneof: "value"
}, {
  no: 3,
  name: "chat_message",
  kind: "message",
  T: Hn,
  oneof: "value"
}, {
  no: 4,
  name: "rpc_request",
  kind: "message",
  T: Ar,
  oneof: "value"
}, {
  no: 5,
  name: "rpc_ack",
  kind: "message",
  T: Or,
  oneof: "value"
}, {
  no: 6,
  name: "rpc_response",
  kind: "message",
  T: Dr,
  oneof: "value"
}, {
  no: 7,
  name: "stream_header",
  kind: "message",
  T: Wn,
  oneof: "value"
}, {
  no: 8,
  name: "stream_chunk",
  kind: "message",
  T: $n,
  oneof: "value"
}, {
  no: 9,
  name: "stream_trailer",
  kind: "message",
  T: zn,
  oneof: "value"
}]), Du = /* @__PURE__ */ S.makeMessageType("livekit.ActiveSpeakerUpdate", () => [{
  no: 1,
  name: "speakers",
  kind: "message",
  T: Tc,
  repeated: !0
}]), Tc = /* @__PURE__ */ S.makeMessageType("livekit.SpeakerInfo", () => [{
  no: 1,
  name: "sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "level",
  kind: "scalar",
  T: 2
  /* ScalarType.FLOAT */
}, {
  no: 3,
  name: "active",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), Mr = /* @__PURE__ */ S.makeMessageType("livekit.UserPacket", () => [{
  no: 1,
  name: "participant_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 5,
  name: "participant_identity",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "payload",
  kind: "scalar",
  T: 12
  /* ScalarType.BYTES */
}, {
  no: 3,
  name: "destination_sids",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 6,
  name: "destination_identities",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 4,
  name: "topic",
  kind: "scalar",
  T: 9,
  opt: !0
}, {
  no: 8,
  name: "id",
  kind: "scalar",
  T: 9,
  opt: !0
}, {
  no: 9,
  name: "start_time",
  kind: "scalar",
  T: 4,
  opt: !0
}, {
  no: 10,
  name: "end_time",
  kind: "scalar",
  T: 4,
  opt: !0
}, {
  no: 11,
  name: "nonce",
  kind: "scalar",
  T: 12
  /* ScalarType.BYTES */
}]), Cc = /* @__PURE__ */ S.makeMessageType("livekit.SipDTMF", () => [{
  no: 3,
  name: "code",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 4,
  name: "digit",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), Lu = /* @__PURE__ */ S.makeMessageType("livekit.Transcription", () => [{
  no: 2,
  name: "transcribed_participant_identity",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "track_id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "segments",
  kind: "message",
  T: Nu,
  repeated: !0
}]), Nu = /* @__PURE__ */ S.makeMessageType("livekit.TranscriptionSegment", () => [{
  no: 1,
  name: "id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "text",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "start_time",
  kind: "scalar",
  T: 4
  /* ScalarType.UINT64 */
}, {
  no: 4,
  name: "end_time",
  kind: "scalar",
  T: 4
  /* ScalarType.UINT64 */
}, {
  no: 5,
  name: "final",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 6,
  name: "language",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), Hn = /* @__PURE__ */ S.makeMessageType("livekit.ChatMessage", () => [{
  no: 1,
  name: "id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "timestamp",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 3,
  name: "edit_timestamp",
  kind: "scalar",
  T: 3,
  opt: !0
}, {
  no: 4,
  name: "message",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 5,
  name: "deleted",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 6,
  name: "generated",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), Ar = /* @__PURE__ */ S.makeMessageType("livekit.RpcRequest", () => [{
  no: 1,
  name: "id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "method",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "payload",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "response_timeout_ms",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 5,
  name: "version",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), Or = /* @__PURE__ */ S.makeMessageType("livekit.RpcAck", () => [{
  no: 1,
  name: "request_id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), Dr = /* @__PURE__ */ S.makeMessageType("livekit.RpcResponse", () => [{
  no: 1,
  name: "request_id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "payload",
  kind: "scalar",
  T: 9,
  oneof: "value"
}, {
  no: 3,
  name: "error",
  kind: "message",
  T: _c,
  oneof: "value"
}]), _c = /* @__PURE__ */ S.makeMessageType("livekit.RpcError", () => [{
  no: 1,
  name: "code",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 2,
  name: "message",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "data",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), wc = /* @__PURE__ */ S.makeMessageType("livekit.ParticipantTracks", () => [{
  no: 1,
  name: "participant_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "track_sids",
  kind: "scalar",
  T: 9,
  repeated: !0
}]), Ec = /* @__PURE__ */ S.makeMessageType("livekit.ServerInfo", () => [{
  no: 1,
  name: "edition",
  kind: "enum",
  T: S.getEnumType(Rc)
}, {
  no: 2,
  name: "version",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "protocol",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}, {
  no: 4,
  name: "region",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 5,
  name: "node_id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 6,
  name: "debug_info",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 7,
  name: "agent_protocol",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}]), Rc = /* @__PURE__ */ S.makeEnum("livekit.ServerInfo.Edition", [{
  no: 0,
  name: "Standard"
}, {
  no: 1,
  name: "Cloud"
}]), Ic = /* @__PURE__ */ S.makeMessageType("livekit.ClientInfo", () => [{
  no: 1,
  name: "sdk",
  kind: "enum",
  T: S.getEnumType(Pc)
}, {
  no: 2,
  name: "version",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "protocol",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}, {
  no: 4,
  name: "os",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 5,
  name: "os_version",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 6,
  name: "device_model",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 7,
  name: "browser",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 8,
  name: "browser_version",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 9,
  name: "address",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 10,
  name: "network",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 11,
  name: "other_sdks",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), Pc = /* @__PURE__ */ S.makeEnum("livekit.ClientInfo.SDK", [{
  no: 0,
  name: "UNKNOWN"
}, {
  no: 1,
  name: "JS"
}, {
  no: 2,
  name: "SWIFT"
}, {
  no: 3,
  name: "ANDROID"
}, {
  no: 4,
  name: "FLUTTER"
}, {
  no: 5,
  name: "GO"
}, {
  no: 6,
  name: "UNITY"
}, {
  no: 7,
  name: "REACT_NATIVE"
}, {
  no: 8,
  name: "RUST"
}, {
  no: 9,
  name: "PYTHON"
}, {
  no: 10,
  name: "CPP"
}, {
  no: 11,
  name: "UNITY_WEB"
}, {
  no: 12,
  name: "NODE"
}, {
  no: 13,
  name: "UNREAL"
}, {
  no: 14,
  name: "ESP32"
}]), xc = /* @__PURE__ */ S.makeMessageType("livekit.ClientConfiguration", () => [{
  no: 1,
  name: "video",
  kind: "message",
  T: Da
}, {
  no: 2,
  name: "screen",
  kind: "message",
  T: Da
}, {
  no: 3,
  name: "resume_connection",
  kind: "enum",
  T: S.getEnumType(on)
}, {
  no: 4,
  name: "disabled_codecs",
  kind: "message",
  T: Uu
}, {
  no: 5,
  name: "force_relay",
  kind: "enum",
  T: S.getEnumType(on)
}]), Da = /* @__PURE__ */ S.makeMessageType("livekit.VideoConfiguration", () => [{
  no: 1,
  name: "hardware_encoder",
  kind: "enum",
  T: S.getEnumType(on)
}]), Uu = /* @__PURE__ */ S.makeMessageType("livekit.DisabledCodecs", () => [{
  no: 1,
  name: "codecs",
  kind: "message",
  T: qn,
  repeated: !0
}, {
  no: 2,
  name: "publish",
  kind: "message",
  T: qn,
  repeated: !0
}]), Mc = /* @__PURE__ */ S.makeMessageType("livekit.TimedVersion", () => [{
  no: 1,
  name: "unix_micro",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 2,
  name: "ticks",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}]), Gs = /* @__PURE__ */ S.makeEnum("livekit.DataStream.OperationType", [{
  no: 0,
  name: "CREATE"
}, {
  no: 1,
  name: "UPDATE"
}, {
  no: 2,
  name: "DELETE"
}, {
  no: 3,
  name: "REACTION"
}]), Ac = /* @__PURE__ */ S.makeMessageType("livekit.DataStream.TextHeader", () => [{
  no: 1,
  name: "operation_type",
  kind: "enum",
  T: S.getEnumType(Gs)
}, {
  no: 2,
  name: "version",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}, {
  no: 3,
  name: "reply_to_stream_id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "attached_stream_ids",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 5,
  name: "generated",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}], {
  localName: "DataStream_TextHeader"
}), Oc = /* @__PURE__ */ S.makeMessageType("livekit.DataStream.ByteHeader", () => [{
  no: 1,
  name: "name",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}], {
  localName: "DataStream_ByteHeader"
}), Wn = /* @__PURE__ */ S.makeMessageType("livekit.DataStream.Header", () => [{
  no: 1,
  name: "stream_id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "timestamp",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 3,
  name: "topic",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "mime_type",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 5,
  name: "total_length",
  kind: "scalar",
  T: 4,
  opt: !0
}, {
  no: 7,
  name: "encryption_type",
  kind: "enum",
  T: S.getEnumType(Ne)
}, {
  no: 8,
  name: "attributes",
  kind: "map",
  K: 9,
  V: {
    kind: "scalar",
    T: 9
    /* ScalarType.STRING */
  }
}, {
  no: 9,
  name: "text_header",
  kind: "message",
  T: Ac,
  oneof: "content_header"
}, {
  no: 10,
  name: "byte_header",
  kind: "message",
  T: Oc,
  oneof: "content_header"
}], {
  localName: "DataStream_Header"
}), $n = /* @__PURE__ */ S.makeMessageType("livekit.DataStream.Chunk", () => [{
  no: 1,
  name: "stream_id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "chunk_index",
  kind: "scalar",
  T: 4
  /* ScalarType.UINT64 */
}, {
  no: 3,
  name: "content",
  kind: "scalar",
  T: 12
  /* ScalarType.BYTES */
}, {
  no: 4,
  name: "version",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}, {
  no: 5,
  name: "iv",
  kind: "scalar",
  T: 12,
  opt: !0
}], {
  localName: "DataStream_Chunk"
}), zn = /* @__PURE__ */ S.makeMessageType("livekit.DataStream.Trailer", () => [{
  no: 1,
  name: "stream_id",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "reason",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "attributes",
  kind: "map",
  K: 9,
  V: {
    kind: "scalar",
    T: 9
    /* ScalarType.STRING */
  }
}], {
  localName: "DataStream_Trailer"
}), Fu = /* @__PURE__ */ S.makeMessageType("livekit.SubscribedAudioCodec", () => [{
  no: 1,
  name: "codec",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "enabled",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), vt = /* @__PURE__ */ S.makeEnum("livekit.SignalTarget", [{
  no: 0,
  name: "PUBLISHER"
}, {
  no: 1,
  name: "SUBSCRIBER"
}]), Js = /* @__PURE__ */ S.makeEnum("livekit.StreamState", [{
  no: 0,
  name: "ACTIVE"
}, {
  no: 1,
  name: "PAUSED"
}]), Vu = /* @__PURE__ */ S.makeEnum("livekit.CandidateProtocol", [{
  no: 0,
  name: "UDP"
}, {
  no: 1,
  name: "TCP"
}, {
  no: 2,
  name: "TLS"
}]), Bu = /* @__PURE__ */ S.makeMessageType("livekit.SignalRequest", () => [{
  no: 1,
  name: "offer",
  kind: "message",
  T: Qt,
  oneof: "message"
}, {
  no: 2,
  name: "answer",
  kind: "message",
  T: Qt,
  oneof: "message"
}, {
  no: 3,
  name: "trickle",
  kind: "message",
  T: ss,
  oneof: "message"
}, {
  no: 4,
  name: "add_track",
  kind: "message",
  T: dn,
  oneof: "message"
}, {
  no: 5,
  name: "mute",
  kind: "message",
  T: rs,
  oneof: "message"
}, {
  no: 6,
  name: "subscription",
  kind: "message",
  T: as,
  oneof: "message"
}, {
  no: 7,
  name: "track_setting",
  kind: "message",
  T: Uc,
  oneof: "message"
}, {
  no: 8,
  name: "leave",
  kind: "message",
  T: os,
  oneof: "message"
}, {
  no: 10,
  name: "update_layers",
  kind: "message",
  T: Vc,
  oneof: "message"
}, {
  no: 11,
  name: "subscription_permission",
  kind: "message",
  T: qc,
  oneof: "message"
}, {
  no: 12,
  name: "sync_state",
  kind: "message",
  T: Vr,
  oneof: "message"
}, {
  no: 13,
  name: "simulate",
  kind: "message",
  T: kt,
  oneof: "message"
}, {
  no: 14,
  name: "ping",
  kind: "scalar",
  T: 3,
  oneof: "message"
}, {
  no: 15,
  name: "update_metadata",
  kind: "message",
  T: Ur,
  oneof: "message"
}, {
  no: 16,
  name: "ping_req",
  kind: "message",
  T: $c,
  oneof: "message"
}, {
  no: 17,
  name: "update_audio_track",
  kind: "message",
  T: Nr,
  oneof: "message"
}, {
  no: 18,
  name: "update_video_track",
  kind: "message",
  T: Fc,
  oneof: "message"
}, {
  no: 19,
  name: "publish_data_track_request",
  kind: "message",
  T: Dc,
  oneof: "message"
}, {
  no: 20,
  name: "unpublish_data_track_request",
  kind: "message",
  T: Nc,
  oneof: "message"
}, {
  no: 21,
  name: "update_data_subscription",
  kind: "message",
  T: Gu,
  oneof: "message"
}]), La = /* @__PURE__ */ S.makeMessageType("livekit.SignalResponse", () => [{
  no: 1,
  name: "join",
  kind: "message",
  T: Wu,
  oneof: "message"
}, {
  no: 2,
  name: "answer",
  kind: "message",
  T: Qt,
  oneof: "message"
}, {
  no: 3,
  name: "offer",
  kind: "message",
  T: Qt,
  oneof: "message"
}, {
  no: 4,
  name: "trickle",
  kind: "message",
  T: ss,
  oneof: "message"
}, {
  no: 5,
  name: "update",
  kind: "message",
  T: Ku,
  oneof: "message"
}, {
  no: 6,
  name: "track_published",
  kind: "message",
  T: Lr,
  oneof: "message"
}, {
  no: 8,
  name: "leave",
  kind: "message",
  T: os,
  oneof: "message"
}, {
  no: 9,
  name: "mute",
  kind: "message",
  T: rs,
  oneof: "message"
}, {
  no: 10,
  name: "speakers_changed",
  kind: "message",
  T: Yu,
  oneof: "message"
}, {
  no: 11,
  name: "room_update",
  kind: "message",
  T: Qu,
  oneof: "message"
}, {
  no: 12,
  name: "connection_quality",
  kind: "message",
  T: Zu,
  oneof: "message"
}, {
  no: 13,
  name: "stream_state_update",
  kind: "message",
  T: th,
  oneof: "message"
}, {
  no: 14,
  name: "subscribed_quality_update",
  kind: "message",
  T: nh,
  oneof: "message"
}, {
  no: 15,
  name: "subscription_permission_update",
  kind: "message",
  T: rh,
  oneof: "message"
}, {
  no: 16,
  name: "refresh_token",
  kind: "scalar",
  T: 9,
  oneof: "message"
}, {
  no: 17,
  name: "track_unpublished",
  kind: "message",
  T: zu,
  oneof: "message"
}, {
  no: 18,
  name: "pong",
  kind: "scalar",
  T: 3,
  oneof: "message"
}, {
  no: 19,
  name: "reconnect",
  kind: "message",
  T: $u,
  oneof: "message"
}, {
  no: 20,
  name: "pong_resp",
  kind: "message",
  T: oh,
  oneof: "message"
}, {
  no: 21,
  name: "subscription_response",
  kind: "message",
  T: lh,
  oneof: "message"
}, {
  no: 22,
  name: "request_response",
  kind: "message",
  T: uh,
  oneof: "message"
}, {
  no: 23,
  name: "track_subscribed",
  kind: "message",
  T: hh,
  oneof: "message"
}, {
  no: 24,
  name: "room_moved",
  kind: "message",
  T: ah,
  oneof: "message"
}, {
  no: 25,
  name: "media_sections_requirement",
  kind: "message",
  T: gh,
  oneof: "message"
}, {
  no: 26,
  name: "subscribed_audio_codec_update",
  kind: "message",
  T: sh,
  oneof: "message"
}, {
  no: 27,
  name: "publish_data_track_response",
  kind: "message",
  T: Lc,
  oneof: "message"
}, {
  no: 28,
  name: "unpublish_data_track_response",
  kind: "message",
  T: ju,
  oneof: "message"
}, {
  no: 29,
  name: "data_track_subscriber_handles",
  kind: "message",
  T: qu,
  oneof: "message"
}]), Ys = /* @__PURE__ */ S.makeMessageType("livekit.SimulcastCodec", () => [{
  no: 1,
  name: "codec",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "cid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "layers",
  kind: "message",
  T: Kt,
  repeated: !0
}, {
  no: 5,
  name: "video_layer_mode",
  kind: "enum",
  T: S.getEnumType(yc)
}]), dn = /* @__PURE__ */ S.makeMessageType("livekit.AddTrackRequest", () => [{
  no: 1,
  name: "cid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "name",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "type",
  kind: "enum",
  T: S.getEnumType(gt)
}, {
  no: 4,
  name: "width",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 5,
  name: "height",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 6,
  name: "muted",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 7,
  name: "disable_dtx",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 8,
  name: "source",
  kind: "enum",
  T: S.getEnumType(Fe)
}, {
  no: 9,
  name: "layers",
  kind: "message",
  T: Kt,
  repeated: !0
}, {
  no: 10,
  name: "simulcast_codecs",
  kind: "message",
  T: Ys,
  repeated: !0
}, {
  no: 11,
  name: "sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 12,
  name: "stereo",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 13,
  name: "disable_red",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 14,
  name: "encryption",
  kind: "enum",
  T: S.getEnumType(Ne)
}, {
  no: 15,
  name: "stream",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 16,
  name: "backup_codec_policy",
  kind: "enum",
  T: S.getEnumType(bc)
}, {
  no: 17,
  name: "audio_features",
  kind: "enum",
  T: S.getEnumType(He),
  repeated: !0
}]), Dc = /* @__PURE__ */ S.makeMessageType("livekit.PublishDataTrackRequest", () => [{
  no: 1,
  name: "pub_handle",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 2,
  name: "name",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "encryption",
  kind: "enum",
  T: S.getEnumType(Ne)
}]), Lc = /* @__PURE__ */ S.makeMessageType("livekit.PublishDataTrackResponse", () => [{
  no: 1,
  name: "info",
  kind: "message",
  T: xr
}]), Nc = /* @__PURE__ */ S.makeMessageType("livekit.UnpublishDataTrackRequest", () => [{
  no: 1,
  name: "pub_handle",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), ju = /* @__PURE__ */ S.makeMessageType("livekit.UnpublishDataTrackResponse", () => [{
  no: 1,
  name: "info",
  kind: "message",
  T: xr
}]), qu = /* @__PURE__ */ S.makeMessageType("livekit.DataTrackSubscriberHandles", () => [{
  no: 1,
  name: "sub_handles",
  kind: "map",
  K: 13,
  V: {
    kind: "message",
    T: Hu
  }
}]), Hu = /* @__PURE__ */ S.makeMessageType("livekit.DataTrackSubscriberHandles.PublishedDataTrack", () => [{
  no: 1,
  name: "publisher_identity",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "publisher_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}], {
  localName: "DataTrackSubscriberHandles_PublishedDataTrack"
}), ss = /* @__PURE__ */ S.makeMessageType("livekit.TrickleRequest", () => [{
  no: 1,
  name: "candidateInit",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "target",
  kind: "enum",
  T: S.getEnumType(vt)
}, {
  no: 3,
  name: "final",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), rs = /* @__PURE__ */ S.makeMessageType("livekit.MuteTrackRequest", () => [{
  no: 1,
  name: "sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "muted",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), Wu = /* @__PURE__ */ S.makeMessageType("livekit.JoinResponse", () => [{
  no: 1,
  name: "room",
  kind: "message",
  T: ns
}, {
  no: 2,
  name: "participant",
  kind: "message",
  T: li
}, {
  no: 3,
  name: "other_participants",
  kind: "message",
  T: li,
  repeated: !0
}, {
  no: 4,
  name: "server_version",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 5,
  name: "ice_servers",
  kind: "message",
  T: Bc,
  repeated: !0
}, {
  no: 6,
  name: "subscriber_primary",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 7,
  name: "alternative_url",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 8,
  name: "client_configuration",
  kind: "message",
  T: xc
}, {
  no: 9,
  name: "server_region",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 10,
  name: "ping_timeout",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}, {
  no: 11,
  name: "ping_interval",
  kind: "scalar",
  T: 5
  /* ScalarType.INT32 */
}, {
  no: 12,
  name: "server_info",
  kind: "message",
  T: Ec
}, {
  no: 13,
  name: "sif_trailer",
  kind: "scalar",
  T: 12
  /* ScalarType.BYTES */
}, {
  no: 14,
  name: "enabled_publish_codecs",
  kind: "message",
  T: qn,
  repeated: !0
}, {
  no: 15,
  name: "fast_publish",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), $u = /* @__PURE__ */ S.makeMessageType("livekit.ReconnectResponse", () => [{
  no: 1,
  name: "ice_servers",
  kind: "message",
  T: Bc,
  repeated: !0
}, {
  no: 2,
  name: "client_configuration",
  kind: "message",
  T: xc
}, {
  no: 3,
  name: "server_info",
  kind: "message",
  T: Ec
}, {
  no: 4,
  name: "last_message_seq",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), Lr = /* @__PURE__ */ S.makeMessageType("livekit.TrackPublishedResponse", () => [{
  no: 1,
  name: "cid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "track",
  kind: "message",
  T: Ei
}]), zu = /* @__PURE__ */ S.makeMessageType("livekit.TrackUnpublishedResponse", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), Qt = /* @__PURE__ */ S.makeMessageType("livekit.SessionDescription", () => [{
  no: 1,
  name: "type",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "sdp",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "id",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 4,
  name: "mid_to_track_id",
  kind: "map",
  K: 9,
  V: {
    kind: "scalar",
    T: 9
    /* ScalarType.STRING */
  }
}]), Ku = /* @__PURE__ */ S.makeMessageType("livekit.ParticipantUpdate", () => [{
  no: 1,
  name: "participants",
  kind: "message",
  T: li,
  repeated: !0
}]), as = /* @__PURE__ */ S.makeMessageType("livekit.UpdateSubscription", () => [{
  no: 1,
  name: "track_sids",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 2,
  name: "subscribe",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 3,
  name: "participant_tracks",
  kind: "message",
  T: wc,
  repeated: !0
}]), Gu = /* @__PURE__ */ S.makeMessageType("livekit.UpdateDataSubscription", () => [{
  no: 1,
  name: "updates",
  kind: "message",
  T: Ju,
  repeated: !0
}]), Ju = /* @__PURE__ */ S.makeMessageType("livekit.UpdateDataSubscription.Update", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "subscribe",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 3,
  name: "options",
  kind: "message",
  T: Ou
}], {
  localName: "UpdateDataSubscription_Update"
}), Uc = /* @__PURE__ */ S.makeMessageType("livekit.UpdateTrackSettings", () => [{
  no: 1,
  name: "track_sids",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 3,
  name: "disabled",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 4,
  name: "quality",
  kind: "enum",
  T: S.getEnumType(Pr)
}, {
  no: 5,
  name: "width",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 6,
  name: "height",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 7,
  name: "fps",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 8,
  name: "priority",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), Nr = /* @__PURE__ */ S.makeMessageType("livekit.UpdateLocalAudioTrack", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "features",
  kind: "enum",
  T: S.getEnumType(He),
  repeated: !0
}]), Fc = /* @__PURE__ */ S.makeMessageType("livekit.UpdateLocalVideoTrack", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "width",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 3,
  name: "height",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), os = /* @__PURE__ */ S.makeMessageType("livekit.LeaveRequest", () => [{
  no: 1,
  name: "can_reconnect",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 2,
  name: "reason",
  kind: "enum",
  T: S.getEnumType(yt)
}, {
  no: 3,
  name: "action",
  kind: "enum",
  T: S.getEnumType(Mi)
}, {
  no: 4,
  name: "regions",
  kind: "message",
  T: ch
}]), Mi = /* @__PURE__ */ S.makeEnum("livekit.LeaveRequest.Action", [{
  no: 0,
  name: "DISCONNECT"
}, {
  no: 1,
  name: "RESUME"
}, {
  no: 2,
  name: "RECONNECT"
}]), Vc = /* @__PURE__ */ S.makeMessageType("livekit.UpdateVideoLayers", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "layers",
  kind: "message",
  T: Kt,
  repeated: !0
}]), Ur = /* @__PURE__ */ S.makeMessageType("livekit.UpdateParticipantMetadata", () => [{
  no: 1,
  name: "metadata",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "name",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "attributes",
  kind: "map",
  K: 9,
  V: {
    kind: "scalar",
    T: 9
    /* ScalarType.STRING */
  }
}, {
  no: 4,
  name: "request_id",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), Bc = /* @__PURE__ */ S.makeMessageType("livekit.ICEServer", () => [{
  no: 1,
  name: "urls",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 2,
  name: "username",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "credential",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), Yu = /* @__PURE__ */ S.makeMessageType("livekit.SpeakersChanged", () => [{
  no: 1,
  name: "speakers",
  kind: "message",
  T: Tc,
  repeated: !0
}]), Qu = /* @__PURE__ */ S.makeMessageType("livekit.RoomUpdate", () => [{
  no: 1,
  name: "room",
  kind: "message",
  T: ns
}]), Xu = /* @__PURE__ */ S.makeMessageType("livekit.ConnectionQualityInfo", () => [{
  no: 1,
  name: "participant_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "quality",
  kind: "enum",
  T: S.getEnumType(en)
}, {
  no: 3,
  name: "score",
  kind: "scalar",
  T: 2
  /* ScalarType.FLOAT */
}]), Zu = /* @__PURE__ */ S.makeMessageType("livekit.ConnectionQualityUpdate", () => [{
  no: 1,
  name: "updates",
  kind: "message",
  T: Xu,
  repeated: !0
}]), eh = /* @__PURE__ */ S.makeMessageType("livekit.StreamStateInfo", () => [{
  no: 1,
  name: "participant_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "state",
  kind: "enum",
  T: S.getEnumType(Js)
}]), th = /* @__PURE__ */ S.makeMessageType("livekit.StreamStateUpdate", () => [{
  no: 1,
  name: "stream_states",
  kind: "message",
  T: eh,
  repeated: !0
}]), Fr = /* @__PURE__ */ S.makeMessageType("livekit.SubscribedQuality", () => [{
  no: 1,
  name: "quality",
  kind: "enum",
  T: S.getEnumType(Pr)
}, {
  no: 2,
  name: "enabled",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), ih = /* @__PURE__ */ S.makeMessageType("livekit.SubscribedCodec", () => [{
  no: 1,
  name: "codec",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "qualities",
  kind: "message",
  T: Fr,
  repeated: !0
}]), nh = /* @__PURE__ */ S.makeMessageType("livekit.SubscribedQualityUpdate", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "subscribed_qualities",
  kind: "message",
  T: Fr,
  repeated: !0
}, {
  no: 3,
  name: "subscribed_codecs",
  kind: "message",
  T: ih,
  repeated: !0
}]), sh = /* @__PURE__ */ S.makeMessageType("livekit.SubscribedAudioCodecUpdate", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "subscribed_audio_codecs",
  kind: "message",
  T: Fu,
  repeated: !0
}]), jc = /* @__PURE__ */ S.makeMessageType("livekit.TrackPermission", () => [{
  no: 1,
  name: "participant_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "all_tracks",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 3,
  name: "track_sids",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 4,
  name: "participant_identity",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), qc = /* @__PURE__ */ S.makeMessageType("livekit.SubscriptionPermission", () => [{
  no: 1,
  name: "all_participants",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 2,
  name: "track_permissions",
  kind: "message",
  T: jc,
  repeated: !0
}]), rh = /* @__PURE__ */ S.makeMessageType("livekit.SubscriptionPermissionUpdate", () => [{
  no: 1,
  name: "participant_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "allowed",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}]), ah = /* @__PURE__ */ S.makeMessageType("livekit.RoomMovedResponse", () => [{
  no: 1,
  name: "room",
  kind: "message",
  T: ns
}, {
  no: 2,
  name: "token",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "participant",
  kind: "message",
  T: li
}, {
  no: 4,
  name: "other_participants",
  kind: "message",
  T: li,
  repeated: !0
}]), Vr = /* @__PURE__ */ S.makeMessageType("livekit.SyncState", () => [{
  no: 1,
  name: "answer",
  kind: "message",
  T: Qt
}, {
  no: 2,
  name: "subscription",
  kind: "message",
  T: as
}, {
  no: 3,
  name: "publish_tracks",
  kind: "message",
  T: Lr,
  repeated: !0
}, {
  no: 4,
  name: "data_channels",
  kind: "message",
  T: Wc,
  repeated: !0
}, {
  no: 5,
  name: "offer",
  kind: "message",
  T: Qt
}, {
  no: 6,
  name: "track_sids_disabled",
  kind: "scalar",
  T: 9,
  repeated: !0
}, {
  no: 7,
  name: "datachannel_receive_states",
  kind: "message",
  T: Hc,
  repeated: !0
}, {
  no: 8,
  name: "publish_data_tracks",
  kind: "message",
  T: Lc,
  repeated: !0
}]), Hc = /* @__PURE__ */ S.makeMessageType("livekit.DataChannelReceiveState", () => [{
  no: 1,
  name: "publisher_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "last_seq",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]), Wc = /* @__PURE__ */ S.makeMessageType("livekit.DataChannelInfo", () => [{
  no: 1,
  name: "label",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "id",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 3,
  name: "target",
  kind: "enum",
  T: S.getEnumType(vt)
}]), kt = /* @__PURE__ */ S.makeMessageType("livekit.SimulateScenario", () => [{
  no: 1,
  name: "speaker_update",
  kind: "scalar",
  T: 5,
  oneof: "scenario"
}, {
  no: 2,
  name: "node_failure",
  kind: "scalar",
  T: 8,
  oneof: "scenario"
}, {
  no: 3,
  name: "migration",
  kind: "scalar",
  T: 8,
  oneof: "scenario"
}, {
  no: 4,
  name: "server_leave",
  kind: "scalar",
  T: 8,
  oneof: "scenario"
}, {
  no: 5,
  name: "switch_candidate_protocol",
  kind: "enum",
  T: S.getEnumType(Vu),
  oneof: "scenario"
}, {
  no: 6,
  name: "subscriber_bandwidth",
  kind: "scalar",
  T: 3,
  oneof: "scenario"
}, {
  no: 7,
  name: "disconnect_signal_on_resume",
  kind: "scalar",
  T: 8,
  oneof: "scenario"
}, {
  no: 8,
  name: "disconnect_signal_on_resume_no_messages",
  kind: "scalar",
  T: 8,
  oneof: "scenario"
}, {
  no: 9,
  name: "leave_request_full_reconnect",
  kind: "scalar",
  T: 8,
  oneof: "scenario"
}]), $c = /* @__PURE__ */ S.makeMessageType("livekit.Ping", () => [{
  no: 1,
  name: "timestamp",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 2,
  name: "rtt",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}]), oh = /* @__PURE__ */ S.makeMessageType("livekit.Pong", () => [{
  no: 1,
  name: "last_ping_timestamp",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}, {
  no: 2,
  name: "timestamp",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}]), ch = /* @__PURE__ */ S.makeMessageType("livekit.RegionSettings", () => [{
  no: 1,
  name: "regions",
  kind: "message",
  T: dh,
  repeated: !0
}]), dh = /* @__PURE__ */ S.makeMessageType("livekit.RegionInfo", () => [{
  no: 1,
  name: "region",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "url",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 3,
  name: "distance",
  kind: "scalar",
  T: 3
  /* ScalarType.INT64 */
}]), lh = /* @__PURE__ */ S.makeMessageType("livekit.SubscriptionResponse", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 2,
  name: "err",
  kind: "enum",
  T: S.getEnumType(Pu)
}]), uh = /* @__PURE__ */ S.makeMessageType("livekit.RequestResponse", () => [{
  no: 1,
  name: "request_id",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 2,
  name: "reason",
  kind: "enum",
  T: S.getEnumType(Br)
}, {
  no: 3,
  name: "message",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "trickle",
  kind: "message",
  T: ss,
  oneof: "request"
}, {
  no: 5,
  name: "add_track",
  kind: "message",
  T: dn,
  oneof: "request"
}, {
  no: 6,
  name: "mute",
  kind: "message",
  T: rs,
  oneof: "request"
}, {
  no: 7,
  name: "update_metadata",
  kind: "message",
  T: Ur,
  oneof: "request"
}, {
  no: 8,
  name: "update_audio_track",
  kind: "message",
  T: Nr,
  oneof: "request"
}, {
  no: 9,
  name: "update_video_track",
  kind: "message",
  T: Fc,
  oneof: "request"
}, {
  no: 10,
  name: "publish_data_track",
  kind: "message",
  T: Dc,
  oneof: "request"
}, {
  no: 11,
  name: "unpublish_data_track",
  kind: "message",
  T: Nc,
  oneof: "request"
}]), Br = /* @__PURE__ */ S.makeEnum("livekit.RequestResponse.Reason", [{
  no: 0,
  name: "OK"
}, {
  no: 1,
  name: "NOT_FOUND"
}, {
  no: 2,
  name: "NOT_ALLOWED"
}, {
  no: 3,
  name: "LIMIT_EXCEEDED"
}, {
  no: 4,
  name: "QUEUED"
}, {
  no: 5,
  name: "UNSUPPORTED_TYPE"
}, {
  no: 6,
  name: "UNCLASSIFIED_ERROR"
}, {
  no: 7,
  name: "INVALID_HANDLE"
}, {
  no: 8,
  name: "INVALID_NAME"
}, {
  no: 9,
  name: "DUPLICATE_HANDLE"
}, {
  no: 10,
  name: "DUPLICATE_NAME"
}]), hh = /* @__PURE__ */ S.makeMessageType("livekit.TrackSubscribed", () => [{
  no: 1,
  name: "track_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}]), zc = /* @__PURE__ */ S.makeMessageType("livekit.ConnectionSettings", () => [{
  no: 1,
  name: "auto_subscribe",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 2,
  name: "adaptive_stream",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 3,
  name: "subscriber_allow_pause",
  kind: "scalar",
  T: 8,
  opt: !0
}, {
  no: 4,
  name: "disable_ice_lite",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 5,
  name: "auto_subscribe_data_track",
  kind: "scalar",
  T: 8,
  opt: !0
}]), ph = /* @__PURE__ */ S.makeMessageType("livekit.JoinRequest", () => [{
  no: 1,
  name: "client_info",
  kind: "message",
  T: Ic
}, {
  no: 2,
  name: "connection_settings",
  kind: "message",
  T: zc
}, {
  no: 3,
  name: "metadata",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 4,
  name: "participant_attributes",
  kind: "map",
  K: 9,
  V: {
    kind: "scalar",
    T: 9
    /* ScalarType.STRING */
  }
}, {
  no: 5,
  name: "add_track_requests",
  kind: "message",
  T: dn,
  repeated: !0
}, {
  no: 6,
  name: "publisher_offer",
  kind: "message",
  T: Qt
}, {
  no: 7,
  name: "reconnect",
  kind: "scalar",
  T: 8
  /* ScalarType.BOOL */
}, {
  no: 8,
  name: "reconnect_reason",
  kind: "enum",
  T: S.getEnumType(si)
}, {
  no: 9,
  name: "participant_sid",
  kind: "scalar",
  T: 9
  /* ScalarType.STRING */
}, {
  no: 10,
  name: "sync_state",
  kind: "message",
  T: Vr
}]), mh = /* @__PURE__ */ S.makeMessageType("livekit.WrappedJoinRequest", () => [{
  no: 1,
  name: "compression",
  kind: "enum",
  T: S.getEnumType(fh)
}, {
  no: 2,
  name: "join_request",
  kind: "scalar",
  T: 12
  /* ScalarType.BYTES */
}]), fh = /* @__PURE__ */ S.makeEnum("livekit.WrappedJoinRequest.Compression", [{
  no: 0,
  name: "NONE"
}, {
  no: 1,
  name: "GZIP"
}]), gh = /* @__PURE__ */ S.makeMessageType("livekit.MediaSectionsRequirement", () => [{
  no: 1,
  name: "num_audios",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}, {
  no: 2,
  name: "num_videos",
  kind: "scalar",
  T: 13
  /* ScalarType.UINT32 */
}]);
function vh(n) {
  return n && n.__esModule && Object.prototype.hasOwnProperty.call(n, "default") ? n.default : n;
}
var Pn = { exports: {} }, bh = Pn.exports, Na;
function yh() {
  return Na || (Na = 1, (function(n) {
    (function(e, t) {
      n.exports ? n.exports = t() : e.log = t();
    })(bh, function() {
      var e = function() {
      }, t = "undefined", i = typeof window !== t && typeof window.navigator !== t && /Trident\/|MSIE /.test(window.navigator.userAgent), s = ["trace", "debug", "info", "warn", "error"], r = {}, o = null;
      function a(v, C) {
        var T = v[C];
        if (typeof T.bind == "function")
          return T.bind(v);
        try {
          return Function.prototype.bind.call(T, v);
        } catch {
          return function() {
            return Function.prototype.apply.apply(T, [v, arguments]);
          };
        }
      }
      function c() {
        console.log && (console.log.apply ? console.log.apply(console, arguments) : Function.prototype.apply.apply(console.log, [console, arguments])), console.trace && console.trace();
      }
      function d(v) {
        return v === "debug" && (v = "log"), typeof console === t ? !1 : v === "trace" && i ? c : console[v] !== void 0 ? a(console, v) : console.log !== void 0 ? a(console, "log") : e;
      }
      function l() {
        for (var v = this.getLevel(), C = 0; C < s.length; C++) {
          var T = s[C];
          this[T] = C < v ? e : this.methodFactory(T, v, this.name);
        }
        if (this.log = this.debug, typeof console === t && v < this.levels.SILENT)
          return "No console available for logging";
      }
      function u(v) {
        return function() {
          typeof console !== t && (l.call(this), this[v].apply(this, arguments));
        };
      }
      function h(v, C, T) {
        return d(v) || u.apply(this, arguments);
      }
      function p(v, C) {
        var T = this, P, R, g, f = "loglevel";
        typeof v == "string" ? f += ":" + v : typeof v == "symbol" && (f = void 0);
        function k(N) {
          var L = (s[N] || "silent").toUpperCase();
          if (!(typeof window === t || !f)) {
            try {
              window.localStorage[f] = L;
              return;
            } catch {
            }
            try {
              window.document.cookie = encodeURIComponent(f) + "=" + L + ";";
            } catch {
            }
          }
        }
        function w() {
          var N;
          if (!(typeof window === t || !f)) {
            try {
              N = window.localStorage[f];
            } catch {
            }
            if (typeof N === t)
              try {
                var L = window.document.cookie, B = encodeURIComponent(f), Q = L.indexOf(B + "=");
                Q !== -1 && (N = /^([^;]+)/.exec(L.slice(Q + B.length + 1))[1]);
              } catch {
              }
            return T.levels[N] === void 0 && (N = void 0), N;
          }
        }
        function D() {
          if (!(typeof window === t || !f)) {
            try {
              window.localStorage.removeItem(f);
            } catch {
            }
            try {
              window.document.cookie = encodeURIComponent(f) + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
            } catch {
            }
          }
        }
        function A(N) {
          var L = N;
          if (typeof L == "string" && T.levels[L.toUpperCase()] !== void 0 && (L = T.levels[L.toUpperCase()]), typeof L == "number" && L >= 0 && L <= T.levels.SILENT)
            return L;
          throw new TypeError("log.setLevel() called with invalid level: " + N);
        }
        T.name = v, T.levels = {
          TRACE: 0,
          DEBUG: 1,
          INFO: 2,
          WARN: 3,
          ERROR: 4,
          SILENT: 5
        }, T.methodFactory = C || h, T.getLevel = function() {
          return g != null ? g : R != null ? R : P;
        }, T.setLevel = function(N, L) {
          return g = A(N), L !== !1 && k(g), l.call(T);
        }, T.setDefaultLevel = function(N) {
          R = A(N), w() || T.setLevel(N, !1);
        }, T.resetLevel = function() {
          g = null, D(), l.call(T);
        }, T.enableAll = function(N) {
          T.setLevel(T.levels.TRACE, N);
        }, T.disableAll = function(N) {
          T.setLevel(T.levels.SILENT, N);
        }, T.rebuild = function() {
          if (o !== T && (P = A(o.getLevel())), l.call(T), o === T)
            for (var N in r)
              r[N].rebuild();
        }, P = A(o ? o.getLevel() : "WARN");
        var O = w();
        O != null && (g = A(O)), l.call(T);
      }
      o = new p(), o.getLogger = function(C) {
        if (typeof C != "symbol" && typeof C != "string" || C === "")
          throw new TypeError("You must supply a name when creating a logger.");
        var T = r[C];
        return T || (T = r[C] = new p(C, o.methodFactory)), T;
      };
      var b = typeof window !== t ? window.log : void 0;
      return o.noConflict = function() {
        return typeof window !== t && window.log === o && (window.log = b), o;
      }, o.getLoggers = function() {
        return r;
      }, o.default = o, o;
    });
  })(Pn)), Pn.exports;
}
var cs = yh(), Qs;
(function(n) {
  n[n.trace = 0] = "trace", n[n.debug = 1] = "debug", n[n.info = 2] = "info", n[n.warn = 3] = "warn", n[n.error = 4] = "error", n[n.silent = 5] = "silent";
})(Qs || (Qs = {}));
var at;
(function(n) {
  n.Default = "livekit", n.Room = "livekit-room", n.TokenSource = "livekit-token-source", n.Participant = "livekit-participant", n.Track = "livekit-track", n.Publication = "livekit-track-publication", n.Engine = "livekit-engine", n.Signal = "livekit-signal", n.PCManager = "livekit-pc-manager", n.PCTransport = "livekit-pc-transport", n.E2EE = "lk-e2ee", n.DataTracks = "livekit-data-tracks";
})(at || (at = {}));
let se = cs.getLogger("livekit");
const Sh = Object.values(at).map((n) => cs.getLogger(n));
se.setDefaultLevel(Qs.info);
function St(n) {
  const e = cs.getLogger(n);
  return e.setDefaultLevel(se.getLevel()), e;
}
function kh(n, e) {
  for (const t of Sh)
    t.setLevel(n);
}
const Th = cs.getLogger("lk-e2ee"), $i = 7e3, Ch = [0, 300, 4 * 300, 9 * 300, 16 * 300, $i, $i, $i, $i, $i];
class Kc {
  constructor(e) {
    this._retryDelays = e !== void 0 ? [...e] : Ch;
  }
  nextRetryDelayInMs(e) {
    if (e.retryCount >= this._retryDelays.length) return null;
    const t = this._retryDelays[e.retryCount];
    return e.retryCount <= 1 ? t : t + Math.random() * 1e3;
  }
}
function _h(n, e) {
  var t = {};
  for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && e.indexOf(i) < 0 && (t[i] = n[i]);
  if (n != null && typeof Object.getOwnPropertySymbols == "function")
    for (var s = 0, i = Object.getOwnPropertySymbols(n); s < i.length; s++)
      e.indexOf(i[s]) < 0 && Object.prototype.propertyIsEnumerable.call(n, i[s]) && (t[i[s]] = n[i[s]]);
  return t;
}
function m(n, e, t, i) {
  function s(r) {
    return r instanceof t ? r : new t(function(o) {
      o(r);
    });
  }
  return new (t || (t = Promise))(function(r, o) {
    function a(l) {
      try {
        d(i.next(l));
      } catch (u) {
        o(u);
      }
    }
    function c(l) {
      try {
        d(i.throw(l));
      } catch (u) {
        o(u);
      }
    }
    function d(l) {
      l.done ? r(l.value) : s(l.value).then(a, c);
    }
    d((i = i.apply(n, e || [])).next());
  });
}
function Ua(n) {
  var e = typeof Symbol == "function" && Symbol.iterator, t = e && n[e], i = 0;
  if (t) return t.call(n);
  if (n && typeof n.length == "number") return {
    next: function() {
      return n && i >= n.length && (n = void 0), { value: n && n[i++], done: !n };
    }
  };
  throw new TypeError(e ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function Nt(n) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var e = n[Symbol.asyncIterator], t;
  return e ? e.call(n) : (n = typeof Ua == "function" ? Ua(n) : n[Symbol.iterator](), t = {}, i("next"), i("throw"), i("return"), t[Symbol.asyncIterator] = function() {
    return this;
  }, t);
  function i(r) {
    t[r] = n[r] && function(o) {
      return new Promise(function(a, c) {
        o = n[r](o), s(a, c, o.done, o.value);
      });
    };
  }
  function s(r, o, a, c) {
    Promise.resolve(c).then(function(d) {
      r({ value: d, done: a });
    }, o);
  }
}
var Sn = { exports: {} }, Fa;
function wh() {
  if (Fa) return Sn.exports;
  Fa = 1;
  var n = typeof Reflect == "object" ? Reflect : null, e = n && typeof n.apply == "function" ? n.apply : function(f, k, w) {
    return Function.prototype.apply.call(f, k, w);
  }, t;
  n && typeof n.ownKeys == "function" ? t = n.ownKeys : Object.getOwnPropertySymbols ? t = function(f) {
    return Object.getOwnPropertyNames(f).concat(Object.getOwnPropertySymbols(f));
  } : t = function(f) {
    return Object.getOwnPropertyNames(f);
  };
  function i(g) {
    console && console.warn && console.warn(g);
  }
  var s = Number.isNaN || function(f) {
    return f !== f;
  };
  function r() {
    r.init.call(this);
  }
  Sn.exports = r, Sn.exports.once = T, r.EventEmitter = r, r.prototype._events = void 0, r.prototype._eventsCount = 0, r.prototype._maxListeners = void 0;
  var o = 10;
  function a(g) {
    if (typeof g != "function")
      throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof g);
  }
  Object.defineProperty(r, "defaultMaxListeners", {
    enumerable: !0,
    get: function() {
      return o;
    },
    set: function(g) {
      if (typeof g != "number" || g < 0 || s(g))
        throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + g + ".");
      o = g;
    }
  }), r.init = function() {
    (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
  }, r.prototype.setMaxListeners = function(f) {
    if (typeof f != "number" || f < 0 || s(f))
      throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + f + ".");
    return this._maxListeners = f, this;
  };
  function c(g) {
    return g._maxListeners === void 0 ? r.defaultMaxListeners : g._maxListeners;
  }
  r.prototype.getMaxListeners = function() {
    return c(this);
  }, r.prototype.emit = function(f) {
    for (var k = [], w = 1; w < arguments.length; w++) k.push(arguments[w]);
    var D = f === "error", A = this._events;
    if (A !== void 0) D = D && A.error === void 0;
    else if (!D) return !1;
    if (D) {
      var O;
      if (k.length > 0 && (O = k[0]), O instanceof Error)
        throw O;
      var N = new Error("Unhandled error." + (O ? " (" + O.message + ")" : ""));
      throw N.context = O, N;
    }
    var L = A[f];
    if (L === void 0) return !1;
    if (typeof L == "function")
      e(L, this, k);
    else
      for (var B = L.length, Q = b(L, B), w = 0; w < B; ++w) e(Q[w], this, k);
    return !0;
  };
  function d(g, f, k, w) {
    var D, A, O;
    if (a(k), A = g._events, A === void 0 ? (A = g._events = /* @__PURE__ */ Object.create(null), g._eventsCount = 0) : (A.newListener !== void 0 && (g.emit("newListener", f, k.listener ? k.listener : k), A = g._events), O = A[f]), O === void 0)
      O = A[f] = k, ++g._eventsCount;
    else if (typeof O == "function" ? O = A[f] = w ? [k, O] : [O, k] : w ? O.unshift(k) : O.push(k), D = c(g), D > 0 && O.length > D && !O.warned) {
      O.warned = !0;
      var N = new Error("Possible EventEmitter memory leak detected. " + O.length + " " + String(f) + " listeners added. Use emitter.setMaxListeners() to increase limit");
      N.name = "MaxListenersExceededWarning", N.emitter = g, N.type = f, N.count = O.length, i(N);
    }
    return g;
  }
  r.prototype.addListener = function(f, k) {
    return d(this, f, k, !1);
  }, r.prototype.on = r.prototype.addListener, r.prototype.prependListener = function(f, k) {
    return d(this, f, k, !0);
  };
  function l() {
    if (!this.fired)
      return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
  }
  function u(g, f, k) {
    var w = {
      fired: !1,
      wrapFn: void 0,
      target: g,
      type: f,
      listener: k
    }, D = l.bind(w);
    return D.listener = k, w.wrapFn = D, D;
  }
  r.prototype.once = function(f, k) {
    return a(k), this.on(f, u(this, f, k)), this;
  }, r.prototype.prependOnceListener = function(f, k) {
    return a(k), this.prependListener(f, u(this, f, k)), this;
  }, r.prototype.removeListener = function(f, k) {
    var w, D, A, O, N;
    if (a(k), D = this._events, D === void 0) return this;
    if (w = D[f], w === void 0) return this;
    if (w === k || w.listener === k)
      --this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : (delete D[f], D.removeListener && this.emit("removeListener", f, w.listener || k));
    else if (typeof w != "function") {
      for (A = -1, O = w.length - 1; O >= 0; O--)
        if (w[O] === k || w[O].listener === k) {
          N = w[O].listener, A = O;
          break;
        }
      if (A < 0) return this;
      A === 0 ? w.shift() : v(w, A), w.length === 1 && (D[f] = w[0]), D.removeListener !== void 0 && this.emit("removeListener", f, N || k);
    }
    return this;
  }, r.prototype.off = r.prototype.removeListener, r.prototype.removeAllListeners = function(f) {
    var k, w, D;
    if (w = this._events, w === void 0) return this;
    if (w.removeListener === void 0)
      return arguments.length === 0 ? (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0) : w[f] !== void 0 && (--this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : delete w[f]), this;
    if (arguments.length === 0) {
      var A = Object.keys(w), O;
      for (D = 0; D < A.length; ++D)
        O = A[D], O !== "removeListener" && this.removeAllListeners(O);
      return this.removeAllListeners("removeListener"), this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0, this;
    }
    if (k = w[f], typeof k == "function")
      this.removeListener(f, k);
    else if (k !== void 0)
      for (D = k.length - 1; D >= 0; D--)
        this.removeListener(f, k[D]);
    return this;
  };
  function h(g, f, k) {
    var w = g._events;
    if (w === void 0) return [];
    var D = w[f];
    return D === void 0 ? [] : typeof D == "function" ? k ? [D.listener || D] : [D] : k ? C(D) : b(D, D.length);
  }
  r.prototype.listeners = function(f) {
    return h(this, f, !0);
  }, r.prototype.rawListeners = function(f) {
    return h(this, f, !1);
  }, r.listenerCount = function(g, f) {
    return typeof g.listenerCount == "function" ? g.listenerCount(f) : p.call(g, f);
  }, r.prototype.listenerCount = p;
  function p(g) {
    var f = this._events;
    if (f !== void 0) {
      var k = f[g];
      if (typeof k == "function")
        return 1;
      if (k !== void 0)
        return k.length;
    }
    return 0;
  }
  r.prototype.eventNames = function() {
    return this._eventsCount > 0 ? t(this._events) : [];
  };
  function b(g, f) {
    for (var k = new Array(f), w = 0; w < f; ++w) k[w] = g[w];
    return k;
  }
  function v(g, f) {
    for (; f + 1 < g.length; f++) g[f] = g[f + 1];
    g.pop();
  }
  function C(g) {
    for (var f = new Array(g.length), k = 0; k < f.length; ++k)
      f[k] = g[k].listener || g[k];
    return f;
  }
  function T(g, f) {
    return new Promise(function(k, w) {
      function D(O) {
        g.removeListener(f, A), w(O);
      }
      function A() {
        typeof g.removeListener == "function" && g.removeListener("error", D), k([].slice.call(arguments));
      }
      R(g, f, A, {
        once: !0
      }), f !== "error" && P(g, D, {
        once: !0
      });
    });
  }
  function P(g, f, k) {
    typeof g.on == "function" && R(g, "error", f, k);
  }
  function R(g, f, k, w) {
    if (typeof g.on == "function")
      w.once ? g.once(f, k) : g.on(f, k);
    else if (typeof g.addEventListener == "function")
      g.addEventListener(f, function D(A) {
        w.once && g.removeEventListener(f, D), k(A);
      });
    else
      throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof g);
  }
  return Sn.exports;
}
var Pt = wh();
let Gc = !0, Jc = !0;
function tn(n, e, t) {
  const i = n.match(e);
  return i && i.length >= t && parseFloat(i[t], 10);
}
function pi(n, e, t) {
  if (!n.RTCPeerConnection)
    return;
  const i = n.RTCPeerConnection.prototype, s = i.addEventListener;
  i.addEventListener = function(o, a) {
    if (o !== e)
      return s.apply(this, arguments);
    const c = (d) => {
      const l = t(d);
      l && (a.handleEvent ? a.handleEvent(l) : a(l));
    };
    return this._eventMap = this._eventMap || {}, this._eventMap[e] || (this._eventMap[e] = /* @__PURE__ */ new Map()), this._eventMap[e].set(a, c), s.apply(this, [o, c]);
  };
  const r = i.removeEventListener;
  i.removeEventListener = function(o, a) {
    if (o !== e || !this._eventMap || !this._eventMap[e])
      return r.apply(this, arguments);
    if (!this._eventMap[e].has(a))
      return r.apply(this, arguments);
    const c = this._eventMap[e].get(a);
    return this._eventMap[e].delete(a), this._eventMap[e].size === 0 && delete this._eventMap[e], Object.keys(this._eventMap).length === 0 && delete this._eventMap, r.apply(this, [o, c]);
  }, Object.defineProperty(i, "on" + e, {
    get() {
      return this["_on" + e];
    },
    set(o) {
      this["_on" + e] && (this.removeEventListener(e, this["_on" + e]), delete this["_on" + e]), o && this.addEventListener(e, this["_on" + e] = o);
    },
    enumerable: !0,
    configurable: !0
  });
}
function Eh(n) {
  return typeof n != "boolean" ? new Error("Argument type: " + typeof n + ". Please use a boolean.") : (Gc = n, n ? "adapter.js logging disabled" : "adapter.js logging enabled");
}
function Rh(n) {
  return typeof n != "boolean" ? new Error("Argument type: " + typeof n + ". Please use a boolean.") : (Jc = !n, "adapter.js deprecation warnings " + (n ? "disabled" : "enabled"));
}
function Yc() {
  if (typeof window == "object") {
    if (Gc)
      return;
    typeof console != "undefined" && typeof console.log == "function" && console.log.apply(console, arguments);
  }
}
function jr(n, e) {
  Jc && console.warn(n + " is deprecated, please use " + e + " instead.");
}
function Ih(n) {
  const e = {
    browser: null,
    version: null
  };
  if (typeof n == "undefined" || !n.navigator || !n.navigator.userAgent)
    return e.browser = "Not a browser.", e;
  const {
    navigator: t
  } = n;
  if (t.userAgentData && t.userAgentData.brands) {
    const i = t.userAgentData.brands.find((s) => s.brand === "Chromium");
    if (i)
      return {
        browser: "chrome",
        version: parseInt(i.version, 10)
      };
  }
  if (t.mozGetUserMedia)
    e.browser = "firefox", e.version = parseInt(tn(t.userAgent, /Firefox\/(\d+)\./, 1));
  else if (t.webkitGetUserMedia || n.isSecureContext === !1 && n.webkitRTCPeerConnection)
    e.browser = "chrome", e.version = parseInt(tn(t.userAgent, /Chrom(e|ium)\/(\d+)\./, 2));
  else if (n.RTCPeerConnection && t.userAgent.match(/AppleWebKit\/(\d+)\./))
    e.browser = "safari", e.version = parseInt(tn(t.userAgent, /AppleWebKit\/(\d+)\./, 1)), e.supportsUnifiedPlan = n.RTCRtpTransceiver && "currentDirection" in n.RTCRtpTransceiver.prototype, e._safariVersion = tn(t.userAgent, /Version\/(\d+(\.?\d+))/, 1);
  else
    return e.browser = "Not a supported browser.", e;
  return e;
}
function Va(n) {
  return Object.prototype.toString.call(n) === "[object Object]";
}
function Qc(n) {
  return Va(n) ? Object.keys(n).reduce(function(e, t) {
    const i = Va(n[t]), s = i ? Qc(n[t]) : n[t], r = i && !Object.keys(s).length;
    return s === void 0 || r ? e : Object.assign(e, {
      [t]: s
    });
  }, {}) : n;
}
function Xs(n, e, t) {
  !e || t.has(e.id) || (t.set(e.id, e), Object.keys(e).forEach((i) => {
    i.endsWith("Id") ? Xs(n, n.get(e[i]), t) : i.endsWith("Ids") && e[i].forEach((s) => {
      Xs(n, n.get(s), t);
    });
  }));
}
function Ba(n, e, t) {
  const i = t ? "outbound-rtp" : "inbound-rtp", s = /* @__PURE__ */ new Map();
  if (e === null)
    return s;
  const r = [];
  return n.forEach((o) => {
    o.type === "track" && o.trackIdentifier === e.id && r.push(o);
  }), r.forEach((o) => {
    n.forEach((a) => {
      a.type === i && a.trackId === o.id && Xs(n, a, s);
    });
  }), s;
}
const ja = Yc;
function Xc(n, e) {
  const t = n && n.navigator;
  if (!t.mediaDevices)
    return;
  const i = function(a) {
    if (typeof a != "object" || a.mandatory || a.optional)
      return a;
    const c = {};
    return Object.keys(a).forEach((d) => {
      if (d === "require" || d === "advanced" || d === "mediaSource")
        return;
      const l = typeof a[d] == "object" ? a[d] : {
        ideal: a[d]
      };
      l.exact !== void 0 && typeof l.exact == "number" && (l.min = l.max = l.exact);
      const u = function(h, p) {
        return h ? h + p.charAt(0).toUpperCase() + p.slice(1) : p === "deviceId" ? "sourceId" : p;
      };
      if (l.ideal !== void 0) {
        c.optional = c.optional || [];
        let h = {};
        typeof l.ideal == "number" ? (h[u("min", d)] = l.ideal, c.optional.push(h), h = {}, h[u("max", d)] = l.ideal, c.optional.push(h)) : (h[u("", d)] = l.ideal, c.optional.push(h));
      }
      l.exact !== void 0 && typeof l.exact != "number" ? (c.mandatory = c.mandatory || {}, c.mandatory[u("", d)] = l.exact) : ["min", "max"].forEach((h) => {
        l[h] !== void 0 && (c.mandatory = c.mandatory || {}, c.mandatory[u(h, d)] = l[h]);
      });
    }), a.advanced && (c.optional = (c.optional || []).concat(a.advanced)), c;
  }, s = function(a, c) {
    if (e.version >= 61)
      return c(a);
    if (a = JSON.parse(JSON.stringify(a)), a && typeof a.audio == "object") {
      const d = function(l, u, h) {
        u in l && !(h in l) && (l[h] = l[u], delete l[u]);
      };
      a = JSON.parse(JSON.stringify(a)), d(a.audio, "autoGainControl", "googAutoGainControl"), d(a.audio, "noiseSuppression", "googNoiseSuppression"), a.audio = i(a.audio);
    }
    if (a && typeof a.video == "object") {
      let d = a.video.facingMode;
      d = d && (typeof d == "object" ? d : {
        ideal: d
      });
      const l = e.version < 66;
      if (d && (d.exact === "user" || d.exact === "environment" || d.ideal === "user" || d.ideal === "environment") && !(t.mediaDevices.getSupportedConstraints && t.mediaDevices.getSupportedConstraints().facingMode && !l)) {
        delete a.video.facingMode;
        let u;
        if (d.exact === "environment" || d.ideal === "environment" ? u = ["back", "rear"] : (d.exact === "user" || d.ideal === "user") && (u = ["front"]), u)
          return t.mediaDevices.enumerateDevices().then((h) => {
            h = h.filter((b) => b.kind === "videoinput");
            let p = h.find((b) => u.some((v) => b.label.toLowerCase().includes(v)));
            return !p && h.length && u.includes("back") && (p = h[h.length - 1]), p && (a.video.deviceId = d.exact ? {
              exact: p.deviceId
            } : {
              ideal: p.deviceId
            }), a.video = i(a.video), ja("chrome: " + JSON.stringify(a)), c(a);
          });
      }
      a.video = i(a.video);
    }
    return ja("chrome: " + JSON.stringify(a)), c(a);
  }, r = function(a) {
    return e.version >= 64 ? a : {
      name: {
        PermissionDeniedError: "NotAllowedError",
        PermissionDismissedError: "NotAllowedError",
        InvalidStateError: "NotAllowedError",
        DevicesNotFoundError: "NotFoundError",
        ConstraintNotSatisfiedError: "OverconstrainedError",
        TrackStartError: "NotReadableError",
        MediaDeviceFailedDueToShutdown: "NotAllowedError",
        MediaDeviceKillSwitchOn: "NotAllowedError",
        TabCaptureError: "AbortError",
        ScreenCaptureError: "AbortError",
        DeviceCaptureError: "AbortError"
      }[a.name] || a.name,
      message: a.message,
      constraint: a.constraint || a.constraintName,
      toString() {
        return this.name + (this.message && ": ") + this.message;
      }
    };
  }, o = function(a, c, d) {
    s(a, (l) => {
      t.webkitGetUserMedia(l, c, (u) => {
        d && d(r(u));
      });
    });
  };
  if (t.getUserMedia = o.bind(t), t.mediaDevices.getUserMedia) {
    const a = t.mediaDevices.getUserMedia.bind(t.mediaDevices);
    t.mediaDevices.getUserMedia = function(c) {
      return s(c, (d) => a(d).then((l) => {
        if (d.audio && !l.getAudioTracks().length || d.video && !l.getVideoTracks().length)
          throw l.getTracks().forEach((u) => {
            u.stop();
          }), new DOMException("", "NotFoundError");
        return l;
      }, (l) => Promise.reject(r(l))));
    };
  }
}
function Zc(n) {
  n.MediaStream = n.MediaStream || n.webkitMediaStream;
}
function ed(n) {
  if (typeof n == "object" && n.RTCPeerConnection && !("ontrack" in n.RTCPeerConnection.prototype)) {
    Object.defineProperty(n.RTCPeerConnection.prototype, "ontrack", {
      get() {
        return this._ontrack;
      },
      set(t) {
        this._ontrack && this.removeEventListener("track", this._ontrack), this.addEventListener("track", this._ontrack = t);
      },
      enumerable: !0,
      configurable: !0
    });
    const e = n.RTCPeerConnection.prototype.setRemoteDescription;
    n.RTCPeerConnection.prototype.setRemoteDescription = function() {
      return this._ontrackpoly || (this._ontrackpoly = (i) => {
        i.stream.addEventListener("addtrack", (s) => {
          let r;
          n.RTCPeerConnection.prototype.getReceivers ? r = this.getReceivers().find((a) => a.track && a.track.id === s.track.id) : r = {
            track: s.track
          };
          const o = new Event("track");
          o.track = s.track, o.receiver = r, o.transceiver = {
            receiver: r
          }, o.streams = [i.stream], this.dispatchEvent(o);
        }), i.stream.getTracks().forEach((s) => {
          let r;
          n.RTCPeerConnection.prototype.getReceivers ? r = this.getReceivers().find((a) => a.track && a.track.id === s.id) : r = {
            track: s
          };
          const o = new Event("track");
          o.track = s, o.receiver = r, o.transceiver = {
            receiver: r
          }, o.streams = [i.stream], this.dispatchEvent(o);
        });
      }, this.addEventListener("addstream", this._ontrackpoly)), e.apply(this, arguments);
    };
  } else
    pi(n, "track", (e) => (e.transceiver || Object.defineProperty(e, "transceiver", {
      value: {
        receiver: e.receiver
      }
    }), e));
}
function td(n) {
  if (typeof n == "object" && n.RTCPeerConnection && !("getSenders" in n.RTCPeerConnection.prototype) && "createDTMFSender" in n.RTCPeerConnection.prototype) {
    const e = function(s, r) {
      return {
        track: r,
        get dtmf() {
          return this._dtmf === void 0 && (r.kind === "audio" ? this._dtmf = s.createDTMFSender(r) : this._dtmf = null), this._dtmf;
        },
        _pc: s
      };
    };
    if (!n.RTCPeerConnection.prototype.getSenders) {
      n.RTCPeerConnection.prototype.getSenders = function() {
        return this._senders = this._senders || [], this._senders.slice();
      };
      const s = n.RTCPeerConnection.prototype.addTrack;
      n.RTCPeerConnection.prototype.addTrack = function(a, c) {
        let d = s.apply(this, arguments);
        return d || (d = e(this, a), this._senders.push(d)), d;
      };
      const r = n.RTCPeerConnection.prototype.removeTrack;
      n.RTCPeerConnection.prototype.removeTrack = function(a) {
        r.apply(this, arguments);
        const c = this._senders.indexOf(a);
        c !== -1 && this._senders.splice(c, 1);
      };
    }
    const t = n.RTCPeerConnection.prototype.addStream;
    n.RTCPeerConnection.prototype.addStream = function(r) {
      this._senders = this._senders || [], t.apply(this, [r]), r.getTracks().forEach((o) => {
        this._senders.push(e(this, o));
      });
    };
    const i = n.RTCPeerConnection.prototype.removeStream;
    n.RTCPeerConnection.prototype.removeStream = function(r) {
      this._senders = this._senders || [], i.apply(this, [r]), r.getTracks().forEach((o) => {
        const a = this._senders.find((c) => c.track === o);
        a && this._senders.splice(this._senders.indexOf(a), 1);
      });
    };
  } else if (typeof n == "object" && n.RTCPeerConnection && "getSenders" in n.RTCPeerConnection.prototype && "createDTMFSender" in n.RTCPeerConnection.prototype && n.RTCRtpSender && !("dtmf" in n.RTCRtpSender.prototype)) {
    const e = n.RTCPeerConnection.prototype.getSenders;
    n.RTCPeerConnection.prototype.getSenders = function() {
      const i = e.apply(this, []);
      return i.forEach((s) => s._pc = this), i;
    }, Object.defineProperty(n.RTCRtpSender.prototype, "dtmf", {
      get() {
        return this._dtmf === void 0 && (this.track.kind === "audio" ? this._dtmf = this._pc.createDTMFSender(this.track) : this._dtmf = null), this._dtmf;
      }
    });
  }
}
function id(n) {
  if (!(typeof n == "object" && n.RTCPeerConnection && n.RTCRtpSender && n.RTCRtpReceiver))
    return;
  if (!("getStats" in n.RTCRtpSender.prototype)) {
    const t = n.RTCPeerConnection.prototype.getSenders;
    t && (n.RTCPeerConnection.prototype.getSenders = function() {
      const r = t.apply(this, []);
      return r.forEach((o) => o._pc = this), r;
    });
    const i = n.RTCPeerConnection.prototype.addTrack;
    i && (n.RTCPeerConnection.prototype.addTrack = function() {
      const r = i.apply(this, arguments);
      return r._pc = this, r;
    }), n.RTCRtpSender.prototype.getStats = function() {
      const r = this;
      return this._pc.getStats().then((o) => (
        /* Note: this will include stats of all senders that
         *   send a track with the same id as sender.track as
         *   it is not possible to identify the RTCRtpSender.
         */
        Ba(o, r.track, !0)
      ));
    };
  }
  if (!("getStats" in n.RTCRtpReceiver.prototype)) {
    const t = n.RTCPeerConnection.prototype.getReceivers;
    t && (n.RTCPeerConnection.prototype.getReceivers = function() {
      const s = t.apply(this, []);
      return s.forEach((r) => r._pc = this), s;
    }), pi(n, "track", (i) => (i.receiver._pc = i.srcElement, i)), n.RTCRtpReceiver.prototype.getStats = function() {
      const s = this;
      return this._pc.getStats().then((r) => Ba(r, s.track, !1));
    };
  }
  if (!("getStats" in n.RTCRtpSender.prototype && "getStats" in n.RTCRtpReceiver.prototype))
    return;
  const e = n.RTCPeerConnection.prototype.getStats;
  n.RTCPeerConnection.prototype.getStats = function() {
    if (arguments.length > 0 && arguments[0] instanceof n.MediaStreamTrack) {
      const i = arguments[0];
      let s, r, o;
      return this.getSenders().forEach((a) => {
        a.track === i && (s ? o = !0 : s = a);
      }), this.getReceivers().forEach((a) => (a.track === i && (r ? o = !0 : r = a), a.track === i)), o || s && r ? Promise.reject(new DOMException("There are more than one sender or receiver for the track.", "InvalidAccessError")) : s ? s.getStats() : r ? r.getStats() : Promise.reject(new DOMException("There is no sender or receiver for the track.", "InvalidAccessError"));
    }
    return e.apply(this, arguments);
  };
}
function nd(n) {
  n.RTCPeerConnection.prototype.getLocalStreams = function() {
    return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, Object.keys(this._shimmedLocalStreams).map((o) => this._shimmedLocalStreams[o][0]);
  };
  const e = n.RTCPeerConnection.prototype.addTrack;
  n.RTCPeerConnection.prototype.addTrack = function(o, a) {
    if (!a)
      return e.apply(this, arguments);
    this._shimmedLocalStreams = this._shimmedLocalStreams || {};
    const c = e.apply(this, arguments);
    return this._shimmedLocalStreams[a.id] ? this._shimmedLocalStreams[a.id].indexOf(c) === -1 && this._shimmedLocalStreams[a.id].push(c) : this._shimmedLocalStreams[a.id] = [a, c], c;
  };
  const t = n.RTCPeerConnection.prototype.addStream;
  n.RTCPeerConnection.prototype.addStream = function(o) {
    this._shimmedLocalStreams = this._shimmedLocalStreams || {}, o.getTracks().forEach((d) => {
      if (this.getSenders().find((u) => u.track === d))
        throw new DOMException("Track already exists.", "InvalidAccessError");
    });
    const a = this.getSenders();
    t.apply(this, arguments);
    const c = this.getSenders().filter((d) => a.indexOf(d) === -1);
    this._shimmedLocalStreams[o.id] = [o].concat(c);
  };
  const i = n.RTCPeerConnection.prototype.removeStream;
  n.RTCPeerConnection.prototype.removeStream = function(o) {
    return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, delete this._shimmedLocalStreams[o.id], i.apply(this, arguments);
  };
  const s = n.RTCPeerConnection.prototype.removeTrack;
  n.RTCPeerConnection.prototype.removeTrack = function(o) {
    return this._shimmedLocalStreams = this._shimmedLocalStreams || {}, o && Object.keys(this._shimmedLocalStreams).forEach((a) => {
      const c = this._shimmedLocalStreams[a].indexOf(o);
      c !== -1 && this._shimmedLocalStreams[a].splice(c, 1), this._shimmedLocalStreams[a].length === 1 && delete this._shimmedLocalStreams[a];
    }), s.apply(this, arguments);
  };
}
function sd(n, e) {
  if (!n.RTCPeerConnection)
    return;
  if (n.RTCPeerConnection.prototype.addTrack && e.version >= 65)
    return nd(n);
  const t = n.RTCPeerConnection.prototype.getLocalStreams;
  n.RTCPeerConnection.prototype.getLocalStreams = function() {
    const l = t.apply(this);
    return this._reverseStreams = this._reverseStreams || {}, l.map((u) => this._reverseStreams[u.id]);
  };
  const i = n.RTCPeerConnection.prototype.addStream;
  n.RTCPeerConnection.prototype.addStream = function(l) {
    if (this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {}, l.getTracks().forEach((u) => {
      if (this.getSenders().find((p) => p.track === u))
        throw new DOMException("Track already exists.", "InvalidAccessError");
    }), !this._reverseStreams[l.id]) {
      const u = new n.MediaStream(l.getTracks());
      this._streams[l.id] = u, this._reverseStreams[u.id] = l, l = u;
    }
    i.apply(this, [l]);
  };
  const s = n.RTCPeerConnection.prototype.removeStream;
  n.RTCPeerConnection.prototype.removeStream = function(l) {
    this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {}, s.apply(this, [this._streams[l.id] || l]), delete this._reverseStreams[this._streams[l.id] ? this._streams[l.id].id : l.id], delete this._streams[l.id];
  }, n.RTCPeerConnection.prototype.addTrack = function(l, u) {
    if (this.signalingState === "closed")
      throw new DOMException("The RTCPeerConnection's signalingState is 'closed'.", "InvalidStateError");
    const h = [].slice.call(arguments, 1);
    if (h.length !== 1 || !h[0].getTracks().find((v) => v === l))
      throw new DOMException("The adapter.js addTrack polyfill only supports a single  stream which is associated with the specified track.", "NotSupportedError");
    if (this.getSenders().find((v) => v.track === l))
      throw new DOMException("Track already exists.", "InvalidAccessError");
    this._streams = this._streams || {}, this._reverseStreams = this._reverseStreams || {};
    const b = this._streams[u.id];
    if (b)
      b.addTrack(l), Promise.resolve().then(() => {
        this.dispatchEvent(new Event("negotiationneeded"));
      });
    else {
      const v = new n.MediaStream([l]);
      this._streams[u.id] = v, this._reverseStreams[v.id] = u, this.addStream(v);
    }
    return this.getSenders().find((v) => v.track === l);
  };
  function r(d, l) {
    let u = l.sdp;
    return Object.keys(d._reverseStreams || []).forEach((h) => {
      const p = d._reverseStreams[h], b = d._streams[p.id];
      u = u.replace(new RegExp(b.id, "g"), p.id);
    }), new RTCSessionDescription({
      type: l.type,
      sdp: u
    });
  }
  function o(d, l) {
    let u = l.sdp;
    return Object.keys(d._reverseStreams || []).forEach((h) => {
      const p = d._reverseStreams[h], b = d._streams[p.id];
      u = u.replace(new RegExp(p.id, "g"), b.id);
    }), new RTCSessionDescription({
      type: l.type,
      sdp: u
    });
  }
  ["createOffer", "createAnswer"].forEach(function(d) {
    const l = n.RTCPeerConnection.prototype[d], u = {
      [d]() {
        const h = arguments;
        return arguments.length && typeof arguments[0] == "function" ? l.apply(this, [(b) => {
          const v = r(this, b);
          h[0].apply(null, [v]);
        }, (b) => {
          h[1] && h[1].apply(null, b);
        }, arguments[2]]) : l.apply(this, arguments).then((b) => r(this, b));
      }
    };
    n.RTCPeerConnection.prototype[d] = u[d];
  });
  const a = n.RTCPeerConnection.prototype.setLocalDescription;
  n.RTCPeerConnection.prototype.setLocalDescription = function() {
    return !arguments.length || !arguments[0].type ? a.apply(this, arguments) : (arguments[0] = o(this, arguments[0]), a.apply(this, arguments));
  };
  const c = Object.getOwnPropertyDescriptor(n.RTCPeerConnection.prototype, "localDescription");
  Object.defineProperty(n.RTCPeerConnection.prototype, "localDescription", {
    get() {
      const d = c.get.apply(this);
      return d.type === "" ? d : r(this, d);
    }
  }), n.RTCPeerConnection.prototype.removeTrack = function(l) {
    if (this.signalingState === "closed")
      throw new DOMException("The RTCPeerConnection's signalingState is 'closed'.", "InvalidStateError");
    if (!l._pc)
      throw new DOMException("Argument 1 of RTCPeerConnection.removeTrack does not implement interface RTCRtpSender.", "TypeError");
    if (!(l._pc === this))
      throw new DOMException("Sender was not created by this connection.", "InvalidAccessError");
    this._streams = this._streams || {};
    let h;
    Object.keys(this._streams).forEach((p) => {
      this._streams[p].getTracks().find((v) => l.track === v) && (h = this._streams[p]);
    }), h && (h.getTracks().length === 1 ? this.removeStream(this._reverseStreams[h.id]) : h.removeTrack(l.track), this.dispatchEvent(new Event("negotiationneeded")));
  };
}
function Zs(n, e) {
  !n.RTCPeerConnection && n.webkitRTCPeerConnection && (n.RTCPeerConnection = n.webkitRTCPeerConnection), n.RTCPeerConnection && e.version < 53 && ["setLocalDescription", "setRemoteDescription", "addIceCandidate"].forEach(function(t) {
    const i = n.RTCPeerConnection.prototype[t], s = {
      [t]() {
        return arguments[0] = new (t === "addIceCandidate" ? n.RTCIceCandidate : n.RTCSessionDescription)(arguments[0]), i.apply(this, arguments);
      }
    };
    n.RTCPeerConnection.prototype[t] = s[t];
  });
}
function rd(n, e) {
  pi(n, "negotiationneeded", (t) => {
    const i = t.target;
    if (!((e.version < 72 || i.getConfiguration && i.getConfiguration().sdpSemantics === "plan-b") && i.signalingState !== "stable"))
      return t;
  });
}
var qa = /* @__PURE__ */ Object.freeze({ __proto__: null, fixNegotiationNeeded: rd, shimAddTrackRemoveTrack: sd, shimAddTrackRemoveTrackWithNative: nd, shimGetSendersWithDtmf: td, shimGetUserMedia: Xc, shimMediaStream: Zc, shimOnTrack: ed, shimPeerConnection: Zs, shimSenderReceiverGetStats: id });
function ad(n, e) {
  const t = n && n.navigator, i = n && n.MediaStreamTrack;
  if (t.getUserMedia = function(s, r, o) {
    jr("navigator.getUserMedia", "navigator.mediaDevices.getUserMedia"), t.mediaDevices.getUserMedia(s).then(r, o);
  }, !(e.version > 55 && "autoGainControl" in t.mediaDevices.getSupportedConstraints())) {
    const s = function(o, a, c) {
      a in o && !(c in o) && (o[c] = o[a], delete o[a]);
    }, r = t.mediaDevices.getUserMedia.bind(t.mediaDevices);
    if (t.mediaDevices.getUserMedia = function(o) {
      return typeof o == "object" && typeof o.audio == "object" && (o = JSON.parse(JSON.stringify(o)), s(o.audio, "autoGainControl", "mozAutoGainControl"), s(o.audio, "noiseSuppression", "mozNoiseSuppression")), r(o);
    }, i && i.prototype.getSettings) {
      const o = i.prototype.getSettings;
      i.prototype.getSettings = function() {
        const a = o.apply(this, arguments);
        return s(a, "mozAutoGainControl", "autoGainControl"), s(a, "mozNoiseSuppression", "noiseSuppression"), a;
      };
    }
    if (i && i.prototype.applyConstraints) {
      const o = i.prototype.applyConstraints;
      i.prototype.applyConstraints = function(a) {
        return this.kind === "audio" && typeof a == "object" && (a = JSON.parse(JSON.stringify(a)), s(a, "autoGainControl", "mozAutoGainControl"), s(a, "noiseSuppression", "mozNoiseSuppression")), o.apply(this, [a]);
      };
    }
  }
}
function Ph(n, e) {
  n.navigator.mediaDevices && "getDisplayMedia" in n.navigator.mediaDevices || n.navigator.mediaDevices && (n.navigator.mediaDevices.getDisplayMedia = function(i) {
    if (!(i && i.video)) {
      const s = new DOMException("getDisplayMedia without video constraints is undefined");
      return s.name = "NotFoundError", s.code = 8, Promise.reject(s);
    }
    return i.video === !0 ? i.video = {
      mediaSource: e
    } : i.video.mediaSource = e, n.navigator.mediaDevices.getUserMedia(i);
  });
}
function od(n) {
  typeof n == "object" && n.RTCTrackEvent && "receiver" in n.RTCTrackEvent.prototype && !("transceiver" in n.RTCTrackEvent.prototype) && Object.defineProperty(n.RTCTrackEvent.prototype, "transceiver", {
    get() {
      return {
        receiver: this.receiver
      };
    }
  });
}
function er(n, e) {
  if (typeof n != "object" || !(n.RTCPeerConnection || n.mozRTCPeerConnection))
    return;
  !n.RTCPeerConnection && n.mozRTCPeerConnection && (n.RTCPeerConnection = n.mozRTCPeerConnection), e.version < 53 && ["setLocalDescription", "setRemoteDescription", "addIceCandidate"].forEach(function(s) {
    const r = n.RTCPeerConnection.prototype[s], o = {
      [s]() {
        return arguments[0] = new (s === "addIceCandidate" ? n.RTCIceCandidate : n.RTCSessionDescription)(arguments[0]), r.apply(this, arguments);
      }
    };
    n.RTCPeerConnection.prototype[s] = o[s];
  });
  const t = {
    inboundrtp: "inbound-rtp",
    outboundrtp: "outbound-rtp",
    candidatepair: "candidate-pair",
    localcandidate: "local-candidate",
    remotecandidate: "remote-candidate"
  }, i = n.RTCPeerConnection.prototype.getStats;
  n.RTCPeerConnection.prototype.getStats = function() {
    const [r, o, a] = arguments;
    return i.apply(this, [r || null]).then((c) => {
      if (e.version < 53 && !o)
        try {
          c.forEach((d) => {
            d.type = t[d.type] || d.type;
          });
        } catch (d) {
          if (d.name !== "TypeError")
            throw d;
          c.forEach((l, u) => {
            c.set(u, Object.assign({}, l, {
              type: t[l.type] || l.type
            }));
          });
        }
      return c;
    }).then(o, a);
  };
}
function cd(n) {
  if (!(typeof n == "object" && n.RTCPeerConnection && n.RTCRtpSender) || n.RTCRtpSender && "getStats" in n.RTCRtpSender.prototype)
    return;
  const e = n.RTCPeerConnection.prototype.getSenders;
  e && (n.RTCPeerConnection.prototype.getSenders = function() {
    const s = e.apply(this, []);
    return s.forEach((r) => r._pc = this), s;
  });
  const t = n.RTCPeerConnection.prototype.addTrack;
  t && (n.RTCPeerConnection.prototype.addTrack = function() {
    const s = t.apply(this, arguments);
    return s._pc = this, s;
  }), n.RTCRtpSender.prototype.getStats = function() {
    return this.track ? this._pc.getStats(this.track) : Promise.resolve(/* @__PURE__ */ new Map());
  };
}
function dd(n) {
  if (!(typeof n == "object" && n.RTCPeerConnection && n.RTCRtpSender) || n.RTCRtpSender && "getStats" in n.RTCRtpReceiver.prototype)
    return;
  const e = n.RTCPeerConnection.prototype.getReceivers;
  e && (n.RTCPeerConnection.prototype.getReceivers = function() {
    const i = e.apply(this, []);
    return i.forEach((s) => s._pc = this), i;
  }), pi(n, "track", (t) => (t.receiver._pc = t.srcElement, t)), n.RTCRtpReceiver.prototype.getStats = function() {
    return this._pc.getStats(this.track);
  };
}
function ld(n) {
  !n.RTCPeerConnection || "removeStream" in n.RTCPeerConnection.prototype || (n.RTCPeerConnection.prototype.removeStream = function(t) {
    jr("removeStream", "removeTrack"), this.getSenders().forEach((i) => {
      i.track && t.getTracks().includes(i.track) && this.removeTrack(i);
    });
  });
}
function ud(n) {
  n.DataChannel && !n.RTCDataChannel && (n.RTCDataChannel = n.DataChannel);
}
function hd(n) {
  if (!(typeof n == "object" && n.RTCPeerConnection))
    return;
  const e = n.RTCPeerConnection.prototype.addTransceiver;
  e && (n.RTCPeerConnection.prototype.addTransceiver = function() {
    this.setParametersPromises = [];
    let i = arguments[1] && arguments[1].sendEncodings;
    i === void 0 && (i = []), i = [...i];
    const s = i.length > 0;
    s && i.forEach((o) => {
      if ("rid" in o && !/^[a-z0-9]{0,16}$/i.test(o.rid))
        throw new TypeError("Invalid RID value provided.");
      if ("scaleResolutionDownBy" in o && !(parseFloat(o.scaleResolutionDownBy) >= 1))
        throw new RangeError("scale_resolution_down_by must be >= 1.0");
      if ("maxFramerate" in o && !(parseFloat(o.maxFramerate) >= 0))
        throw new RangeError("max_framerate must be >= 0.0");
    });
    const r = e.apply(this, arguments);
    if (s) {
      const {
        sender: o
      } = r, a = o.getParameters();
      (!("encodings" in a) || // Avoid being fooled by patched getParameters() below.
      a.encodings.length === 1 && Object.keys(a.encodings[0]).length === 0) && (a.encodings = i, o.sendEncodings = i, this.setParametersPromises.push(o.setParameters(a).then(() => {
        delete o.sendEncodings;
      }).catch(() => {
        delete o.sendEncodings;
      })));
    }
    return r;
  });
}
function pd(n) {
  if (!(typeof n == "object" && n.RTCRtpSender))
    return;
  const e = n.RTCRtpSender.prototype.getParameters;
  e && (n.RTCRtpSender.prototype.getParameters = function() {
    const i = e.apply(this, arguments);
    return "encodings" in i || (i.encodings = [].concat(this.sendEncodings || [{}])), i;
  });
}
function md(n) {
  if (!(typeof n == "object" && n.RTCPeerConnection))
    return;
  const e = n.RTCPeerConnection.prototype.createOffer;
  n.RTCPeerConnection.prototype.createOffer = function() {
    return this.setParametersPromises && this.setParametersPromises.length ? Promise.all(this.setParametersPromises).then(() => e.apply(this, arguments)).finally(() => {
      this.setParametersPromises = [];
    }) : e.apply(this, arguments);
  };
}
function fd(n) {
  if (!(typeof n == "object" && n.RTCPeerConnection))
    return;
  const e = n.RTCPeerConnection.prototype.createAnswer;
  n.RTCPeerConnection.prototype.createAnswer = function() {
    return this.setParametersPromises && this.setParametersPromises.length ? Promise.all(this.setParametersPromises).then(() => e.apply(this, arguments)).finally(() => {
      this.setParametersPromises = [];
    }) : e.apply(this, arguments);
  };
}
var Ha = /* @__PURE__ */ Object.freeze({ __proto__: null, shimAddTransceiver: hd, shimCreateAnswer: fd, shimCreateOffer: md, shimGetDisplayMedia: Ph, shimGetParameters: pd, shimGetUserMedia: ad, shimOnTrack: od, shimPeerConnection: er, shimRTCDataChannel: ud, shimReceiverGetStats: dd, shimRemoveStream: ld, shimSenderGetStats: cd });
function gd(n) {
  if (!(typeof n != "object" || !n.RTCPeerConnection)) {
    if ("getLocalStreams" in n.RTCPeerConnection.prototype || (n.RTCPeerConnection.prototype.getLocalStreams = function() {
      return this._localStreams || (this._localStreams = []), this._localStreams;
    }), !("addStream" in n.RTCPeerConnection.prototype)) {
      const e = n.RTCPeerConnection.prototype.addTrack;
      n.RTCPeerConnection.prototype.addStream = function(i) {
        this._localStreams || (this._localStreams = []), this._localStreams.includes(i) || this._localStreams.push(i), i.getAudioTracks().forEach((s) => e.call(this, s, i)), i.getVideoTracks().forEach((s) => e.call(this, s, i));
      }, n.RTCPeerConnection.prototype.addTrack = function(i) {
        for (var s = arguments.length, r = new Array(s > 1 ? s - 1 : 0), o = 1; o < s; o++)
          r[o - 1] = arguments[o];
        return r && r.forEach((a) => {
          this._localStreams ? this._localStreams.includes(a) || this._localStreams.push(a) : this._localStreams = [a];
        }), e.apply(this, arguments);
      };
    }
    "removeStream" in n.RTCPeerConnection.prototype || (n.RTCPeerConnection.prototype.removeStream = function(t) {
      this._localStreams || (this._localStreams = []);
      const i = this._localStreams.indexOf(t);
      if (i === -1)
        return;
      this._localStreams.splice(i, 1);
      const s = t.getTracks();
      this.getSenders().forEach((r) => {
        s.includes(r.track) && this.removeTrack(r);
      });
    });
  }
}
function vd(n) {
  if (!(typeof n != "object" || !n.RTCPeerConnection) && ("getRemoteStreams" in n.RTCPeerConnection.prototype || (n.RTCPeerConnection.prototype.getRemoteStreams = function() {
    return this._remoteStreams ? this._remoteStreams : [];
  }), !("onaddstream" in n.RTCPeerConnection.prototype))) {
    Object.defineProperty(n.RTCPeerConnection.prototype, "onaddstream", {
      get() {
        return this._onaddstream;
      },
      set(t) {
        this._onaddstream && (this.removeEventListener("addstream", this._onaddstream), this.removeEventListener("track", this._onaddstreampoly)), this.addEventListener("addstream", this._onaddstream = t), this.addEventListener("track", this._onaddstreampoly = (i) => {
          i.streams.forEach((s) => {
            if (this._remoteStreams || (this._remoteStreams = []), this._remoteStreams.includes(s))
              return;
            this._remoteStreams.push(s);
            const r = new Event("addstream");
            r.stream = s, this.dispatchEvent(r);
          });
        });
      }
    });
    const e = n.RTCPeerConnection.prototype.setRemoteDescription;
    n.RTCPeerConnection.prototype.setRemoteDescription = function() {
      const i = this;
      return this._onaddstreampoly || this.addEventListener("track", this._onaddstreampoly = function(s) {
        s.streams.forEach((r) => {
          if (i._remoteStreams || (i._remoteStreams = []), i._remoteStreams.indexOf(r) >= 0)
            return;
          i._remoteStreams.push(r);
          const o = new Event("addstream");
          o.stream = r, i.dispatchEvent(o);
        });
      }), e.apply(i, arguments);
    };
  }
}
function bd(n) {
  if (typeof n != "object" || !n.RTCPeerConnection)
    return;
  const e = n.RTCPeerConnection.prototype, t = e.createOffer, i = e.createAnswer, s = e.setLocalDescription, r = e.setRemoteDescription, o = e.addIceCandidate;
  e.createOffer = function(d, l) {
    const u = arguments.length >= 2 ? arguments[2] : arguments[0], h = t.apply(this, [u]);
    return l ? (h.then(d, l), Promise.resolve()) : h;
  }, e.createAnswer = function(d, l) {
    const u = arguments.length >= 2 ? arguments[2] : arguments[0], h = i.apply(this, [u]);
    return l ? (h.then(d, l), Promise.resolve()) : h;
  };
  let a = function(c, d, l) {
    const u = s.apply(this, [c]);
    return l ? (u.then(d, l), Promise.resolve()) : u;
  };
  e.setLocalDescription = a, a = function(c, d, l) {
    const u = r.apply(this, [c]);
    return l ? (u.then(d, l), Promise.resolve()) : u;
  }, e.setRemoteDescription = a, a = function(c, d, l) {
    const u = o.apply(this, [c]);
    return l ? (u.then(d, l), Promise.resolve()) : u;
  }, e.addIceCandidate = a;
}
function yd(n) {
  const e = n && n.navigator;
  if (e.mediaDevices && e.mediaDevices.getUserMedia) {
    const t = e.mediaDevices, i = t.getUserMedia.bind(t);
    e.mediaDevices.getUserMedia = (s) => i(Sd(s));
  }
  !e.getUserMedia && e.mediaDevices && e.mediaDevices.getUserMedia && (e.getUserMedia = function(i, s, r) {
    e.mediaDevices.getUserMedia(i).then(s, r);
  }.bind(e));
}
function Sd(n) {
  return n && n.video !== void 0 ? Object.assign({}, n, {
    video: Qc(n.video)
  }) : n;
}
function kd(n) {
  if (!n.RTCPeerConnection)
    return;
  const e = n.RTCPeerConnection;
  n.RTCPeerConnection = function(i, s) {
    if (i && i.iceServers) {
      const r = [];
      for (let o = 0; o < i.iceServers.length; o++) {
        let a = i.iceServers[o];
        a.urls === void 0 && a.url ? (jr("RTCIceServer.url", "RTCIceServer.urls"), a = JSON.parse(JSON.stringify(a)), a.urls = a.url, delete a.url, r.push(a)) : r.push(i.iceServers[o]);
      }
      i.iceServers = r;
    }
    return new e(i, s);
  }, n.RTCPeerConnection.prototype = e.prototype, "generateCertificate" in e && Object.defineProperty(n.RTCPeerConnection, "generateCertificate", {
    get() {
      return e.generateCertificate;
    }
  });
}
function Td(n) {
  typeof n == "object" && n.RTCTrackEvent && "receiver" in n.RTCTrackEvent.prototype && !("transceiver" in n.RTCTrackEvent.prototype) && Object.defineProperty(n.RTCTrackEvent.prototype, "transceiver", {
    get() {
      return {
        receiver: this.receiver
      };
    }
  });
}
function Cd(n) {
  const e = n.RTCPeerConnection.prototype.createOffer;
  n.RTCPeerConnection.prototype.createOffer = function(i) {
    if (i) {
      typeof i.offerToReceiveAudio != "undefined" && (i.offerToReceiveAudio = !!i.offerToReceiveAudio);
      const s = this.getTransceivers().find((o) => o.receiver.track.kind === "audio");
      i.offerToReceiveAudio === !1 && s ? s.direction === "sendrecv" ? s.setDirection ? s.setDirection("sendonly") : s.direction = "sendonly" : s.direction === "recvonly" && (s.setDirection ? s.setDirection("inactive") : s.direction = "inactive") : i.offerToReceiveAudio === !0 && !s && this.addTransceiver("audio", {
        direction: "recvonly"
      }), typeof i.offerToReceiveVideo != "undefined" && (i.offerToReceiveVideo = !!i.offerToReceiveVideo);
      const r = this.getTransceivers().find((o) => o.receiver.track.kind === "video");
      i.offerToReceiveVideo === !1 && r ? r.direction === "sendrecv" ? r.setDirection ? r.setDirection("sendonly") : r.direction = "sendonly" : r.direction === "recvonly" && (r.setDirection ? r.setDirection("inactive") : r.direction = "inactive") : i.offerToReceiveVideo === !0 && !r && this.addTransceiver("video", {
        direction: "recvonly"
      });
    }
    return e.apply(this, arguments);
  };
}
function _d(n) {
  typeof n != "object" || n.AudioContext || (n.AudioContext = n.webkitAudioContext);
}
var Wa = /* @__PURE__ */ Object.freeze({ __proto__: null, shimAudioContext: _d, shimCallbacksAPI: bd, shimConstraints: Sd, shimCreateOfferLegacy: Cd, shimGetUserMedia: yd, shimLocalStreamsAPI: gd, shimRTCIceServerUrls: kd, shimRemoteStreamsAPI: vd, shimTrackEventTransceiver: Td }), ys = { exports: {} }, $a;
function xh() {
  return $a || ($a = 1, (function(n) {
    const e = {};
    e.generateIdentifier = function() {
      return Math.random().toString(36).substring(2, 12);
    }, e.localCName = e.generateIdentifier(), e.splitLines = function(t) {
      return t.trim().split(`
`).map((i) => i.trim());
    }, e.splitSections = function(t) {
      return t.split(`
m=`).map((s, r) => (r > 0 ? "m=" + s : s).trim() + `\r
`);
    }, e.getDescription = function(t) {
      const i = e.splitSections(t);
      return i && i[0];
    }, e.getMediaSections = function(t) {
      const i = e.splitSections(t);
      return i.shift(), i;
    }, e.matchPrefix = function(t, i) {
      return e.splitLines(t).filter((s) => s.indexOf(i) === 0);
    }, e.parseCandidate = function(t) {
      let i;
      t.indexOf("a=candidate:") === 0 ? i = t.substring(12).split(" ") : i = t.substring(10).split(" ");
      const s = {
        foundation: i[0],
        component: {
          1: "rtp",
          2: "rtcp"
        }[i[1]] || i[1],
        protocol: i[2].toLowerCase(),
        priority: parseInt(i[3], 10),
        ip: i[4],
        address: i[4],
        // address is an alias for ip.
        port: parseInt(i[5], 10),
        // skip parts[6] == 'typ'
        type: i[7]
      };
      for (let r = 8; r < i.length; r += 2)
        switch (i[r]) {
          case "raddr":
            s.relatedAddress = i[r + 1];
            break;
          case "rport":
            s.relatedPort = parseInt(i[r + 1], 10);
            break;
          case "tcptype":
            s.tcpType = i[r + 1];
            break;
          case "ufrag":
            s.ufrag = i[r + 1], s.usernameFragment = i[r + 1];
            break;
          default:
            s[i[r]] === void 0 && (s[i[r]] = i[r + 1]);
            break;
        }
      return s;
    }, e.writeCandidate = function(t) {
      const i = [];
      i.push(t.foundation);
      const s = t.component;
      s === "rtp" ? i.push(1) : s === "rtcp" ? i.push(2) : i.push(s), i.push(t.protocol.toUpperCase()), i.push(t.priority), i.push(t.address || t.ip), i.push(t.port);
      const r = t.type;
      return i.push("typ"), i.push(r), r !== "host" && t.relatedAddress && t.relatedPort && (i.push("raddr"), i.push(t.relatedAddress), i.push("rport"), i.push(t.relatedPort)), t.tcpType && t.protocol.toLowerCase() === "tcp" && (i.push("tcptype"), i.push(t.tcpType)), (t.usernameFragment || t.ufrag) && (i.push("ufrag"), i.push(t.usernameFragment || t.ufrag)), "candidate:" + i.join(" ");
    }, e.parseIceOptions = function(t) {
      return t.substring(14).split(" ");
    }, e.parseRtpMap = function(t) {
      let i = t.substring(9).split(" ");
      const s = {
        payloadType: parseInt(i.shift(), 10)
        // was: id
      };
      return i = i[0].split("/"), s.name = i[0], s.clockRate = parseInt(i[1], 10), s.channels = i.length === 3 ? parseInt(i[2], 10) : 1, s.numChannels = s.channels, s;
    }, e.writeRtpMap = function(t) {
      let i = t.payloadType;
      t.preferredPayloadType !== void 0 && (i = t.preferredPayloadType);
      const s = t.channels || t.numChannels || 1;
      return "a=rtpmap:" + i + " " + t.name + "/" + t.clockRate + (s !== 1 ? "/" + s : "") + `\r
`;
    }, e.parseExtmap = function(t) {
      const i = t.substring(9).split(" ");
      return {
        id: parseInt(i[0], 10),
        direction: i[0].indexOf("/") > 0 ? i[0].split("/")[1] : "sendrecv",
        uri: i[1],
        attributes: i.slice(2).join(" ")
      };
    }, e.writeExtmap = function(t) {
      return "a=extmap:" + (t.id || t.preferredId) + (t.direction && t.direction !== "sendrecv" ? "/" + t.direction : "") + " " + t.uri + (t.attributes ? " " + t.attributes : "") + `\r
`;
    }, e.parseFmtp = function(t) {
      const i = {};
      let s;
      const r = t.substring(t.indexOf(" ") + 1).split(";");
      for (let o = 0; o < r.length; o++)
        s = r[o].trim().split("="), i[s[0].trim()] = s[1];
      return i;
    }, e.writeFmtp = function(t) {
      let i = "", s = t.payloadType;
      if (t.preferredPayloadType !== void 0 && (s = t.preferredPayloadType), t.parameters && Object.keys(t.parameters).length) {
        const r = [];
        Object.keys(t.parameters).forEach((o) => {
          t.parameters[o] !== void 0 ? r.push(o + "=" + t.parameters[o]) : r.push(o);
        }), i += "a=fmtp:" + s + " " + r.join(";") + `\r
`;
      }
      return i;
    }, e.parseRtcpFb = function(t) {
      const i = t.substring(t.indexOf(" ") + 1).split(" ");
      return {
        type: i.shift(),
        parameter: i.join(" ")
      };
    }, e.writeRtcpFb = function(t) {
      let i = "", s = t.payloadType;
      return t.preferredPayloadType !== void 0 && (s = t.preferredPayloadType), t.rtcpFeedback && t.rtcpFeedback.length && t.rtcpFeedback.forEach((r) => {
        i += "a=rtcp-fb:" + s + " " + r.type + (r.parameter && r.parameter.length ? " " + r.parameter : "") + `\r
`;
      }), i;
    }, e.parseSsrcMedia = function(t) {
      const i = t.indexOf(" "), s = {
        ssrc: parseInt(t.substring(7, i), 10)
      }, r = t.indexOf(":", i);
      return r > -1 ? (s.attribute = t.substring(i + 1, r), s.value = t.substring(r + 1)) : s.attribute = t.substring(i + 1), s;
    }, e.parseSsrcGroup = function(t) {
      const i = t.substring(13).split(" ");
      return {
        semantics: i.shift(),
        ssrcs: i.map((s) => parseInt(s, 10))
      };
    }, e.getMid = function(t) {
      const i = e.matchPrefix(t, "a=mid:")[0];
      if (i)
        return i.substring(6);
    }, e.parseFingerprint = function(t) {
      const i = t.substring(14).split(" ");
      return {
        algorithm: i[0].toLowerCase(),
        // algorithm is case-sensitive in Edge.
        value: i[1].toUpperCase()
        // the definition is upper-case in RFC 4572.
      };
    }, e.getDtlsParameters = function(t, i) {
      return {
        role: "auto",
        fingerprints: e.matchPrefix(t + i, "a=fingerprint:").map(e.parseFingerprint)
      };
    }, e.writeDtlsParameters = function(t, i) {
      let s = "a=setup:" + i + `\r
`;
      return t.fingerprints.forEach((r) => {
        s += "a=fingerprint:" + r.algorithm + " " + r.value + `\r
`;
      }), s;
    }, e.parseCryptoLine = function(t) {
      const i = t.substring(9).split(" ");
      return {
        tag: parseInt(i[0], 10),
        cryptoSuite: i[1],
        keyParams: i[2],
        sessionParams: i.slice(3)
      };
    }, e.writeCryptoLine = function(t) {
      return "a=crypto:" + t.tag + " " + t.cryptoSuite + " " + (typeof t.keyParams == "object" ? e.writeCryptoKeyParams(t.keyParams) : t.keyParams) + (t.sessionParams ? " " + t.sessionParams.join(" ") : "") + `\r
`;
    }, e.parseCryptoKeyParams = function(t) {
      if (t.indexOf("inline:") !== 0)
        return null;
      const i = t.substring(7).split("|");
      return {
        keyMethod: "inline",
        keySalt: i[0],
        lifeTime: i[1],
        mkiValue: i[2] ? i[2].split(":")[0] : void 0,
        mkiLength: i[2] ? i[2].split(":")[1] : void 0
      };
    }, e.writeCryptoKeyParams = function(t) {
      return t.keyMethod + ":" + t.keySalt + (t.lifeTime ? "|" + t.lifeTime : "") + (t.mkiValue && t.mkiLength ? "|" + t.mkiValue + ":" + t.mkiLength : "");
    }, e.getCryptoParameters = function(t, i) {
      return e.matchPrefix(t + i, "a=crypto:").map(e.parseCryptoLine);
    }, e.getIceParameters = function(t, i) {
      const s = e.matchPrefix(t + i, "a=ice-ufrag:")[0], r = e.matchPrefix(t + i, "a=ice-pwd:")[0];
      return s && r ? {
        usernameFragment: s.substring(12),
        password: r.substring(10)
      } : null;
    }, e.writeIceParameters = function(t) {
      let i = "a=ice-ufrag:" + t.usernameFragment + `\r
a=ice-pwd:` + t.password + `\r
`;
      return t.iceLite && (i += `a=ice-lite\r
`), i;
    }, e.parseRtpParameters = function(t) {
      const i = {
        codecs: [],
        headerExtensions: [],
        fecMechanisms: [],
        rtcp: []
      }, r = e.splitLines(t)[0].split(" ");
      i.profile = r[2];
      for (let a = 3; a < r.length; a++) {
        const c = r[a], d = e.matchPrefix(t, "a=rtpmap:" + c + " ")[0];
        if (d) {
          const l = e.parseRtpMap(d), u = e.matchPrefix(t, "a=fmtp:" + c + " ");
          switch (l.parameters = u.length ? e.parseFmtp(u[0]) : {}, l.rtcpFeedback = e.matchPrefix(t, "a=rtcp-fb:" + c + " ").map(e.parseRtcpFb), i.codecs.push(l), l.name.toUpperCase()) {
            case "RED":
            case "ULPFEC":
              i.fecMechanisms.push(l.name.toUpperCase());
              break;
          }
        }
      }
      e.matchPrefix(t, "a=extmap:").forEach((a) => {
        i.headerExtensions.push(e.parseExtmap(a));
      });
      const o = e.matchPrefix(t, "a=rtcp-fb:* ").map(e.parseRtcpFb);
      return i.codecs.forEach((a) => {
        o.forEach((c) => {
          a.rtcpFeedback.find((l) => l.type === c.type && l.parameter === c.parameter) || a.rtcpFeedback.push(c);
        });
      }), i;
    }, e.writeRtpDescription = function(t, i) {
      let s = "";
      s += "m=" + t + " ", s += i.codecs.length > 0 ? "9" : "0", s += " " + (i.profile || "UDP/TLS/RTP/SAVPF") + " ", s += i.codecs.map((o) => o.preferredPayloadType !== void 0 ? o.preferredPayloadType : o.payloadType).join(" ") + `\r
`, s += `c=IN IP4 0.0.0.0\r
`, s += `a=rtcp:9 IN IP4 0.0.0.0\r
`, i.codecs.forEach((o) => {
        s += e.writeRtpMap(o), s += e.writeFmtp(o), s += e.writeRtcpFb(o);
      });
      let r = 0;
      return i.codecs.forEach((o) => {
        o.maxptime > r && (r = o.maxptime);
      }), r > 0 && (s += "a=maxptime:" + r + `\r
`), i.headerExtensions && i.headerExtensions.forEach((o) => {
        s += e.writeExtmap(o);
      }), s;
    }, e.parseRtpEncodingParameters = function(t) {
      const i = [], s = e.parseRtpParameters(t), r = s.fecMechanisms.indexOf("RED") !== -1, o = s.fecMechanisms.indexOf("ULPFEC") !== -1, a = e.matchPrefix(t, "a=ssrc:").map((h) => e.parseSsrcMedia(h)).filter((h) => h.attribute === "cname"), c = a.length > 0 && a[0].ssrc;
      let d;
      const l = e.matchPrefix(t, "a=ssrc-group:FID").map((h) => h.substring(17).split(" ").map((b) => parseInt(b, 10)));
      l.length > 0 && l[0].length > 1 && l[0][0] === c && (d = l[0][1]), s.codecs.forEach((h) => {
        if (h.name.toUpperCase() === "RTX" && h.parameters.apt) {
          let p = {
            ssrc: c,
            codecPayloadType: parseInt(h.parameters.apt, 10)
          };
          c && d && (p.rtx = {
            ssrc: d
          }), i.push(p), r && (p = JSON.parse(JSON.stringify(p)), p.fec = {
            ssrc: c,
            mechanism: o ? "red+ulpfec" : "red"
          }, i.push(p));
        }
      }), i.length === 0 && c && i.push({
        ssrc: c
      });
      let u = e.matchPrefix(t, "b=");
      return u.length && (u[0].indexOf("b=TIAS:") === 0 ? u = parseInt(u[0].substring(7), 10) : u[0].indexOf("b=AS:") === 0 ? u = parseInt(u[0].substring(5), 10) * 1e3 * 0.95 - 2e3 * 8 : u = void 0, i.forEach((h) => {
        h.maxBitrate = u;
      })), i;
    }, e.parseRtcpParameters = function(t) {
      const i = {}, s = e.matchPrefix(t, "a=ssrc:").map((a) => e.parseSsrcMedia(a)).filter((a) => a.attribute === "cname")[0];
      s && (i.cname = s.value, i.ssrc = s.ssrc);
      const r = e.matchPrefix(t, "a=rtcp-rsize");
      i.reducedSize = r.length > 0, i.compound = r.length === 0;
      const o = e.matchPrefix(t, "a=rtcp-mux");
      return i.mux = o.length > 0, i;
    }, e.writeRtcpParameters = function(t) {
      let i = "";
      return t.reducedSize && (i += `a=rtcp-rsize\r
`), t.mux && (i += `a=rtcp-mux\r
`), t.ssrc !== void 0 && t.cname && (i += "a=ssrc:" + t.ssrc + " cname:" + t.cname + `\r
`), i;
    }, e.parseMsid = function(t) {
      let i;
      const s = e.matchPrefix(t, "a=msid:");
      if (s.length === 1)
        return i = s[0].substring(7).split(" "), {
          stream: i[0],
          track: i[1]
        };
      const r = e.matchPrefix(t, "a=ssrc:").map((o) => e.parseSsrcMedia(o)).filter((o) => o.attribute === "msid");
      if (r.length > 0)
        return i = r[0].value.split(" "), {
          stream: i[0],
          track: i[1]
        };
    }, e.parseSctpDescription = function(t) {
      const i = e.parseMLine(t), s = e.matchPrefix(t, "a=max-message-size:");
      let r;
      s.length > 0 && (r = parseInt(s[0].substring(19), 10)), isNaN(r) && (r = 65536);
      const o = e.matchPrefix(t, "a=sctp-port:");
      if (o.length > 0)
        return {
          port: parseInt(o[0].substring(12), 10),
          protocol: i.fmt,
          maxMessageSize: r
        };
      const a = e.matchPrefix(t, "a=sctpmap:");
      if (a.length > 0) {
        const c = a[0].substring(10).split(" ");
        return {
          port: parseInt(c[0], 10),
          protocol: c[1],
          maxMessageSize: r
        };
      }
    }, e.writeSctpDescription = function(t, i) {
      let s = [];
      return t.protocol !== "DTLS/SCTP" ? s = ["m=" + t.kind + " 9 " + t.protocol + " " + i.protocol + `\r
`, `c=IN IP4 0.0.0.0\r
`, "a=sctp-port:" + i.port + `\r
`] : s = ["m=" + t.kind + " 9 " + t.protocol + " " + i.port + `\r
`, `c=IN IP4 0.0.0.0\r
`, "a=sctpmap:" + i.port + " " + i.protocol + ` 65535\r
`], i.maxMessageSize !== void 0 && s.push("a=max-message-size:" + i.maxMessageSize + `\r
`), s.join("");
    }, e.generateSessionId = function() {
      return Math.random().toString().substr(2, 22);
    }, e.writeSessionBoilerplate = function(t, i, s) {
      let r;
      const o = i !== void 0 ? i : 2;
      return t ? r = t : r = e.generateSessionId(), `v=0\r
o=` + (s || "thisisadapterortc") + " " + r + " " + o + ` IN IP4 127.0.0.1\r
s=-\r
t=0 0\r
`;
    }, e.getDirection = function(t, i) {
      const s = e.splitLines(t);
      for (let r = 0; r < s.length; r++)
        switch (s[r]) {
          case "a=sendrecv":
          case "a=sendonly":
          case "a=recvonly":
          case "a=inactive":
            return s[r].substring(2);
        }
      return i ? e.getDirection(i) : "sendrecv";
    }, e.getKind = function(t) {
      return e.splitLines(t)[0].split(" ")[0].substring(2);
    }, e.isRejected = function(t) {
      return t.split(" ", 2)[1] === "0";
    }, e.parseMLine = function(t) {
      const s = e.splitLines(t)[0].substring(2).split(" ");
      return {
        kind: s[0],
        port: parseInt(s[1], 10),
        protocol: s[2],
        fmt: s.slice(3).join(" ")
      };
    }, e.parseOLine = function(t) {
      const s = e.matchPrefix(t, "o=")[0].substring(2).split(" ");
      return {
        username: s[0],
        sessionId: s[1],
        sessionVersion: parseInt(s[2], 10),
        netType: s[3],
        addressType: s[4],
        address: s[5]
      };
    }, e.isValidSDP = function(t) {
      if (typeof t != "string" || t.length === 0)
        return !1;
      const i = e.splitLines(t);
      for (let s = 0; s < i.length; s++)
        if (i[s].length < 2 || i[s].charAt(1) !== "=")
          return !1;
      return !0;
    }, n.exports = e;
  })(ys)), ys.exports;
}
var wd = xh(), Ai = /* @__PURE__ */ vh(wd), Mh = /* @__PURE__ */ Ol({ __proto__: null, default: Ai }, [wd]);
function xn(n) {
  if (!n.RTCIceCandidate || n.RTCIceCandidate && "foundation" in n.RTCIceCandidate.prototype)
    return;
  const e = n.RTCIceCandidate;
  n.RTCIceCandidate = function(i) {
    if (typeof i == "object" && i.candidate && i.candidate.indexOf("a=") === 0 && (i = JSON.parse(JSON.stringify(i)), i.candidate = i.candidate.substring(2)), i.candidate && i.candidate.length) {
      const s = new e(i), r = Ai.parseCandidate(i.candidate);
      for (const o in r)
        o in s || Object.defineProperty(s, o, {
          value: r[o]
        });
      return s.toJSON = function() {
        return {
          candidate: s.candidate,
          sdpMid: s.sdpMid,
          sdpMLineIndex: s.sdpMLineIndex,
          usernameFragment: s.usernameFragment
        };
      }, s;
    }
    return new e(i);
  }, n.RTCIceCandidate.prototype = e.prototype, pi(n, "icecandidate", (t) => (t.candidate && Object.defineProperty(t, "candidate", {
    value: new n.RTCIceCandidate(t.candidate),
    writable: "false"
  }), t));
}
function tr(n) {
  !n.RTCIceCandidate || n.RTCIceCandidate && "relayProtocol" in n.RTCIceCandidate.prototype || pi(n, "icecandidate", (e) => {
    if (e.candidate) {
      const t = Ai.parseCandidate(e.candidate.candidate);
      t.type === "relay" && (e.candidate.relayProtocol = {
        0: "tls",
        1: "tcp",
        2: "udp"
      }[t.priority >> 24]);
    }
    return e;
  });
}
function Mn(n, e) {
  if (!n.RTCPeerConnection)
    return;
  "sctp" in n.RTCPeerConnection.prototype || Object.defineProperty(n.RTCPeerConnection.prototype, "sctp", {
    get() {
      return typeof this._sctp == "undefined" ? null : this._sctp;
    }
  });
  const t = function(a) {
    if (!a || !a.sdp)
      return !1;
    const c = Ai.splitSections(a.sdp);
    return c.shift(), c.some((d) => {
      const l = Ai.parseMLine(d);
      return l && l.kind === "application" && l.protocol.indexOf("SCTP") !== -1;
    });
  }, i = function(a) {
    const c = a.sdp.match(/mozilla...THIS_IS_SDPARTA-(\d+)/);
    if (c === null || c.length < 2)
      return -1;
    const d = parseInt(c[1], 10);
    return d !== d ? -1 : d;
  }, s = function(a) {
    let c = 65536;
    return e.browser === "firefox" && (e.version < 57 ? a === -1 ? c = 16384 : c = 2147483637 : e.version < 60 ? c = e.version === 57 ? 65535 : 65536 : c = 2147483637), c;
  }, r = function(a, c) {
    let d = 65536;
    e.browser === "firefox" && e.version === 57 && (d = 65535);
    const l = Ai.matchPrefix(a.sdp, "a=max-message-size:");
    return l.length > 0 ? d = parseInt(l[0].substring(19), 10) : e.browser === "firefox" && c !== -1 && (d = 2147483637), d;
  }, o = n.RTCPeerConnection.prototype.setRemoteDescription;
  n.RTCPeerConnection.prototype.setRemoteDescription = function() {
    if (this._sctp = null, e.browser === "chrome" && e.version >= 76) {
      const {
        sdpSemantics: c
      } = this.getConfiguration();
      c === "plan-b" && Object.defineProperty(this, "sctp", {
        get() {
          return typeof this._sctp == "undefined" ? null : this._sctp;
        },
        enumerable: !0,
        configurable: !0
      });
    }
    if (t(arguments[0])) {
      const c = i(arguments[0]), d = s(c), l = r(arguments[0], c);
      let u;
      d === 0 && l === 0 ? u = Number.POSITIVE_INFINITY : d === 0 || l === 0 ? u = Math.max(d, l) : u = Math.min(d, l);
      const h = {};
      Object.defineProperty(h, "maxMessageSize", {
        get() {
          return u;
        }
      }), this._sctp = h;
    }
    return o.apply(this, arguments);
  };
}
function An(n) {
  if (!(n.RTCPeerConnection && "createDataChannel" in n.RTCPeerConnection.prototype))
    return;
  function e(i, s) {
    const r = i.send;
    i.send = function() {
      const a = arguments[0], c = a.length || a.size || a.byteLength;
      if (i.readyState === "open" && s.sctp && c > s.sctp.maxMessageSize)
        throw new TypeError("Message too large (can send a maximum of " + s.sctp.maxMessageSize + " bytes)");
      return r.apply(i, arguments);
    };
  }
  const t = n.RTCPeerConnection.prototype.createDataChannel;
  n.RTCPeerConnection.prototype.createDataChannel = function() {
    const s = t.apply(this, arguments);
    return e(s, this), s;
  }, pi(n, "datachannel", (i) => (e(i.channel, i.target), i));
}
function ir(n) {
  if (!n.RTCPeerConnection || "connectionState" in n.RTCPeerConnection.prototype)
    return;
  const e = n.RTCPeerConnection.prototype;
  Object.defineProperty(e, "connectionState", {
    get() {
      return {
        completed: "connected",
        checking: "connecting"
      }[this.iceConnectionState] || this.iceConnectionState;
    },
    enumerable: !0,
    configurable: !0
  }), Object.defineProperty(e, "onconnectionstatechange", {
    get() {
      return this._onconnectionstatechange || null;
    },
    set(t) {
      this._onconnectionstatechange && (this.removeEventListener("connectionstatechange", this._onconnectionstatechange), delete this._onconnectionstatechange), t && this.addEventListener("connectionstatechange", this._onconnectionstatechange = t);
    },
    enumerable: !0,
    configurable: !0
  }), ["setLocalDescription", "setRemoteDescription"].forEach((t) => {
    const i = e[t];
    e[t] = function() {
      return this._connectionstatechangepoly || (this._connectionstatechangepoly = (s) => {
        const r = s.target;
        if (r._lastConnectionState !== r.connectionState) {
          r._lastConnectionState = r.connectionState;
          const o = new Event("connectionstatechange", s);
          r.dispatchEvent(o);
        }
        return s;
      }, this.addEventListener("iceconnectionstatechange", this._connectionstatechangepoly)), i.apply(this, arguments);
    };
  });
}
function nr(n, e) {
  if (!n.RTCPeerConnection || e.browser === "chrome" && e.version >= 71 || e.browser === "safari" && e._safariVersion >= 13.1)
    return;
  const t = n.RTCPeerConnection.prototype.setRemoteDescription;
  n.RTCPeerConnection.prototype.setRemoteDescription = function(s) {
    if (s && s.sdp && s.sdp.indexOf(`
a=extmap-allow-mixed`) !== -1) {
      const r = s.sdp.split(`
`).filter((o) => o.trim() !== "a=extmap-allow-mixed").join(`
`);
      n.RTCSessionDescription && s instanceof n.RTCSessionDescription ? arguments[0] = new n.RTCSessionDescription({
        type: s.type,
        sdp: r
      }) : s.sdp = r;
    }
    return t.apply(this, arguments);
  };
}
function On(n, e) {
  if (!(n.RTCPeerConnection && n.RTCPeerConnection.prototype))
    return;
  const t = n.RTCPeerConnection.prototype.addIceCandidate;
  !t || t.length === 0 || (n.RTCPeerConnection.prototype.addIceCandidate = function() {
    return arguments[0] ? (e.browser === "chrome" && e.version < 78 || e.browser === "firefox" && e.version < 68 || e.browser === "safari") && arguments[0] && arguments[0].candidate === "" ? Promise.resolve() : t.apply(this, arguments) : (arguments[1] && arguments[1].apply(null), Promise.resolve());
  });
}
function Dn(n, e) {
  if (!(n.RTCPeerConnection && n.RTCPeerConnection.prototype))
    return;
  const t = n.RTCPeerConnection.prototype.setLocalDescription;
  !t || t.length === 0 || (n.RTCPeerConnection.prototype.setLocalDescription = function() {
    let s = arguments[0] || {};
    if (typeof s != "object" || s.type && s.sdp)
      return t.apply(this, arguments);
    if (s = {
      type: s.type,
      sdp: s.sdp
    }, !s.type)
      switch (this.signalingState) {
        case "stable":
        case "have-local-offer":
        case "have-remote-pranswer":
          s.type = "offer";
          break;
        default:
          s.type = "answer";
          break;
      }
    return s.sdp || s.type !== "offer" && s.type !== "answer" ? t.apply(this, [s]) : (s.type === "offer" ? this.createOffer : this.createAnswer).apply(this).then((o) => t.apply(this, [o]));
  });
}
var Ah = /* @__PURE__ */ Object.freeze({ __proto__: null, removeExtmapAllowMixed: nr, shimAddIceCandidateNullOrEmpty: On, shimConnectionState: ir, shimMaxMessageSize: Mn, shimParameterlessSetLocalDescription: Dn, shimRTCIceCandidate: xn, shimRTCIceCandidateRelayProtocol: tr, shimSendThrowTypeError: An });
function Oh() {
  let {
    window: n
  } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
    shimChrome: !0,
    shimFirefox: !0,
    shimSafari: !0
  };
  const t = Yc, i = Ih(n), s = {
    browserDetails: i,
    commonShim: Ah,
    extractVersion: tn,
    disableLog: Eh,
    disableWarnings: Rh,
    // Expose sdp as a convenience. For production apps include directly.
    sdp: Mh
  };
  switch (i.browser) {
    case "chrome":
      if (!qa || !Zs || !e.shimChrome)
        return t("Chrome shim is not included in this adapter release."), s;
      if (i.version === null)
        return t("Chrome shim can not determine version, not shimming."), s;
      t("adapter.js shimming chrome."), s.browserShim = qa, On(n, i), Dn(n), Xc(n, i), Zc(n), Zs(n, i), ed(n), sd(n, i), td(n), id(n), rd(n, i), xn(n), tr(n), ir(n), Mn(n, i), An(n), nr(n, i);
      break;
    case "firefox":
      if (!Ha || !er || !e.shimFirefox)
        return t("Firefox shim is not included in this adapter release."), s;
      t("adapter.js shimming firefox."), s.browserShim = Ha, On(n, i), Dn(n), ad(n, i), er(n, i), od(n), ld(n), cd(n), dd(n), ud(n), hd(n), pd(n), md(n), fd(n), xn(n), ir(n), Mn(n, i), An(n);
      break;
    case "safari":
      if (!Wa || !e.shimSafari)
        return t("Safari shim is not included in this adapter release."), s;
      t("adapter.js shimming safari."), s.browserShim = Wa, On(n, i), Dn(n), kd(n), Cd(n), bd(n), gd(n), vd(n), Td(n), yd(n), _d(n), xn(n), tr(n), Mn(n, i), An(n), nr(n, i);
      break;
    default:
      t("Unsupported browser!");
      break;
  }
  return s;
}
Oh({
  window: typeof window == "undefined" ? void 0 : window
});
var sr, Ed;
class Je extends (Ed = Promise) {
  // eslint-disable-next-line @typescript-eslint/no-useless-constructor
  constructor(e) {
    super(e);
  }
  catch(e) {
    return super.catch(e);
  }
  static reject(e) {
    return super.reject(e);
  }
  static all(e) {
    return super.all(e);
  }
  static race(e) {
    return super.race(e);
  }
}
sr = Je;
Je.resolve = (n) => Reflect.get(Ed, "resolve", sr).call(sr, n);
const Dh = /version\/(\d+(\.?_?\d+)+)/i;
let Ss;
function nt(n) {
  let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
  if (typeof navigator == "undefined")
    return;
  const t = navigator.userAgent.toLowerCase();
  if (Ss === void 0 || e) {
    const i = Lh.find((s) => {
      let {
        test: r
      } = s;
      return r.test(t);
    });
    Ss = i == null ? void 0 : i.describe(t);
  }
  return Ss;
}
const Lh = [
  {
    test: /firefox|iceweasel|fxios/i,
    describe(n) {
      return {
        name: "Firefox",
        version: Ln(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, n),
        os: n.toLowerCase().includes("fxios") ? "iOS" : void 0,
        osVersion: ks(n)
      };
    }
  },
  {
    test: /chrom|crios|crmo/i,
    describe(n) {
      return {
        name: "Chrome",
        version: Ln(/(?:chrome|chromium|crios|crmo)\/(\d+(\.?_?\d+)+)/i, n),
        os: n.toLowerCase().includes("crios") ? "iOS" : void 0,
        osVersion: ks(n)
      };
    }
  },
  /* Safari */
  {
    test: /safari|applewebkit/i,
    describe(n) {
      return {
        name: "Safari",
        version: Ln(Dh, n),
        os: n.includes("mobile/") ? "iOS" : "macOS",
        osVersion: ks(n)
      };
    }
  }
];
function Ln(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1;
  const i = e.match(n);
  return i && i.length >= t && i[t] || "";
}
function ks(n) {
  return n.includes("mac os") ? Ln(/\(.+?(\d+_\d+(:?_\d+)?)/, n, 1).replace(/_/g, ".") : void 0;
}
var Nh = "2.17.3";
const Uh = Nh, Fh = 16;
class Xt extends Error {
  constructor(e, t, i) {
    super(t || "an error has occurred"), this.name = "LiveKitError", this.code = e, typeof (i == null ? void 0 : i.cause) != "undefined" && (this.cause = i == null ? void 0 : i.cause);
  }
}
class qr extends Xt {
}
var Re;
(function(n) {
  n[n.NotAllowed = 0] = "NotAllowed", n[n.ServerUnreachable = 1] = "ServerUnreachable", n[n.InternalError = 2] = "InternalError", n[n.Cancelled = 3] = "Cancelled", n[n.LeaveRequest = 4] = "LeaveRequest", n[n.Timeout = 5] = "Timeout", n[n.WebSocket = 6] = "WebSocket", n[n.ServiceNotFound = 7] = "ServiceNotFound";
})(Re || (Re = {}));
class Z extends qr {
  constructor(e, t, i, s) {
    super(1, e), this.name = "ConnectionError", this.status = i, this.reason = t, this.context = s, this.reasonName = Re[t];
  }
  static notAllowed(e, t, i) {
    return new Z(e, Re.NotAllowed, t, i);
  }
  static timeout(e) {
    return new Z(e, Re.Timeout);
  }
  static leaveRequest(e, t) {
    return new Z(e, Re.LeaveRequest, void 0, t);
  }
  static internal(e, t) {
    return new Z(e, Re.InternalError, void 0, t);
  }
  static cancelled(e) {
    return new Z(e, Re.Cancelled);
  }
  static serverUnreachable(e, t) {
    return new Z(e, Re.ServerUnreachable, t);
  }
  static websocket(e, t, i) {
    return new Z(e, Re.WebSocket, t, i);
  }
  static serviceNotFound(e, t) {
    return new Z(e, Re.ServiceNotFound, void 0, t);
  }
}
class Hr extends Xt {
  constructor(e) {
    super(21, e != null ? e : "device is unsupported"), this.name = "DeviceUnsupportedError";
  }
}
class Ut extends Xt {
  constructor(e) {
    super(20, e != null ? e : "track is invalid"), this.name = "TrackInvalidError";
  }
}
class Vh extends Xt {
  constructor(e) {
    super(10, e != null ? e : "unsupported server"), this.name = "UnsupportedServer";
  }
}
class De extends Xt {
  constructor(e) {
    super(12, e != null ? e : "unexpected connection state"), this.name = "UnexpectedConnectionState";
  }
}
class oi extends Xt {
  constructor(e) {
    super(13, e != null ? e : "unable to negotiate"), this.name = "NegotiationError";
  }
}
class za extends Xt {
  constructor(e, t) {
    super(15, e), this.name = "PublishTrackError", this.status = t;
  }
}
class Ka extends qr {
  constructor(e, t) {
    super(15, e), this.name = "SignalRequestError", this.reason = t, this.reasonName = typeof t == "string" ? t : Br[t];
  }
}
var Qe;
(function(n) {
  n[n.AlreadyOpened = 0] = "AlreadyOpened", n[n.AbnormalEnd = 1] = "AbnormalEnd", n[n.DecodeFailed = 2] = "DecodeFailed", n[n.LengthExceeded = 3] = "LengthExceeded", n[n.Incomplete = 4] = "Incomplete", n[n.HandlerAlreadyRegistered = 7] = "HandlerAlreadyRegistered", n[n.EncryptionTypeMismatch = 8] = "EncryptionTypeMismatch";
})(Qe || (Qe = {}));
class ut extends qr {
  constructor(e, t) {
    super(16, e), this.name = "DataStreamError", this.reason = t, this.reasonName = Qe[t];
  }
}
class vi extends Xt {
  constructor(e) {
    super(18, e), this.name = "SignalReconnectError";
  }
}
var Kn;
(function(n) {
  n.PermissionDenied = "PermissionDenied", n.NotFound = "NotFound", n.DeviceInUse = "DeviceInUse", n.Other = "Other";
})(Kn || (Kn = {}));
(function(n) {
  function e(t) {
    if (t && "name" in t)
      return t.name === "NotFoundError" || t.name === "DevicesNotFoundError" ? n.NotFound : t.name === "NotAllowedError" || t.name === "PermissionDeniedError" ? n.PermissionDenied : t.name === "NotReadableError" || t.name === "TrackStartError" ? n.DeviceInUse : n.Other;
  }
  n.getFailure = e;
})(Kn || (Kn = {}));
class Be {
}
Be.setTimeout = function() {
  return setTimeout(...arguments);
};
Be.setInterval = // eslint-disable-next-line @typescript-eslint/no-implied-eval
function() {
  return setInterval(...arguments);
};
Be.clearTimeout = function() {
  return clearTimeout(...arguments);
};
Be.clearInterval = function() {
  return clearInterval(...arguments);
};
var x;
(function(n) {
  n.Connected = "connected", n.Reconnecting = "reconnecting", n.SignalReconnecting = "signalReconnecting", n.Reconnected = "reconnected", n.Disconnected = "disconnected", n.ConnectionStateChanged = "connectionStateChanged", n.Moved = "moved", n.MediaDevicesChanged = "mediaDevicesChanged", n.ParticipantConnected = "participantConnected", n.ParticipantDisconnected = "participantDisconnected", n.TrackPublished = "trackPublished", n.TrackSubscribed = "trackSubscribed", n.TrackSubscriptionFailed = "trackSubscriptionFailed", n.TrackUnpublished = "trackUnpublished", n.TrackUnsubscribed = "trackUnsubscribed", n.TrackMuted = "trackMuted", n.TrackUnmuted = "trackUnmuted", n.LocalTrackPublished = "localTrackPublished", n.LocalTrackUnpublished = "localTrackUnpublished", n.LocalAudioSilenceDetected = "localAudioSilenceDetected", n.ActiveSpeakersChanged = "activeSpeakersChanged", n.ParticipantMetadataChanged = "participantMetadataChanged", n.ParticipantNameChanged = "participantNameChanged", n.ParticipantAttributesChanged = "participantAttributesChanged", n.ParticipantActive = "participantActive", n.RoomMetadataChanged = "roomMetadataChanged", n.DataReceived = "dataReceived", n.SipDTMFReceived = "sipDTMFReceived", n.TranscriptionReceived = "transcriptionReceived", n.ConnectionQualityChanged = "connectionQualityChanged", n.TrackStreamStateChanged = "trackStreamStateChanged", n.TrackSubscriptionPermissionChanged = "trackSubscriptionPermissionChanged", n.TrackSubscriptionStatusChanged = "trackSubscriptionStatusChanged", n.AudioPlaybackStatusChanged = "audioPlaybackChanged", n.VideoPlaybackStatusChanged = "videoPlaybackChanged", n.MediaDevicesError = "mediaDevicesError", n.ParticipantPermissionsChanged = "participantPermissionsChanged", n.SignalConnected = "signalConnected", n.RecordingStatusChanged = "recordingStatusChanged", n.ParticipantEncryptionStatusChanged = "participantEncryptionStatusChanged", n.EncryptionError = "encryptionError", n.DCBufferStatusChanged = "dcBufferStatusChanged", n.ActiveDeviceChanged = "activeDeviceChanged", n.ChatMessage = "chatMessage", n.LocalTrackSubscribed = "localTrackSubscribed", n.MetricsReceived = "metricsReceived";
})(x || (x = {}));
var W;
(function(n) {
  n.TrackPublished = "trackPublished", n.TrackSubscribed = "trackSubscribed", n.TrackSubscriptionFailed = "trackSubscriptionFailed", n.TrackUnpublished = "trackUnpublished", n.TrackUnsubscribed = "trackUnsubscribed", n.TrackMuted = "trackMuted", n.TrackUnmuted = "trackUnmuted", n.LocalTrackPublished = "localTrackPublished", n.LocalTrackUnpublished = "localTrackUnpublished", n.LocalTrackCpuConstrained = "localTrackCpuConstrained", n.LocalSenderCreated = "localSenderCreated", n.ParticipantMetadataChanged = "participantMetadataChanged", n.ParticipantNameChanged = "participantNameChanged", n.DataReceived = "dataReceived", n.SipDTMFReceived = "sipDTMFReceived", n.TranscriptionReceived = "transcriptionReceived", n.IsSpeakingChanged = "isSpeakingChanged", n.ConnectionQualityChanged = "connectionQualityChanged", n.TrackStreamStateChanged = "trackStreamStateChanged", n.TrackSubscriptionPermissionChanged = "trackSubscriptionPermissionChanged", n.TrackSubscriptionStatusChanged = "trackSubscriptionStatusChanged", n.TrackCpuConstrained = "trackCpuConstrained", n.MediaDevicesError = "mediaDevicesError", n.AudioStreamAcquired = "audioStreamAcquired", n.ParticipantPermissionsChanged = "participantPermissionsChanged", n.PCTrackAdded = "pcTrackAdded", n.AttributesChanged = "attributesChanged", n.LocalTrackSubscribed = "localTrackSubscribed", n.ChatMessage = "chatMessage", n.Active = "active";
})(W || (W = {}));
var H;
(function(n) {
  n.TransportsCreated = "transportsCreated", n.Connected = "connected", n.Disconnected = "disconnected", n.Resuming = "resuming", n.Resumed = "resumed", n.Restarting = "restarting", n.Restarted = "restarted", n.SignalResumed = "signalResumed", n.SignalRestarted = "signalRestarted", n.Closing = "closing", n.MediaTrackAdded = "mediaTrackAdded", n.ActiveSpeakersUpdate = "activeSpeakersUpdate", n.DataPacketReceived = "dataPacketReceived", n.RTPVideoMapUpdate = "rtpVideoMapUpdate", n.DCBufferStatusChanged = "dcBufferStatusChanged", n.ParticipantUpdate = "participantUpdate", n.RoomUpdate = "roomUpdate", n.SpeakersChanged = "speakersChanged", n.StreamStateChanged = "streamStateChanged", n.ConnectionQualityUpdate = "connectionQualityUpdate", n.SubscriptionError = "subscriptionError", n.SubscriptionPermissionUpdate = "subscriptionPermissionUpdate", n.RemoteMute = "remoteMute", n.SubscribedQualityUpdate = "subscribedQualityUpdate", n.LocalTrackUnpublished = "localTrackUnpublished", n.LocalTrackSubscribed = "localTrackSubscribed", n.Offline = "offline", n.SignalRequestResponse = "signalRequestResponse", n.SignalConnected = "signalConnected", n.RoomMoved = "roomMoved";
})(H || (H = {}));
var U;
(function(n) {
  n.Message = "message", n.Muted = "muted", n.Unmuted = "unmuted", n.Restarted = "restarted", n.Ended = "ended", n.Subscribed = "subscribed", n.Unsubscribed = "unsubscribed", n.CpuConstrained = "cpuConstrained", n.UpdateSettings = "updateSettings", n.UpdateSubscription = "updateSubscription", n.AudioPlaybackStarted = "audioPlaybackStarted", n.AudioPlaybackFailed = "audioPlaybackFailed", n.AudioSilenceDetected = "audioSilenceDetected", n.VisibilityChanged = "visibilityChanged", n.VideoDimensionsChanged = "videoDimensionsChanged", n.VideoPlaybackStarted = "videoPlaybackStarted", n.VideoPlaybackFailed = "videoPlaybackFailed", n.ElementAttached = "elementAttached", n.ElementDetached = "elementDetached", n.UpstreamPaused = "upstreamPaused", n.UpstreamResumed = "upstreamResumed", n.SubscriptionPermissionChanged = "subscriptionPermissionChanged", n.SubscriptionStatusChanged = "subscriptionStatusChanged", n.SubscriptionFailed = "subscriptionFailed", n.TrackProcessorUpdate = "trackProcessorUpdate", n.AudioTrackFeatureUpdate = "audioTrackFeatureUpdate", n.TranscriptionReceived = "transcriptionReceived", n.TimeSyncUpdate = "timeSyncUpdate", n.PreConnectBufferFlushed = "preConnectBufferFlushed";
})(U || (U = {}));
function Bh(n) {
  return typeof n == "undefined" ? n : typeof structuredClone == "function" ? typeof n == "object" && n !== null ? structuredClone(Object.assign({}, n)) : structuredClone(n) : JSON.parse(JSON.stringify(n));
}
class we {
  constructor(e, t, i, s, r) {
    if (typeof e == "object")
      this.width = e.width, this.height = e.height, this.aspectRatio = e.aspectRatio, this.encoding = {
        maxBitrate: e.maxBitrate,
        maxFramerate: e.maxFramerate,
        priority: e.priority
      };
    else if (t !== void 0 && i !== void 0)
      this.width = e, this.height = t, this.aspectRatio = e / t, this.encoding = {
        maxBitrate: i,
        maxFramerate: s,
        priority: r
      };
    else
      throw new TypeError("Unsupported options: provide at least width, height and maxBitrate");
  }
  get resolution() {
    return {
      width: this.width,
      height: this.height,
      frameRate: this.encoding.maxFramerate,
      aspectRatio: this.aspectRatio
    };
  }
}
const jh = ["vp8", "h264"], qh = ["vp8", "h264", "vp9", "av1", "h265"];
function Hh(n) {
  return !!jh.find((e) => e === n);
}
const Wh = Hh;
var Ga;
(function(n) {
  n[n.PREFER_REGRESSION = 0] = "PREFER_REGRESSION", n[n.SIMULCAST = 1] = "SIMULCAST", n[n.REGRESSION = 2] = "REGRESSION";
})(Ga || (Ga = {}));
var rr;
(function(n) {
  n.telephone = {
    maxBitrate: 12e3
  }, n.speech = {
    maxBitrate: 24e3
  }, n.music = {
    maxBitrate: 48e3
  }, n.musicStereo = {
    maxBitrate: 64e3
  }, n.musicHighQuality = {
    maxBitrate: 96e3
  }, n.musicHighQualityStereo = {
    maxBitrate: 128e3
  };
})(rr || (rr = {}));
const ln = {
  h90: new we(160, 90, 9e4, 20),
  h180: new we(320, 180, 16e4, 20),
  h216: new we(384, 216, 18e4, 20),
  h360: new we(640, 360, 45e4, 20),
  h540: new we(960, 540, 8e5, 25),
  h720: new we(1280, 720, 17e5, 30),
  h1080: new we(1920, 1080, 3e6, 30),
  h1440: new we(2560, 1440, 5e6, 30),
  h2160: new we(3840, 2160, 8e6, 30)
}, ar = {
  h120: new we(160, 120, 7e4, 20),
  h180: new we(240, 180, 125e3, 20),
  h240: new we(320, 240, 14e4, 20),
  h360: new we(480, 360, 33e4, 20),
  h480: new we(640, 480, 5e5, 20),
  h540: new we(720, 540, 6e5, 25),
  h720: new we(960, 720, 13e5, 30),
  h1080: new we(1440, 1080, 23e5, 30),
  h1440: new we(1920, 1440, 38e5, 30)
}, Wr = {
  h360fps3: new we(640, 360, 2e5, 3, "medium"),
  h360fps15: new we(640, 360, 4e5, 15, "medium"),
  h720fps5: new we(1280, 720, 8e5, 5, "medium"),
  h720fps15: new we(1280, 720, 15e5, 15, "medium"),
  h720fps30: new we(1280, 720, 2e6, 30, "medium"),
  h1080fps15: new we(1920, 1080, 25e5, 15, "medium"),
  h1080fps30: new we(1920, 1080, 5e6, 30, "medium"),
  // original resolution, without resizing
  original: new we(0, 0, 7e6, 30, "medium")
};
function Rd(n, e, t) {
  var i, s, r, o;
  const {
    optionsWithoutProcessor: a,
    audioProcessor: c,
    videoProcessor: d
  } = xd(n != null ? n : {}), l = e == null ? void 0 : e.processor, u = t == null ? void 0 : t.processor, h = a != null ? a : {};
  return h.audio === !0 && (h.audio = {}), h.video === !0 && (h.video = {}), h.audio && (or(h.audio, e), (i = (r = h.audio).deviceId) !== null && i !== void 0 || (r.deviceId = {
    ideal: "default"
  }), (c || l) && (h.audio.processor = c != null ? c : l)), h.video && (or(h.video, t), (s = (o = h.video).deviceId) !== null && s !== void 0 || (o.deviceId = {
    ideal: "default"
  }), (d || u) && (h.video.processor = d != null ? d : u)), h;
}
function or(n, e) {
  return Object.keys(e).forEach((t) => {
    n[t] === void 0 && (n[t] = e[t]);
  }), n;
}
function $r(n) {
  var e, t, i, s;
  const r = {};
  if (n.video)
    if (typeof n.video == "object") {
      const o = {}, a = o, c = n.video;
      Object.keys(c).forEach((d) => {
        switch (d) {
          case "resolution":
            or(a, c.resolution);
            break;
          default:
            a[d] = c[d];
        }
      }), r.video = o, (e = (i = r.video).deviceId) !== null && e !== void 0 || (i.deviceId = {
        ideal: "default"
      });
    } else
      r.video = n.video ? {
        deviceId: {
          ideal: "default"
        }
      } : !1;
  else
    r.video = !1;
  return n.audio ? typeof n.audio == "object" ? (r.audio = n.audio, (t = (s = r.audio).deviceId) !== null && t !== void 0 || (s.deviceId = {
    ideal: "default"
  })) : r.audio = {
    deviceId: {
      ideal: "default"
    }
  } : r.audio = !1, r;
}
function Id(n) {
  return m(this, arguments, void 0, function(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 200;
    return (function* () {
      const i = Pd();
      if (i) {
        const s = i.createAnalyser();
        s.fftSize = 2048;
        const r = s.frequencyBinCount, o = new Uint8Array(r);
        i.createMediaStreamSource(new MediaStream([e.mediaStreamTrack])).connect(s), yield ze(t), s.getByteTimeDomainData(o);
        const c = o.some((d) => d !== 128 && d !== 0);
        return i.close(), !c;
      }
      return !1;
    })();
  });
}
function Pd() {
  var n;
  const e = (
    // @ts-ignore
    typeof window != "undefined" && (window.AudioContext || window.webkitAudioContext)
  );
  if (e) {
    const t = new e({
      latencyHint: "interactive"
    });
    if (t.state === "suspended" && typeof window != "undefined" && (!((n = window.document) === null || n === void 0) && n.body)) {
      const i = () => m(this, void 0, void 0, function* () {
        var s;
        try {
          t.state === "suspended" && (yield t.resume());
        } catch (r) {
          console.warn("Error trying to auto-resume audio context", r);
        } finally {
          (s = window.document.body) === null || s === void 0 || s.removeEventListener("click", i);
        }
      });
      t.addEventListener("statechange", () => {
        var s;
        t.state === "closed" && ((s = window.document.body) === null || s === void 0 || s.removeEventListener("click", i));
      }), window.document.body.addEventListener("click", i);
    }
    return t;
  }
}
function $h(n) {
  return n === "audioinput" ? E.Source.Microphone : n === "videoinput" ? E.Source.Camera : E.Source.Unknown;
}
function cr(n) {
  return n === E.Source.Microphone ? "audioinput" : n === E.Source.Camera ? "videoinput" : void 0;
}
function zh(n) {
  var e, t;
  let i = (e = n.video) !== null && e !== void 0 ? e : !0;
  return n.resolution && n.resolution.width > 0 && n.resolution.height > 0 && (i = typeof i == "boolean" ? {} : i, hi() ? i = Object.assign(Object.assign({}, i), {
    width: {
      max: n.resolution.width
    },
    height: {
      max: n.resolution.height
    },
    frameRate: n.resolution.frameRate
  }) : i = Object.assign(Object.assign({}, i), {
    width: {
      ideal: n.resolution.width
    },
    height: {
      ideal: n.resolution.height
    },
    frameRate: n.resolution.frameRate
  })), {
    audio: (t = n.audio) !== null && t !== void 0 ? t : !1,
    video: i,
    // @ts-expect-error support for experimental display media features
    controller: n.controller,
    selfBrowserSurface: n.selfBrowserSurface,
    surfaceSwitching: n.surfaceSwitching,
    systemAudio: n.systemAudio,
    preferCurrentTab: n.preferCurrentTab
  };
}
function rn(n) {
  return n.split("/")[1].toLowerCase();
}
function Kh(n) {
  const e = [];
  return n.forEach((t) => {
    t.track !== void 0 && e.push(new Lr({
      cid: t.track.mediaStreamID,
      track: t.trackInfo
    }));
  }), e;
}
function ue(n) {
  return "mediaStreamTrack" in n ? {
    trackID: n.sid,
    source: n.source,
    muted: n.isMuted,
    enabled: n.mediaStreamTrack.enabled,
    kind: n.kind,
    streamID: n.mediaStreamID,
    streamTrackID: n.mediaStreamTrack.id
  } : {
    trackID: n.trackSid,
    enabled: n.isEnabled,
    muted: n.isMuted,
    trackInfo: Object.assign({
      mimeType: n.mimeType,
      name: n.trackName,
      encrypted: n.isEncrypted,
      kind: n.kind,
      source: n.source
    }, n.track ? ue(n.track) : {})
  };
}
function Gh() {
  return typeof RTCRtpReceiver != "undefined" && "getSynchronizationSources" in RTCRtpReceiver;
}
function Jh(n, e) {
  var t;
  n === void 0 && (n = {}), e === void 0 && (e = {});
  const i = [...Object.keys(e), ...Object.keys(n)], s = {};
  for (const r of i)
    n[r] !== e[r] && (s[r] = (t = e[r]) !== null && t !== void 0 ? t : "");
  return s;
}
function xd(n) {
  const e = Object.assign({}, n);
  let t, i;
  return typeof e.audio == "object" && e.audio.processor && (t = e.audio.processor, e.audio = Object.assign(Object.assign({}, e.audio), {
    processor: void 0
  })), typeof e.video == "object" && e.video.processor && (i = e.video.processor, e.video = Object.assign(Object.assign({}, e.video), {
    processor: void 0
  })), {
    audioProcessor: t,
    videoProcessor: i,
    optionsWithoutProcessor: Bh(e)
  };
}
function Yh(n) {
  switch (n) {
    case Fe.CAMERA:
      return E.Source.Camera;
    case Fe.MICROPHONE:
      return E.Source.Microphone;
    case Fe.SCREEN_SHARE:
      return E.Source.ScreenShare;
    case Fe.SCREEN_SHARE_AUDIO:
      return E.Source.ScreenShareAudio;
    default:
      return E.Source.Unknown;
  }
}
function Ja(n, e) {
  return n.width * n.height < e.width * e.height;
}
function Qh(n, e) {
  var t;
  return (t = n.layers) === null || t === void 0 ? void 0 : t.find((i) => i.quality === e);
}
const Xh = 5e3, zi = [];
var rt;
(function(n) {
  n[n.LOW = 0] = "LOW", n[n.MEDIUM = 1] = "MEDIUM", n[n.HIGH = 2] = "HIGH";
})(rt || (rt = {}));
class E extends Pt.EventEmitter {
  /**
   * indicates current state of stream, it'll indicate `paused` if the track
   * has been paused by congestion controller
   */
  get streamState() {
    return this._streamState;
  }
  /** @internal */
  setStreamState(e) {
    this._streamState = e;
  }
  constructor(e, t) {
    let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    var s;
    super(), this.attachedElements = [], this.isMuted = !1, this._streamState = E.StreamState.Active, this.isInBackground = !1, this._currentBitrate = 0, this.log = se, this.appVisibilityChangedListener = () => {
      this.backgroundTimeout && clearTimeout(this.backgroundTimeout), document.visibilityState === "hidden" ? this.backgroundTimeout = setTimeout(() => this.handleAppVisibilityChanged(), Xh) : this.handleAppVisibilityChanged();
    }, this.log = St((s = i.loggerName) !== null && s !== void 0 ? s : at.Track), this.loggerContextCb = i.loggerContextCb, this.setMaxListeners(100), this.kind = t, this._mediaStreamTrack = e, this._mediaStreamID = e.id, this.source = E.Source.Unknown;
  }
  get logContext() {
    var e;
    return Object.assign(Object.assign({}, (e = this.loggerContextCb) === null || e === void 0 ? void 0 : e.call(this)), ue(this));
  }
  /** current receive bits per second */
  get currentBitrate() {
    return this._currentBitrate;
  }
  get mediaStreamTrack() {
    return this._mediaStreamTrack;
  }
  /**
   * @internal
   * used for keep mediaStream's first id, since it's id might change
   * if we disable/enable a track
   */
  get mediaStreamID() {
    return this._mediaStreamID;
  }
  attach(e) {
    let t = "audio";
    this.kind === E.Kind.Video && (t = "video"), this.attachedElements.length === 0 && this.kind === E.Kind.Video && this.addAppVisibilityListener(), e || (t === "audio" && (zi.forEach((r) => {
      r.parentElement === null && !e && (e = r);
    }), e && zi.splice(zi.indexOf(e), 1)), e || (e = document.createElement(t))), this.attachedElements.includes(e) || this.attachedElements.push(e), Ri(this.mediaStreamTrack, e);
    const i = e.srcObject.getTracks(), s = i.some((r) => r.kind === "audio");
    return e.play().then(() => {
      this.emit(s ? U.AudioPlaybackStarted : U.VideoPlaybackStarted);
    }).catch((r) => {
      r.name === "NotAllowedError" ? this.emit(s ? U.AudioPlaybackFailed : U.VideoPlaybackFailed, r) : r.name === "AbortError" ? se.debug("".concat(s ? "audio" : "video", " playback aborted, likely due to new play request")) : se.warn("could not playback ".concat(s ? "audio" : "video"), r), s && e && i.some((o) => o.kind === "video") && r.name === "NotAllowedError" && (e.muted = !0, e.play().catch(() => {
      }));
    }), this.emit(U.ElementAttached, e), e;
  }
  detach(e) {
    try {
      if (e) {
        Oi(this.mediaStreamTrack, e);
        const i = this.attachedElements.indexOf(e);
        return i >= 0 && (this.attachedElements.splice(i, 1), this.recycleElement(e), this.emit(U.ElementDetached, e)), e;
      }
      const t = [];
      return this.attachedElements.forEach((i) => {
        Oi(this.mediaStreamTrack, i), t.push(i), this.recycleElement(i), this.emit(U.ElementDetached, i);
      }), this.attachedElements = [], t;
    } finally {
      this.attachedElements.length === 0 && this.removeAppVisibilityListener();
    }
  }
  stop() {
    this.stopMonitor(), this._mediaStreamTrack.stop();
  }
  enable() {
    this._mediaStreamTrack.enabled = !0;
  }
  disable() {
    this._mediaStreamTrack.enabled = !1;
  }
  /* @internal */
  stopMonitor() {
    this.monitorInterval && clearInterval(this.monitorInterval), this.timeSyncHandle && cancelAnimationFrame(this.timeSyncHandle);
  }
  /** @internal */
  updateLoggerOptions(e) {
    e.loggerName && (this.log = St(e.loggerName)), e.loggerContextCb && (this.loggerContextCb = e.loggerContextCb);
  }
  recycleElement(e) {
    if (e instanceof HTMLAudioElement) {
      let t = !0;
      e.pause(), zi.forEach((i) => {
        i.parentElement || (t = !1);
      }), t && zi.push(e);
    }
  }
  handleAppVisibilityChanged() {
    return m(this, void 0, void 0, function* () {
      this.isInBackground = document.visibilityState === "hidden", !this.isInBackground && this.kind === E.Kind.Video && setTimeout(() => this.attachedElements.forEach((e) => e.play().catch(() => {
      })), 0);
    });
  }
  addAppVisibilityListener() {
    it() ? (this.isInBackground = document.visibilityState === "hidden", document.addEventListener("visibilitychange", this.appVisibilityChangedListener)) : this.isInBackground = !1;
  }
  removeAppVisibilityListener() {
    it() && document.removeEventListener("visibilitychange", this.appVisibilityChangedListener);
  }
}
function Ri(n, e) {
  let t;
  e.srcObject instanceof MediaStream ? t = e.srcObject : t = new MediaStream();
  let i;
  n.kind === "audio" ? i = t.getAudioTracks() : i = t.getVideoTracks(), i.includes(n) || (i.forEach((s) => {
    t.removeTrack(s);
  }), t.addTrack(n)), (!hi() || !(e instanceof HTMLVideoElement)) && (e.autoplay = !0), e.muted = t.getAudioTracks().length === 0, e instanceof HTMLVideoElement && (e.playsInline = !0), e.srcObject !== t && (e.srcObject = t, (hi() || ui()) && e instanceof HTMLVideoElement && setTimeout(() => {
    e.srcObject = t, e.play().catch(() => {
    });
  }, 0));
}
function Oi(n, e) {
  if (e.srcObject instanceof MediaStream) {
    const t = e.srcObject;
    t.removeTrack(n), t.getTracks().length > 0 ? e.srcObject = t : e.srcObject = null;
  }
}
(function(n) {
  let e;
  (function(d) {
    d.Audio = "audio", d.Video = "video", d.Unknown = "unknown";
  })(e = n.Kind || (n.Kind = {}));
  let t;
  (function(d) {
    d.Camera = "camera", d.Microphone = "microphone", d.ScreenShare = "screen_share", d.ScreenShareAudio = "screen_share_audio", d.Unknown = "unknown";
  })(t = n.Source || (n.Source = {}));
  let i;
  (function(d) {
    d.Active = "active", d.Paused = "paused", d.Unknown = "unknown";
  })(i = n.StreamState || (n.StreamState = {}));
  function s(d) {
    switch (d) {
      case e.Audio:
        return gt.AUDIO;
      case e.Video:
        return gt.VIDEO;
      default:
        return gt.DATA;
    }
  }
  n.kindToProto = s;
  function r(d) {
    switch (d) {
      case gt.AUDIO:
        return e.Audio;
      case gt.VIDEO:
        return e.Video;
      default:
        return e.Unknown;
    }
  }
  n.kindFromProto = r;
  function o(d) {
    switch (d) {
      case t.Camera:
        return Fe.CAMERA;
      case t.Microphone:
        return Fe.MICROPHONE;
      case t.ScreenShare:
        return Fe.SCREEN_SHARE;
      case t.ScreenShareAudio:
        return Fe.SCREEN_SHARE_AUDIO;
      default:
        return Fe.UNKNOWN;
    }
  }
  n.sourceToProto = o;
  function a(d) {
    switch (d) {
      case Fe.CAMERA:
        return t.Camera;
      case Fe.MICROPHONE:
        return t.Microphone;
      case Fe.SCREEN_SHARE:
        return t.ScreenShare;
      case Fe.SCREEN_SHARE_AUDIO:
        return t.ScreenShareAudio;
      default:
        return t.Unknown;
    }
  }
  n.sourceFromProto = a;
  function c(d) {
    switch (d) {
      case Js.ACTIVE:
        return i.Active;
      case Js.PAUSED:
        return i.Paused;
      default:
        return i.Unknown;
    }
  }
  n.streamStateFromProto = c;
})(E || (E = {}));
const Zh = "|", Ya = "https://aomediacodec.github.io/av1-rtp-spec/#dependency-descriptor-rtp-header-extension";
function ep(n) {
  const e = n.split(Zh);
  return e.length > 1 ? [e[0], n.substr(e[0].length + 1)] : [n, ""];
}
function ze(n) {
  return new Je((e) => Be.setTimeout(e, n));
}
function dr() {
  return "addTransceiver" in RTCPeerConnection.prototype;
}
function lr() {
  return "addTrack" in RTCPeerConnection.prototype;
}
function tp() {
  if (!("getCapabilities" in RTCRtpSender) || hi() || ui())
    return !1;
  const n = RTCRtpSender.getCapabilities("video");
  let e = !1;
  if (n) {
    for (const t of n.codecs)
      if (t.mimeType.toLowerCase() === "video/av1") {
        e = !0;
        break;
      }
  }
  return e;
}
function ip() {
  if (!("getCapabilities" in RTCRtpSender) || ui())
    return !1;
  if (hi()) {
    const t = nt();
    if (t != null && t.version && It(t.version, "16") < 0 || (t == null ? void 0 : t.os) === "iOS" && (t != null && t.osVersion) && It(t.osVersion, "16") < 0)
      return !1;
  }
  const n = RTCRtpSender.getCapabilities("video");
  let e = !1;
  if (n) {
    for (const t of n.codecs)
      if (t.mimeType.toLowerCase() === "video/vp9") {
        e = !0;
        break;
      }
  }
  return e;
}
function bt(n) {
  return n === "av1" || n === "vp9";
}
function ur(n) {
  return !document || un() ? !1 : (n || (n = document.createElement("audio")), "setSinkId" in n);
}
function np() {
  return typeof RTCPeerConnection == "undefined" ? !1 : dr() || lr();
}
function ui() {
  var n;
  return ((n = nt()) === null || n === void 0 ? void 0 : n.name) === "Firefox";
}
function Qa() {
  const n = nt();
  return !!n && n.name === "Chrome" && n.os !== "iOS";
}
function hi() {
  var n;
  return ((n = nt()) === null || n === void 0 ? void 0 : n.name) === "Safari";
}
function un() {
  const n = nt();
  return (n == null ? void 0 : n.name) === "Safari" || (n == null ? void 0 : n.os) === "iOS";
}
function sp() {
  const n = nt();
  return (n == null ? void 0 : n.name) === "Safari" && n.version.startsWith("17.") || (n == null ? void 0 : n.os) === "iOS" && !!(n != null && n.osVersion) && It(n.osVersion, "17") >= 0;
}
function rp(n) {
  return n || (n = nt()), (n == null ? void 0 : n.name) === "Safari" && It(n.version, "18.3") > 0 || (n == null ? void 0 : n.os) === "iOS" && !!(n != null && n.osVersion) && It(n.osVersion, "18.3") > 0;
}
function Md() {
  var n, e;
  return it() ? (
    // @ts-expect-error `userAgentData` is not yet part of typescript
    (e = (n = navigator.userAgentData) === null || n === void 0 ? void 0 : n.mobile) !== null && e !== void 0 ? e : /Tablet|iPad|Mobile|Android|BlackBerry/.test(navigator.userAgent)
  ) : !1;
}
function ap() {
  const n = nt(), e = "17.2";
  if (n)
    return n.name !== "Safari" && n.os !== "iOS" || n.os === "iOS" && n.osVersion && It(n.osVersion, e) >= 0 ? !0 : n.name === "Safari" && It(n.version, e) >= 0;
}
function it() {
  return typeof document != "undefined";
}
function Rt() {
  return navigator.product == "ReactNative";
}
function Vi(n) {
  return n.hostname.endsWith(".livekit.cloud") || n.hostname.endsWith(".livekit.run");
}
function Ts(n) {
  return Vi(n) ? n.hostname.split(".")[0] : null;
}
function Ad() {
  if (global && global.LiveKitReactNativeGlobal)
    return global.LiveKitReactNativeGlobal;
}
function Od() {
  if (!Rt())
    return;
  let n = Ad();
  if (n)
    return n.platform;
}
function Xa() {
  if (it())
    return window.devicePixelRatio;
  if (Rt()) {
    let n = Ad();
    if (n)
      return n.devicePixelRatio;
  }
  return 1;
}
function It(n, e) {
  const t = n.split("."), i = e.split("."), s = Math.min(t.length, i.length);
  for (let r = 0; r < s; ++r) {
    const o = parseInt(t[r], 10), a = parseInt(i[r], 10);
    if (o > a) return 1;
    if (o < a) return -1;
    if (r === s - 1 && o === a) return 0;
  }
  return n === "" && e !== "" ? -1 : e === "" ? 1 : t.length == i.length ? 0 : t.length < i.length ? -1 : 1;
}
function op(n) {
  for (const e of n)
    e.target.handleResize(e);
}
function cp(n) {
  for (const e of n)
    e.target.handleVisibilityChanged(e);
}
let Cs = null;
const Za = () => (Cs || (Cs = new ResizeObserver(op)), Cs);
let _s = null;
const eo = () => (_s || (_s = new IntersectionObserver(cp, {
  root: null,
  rootMargin: "0px"
})), _s);
function dp() {
  var n;
  const e = new Ic({
    sdk: Pc.JS,
    protocol: Fh,
    version: Uh
  });
  return Rt() && (e.os = (n = Od()) !== null && n !== void 0 ? n : ""), e;
}
function to() {
  let n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 16, e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 16, t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
  const s = document.createElement("canvas");
  s.width = n, s.height = e;
  const r = s.getContext("2d");
  r == null || r.fillRect(0, 0, s.width, s.height), i && r && (r.beginPath(), r.arc(n / 2, e / 2, 50, 0, Math.PI * 2, !0), r.closePath(), r.fillStyle = "grey", r.fill());
  const o = s.captureStream(), [a] = o.getTracks();
  if (!a)
    throw Error("Could not get empty media stream video track");
  return a.enabled = t, a;
}
let Ki;
function ws() {
  if (!Ki) {
    const n = new AudioContext(), e = n.createOscillator(), t = n.createGain();
    t.gain.setValueAtTime(0, 0);
    const i = n.createMediaStreamDestination();
    if (e.connect(t), t.connect(i), e.start(), [Ki] = i.stream.getAudioTracks(), !Ki)
      throw Error("Could not get empty media stream audio track");
    Ki.enabled = !1;
  }
  return Ki.clone();
}
class $t {
  get isResolved() {
    return this._isResolved;
  }
  constructor(e, t) {
    this._isResolved = !1, this.onFinally = t, this.promise = new Promise((i, s) => m(this, void 0, void 0, function* () {
      this.resolve = i, this.reject = s, e && (yield e(i, s));
    })).finally(() => {
      var i;
      this._isResolved = !0, (i = this.onFinally) === null || i === void 0 || i.call(this);
    });
  }
}
function lp(n) {
  return qh.includes(n);
}
function ci(n) {
  if (typeof n == "string" || typeof n == "number")
    return n;
  if (Array.isArray(n))
    return n[0];
  if (n.exact !== void 0)
    return Array.isArray(n.exact) ? n.exact[0] : n.exact;
  if (n.ideal !== void 0)
    return Array.isArray(n.ideal) ? n.ideal[0] : n.ideal;
  throw Error("could not unwrap constraint");
}
function up(n) {
  return n.startsWith("http") ? n.replace(/^(http)/, "ws") : n;
}
function hn(n) {
  return n.startsWith("ws") ? n.replace(/^(ws)/, "http") : n;
}
function hp(n, e) {
  return n.segments.map((t) => {
    let {
      id: i,
      text: s,
      language: r,
      startTime: o,
      endTime: a,
      final: c
    } = t;
    var d;
    const l = (d = e.get(i)) !== null && d !== void 0 ? d : Date.now(), u = Date.now();
    return c ? e.delete(i) : e.set(i, l), {
      id: i,
      text: s,
      startTime: Number.parseInt(o.toString()),
      endTime: Number.parseInt(a.toString()),
      final: c,
      language: r,
      firstReceivedTime: l,
      lastReceivedTime: u
    };
  });
}
function pp(n) {
  const {
    id: e,
    timestamp: t,
    message: i,
    editTimestamp: s
  } = n;
  return {
    id: e,
    timestamp: Number.parseInt(t.toString()),
    editTimestamp: s ? Number.parseInt(s.toString()) : void 0,
    message: i
  };
}
function io(n) {
  switch (n.reason) {
    case Re.LeaveRequest:
      return n.context;
    case Re.Cancelled:
      return yt.CLIENT_INITIATED;
    case Re.NotAllowed:
      return yt.USER_REJECTED;
    case Re.ServerUnreachable:
      return yt.JOIN_FAILURE;
    default:
      return yt.UNKNOWN_REASON;
  }
}
function Nn(n) {
  return n !== void 0 ? Number(n) : void 0;
}
function ri(n) {
  return n !== void 0 ? BigInt(n) : void 0;
}
function Di(n) {
  return !!n && !(n instanceof MediaStreamTrack) && n.isLocal;
}
function Et(n) {
  return !!n && n.kind == E.Kind.Audio;
}
function Zt(n) {
  return !!n && n.kind == E.Kind.Video;
}
function jt(n) {
  return Di(n) && Zt(n);
}
function At(n) {
  return Di(n) && Et(n);
}
function hr(n) {
  return !!n && !n.isLocal;
}
function mp(n) {
  return !!n && !n.isLocal;
}
function Es(n) {
  return hr(n) && Zt(n);
}
function fp(n) {
  return n.isLocal;
}
function gp(n, e) {
  const t = [];
  let i = new TextEncoder().encode(n);
  for (; i.length > e; ) {
    let s = e;
    for (; s > 0; ) {
      const r = i[s];
      if (r !== void 0 && (r & 192) !== 128)
        break;
      s--;
    }
    t.push(i.slice(0, s)), i = i.slice(s);
  }
  return i.length > 0 && t.push(i), t;
}
function vp(n) {
  var e;
  const t = n.get("Cache-Control");
  if (t) {
    const i = (e = t.match(/(?:^|[,\s])max-age=(\d+)/)) === null || e === void 0 ? void 0 : e[1];
    if (i)
      return parseInt(i, 10);
  }
}
function bp(n, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
  const i = yp(n, e);
  return t ? i : zr(i, "v1");
}
function yp(n, e) {
  const t = new URL(up(n));
  return e.forEach((i, s) => {
    t.searchParams.set(s, i);
  }), zr(t, "rtc");
}
function Sp(n) {
  const e = new URL(hn(n));
  return zr(e, "validate");
}
function Dd(n) {
  return n.endsWith("/") ? n : "".concat(n, "/");
}
function zr(n, e) {
  return n.pathname = "".concat(Dd(n.pathname)).concat(e), n;
}
function no(n) {
  if (typeof n == "string")
    return La.fromJson(JSON.parse(n), {
      ignoreUnknownFields: !0
    });
  if (n instanceof ArrayBuffer)
    return La.fromBinary(new Uint8Array(n));
  throw new Error("could not decode websocket message: ".concat(typeof n));
}
function kp(n) {
  let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Unknown reason";
  if (!(n instanceof AbortSignal))
    return e;
  const t = n.reason;
  switch (typeof t) {
    case "string":
      return t;
    case "object":
      return t instanceof Error ? t.message : e;
    default:
      return "toString" in t ? t.toString() : e;
  }
}
const Tp = 10, Gi = "lk_e2ee", Cp = "LKFrameEncryptionKey", _p = {
  sharedKey: !1,
  ratchetSalt: Cp,
  ratchetWindowSize: 8,
  failureTolerance: Tp,
  keyringSize: 16
};
var Gt;
(function(n) {
  n.SetKey = "setKey", n.RatchetRequest = "ratchetRequest", n.KeyRatcheted = "keyRatcheted";
})(Gt || (Gt = {}));
var so;
(function(n) {
  n.KeyRatcheted = "keyRatcheted";
})(so || (so = {}));
var zt;
(function(n) {
  n.ParticipantEncryptionStatusChanged = "participantEncryptionStatusChanged", n.EncryptionError = "encryptionError";
})(zt || (zt = {}));
var ro;
(function(n) {
  n.Error = "cryptorError";
})(ro || (ro = {}));
function wp() {
  return Ep() || pr();
}
function pr() {
  return typeof window.RTCRtpScriptTransform != "undefined";
}
function Ep() {
  return typeof window.RTCRtpSender != "undefined" && // @ts-ignore
  typeof window.RTCRtpSender.prototype.createEncodedStreams != "undefined";
}
function Rp(n) {
  var e, t, i, s, r;
  if (((e = n.value) === null || e === void 0 ? void 0 : e.case) !== "sipDtmf" && ((t = n.value) === null || t === void 0 ? void 0 : t.case) !== "metrics" && ((i = n.value) === null || i === void 0 ? void 0 : i.case) !== "speaker" && ((s = n.value) === null || s === void 0 ? void 0 : s.case) !== "transcription" && ((r = n.value) === null || r === void 0 ? void 0 : r.case) !== "encryptedPacket")
    return new kc({
      value: n.value
    });
}
class _v extends Pt.EventEmitter {
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    super(), this.latestManuallySetKeyIndex = 0, this.onKeyRatcheted = (t, i, s) => {
      se.debug("key ratcheted event received", {
        ratchetResult: t,
        participantId: i,
        keyIndex: s
      });
    }, this.keyInfoMap = /* @__PURE__ */ new Map(), this.options = Object.assign(Object.assign({}, _p), e), this.on(Gt.KeyRatcheted, this.onKeyRatcheted);
  }
  /**
   * callback to invoke once a key has been set for a participant
   * @param key
   * @param participantIdentity
   * @param keyIndex
   */
  onSetEncryptionKey(e, t, i) {
    const s = {
      key: e,
      participantIdentity: t,
      keyIndex: i
    };
    if (!this.options.sharedKey && !t)
      throw new Error("participant identity needs to be passed for encryption key if sharedKey option is false");
    this.keyInfoMap.set("".concat(t != null ? t : "shared", "-").concat(i != null ? i : 0), s), i !== void 0 && (this.latestManuallySetKeyIndex = i), this.emit(Gt.SetKey, s, i !== void 0);
  }
  getKeys() {
    return Array.from(this.keyInfoMap.values());
  }
  getLatestManuallySetKeyIndex() {
    return this.latestManuallySetKeyIndex;
  }
  getOptions() {
    return this.options;
  }
  ratchetKey(e, t) {
    this.emit(Gt.RatchetRequest, e, t);
  }
}
var ao;
(function(n) {
  n[n.InvalidKey = 0] = "InvalidKey", n[n.MissingKey = 1] = "MissingKey", n[n.InternalError = 2] = "InternalError";
})(ao || (ao = {}));
class Ip extends Pt.EventEmitter {
  constructor(e, t) {
    super(), this.decryptDataRequests = /* @__PURE__ */ new Map(), this.encryptDataRequests = /* @__PURE__ */ new Map(), this.onWorkerMessage = (i) => {
      var s, r;
      const {
        kind: o,
        data: a
      } = i.data;
      switch (o) {
        case "error":
          if (se.error(a.error.message), a.uuid) {
            const l = this.decryptDataRequests.get(a.uuid);
            if (l != null && l.reject) {
              l.reject(a.error);
              break;
            }
            const u = this.encryptDataRequests.get(a.uuid);
            if (u != null && u.reject) {
              u.reject(a.error);
              break;
            }
          }
          this.emit(zt.EncryptionError, a.error, a.participantIdentity);
          break;
        case "initAck":
          a.enabled && this.keyProvider.getKeys().forEach((l) => {
            this.postKey(l, !1);
          });
          break;
        case "enable":
          if (a.enabled && this.keyProvider.getKeys().forEach((l) => {
            this.postKey(l, !1);
          }), this.encryptionEnabled !== a.enabled && a.participantIdentity === ((s = this.room) === null || s === void 0 ? void 0 : s.localParticipant.identity))
            this.emit(zt.ParticipantEncryptionStatusChanged, a.enabled, this.room.localParticipant), this.encryptionEnabled = a.enabled;
          else if (a.participantIdentity) {
            const l = (r = this.room) === null || r === void 0 ? void 0 : r.getParticipantByIdentity(a.participantIdentity);
            if (!l)
              throw TypeError("couldn't set encryption status, participant not found".concat(a.participantIdentity));
            this.emit(zt.ParticipantEncryptionStatusChanged, a.enabled, l);
          }
          break;
        case "ratchetKey":
          this.keyProvider.emit(Gt.KeyRatcheted, a.ratchetResult, a.participantIdentity, a.keyIndex);
          break;
        case "decryptDataResponse":
          const c = this.decryptDataRequests.get(a.uuid);
          c != null && c.resolve && c.resolve(a);
          break;
        case "encryptDataResponse":
          const d = this.encryptDataRequests.get(a.uuid);
          d != null && d.resolve && d.resolve(a);
          break;
      }
    }, this.onWorkerError = (i) => {
      se.error("e2ee worker encountered an error:", {
        error: i.error
      }), this.emit(zt.EncryptionError, i.error, void 0);
    }, this.keyProvider = e.keyProvider, this.worker = e.worker, this.encryptionEnabled = !1, this.dataChannelEncryptionEnabled = t;
  }
  get isEnabled() {
    return this.encryptionEnabled;
  }
  get isDataChannelEncryptionEnabled() {
    return this.isEnabled && this.dataChannelEncryptionEnabled;
  }
  /**
   * @internal
   */
  setup(e) {
    if (!wp())
      throw new Hr("tried to setup end-to-end encryption on an unsupported browser");
    if (se.info("setting up e2ee"), e !== this.room) {
      this.room = e, this.setupEventListeners(e, this.keyProvider);
      const t = {
        kind: "init",
        data: {
          keyProviderOptions: this.keyProvider.getOptions(),
          loglevel: Th.getLevel()
        }
      };
      this.worker && (se.info("initializing worker", {
        worker: this.worker
      }), this.worker.onmessage = this.onWorkerMessage, this.worker.onerror = this.onWorkerError, this.worker.postMessage(t));
    }
  }
  /**
   * @internal
   */
  setParticipantCryptorEnabled(e, t) {
    se.debug("set e2ee to ".concat(e, " for participant ").concat(t)), this.postEnable(e, t);
  }
  /**
   * @internal
   */
  setSifTrailer(e) {
    !e || e.length === 0 ? se.warn("ignoring server sent trailer as it's empty") : this.postSifTrailer(e);
  }
  setupEngine(e) {
    e.on(H.RTPVideoMapUpdate, (t) => {
      this.postRTPMap(t);
    });
  }
  setupEventListeners(e, t) {
    e.on(x.TrackPublished, (i, s) => this.setParticipantCryptorEnabled(i.trackInfo.encryption !== Ne.NONE, s.identity)), e.on(x.ConnectionStateChanged, (i) => {
      i === fe.Connected && e.remoteParticipants.forEach((s) => {
        s.trackPublications.forEach((r) => {
          this.setParticipantCryptorEnabled(r.trackInfo.encryption !== Ne.NONE, s.identity);
        });
      });
    }).on(x.TrackUnsubscribed, (i, s, r) => {
      var o;
      const a = {
        kind: "removeTransform",
        data: {
          participantIdentity: r.identity,
          trackId: i.mediaStreamID
        }
      };
      (o = this.worker) === null || o === void 0 || o.postMessage(a);
    }).on(x.TrackSubscribed, (i, s, r) => {
      this.setupE2EEReceiver(i, r.identity, s.trackInfo);
    }).on(x.SignalConnected, () => {
      if (!this.room)
        throw new TypeError("expected room to be present on signal connect");
      const i = t.getLatestManuallySetKeyIndex();
      t.getKeys().forEach((s) => {
        var r;
        this.postKey(s, i === ((r = s.keyIndex) !== null && r !== void 0 ? r : 0));
      }), this.setParticipantCryptorEnabled(this.room.localParticipant.isE2EEEnabled, this.room.localParticipant.identity);
    }), e.localParticipant.on(W.LocalSenderCreated, (i, s) => m(this, void 0, void 0, function* () {
      this.setupE2EESender(s, i);
    })), e.localParticipant.on(W.LocalTrackPublished, (i) => {
      if (!Zt(i.track) || !un())
        return;
      const s = {
        kind: "updateCodec",
        data: {
          trackId: i.track.mediaStreamID,
          codec: rn(i.trackInfo.codecs[0].mimeType),
          participantIdentity: this.room.localParticipant.identity
        }
      };
      this.worker.postMessage(s);
    }), t.on(Gt.SetKey, (i, s) => this.postKey(i, s != null ? s : !0)).on(Gt.RatchetRequest, (i, s) => this.postRatchetRequest(i, s));
  }
  encryptData(e) {
    return m(this, void 0, void 0, function* () {
      if (!this.worker)
        throw Error("could not encrypt data, worker is missing");
      const t = crypto.randomUUID(), i = {
        kind: "encryptDataRequest",
        data: {
          uuid: t,
          payload: e,
          participantIdentity: this.room.localParticipant.identity
        }
      }, s = new $t();
      return s.onFinally = () => {
        this.encryptDataRequests.delete(t);
      }, this.encryptDataRequests.set(t, s), this.worker.postMessage(i), s.promise;
    });
  }
  handleEncryptedData(e, t, i, s) {
    if (!this.worker)
      throw Error("could not handle encrypted data, worker is missing");
    const r = crypto.randomUUID(), o = {
      kind: "decryptDataRequest",
      data: {
        uuid: r,
        payload: e,
        iv: t,
        participantIdentity: i,
        keyIndex: s
      }
    }, a = new $t();
    return a.onFinally = () => {
      this.decryptDataRequests.delete(r);
    }, this.decryptDataRequests.set(r, a), this.worker.postMessage(o), a.promise;
  }
  postRatchetRequest(e, t) {
    if (!this.worker)
      throw Error("could not ratchet key, worker is missing");
    const i = {
      kind: "ratchetRequest",
      data: {
        participantIdentity: e,
        keyIndex: t
      }
    };
    this.worker.postMessage(i);
  }
  postKey(e, t) {
    let {
      key: i,
      participantIdentity: s,
      keyIndex: r
    } = e;
    var o;
    if (!this.worker)
      throw Error("could not set key, worker is missing");
    const a = {
      kind: "setKey",
      data: {
        participantIdentity: s,
        isPublisher: s === ((o = this.room) === null || o === void 0 ? void 0 : o.localParticipant.identity),
        key: i,
        keyIndex: r,
        updateCurrentKeyIndex: t
      }
    };
    this.worker.postMessage(a);
  }
  postEnable(e, t) {
    if (this.worker) {
      const i = {
        kind: "enable",
        data: {
          enabled: e,
          participantIdentity: t
        }
      };
      this.worker.postMessage(i);
    } else
      throw new ReferenceError("failed to enable e2ee, worker is not ready");
  }
  postRTPMap(e) {
    var t;
    if (!this.worker)
      throw TypeError("could not post rtp map, worker is missing");
    if (!(!((t = this.room) === null || t === void 0) && t.localParticipant.identity))
      throw TypeError("could not post rtp map, local participant identity is missing");
    const i = {
      kind: "setRTPMap",
      data: {
        map: e,
        participantIdentity: this.room.localParticipant.identity
      }
    };
    this.worker.postMessage(i);
  }
  postSifTrailer(e) {
    if (!this.worker)
      throw Error("could not post SIF trailer, worker is missing");
    const t = {
      kind: "setSifTrailer",
      data: {
        trailer: e
      }
    };
    this.worker.postMessage(t);
  }
  setupE2EEReceiver(e, t, i) {
    if (e.receiver) {
      if (!(i != null && i.mimeType) || i.mimeType === "")
        throw new TypeError("MimeType missing from trackInfo, cannot set up E2EE cryptor");
      this.handleReceiver(e.receiver, e.mediaStreamID, t, e.kind === "video" ? rn(i.mimeType) : void 0);
    }
  }
  setupE2EESender(e, t) {
    if (!Di(e) || !t) {
      t || se.warn("early return because sender is not ready");
      return;
    }
    this.handleSender(t, e.mediaStreamID, void 0);
  }
  /**
   * Handles the given {@code RTCRtpReceiver} by creating a {@code TransformStream} which will inject
   * a frame decoder.
   *
   */
  handleReceiver(e, t, i, s) {
    return m(this, void 0, void 0, function* () {
      if (this.worker) {
        if (pr() && // Chrome occasionally throws an `InvalidState` error when using script transforms directly after introducing this API in 141.
        // Disabling it for Chrome based browsers until the API has stabilized
        !Qa()) {
          const r = {
            kind: "decode",
            participantIdentity: i,
            trackId: t,
            codec: s
          };
          e.transform = new RTCRtpScriptTransform(this.worker, r);
        } else {
          if (Gi in e && s) {
            const c = {
              kind: "updateCodec",
              data: {
                trackId: t,
                codec: s,
                participantIdentity: i
              }
            };
            this.worker.postMessage(c);
            return;
          }
          let r = e.writableStream, o = e.readableStream;
          if (!r || !o) {
            const c = e.createEncodedStreams();
            e.writableStream = c.writable, r = c.writable, e.readableStream = c.readable, o = c.readable;
          }
          const a = {
            kind: "decode",
            data: {
              readableStream: o,
              writableStream: r,
              trackId: t,
              codec: s,
              participantIdentity: i,
              isReuse: Gi in e
            }
          };
          this.worker.postMessage(a, [o, r]);
        }
        e[Gi] = !0;
      }
    });
  }
  /**
   * Handles the given {@code RTCRtpSender} by creating a {@code TransformStream} which will inject
   * a frame encoder.
   *
   */
  handleSender(e, t, i) {
    var s;
    if (!(Gi in e || !this.worker)) {
      if (!(!((s = this.room) === null || s === void 0) && s.localParticipant.identity) || this.room.localParticipant.identity === "")
        throw TypeError("local identity needs to be known in order to set up encrypted sender");
      if (pr() && // Chrome occasionally throws an `InvalidState` error when using script transforms directly after introducing this API in 141.
      // Disabling it for Chrome based browsers until the API has stabilized
      !Qa()) {
        se.info("initialize script transform");
        const r = {
          kind: "encode",
          participantIdentity: this.room.localParticipant.identity,
          trackId: t,
          codec: i
        };
        e.transform = new RTCRtpScriptTransform(this.worker, r);
      } else {
        se.info("initialize encoded streams");
        const r = e.createEncodedStreams(), o = {
          kind: "encode",
          data: {
            readableStream: r.readable,
            writableStream: r.writable,
            codec: i,
            trackId: t,
            participantIdentity: this.room.localParticipant.identity,
            isReuse: !1
          }
        };
        this.worker.postMessage(o, [r.readable, r.writable]);
      }
      e[Gi] = !0;
    }
  }
}
const Pp = 500, xp = 15e3;
class Li {
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  constructor() {
    this.failedConnectionAttempts = /* @__PURE__ */ new Map(), this.backOffPromises = /* @__PURE__ */ new Map();
  }
  static getInstance() {
    return this._instance || (this._instance = new Li()), this._instance;
  }
  addFailedConnectionAttempt(e) {
    var t;
    const i = new URL(e), s = Ts(i);
    if (!s)
      return;
    let r = (t = this.failedConnectionAttempts.get(s)) !== null && t !== void 0 ? t : 0;
    this.failedConnectionAttempts.set(s, r + 1), this.backOffPromises.set(s, ze(Math.min(Pp * Math.pow(2, r), xp)));
  }
  getBackOffPromise(e) {
    const t = new URL(e), i = t && Ts(t);
    return i && this.backOffPromises.get(i) || Promise.resolve();
  }
  resetFailedConnectionAttempts(e) {
    const t = new URL(e), i = t && Ts(t);
    i && (this.failedConnectionAttempts.set(i, 0), this.backOffPromises.set(i, Promise.resolve()));
  }
  resetAll() {
    this.backOffPromises.clear(), this.failedConnectionAttempts.clear();
  }
}
Li._instance = null;
const Rs = "default";
class We {
  constructor() {
    this._previousDevices = [];
  }
  static getInstance() {
    return this.instance === void 0 && (this.instance = new We()), this.instance;
  }
  get previousDevices() {
    return this._previousDevices;
  }
  getDevices(e) {
    return m(this, arguments, void 0, function(t) {
      var i = this;
      let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
      return (function* () {
        var r;
        if (((r = We.userMediaPromiseMap) === null || r === void 0 ? void 0 : r.size) > 0) {
          se.debug("awaiting getUserMedia promise");
          try {
            t ? yield We.userMediaPromiseMap.get(t) : yield Promise.all(We.userMediaPromiseMap.values());
          } catch {
            se.warn("error waiting for media permissons");
          }
        }
        let o = yield navigator.mediaDevices.enumerateDevices();
        if (s && // for safari we need to skip this check, as otherwise it will re-acquire user media and fail on iOS https://bugs.webkit.org/show_bug.cgi?id=179363
        !(hi() && i.hasDeviceInUse(t)) && (o.filter((c) => c.kind === t).length === 0 || o.some((c) => {
          const d = c.label === "", l = t ? c.kind === t : !0;
          return d && l;
        }))) {
          const c = {
            video: t !== "audioinput" && t !== "audiooutput",
            audio: t !== "videoinput" && {
              deviceId: {
                ideal: "default"
              }
            }
          }, d = yield navigator.mediaDevices.getUserMedia(c);
          o = yield navigator.mediaDevices.enumerateDevices(), d.getTracks().forEach((l) => {
            l.stop();
          });
        }
        return i._previousDevices = o, t && (o = o.filter((a) => a.kind === t)), o;
      })();
    });
  }
  normalizeDeviceId(e, t, i) {
    return m(this, void 0, void 0, function* () {
      if (t !== Rs)
        return t;
      const s = yield this.getDevices(e), r = s.find((a) => a.deviceId === Rs);
      if (!r) {
        se.warn("could not reliably determine default device");
        return;
      }
      const o = s.find((a) => a.deviceId !== Rs && a.groupId === (i != null ? i : r.groupId));
      if (!o) {
        se.warn("could not reliably determine default device");
        return;
      }
      return o == null ? void 0 : o.deviceId;
    });
  }
  hasDeviceInUse(e) {
    return e ? We.userMediaPromiseMap.has(e) : We.userMediaPromiseMap.size > 0;
  }
}
We.mediaDeviceKinds = ["audioinput", "audiooutput", "videoinput"];
We.userMediaPromiseMap = /* @__PURE__ */ new Map();
var an;
(function(n) {
  n[n.WAITING = 0] = "WAITING", n[n.RUNNING = 1] = "RUNNING", n[n.COMPLETED = 2] = "COMPLETED";
})(an || (an = {}));
class Mp {
  constructor() {
    this.pendingTasks = /* @__PURE__ */ new Map(), this.taskMutex = new Ze(), this.nextTaskIndex = 0;
  }
  run(e) {
    return m(this, void 0, void 0, function* () {
      const t = {
        id: this.nextTaskIndex++,
        enqueuedAt: Date.now(),
        status: an.WAITING
      };
      this.pendingTasks.set(t.id, t);
      const i = yield this.taskMutex.lock();
      try {
        return t.executedAt = Date.now(), t.status = an.RUNNING, yield e();
      } finally {
        t.status = an.COMPLETED, this.pendingTasks.delete(t.id), i();
      }
    });
  }
  flush() {
    return m(this, void 0, void 0, function* () {
      return this.run(() => m(this, void 0, void 0, function* () {
      }));
    });
  }
  snapshot() {
    return Array.from(this.pendingTasks.values());
  }
}
class Ap {
  get readyState() {
    return this.ws.readyState;
  }
  constructor(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var i, s;
    if (!((i = t.signal) === null || i === void 0) && i.aborted)
      throw new DOMException("This operation was aborted", "AbortError");
    this.url = e;
    const r = new WebSocket(e, (s = t.protocols) !== null && s !== void 0 ? s : []);
    r.binaryType = "arraybuffer", this.ws = r;
    const o = function() {
      let {
        closeCode: a,
        reason: c
      } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      return r.close(a, c);
    };
    this.opened = new Je((a, c) => {
      const d = () => {
        c(Z.websocket("Encountered websocket error during connection establishment"));
      };
      r.onopen = () => {
        a({
          readable: new ReadableStream({
            start(l) {
              r.onmessage = (u) => {
                let {
                  data: h
                } = u;
                return l.enqueue(h);
              }, r.onerror = (u) => l.error(u);
            },
            cancel: o
          }),
          writable: new WritableStream({
            write(l) {
              r.send(l);
            },
            abort() {
              r.close();
            },
            close: o
          }),
          protocol: r.protocol,
          extensions: r.extensions
        }), r.removeEventListener("error", d);
      }, r.addEventListener("error", d);
    }), this.closed = new Je((a, c) => {
      const d = () => m(this, void 0, void 0, function* () {
        const l = new Je((h) => {
          r.readyState !== WebSocket.CLOSED && r.addEventListener("close", (p) => {
            h(p);
          }, {
            once: !0
          });
        }), u = yield Je.race([ze(250), l]);
        u ? a(u) : c(Z.websocket("Encountered unspecified websocket error without a timely close event"));
      });
      r.onclose = (l) => {
        let {
          code: u,
          reason: h
        } = l;
        a({
          closeCode: u,
          reason: h
        }), r.removeEventListener("error", d);
      }, r.addEventListener("error", d);
    }), t.signal && (t.signal.onabort = () => r.close()), this.close = o;
  }
}
const Op = ["syncState", "trickle", "offer", "answer", "simulate", "leave"];
function Dp(n) {
  const e = Op.indexOf(n.case) >= 0;
  return se.trace("request allowed to bypass queue:", {
    canPass: e,
    req: n
  }), e;
}
var Ee;
(function(n) {
  n[n.CONNECTING = 0] = "CONNECTING", n[n.CONNECTED = 1] = "CONNECTED", n[n.RECONNECTING = 2] = "RECONNECTING", n[n.DISCONNECTING = 3] = "DISCONNECTING", n[n.DISCONNECTED = 4] = "DISCONNECTED";
})(Ee || (Ee = {}));
const Lp = 250;
class Kr {
  get currentState() {
    return this.state;
  }
  get isDisconnected() {
    return this.state === Ee.DISCONNECTING || this.state === Ee.DISCONNECTED;
  }
  get isEstablishingConnection() {
    return this.state === Ee.CONNECTING || this.state === Ee.RECONNECTING;
  }
  getNextRequestId() {
    return this._requestId += 1, this._requestId;
  }
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var i;
    this.rtt = 0, this.state = Ee.DISCONNECTED, this.log = se, this._requestId = 0, this.useV0SignalPath = !1, this.resetCallbacks = () => {
      this.onAnswer = void 0, this.onLeave = void 0, this.onLocalTrackPublished = void 0, this.onLocalTrackUnpublished = void 0, this.onNegotiateRequested = void 0, this.onOffer = void 0, this.onRemoteMuteChanged = void 0, this.onSubscribedQualityUpdate = void 0, this.onTokenRefresh = void 0, this.onTrickle = void 0, this.onClose = void 0, this.onMediaSectionsRequirement = void 0;
    }, this.log = St((i = t.loggerName) !== null && i !== void 0 ? i : at.Signal), this.loggerContextCb = t.loggerContextCb, this.useJSON = e, this.requestQueue = new Mp(), this.queuedRequests = [], this.closingLock = new Ze(), this.connectionLock = new Ze(), this.state = Ee.DISCONNECTED;
  }
  get logContext() {
    var e, t;
    return (t = (e = this.loggerContextCb) === null || e === void 0 ? void 0 : e.call(this)) !== null && t !== void 0 ? t : {};
  }
  join(e, t, i, s) {
    return m(this, arguments, void 0, function(r, o, a, c) {
      var d = this;
      let l = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1;
      return (function* () {
        return d.state = Ee.CONNECTING, d.options = a, yield d.connect(r, o, a, c, l);
      })();
    });
  }
  reconnect(e, t, i, s) {
    return m(this, void 0, void 0, function* () {
      if (!this.options) {
        this.log.warn("attempted to reconnect without signal options being set, ignoring", this.logContext);
        return;
      }
      return this.state = Ee.RECONNECTING, this.clearPingInterval(), yield this.connect(e, t, Object.assign(Object.assign({}, this.options), {
        reconnect: !0,
        sid: i,
        reconnectReason: s
      }), void 0, this.useV0SignalPath);
    });
  }
  connect(e, t, i, s) {
    return m(this, arguments, void 0, function(r, o, a, c) {
      var d = this;
      let l = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1;
      return (function* () {
        const u = yield d.connectionLock.lock();
        d.connectOptions = a, d.useV0SignalPath = l;
        const h = dp(), p = l ? Np(o, h, a) : Up(o, h, a), b = bp(r, p, l).toString(), v = Sp(b).toString();
        return new Promise((C, T) => m(d, void 0, void 0, function* () {
          var P, R;
          try {
            let g = !1;
            const f = (O) => m(this, void 0, void 0, function* () {
              if (g)
                return;
              g = !0;
              const N = O instanceof Event ? O.currentTarget : O, L = kp(N, "Abort handler called");
              this.streamWriter && !this.isDisconnected ? this.sendLeave().then(() => this.close(L)).catch((B) => {
                this.log.error(B), this.close();
              }) : this.close(), k(), T(Z.cancelled(L));
            });
            c == null || c.addEventListener("abort", f);
            const k = () => {
              clearTimeout(w), c == null || c.removeEventListener("abort", f);
            }, w = setTimeout(() => {
              f(Z.timeout("room connection has timed out (signal)"));
            }, a.websocketTimeout), D = (O, N) => {
              this.handleSignalConnected(O, w, N);
            }, A = new URL(b);
            A.searchParams.has("access_token") && A.searchParams.set("access_token", "<redacted>"), this.log.debug("connecting to ".concat(A), Object.assign({
              reconnect: a.reconnect,
              reconnectReason: a.reconnectReason
            }, this.logContext)), this.ws && (yield this.close(!1)), this.ws = new Ap(b);
            try {
              this.ws.closed.then((re) => {
                var K;
                this.isEstablishingConnection && T(Z.internal("Websocket got closed during a (re)connection attempt: ".concat(re.reason))), re.closeCode !== 1e3 && (this.log.warn("websocket closed", Object.assign(Object.assign({}, this.logContext), {
                  reason: re.reason,
                  code: re.closeCode,
                  wasClean: re.closeCode === 1e3,
                  state: this.state
                })), this.state === Ee.CONNECTED && this.handleOnClose((K = re.reason) !== null && K !== void 0 ? K : "Unexpected WS error"));
              }).catch((re) => {
                this.isEstablishingConnection && T(Z.internal("Websocket error during a (re)connection attempt: ".concat(re)));
              });
              const O = yield this.ws.opened.catch((re) => m(this, void 0, void 0, function* () {
                if (this.state !== Ee.CONNECTED) {
                  this.state = Ee.DISCONNECTED, clearTimeout(w);
                  const K = yield this.handleConnectionError(re, v);
                  T(K);
                  return;
                }
                this.handleWSError(re), T(re);
              }));
              if (clearTimeout(w), !O)
                return;
              const N = O.readable.getReader();
              this.streamWriter = O.writable.getWriter();
              const L = yield N.read();
              if (N.releaseLock(), !L.value)
                throw Z.internal("no message received as first message");
              const B = no(L.value), Q = this.validateFirstMessage(B, (P = a.reconnect) !== null && P !== void 0 ? P : !1);
              if (!Q.isValid) {
                T(Q.error);
                return;
              }
              ((R = B.message) === null || R === void 0 ? void 0 : R.case) === "join" && (this.pingTimeoutDuration = B.message.value.pingTimeout, this.pingIntervalDuration = B.message.value.pingInterval, this.pingTimeoutDuration && this.pingTimeoutDuration > 0 && this.log.debug("ping config", Object.assign(Object.assign({}, this.logContext), {
                timeout: this.pingTimeoutDuration,
                interval: this.pingIntervalDuration
              })));
              const ae = Q.shouldProcessFirstMessage ? B : void 0;
              D(O, ae), C(Q.response);
            } catch (O) {
              T(O);
            } finally {
              k();
            }
          } finally {
            u();
          }
        }));
      })();
    });
  }
  startReadingLoop(e, t) {
    return m(this, void 0, void 0, function* () {
      for (t && this.handleSignalResponse(t); ; ) {
        this.signalLatency && (yield ze(this.signalLatency));
        const {
          done: i,
          value: s
        } = yield e.read();
        if (i)
          break;
        const r = no(s);
        this.handleSignalResponse(r);
      }
    });
  }
  close() {
    return m(this, arguments, void 0, function() {
      var e = this;
      let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "Close method called on signal client";
      return (function* () {
        if ([Ee.DISCONNECTING || Ee.DISCONNECTED].includes(e.state)) {
          e.log.debug("ignoring signal close as it's already in disconnecting state");
          return;
        }
        const s = yield e.closingLock.lock();
        try {
          if (e.clearPingInterval(), t && (e.state = Ee.DISCONNECTING), e.ws) {
            e.ws.close({
              closeCode: 1e3,
              reason: i
            });
            const r = e.ws.closed;
            e.ws = void 0, e.streamWriter = void 0, yield Promise.race([r, ze(Lp)]);
          }
        } catch (r) {
          e.log.debug("websocket error while closing", Object.assign(Object.assign({}, e.logContext), {
            error: r
          }));
        } finally {
          t && (e.state = Ee.DISCONNECTED), s();
        }
      })();
    });
  }
  // initial offer after joining
  sendOffer(e, t) {
    this.log.debug("sending offer", Object.assign(Object.assign({}, this.logContext), {
      offerSdp: e.sdp
    })), this.sendRequest({
      case: "offer",
      value: Ii(e, t)
    });
  }
  // answer a server-initiated offer
  sendAnswer(e, t) {
    return this.log.debug("sending answer", Object.assign(Object.assign({}, this.logContext), {
      answerSdp: e.sdp
    })), this.sendRequest({
      case: "answer",
      value: Ii(e, t)
    });
  }
  sendIceCandidate(e, t) {
    return this.log.debug("sending ice candidate", Object.assign(Object.assign({}, this.logContext), {
      candidate: e
    })), this.sendRequest({
      case: "trickle",
      value: new ss({
        candidateInit: JSON.stringify(e),
        target: t
      })
    });
  }
  sendMuteTrack(e, t) {
    return this.sendRequest({
      case: "mute",
      value: new rs({
        sid: e,
        muted: t
      })
    });
  }
  sendAddTrack(e) {
    return this.sendRequest({
      case: "addTrack",
      value: e
    });
  }
  sendUpdateLocalMetadata(e, t) {
    return m(this, arguments, void 0, function(i, s) {
      var r = this;
      let o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      return (function* () {
        const a = r.getNextRequestId();
        return yield r.sendRequest({
          case: "updateMetadata",
          value: new Ur({
            requestId: a,
            metadata: i,
            name: s,
            attributes: o
          })
        }), a;
      })();
    });
  }
  sendUpdateTrackSettings(e) {
    this.sendRequest({
      case: "trackSetting",
      value: e
    });
  }
  sendUpdateSubscription(e) {
    return this.sendRequest({
      case: "subscription",
      value: e
    });
  }
  sendSyncState(e) {
    return this.sendRequest({
      case: "syncState",
      value: e
    });
  }
  sendUpdateVideoLayers(e, t) {
    return this.sendRequest({
      case: "updateLayers",
      value: new Vc({
        trackSid: e,
        layers: t
      })
    });
  }
  sendUpdateSubscriptionPermissions(e, t) {
    return this.sendRequest({
      case: "subscriptionPermission",
      value: new qc({
        allParticipants: e,
        trackPermissions: t
      })
    });
  }
  sendSimulateScenario(e) {
    return this.sendRequest({
      case: "simulate",
      value: e
    });
  }
  sendPing() {
    return Promise.all([this.sendRequest({
      case: "ping",
      value: Pe.parse(Date.now())
    }), this.sendRequest({
      case: "pingReq",
      value: new $c({
        timestamp: Pe.parse(Date.now()),
        rtt: Pe.parse(this.rtt)
      })
    })]);
  }
  sendUpdateLocalAudioTrack(e, t) {
    return this.sendRequest({
      case: "updateAudioTrack",
      value: new Nr({
        trackSid: e,
        features: t
      })
    });
  }
  sendLeave() {
    return this.sendRequest({
      case: "leave",
      value: new os({
        reason: yt.CLIENT_INITIATED,
        // server doesn't process this field, keeping it here to indicate the intent of a full disconnect
        action: Mi.DISCONNECT
      })
    });
  }
  sendRequest(e) {
    return m(this, arguments, void 0, function(t) {
      var i = this;
      let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
      return (function* () {
        if (!s && !Dp(t) && i.state === Ee.RECONNECTING) {
          i.queuedRequests.push(() => m(i, void 0, void 0, function* () {
            yield this.sendRequest(t, !0);
          }));
          return;
        }
        if (s || (yield i.requestQueue.flush()), i.signalLatency && (yield ze(i.signalLatency)), i.isDisconnected) {
          i.log.debug("skipping signal request (type: ".concat(t.case, ") - SignalClient disconnected"));
          return;
        }
        if (!i.streamWriter) {
          i.log.error("cannot send signal request before connected, type: ".concat(t == null ? void 0 : t.case), i.logContext);
          return;
        }
        const o = new Bu({
          message: t
        });
        try {
          i.useJSON ? yield i.streamWriter.write(o.toJsonString()) : yield i.streamWriter.write(o.toBinary());
        } catch (a) {
          i.log.error("error sending signal message", Object.assign(Object.assign({}, i.logContext), {
            error: a
          }));
        }
      })();
    });
  }
  handleSignalResponse(e) {
    var t, i;
    const s = e.message;
    if (s == null) {
      this.log.debug("received unsupported message", this.logContext);
      return;
    }
    let r = !1;
    if (s.case === "answer") {
      const o = oo(s.value);
      this.onAnswer && this.onAnswer(o, s.value.id, s.value.midToTrackId);
    } else if (s.case === "offer") {
      const o = oo(s.value);
      this.onOffer && this.onOffer(o, s.value.id, s.value.midToTrackId);
    } else if (s.case === "trickle") {
      const o = JSON.parse(s.value.candidateInit);
      this.onTrickle && this.onTrickle(o, s.value.target);
    } else s.case === "update" ? this.onParticipantUpdate && this.onParticipantUpdate((t = s.value.participants) !== null && t !== void 0 ? t : []) : s.case === "trackPublished" ? this.onLocalTrackPublished && this.onLocalTrackPublished(s.value) : s.case === "speakersChanged" ? this.onSpeakersChanged && this.onSpeakersChanged((i = s.value.speakers) !== null && i !== void 0 ? i : []) : s.case === "leave" ? this.onLeave && this.onLeave(s.value) : s.case === "mute" ? this.onRemoteMuteChanged && this.onRemoteMuteChanged(s.value.sid, s.value.muted) : s.case === "roomUpdate" ? this.onRoomUpdate && s.value.room && this.onRoomUpdate(s.value.room) : s.case === "connectionQuality" ? this.onConnectionQuality && this.onConnectionQuality(s.value) : s.case === "streamStateUpdate" ? this.onStreamStateUpdate && this.onStreamStateUpdate(s.value) : s.case === "subscribedQualityUpdate" ? this.onSubscribedQualityUpdate && this.onSubscribedQualityUpdate(s.value) : s.case === "subscriptionPermissionUpdate" ? this.onSubscriptionPermissionUpdate && this.onSubscriptionPermissionUpdate(s.value) : s.case === "refreshToken" ? this.onTokenRefresh && this.onTokenRefresh(s.value) : s.case === "trackUnpublished" ? this.onLocalTrackUnpublished && this.onLocalTrackUnpublished(s.value) : s.case === "subscriptionResponse" ? this.onSubscriptionError && this.onSubscriptionError(s.value) : s.case === "pong" || (s.case === "pongResp" ? (this.rtt = Date.now() - Number.parseInt(s.value.lastPingTimestamp.toString()), this.resetPingTimeout(), r = !0) : s.case === "requestResponse" ? this.onRequestResponse && this.onRequestResponse(s.value) : s.case === "trackSubscribed" ? this.onLocalTrackSubscribed && this.onLocalTrackSubscribed(s.value.trackSid) : s.case === "roomMoved" ? (this.onTokenRefresh && this.onTokenRefresh(s.value.token), this.onRoomMoved && this.onRoomMoved(s.value)) : s.case === "mediaSectionsRequirement" ? this.onMediaSectionsRequirement && this.onMediaSectionsRequirement(s.value) : this.log.debug("unsupported message", Object.assign(Object.assign({}, this.logContext), {
      msgCase: s.case
    })));
    r || this.resetPingTimeout();
  }
  setReconnected() {
    for (; this.queuedRequests.length > 0; ) {
      const e = this.queuedRequests.shift();
      e && this.requestQueue.run(e);
    }
  }
  handleOnClose(e) {
    return m(this, void 0, void 0, function* () {
      if (this.state === Ee.DISCONNECTED) return;
      const t = this.onClose;
      yield this.close(void 0, e), this.log.debug("websocket connection closed: ".concat(e), Object.assign(Object.assign({}, this.logContext), {
        reason: e
      })), t && t(e);
    });
  }
  handleWSError(e) {
    this.log.error("websocket error", Object.assign(Object.assign({}, this.logContext), {
      error: e
    }));
  }
  /**
   * Resets the ping timeout and starts a new timeout.
   * Call this after receiving a pong message
   */
  resetPingTimeout() {
    if (this.clearPingTimeout(), !this.pingTimeoutDuration) {
      this.log.warn("ping timeout duration not set", this.logContext);
      return;
    }
    this.pingTimeout = Be.setTimeout(() => {
      this.log.warn("ping timeout triggered. last pong received at: ".concat(new Date(Date.now() - this.pingTimeoutDuration * 1e3).toUTCString()), this.logContext), this.handleOnClose("ping timeout");
    }, this.pingTimeoutDuration * 1e3);
  }
  /**
   * Clears ping timeout (does not start a new timeout)
   */
  clearPingTimeout() {
    this.pingTimeout && Be.clearTimeout(this.pingTimeout);
  }
  startPingInterval() {
    if (this.clearPingInterval(), this.resetPingTimeout(), !this.pingIntervalDuration) {
      this.log.warn("ping interval duration not set", this.logContext);
      return;
    }
    this.log.debug("start ping interval", this.logContext), this.pingInterval = Be.setInterval(() => {
      this.sendPing();
    }, this.pingIntervalDuration * 1e3);
  }
  clearPingInterval() {
    this.log.debug("clearing ping interval", this.logContext), this.clearPingTimeout(), this.pingInterval && Be.clearInterval(this.pingInterval);
  }
  /**
   * Handles the successful connection to the signal server
   * @param connection The WebSocket connection
   * @param timeoutHandle The timeout handle to clear
   * @param firstMessage Optional first message to process
   * @internal
   */
  handleSignalConnected(e, t, i) {
    this.state = Ee.CONNECTED, clearTimeout(t), this.startPingInterval(), this.startReadingLoop(e.readable.getReader(), i);
  }
  /**
   * Validates the first message received from the signal server
   * @param firstSignalResponse The first signal response received
   * @param isReconnect Whether this is a reconnection attempt
   * @returns Validation result with response or error
   * @internal
   */
  validateFirstMessage(e, t) {
    var i, s, r, o, a;
    return ((i = e.message) === null || i === void 0 ? void 0 : i.case) === "join" ? {
      isValid: !0,
      response: e.message.value
    } : this.state === Ee.RECONNECTING && ((s = e.message) === null || s === void 0 ? void 0 : s.case) !== "leave" ? ((r = e.message) === null || r === void 0 ? void 0 : r.case) === "reconnect" ? {
      isValid: !0,
      response: e.message.value
    } : (this.log.debug("declaring signal reconnected without reconnect response received", this.logContext), {
      isValid: !0,
      response: void 0,
      shouldProcessFirstMessage: !0
    }) : this.isEstablishingConnection && ((o = e.message) === null || o === void 0 ? void 0 : o.case) === "leave" ? {
      isValid: !1,
      error: Z.leaveRequest("Received leave request while trying to (re)connect", e.message.value.reason)
    } : t ? {
      isValid: !1,
      error: Z.internal("Unexpected first message")
    } : {
      isValid: !1,
      error: Z.internal("did not receive join response, got ".concat((a = e.message) === null || a === void 0 ? void 0 : a.case, " instead"))
    };
  }
  /**
   * Handles WebSocket connection errors by validating with the server
   * @param reason The error that occurred
   * @param validateUrl The URL to validate the connection with
   * @returns A ConnectionError with appropriate reason and status
   * @internal
   */
  handleConnectionError(e, t) {
    return m(this, void 0, void 0, function* () {
      try {
        const i = yield fetch(t);
        switch (i.status) {
          case 404:
            return Z.serviceNotFound("v1 RTC path not found. Consider upgrading your LiveKit server version", "v0-rtc");
          case 401:
          case 403:
            const s = yield i.text();
            return Z.notAllowed(s, i.status);
          default:
            break;
        }
        return e instanceof Z ? e : Z.internal("Encountered unknown websocket error during connection: ".concat(e), {
          status: i.status,
          statusText: i.statusText
        });
      } catch (i) {
        return i instanceof Z ? i : Z.serverUnreachable(i instanceof Error ? i.message : "server was not reachable");
      }
    });
  }
}
function oo(n) {
  const e = {
    type: "offer",
    sdp: n.sdp
  };
  switch (n.type) {
    case "answer":
    case "offer":
    case "pranswer":
    case "rollback":
      e.type = n.type;
      break;
  }
  return e;
}
function Ii(n, e) {
  return new Qt({
    sdp: n.sdp,
    type: n.type,
    id: e
  });
}
function Np(n, e, t) {
  var i;
  const s = new URLSearchParams();
  return s.set("access_token", n), t.reconnect && (s.set("reconnect", "1"), t.sid && s.set("sid", t.sid)), s.set("auto_subscribe", t.autoSubscribe ? "1" : "0"), s.set("sdk", Rt() ? "reactnative" : "js"), s.set("version", e.version), s.set("protocol", e.protocol.toString()), e.deviceModel && s.set("device_model", e.deviceModel), e.os && s.set("os", e.os), e.osVersion && s.set("os_version", e.osVersion), e.browser && s.set("browser", e.browser), e.browserVersion && s.set("browser_version", e.browserVersion), t.adaptiveStream && s.set("adaptive_stream", "1"), t.reconnectReason && s.set("reconnect_reason", t.reconnectReason.toString()), !((i = navigator.connection) === null || i === void 0) && i.type && s.set("network", navigator.connection.type), s;
}
function Up(n, e, t) {
  const i = new URLSearchParams();
  i.set("access_token", n);
  const s = new ph({
    clientInfo: e,
    connectionSettings: new zc({
      autoSubscribe: !!t.autoSubscribe,
      adaptiveStream: !!t.adaptiveStream
    }),
    reconnect: !!t.reconnect,
    participantSid: t.sid ? t.sid : void 0
  });
  t.reconnectReason && (s.reconnectReason = t.reconnectReason);
  const r = new mh({
    joinRequest: s.toBinary()
  });
  return i.set("join_request", btoa(new TextDecoder("utf-8").decode(r.toBinary()))), i;
}
class co {
  constructor() {
    this.buffer = [], this._totalSize = 0;
  }
  push(e) {
    this.buffer.push(e), this._totalSize += e.data.byteLength;
  }
  pop() {
    const e = this.buffer.shift();
    return e && (this._totalSize -= e.data.byteLength), e;
  }
  getAll() {
    return this.buffer.slice();
  }
  popToSequence(e) {
    for (; this.buffer.length > 0 && this.buffer[0].sequence <= e; )
      this.pop();
  }
  alignBufferedAmount(e) {
    for (; this.buffer.length > 0; ) {
      const t = this.buffer[0];
      if (this._totalSize - t.data.byteLength <= e)
        break;
      this.pop();
    }
  }
  get length() {
    return this.buffer.length;
  }
}
class Fp {
  /**
   * @param ttl ttl of the key (ms)
   */
  constructor(e) {
    this._map = /* @__PURE__ */ new Map(), this._lastCleanup = 0, this.ttl = e;
  }
  set(e, t) {
    const i = Date.now();
    i - this._lastCleanup > this.ttl / 2 && this.cleanup();
    const s = i + this.ttl;
    return this._map.set(e, {
      value: t,
      expiresAt: s
    }), this;
  }
  get(e) {
    const t = this._map.get(e);
    if (t) {
      if (t.expiresAt < Date.now()) {
        this._map.delete(e);
        return;
      }
      return t.value;
    }
  }
  has(e) {
    const t = this._map.get(e);
    return t ? t.expiresAt < Date.now() ? (this._map.delete(e), !1) : !0 : !1;
  }
  delete(e) {
    return this._map.delete(e);
  }
  clear() {
    this._map.clear();
  }
  cleanup() {
    const e = Date.now();
    for (const [t, i] of this._map.entries())
      i.expiresAt < e && this._map.delete(t);
    this._lastCleanup = e;
  }
  get size() {
    return this.cleanup(), this._map.size;
  }
  forEach(e) {
    this.cleanup();
    for (const [t, i] of this._map.entries())
      i.expiresAt >= Date.now() && e(i.value, t, this.asValueMap());
  }
  map(e) {
    this.cleanup();
    const t = [], i = this.asValueMap();
    for (const [s, r] of i.entries())
      t.push(e(r, s, i));
    return t;
  }
  asValueMap() {
    const e = /* @__PURE__ */ new Map();
    for (const [t, i] of this._map.entries())
      i.expiresAt >= Date.now() && e.set(t, i.value);
    return e;
  }
}
var mt = {}, Is = {}, Ps = { exports: {} }, lo;
function Gr() {
  if (lo) return Ps.exports;
  lo = 1;
  var n = Ps.exports = {
    v: [{
      name: "version",
      reg: /^(\d*)$/
    }],
    o: [{
      // o=- 20518 0 IN IP4 203.0.113.1
      // NB: sessionId will be a String in most cases because it is huge
      name: "origin",
      reg: /^(\S*) (\d*) (\d*) (\S*) IP(\d) (\S*)/,
      names: ["username", "sessionId", "sessionVersion", "netType", "ipVer", "address"],
      format: "%s %s %d %s IP%d %s"
    }],
    // default parsing of these only (though some of these feel outdated)
    s: [{
      name: "name"
    }],
    i: [{
      name: "description"
    }],
    u: [{
      name: "uri"
    }],
    e: [{
      name: "email"
    }],
    p: [{
      name: "phone"
    }],
    z: [{
      name: "timezones"
    }],
    // TODO: this one can actually be parsed properly...
    r: [{
      name: "repeats"
    }],
    // TODO: this one can also be parsed properly
    // k: [{}], // outdated thing ignored
    t: [{
      // t=0 0
      name: "timing",
      reg: /^(\d*) (\d*)/,
      names: ["start", "stop"],
      format: "%d %d"
    }],
    c: [{
      // c=IN IP4 10.47.197.26
      name: "connection",
      reg: /^IN IP(\d) (\S*)/,
      names: ["version", "ip"],
      format: "IN IP%d %s"
    }],
    b: [{
      // b=AS:4000
      push: "bandwidth",
      reg: /^(TIAS|AS|CT|RR|RS):(\d*)/,
      names: ["type", "limit"],
      format: "%s:%s"
    }],
    m: [{
      // m=video 51744 RTP/AVP 126 97 98 34 31
      // NB: special - pushes to session
      // TODO: rtp/fmtp should be filtered by the payloads found here?
      reg: /^(\w*) (\d*) ([\w/]*)(?: (.*))?/,
      names: ["type", "port", "protocol", "payloads"],
      format: "%s %d %s %s"
    }],
    a: [
      {
        // a=rtpmap:110 opus/48000/2
        push: "rtp",
        reg: /^rtpmap:(\d*) ([\w\-.]*)(?:\s*\/(\d*)(?:\s*\/(\S*))?)?/,
        names: ["payload", "codec", "rate", "encoding"],
        format: function(e) {
          return e.encoding ? "rtpmap:%d %s/%s/%s" : e.rate ? "rtpmap:%d %s/%s" : "rtpmap:%d %s";
        }
      },
      {
        // a=fmtp:108 profile-level-id=24;object=23;bitrate=64000
        // a=fmtp:111 minptime=10; useinbandfec=1
        push: "fmtp",
        reg: /^fmtp:(\d*) ([\S| ]*)/,
        names: ["payload", "config"],
        format: "fmtp:%d %s"
      },
      {
        // a=control:streamid=0
        name: "control",
        reg: /^control:(.*)/,
        format: "control:%s"
      },
      {
        // a=rtcp:65179 IN IP4 193.84.77.194
        name: "rtcp",
        reg: /^rtcp:(\d*)(?: (\S*) IP(\d) (\S*))?/,
        names: ["port", "netType", "ipVer", "address"],
        format: function(e) {
          return e.address != null ? "rtcp:%d %s IP%d %s" : "rtcp:%d";
        }
      },
      {
        // a=rtcp-fb:98 trr-int 100
        push: "rtcpFbTrrInt",
        reg: /^rtcp-fb:(\*|\d*) trr-int (\d*)/,
        names: ["payload", "value"],
        format: "rtcp-fb:%s trr-int %d"
      },
      {
        // a=rtcp-fb:98 nack rpsi
        push: "rtcpFb",
        reg: /^rtcp-fb:(\*|\d*) ([\w-_]*)(?: ([\w-_]*))?/,
        names: ["payload", "type", "subtype"],
        format: function(e) {
          return e.subtype != null ? "rtcp-fb:%s %s %s" : "rtcp-fb:%s %s";
        }
      },
      {
        // a=extmap:2 urn:ietf:params:rtp-hdrext:toffset
        // a=extmap:1/recvonly URI-gps-string
        // a=extmap:3 urn:ietf:params:rtp-hdrext:encrypt urn:ietf:params:rtp-hdrext:smpte-tc 25@600/24
        push: "ext",
        reg: /^extmap:(\d+)(?:\/(\w+))?(?: (urn:ietf:params:rtp-hdrext:encrypt))? (\S*)(?: (\S*))?/,
        names: ["value", "direction", "encrypt-uri", "uri", "config"],
        format: function(e) {
          return "extmap:%d" + (e.direction ? "/%s" : "%v") + (e["encrypt-uri"] ? " %s" : "%v") + " %s" + (e.config ? " %s" : "");
        }
      },
      {
        // a=extmap-allow-mixed
        name: "extmapAllowMixed",
        reg: /^(extmap-allow-mixed)/
      },
      {
        // a=crypto:1 AES_CM_128_HMAC_SHA1_80 inline:PS1uQCVeeCFCanVmcjkpPywjNWhcYD0mXXtxaVBR|2^20|1:32
        push: "crypto",
        reg: /^crypto:(\d*) ([\w_]*) (\S*)(?: (\S*))?/,
        names: ["id", "suite", "config", "sessionConfig"],
        format: function(e) {
          return e.sessionConfig != null ? "crypto:%d %s %s %s" : "crypto:%d %s %s";
        }
      },
      {
        // a=setup:actpass
        name: "setup",
        reg: /^setup:(\w*)/,
        format: "setup:%s"
      },
      {
        // a=connection:new
        name: "connectionType",
        reg: /^connection:(new|existing)/,
        format: "connection:%s"
      },
      {
        // a=mid:1
        name: "mid",
        reg: /^mid:([^\s]*)/,
        format: "mid:%s"
      },
      {
        // a=msid:0c8b064d-d807-43b4-b434-f92a889d8587 98178685-d409-46e0-8e16-7ef0db0db64a
        name: "msid",
        reg: /^msid:(.*)/,
        format: "msid:%s"
      },
      {
        // a=ptime:20
        name: "ptime",
        reg: /^ptime:(\d*(?:\.\d*)*)/,
        format: "ptime:%d"
      },
      {
        // a=maxptime:60
        name: "maxptime",
        reg: /^maxptime:(\d*(?:\.\d*)*)/,
        format: "maxptime:%d"
      },
      {
        // a=sendrecv
        name: "direction",
        reg: /^(sendrecv|recvonly|sendonly|inactive)/
      },
      {
        // a=ice-lite
        name: "icelite",
        reg: /^(ice-lite)/
      },
      {
        // a=ice-ufrag:F7gI
        name: "iceUfrag",
        reg: /^ice-ufrag:(\S*)/,
        format: "ice-ufrag:%s"
      },
      {
        // a=ice-pwd:x9cml/YzichV2+XlhiMu8g
        name: "icePwd",
        reg: /^ice-pwd:(\S*)/,
        format: "ice-pwd:%s"
      },
      {
        // a=fingerprint:SHA-1 00:11:22:33:44:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33
        name: "fingerprint",
        reg: /^fingerprint:(\S*) (\S*)/,
        names: ["type", "hash"],
        format: "fingerprint:%s %s"
      },
      {
        // a=candidate:0 1 UDP 2113667327 203.0.113.1 54400 typ host
        // a=candidate:1162875081 1 udp 2113937151 192.168.34.75 60017 typ host generation 0 network-id 3 network-cost 10
        // a=candidate:3289912957 2 udp 1845501695 193.84.77.194 60017 typ srflx raddr 192.168.34.75 rport 60017 generation 0 network-id 3 network-cost 10
        // a=candidate:229815620 1 tcp 1518280447 192.168.150.19 60017 typ host tcptype active generation 0 network-id 3 network-cost 10
        // a=candidate:3289912957 2 tcp 1845501695 193.84.77.194 60017 typ srflx raddr 192.168.34.75 rport 60017 tcptype passive generation 0 network-id 3 network-cost 10
        push: "candidates",
        reg: /^candidate:(\S*) (\d*) (\S*) (\d*) (\S*) (\d*) typ (\S*)(?: raddr (\S*) rport (\d*))?(?: tcptype (\S*))?(?: generation (\d*))?(?: network-id (\d*))?(?: network-cost (\d*))?/,
        names: ["foundation", "component", "transport", "priority", "ip", "port", "type", "raddr", "rport", "tcptype", "generation", "network-id", "network-cost"],
        format: function(e) {
          var t = "candidate:%s %d %s %d %s %d typ %s";
          return t += e.raddr != null ? " raddr %s rport %d" : "%v%v", t += e.tcptype != null ? " tcptype %s" : "%v", e.generation != null && (t += " generation %d"), t += e["network-id"] != null ? " network-id %d" : "%v", t += e["network-cost"] != null ? " network-cost %d" : "%v", t;
        }
      },
      {
        // a=end-of-candidates (keep after the candidates line for readability)
        name: "endOfCandidates",
        reg: /^(end-of-candidates)/
      },
      {
        // a=remote-candidates:1 203.0.113.1 54400 2 203.0.113.1 54401 ...
        name: "remoteCandidates",
        reg: /^remote-candidates:(.*)/,
        format: "remote-candidates:%s"
      },
      {
        // a=ice-options:google-ice
        name: "iceOptions",
        reg: /^ice-options:(\S*)/,
        format: "ice-options:%s"
      },
      {
        // a=ssrc:2566107569 cname:t9YU8M1UxTF8Y1A1
        push: "ssrcs",
        reg: /^ssrc:(\d*) ([\w_-]*)(?::(.*))?/,
        names: ["id", "attribute", "value"],
        format: function(e) {
          var t = "ssrc:%d";
          return e.attribute != null && (t += " %s", e.value != null && (t += ":%s")), t;
        }
      },
      {
        // a=ssrc-group:FEC 1 2
        // a=ssrc-group:FEC-FR 3004364195 1080772241
        push: "ssrcGroups",
        // token-char = %x21 / %x23-27 / %x2A-2B / %x2D-2E / %x30-39 / %x41-5A / %x5E-7E
        reg: /^ssrc-group:([\x21\x23\x24\x25\x26\x27\x2A\x2B\x2D\x2E\w]*) (.*)/,
        names: ["semantics", "ssrcs"],
        format: "ssrc-group:%s %s"
      },
      {
        // a=msid-semantic: WMS Jvlam5X3SX1OP6pn20zWogvaKJz5Hjf9OnlV
        name: "msidSemantic",
        reg: /^msid-semantic:\s?(\w*) (\S*)/,
        names: ["semantic", "token"],
        format: "msid-semantic: %s %s"
        // space after ':' is not accidental
      },
      {
        // a=group:BUNDLE audio video
        push: "groups",
        reg: /^group:(\w*) (.*)/,
        names: ["type", "mids"],
        format: "group:%s %s"
      },
      {
        // a=rtcp-mux
        name: "rtcpMux",
        reg: /^(rtcp-mux)/
      },
      {
        // a=rtcp-rsize
        name: "rtcpRsize",
        reg: /^(rtcp-rsize)/
      },
      {
        // a=sctpmap:5000 webrtc-datachannel 1024
        name: "sctpmap",
        reg: /^sctpmap:([\w_/]*) (\S*)(?: (\S*))?/,
        names: ["sctpmapNumber", "app", "maxMessageSize"],
        format: function(e) {
          return e.maxMessageSize != null ? "sctpmap:%s %s %s" : "sctpmap:%s %s";
        }
      },
      {
        // a=x-google-flag:conference
        name: "xGoogleFlag",
        reg: /^x-google-flag:([^\s]*)/,
        format: "x-google-flag:%s"
      },
      {
        // a=rid:1 send max-width=1280;max-height=720;max-fps=30;depend=0
        push: "rids",
        reg: /^rid:([\d\w]+) (\w+)(?: ([\S| ]*))?/,
        names: ["id", "direction", "params"],
        format: function(e) {
          return e.params ? "rid:%s %s %s" : "rid:%s %s";
        }
      },
      {
        // a=imageattr:97 send [x=800,y=640,sar=1.1,q=0.6] [x=480,y=320] recv [x=330,y=250]
        // a=imageattr:* send [x=800,y=640] recv *
        // a=imageattr:100 recv [x=320,y=240]
        push: "imageattrs",
        reg: new RegExp(
          // a=imageattr:97
          "^imageattr:(\\d+|\\*)[\\s\\t]+(send|recv)[\\s\\t]+(\\*|\\[\\S+\\](?:[\\s\\t]+\\[\\S+\\])*)(?:[\\s\\t]+(recv|send)[\\s\\t]+(\\*|\\[\\S+\\](?:[\\s\\t]+\\[\\S+\\])*))?"
        ),
        names: ["pt", "dir1", "attrs1", "dir2", "attrs2"],
        format: function(e) {
          return "imageattr:%s %s %s" + (e.dir2 ? " %s %s" : "");
        }
      },
      {
        // a=simulcast:send 1,2,3;~4,~5 recv 6;~7,~8
        // a=simulcast:recv 1;4,5 send 6;7
        name: "simulcast",
        reg: new RegExp(
          // a=simulcast:
          "^simulcast:(send|recv) ([a-zA-Z0-9\\-_~;,]+)(?:\\s?(send|recv) ([a-zA-Z0-9\\-_~;,]+))?$"
        ),
        names: ["dir1", "list1", "dir2", "list2"],
        format: function(e) {
          return "simulcast:%s %s" + (e.dir2 ? " %s %s" : "");
        }
      },
      {
        // old simulcast draft 03 (implemented by Firefox)
        //   https://tools.ietf.org/html/draft-ietf-mmusic-sdp-simulcast-03
        // a=simulcast: recv pt=97;98 send pt=97
        // a=simulcast: send rid=5;6;7 paused=6,7
        name: "simulcast_03",
        reg: /^simulcast:[\s\t]+([\S+\s\t]+)$/,
        names: ["value"],
        format: "simulcast: %s"
      },
      {
        // a=framerate:25
        // a=framerate:29.97
        name: "framerate",
        reg: /^framerate:(\d+(?:$|\.\d+))/,
        format: "framerate:%s"
      },
      {
        // RFC4570
        // a=source-filter: incl IN IP4 239.5.2.31 10.1.15.5
        name: "sourceFilter",
        reg: /^source-filter: *(excl|incl) (\S*) (IP4|IP6|\*) (\S*) (.*)/,
        names: ["filterMode", "netType", "addressTypes", "destAddress", "srcList"],
        format: "source-filter: %s %s %s %s %s"
      },
      {
        // a=bundle-only
        name: "bundleOnly",
        reg: /^(bundle-only)/
      },
      {
        // a=label:1
        name: "label",
        reg: /^label:(.+)/,
        format: "label:%s"
      },
      {
        // RFC version 26 for SCTP over DTLS
        // https://tools.ietf.org/html/draft-ietf-mmusic-sctp-sdp-26#section-5
        name: "sctpPort",
        reg: /^sctp-port:(\d+)$/,
        format: "sctp-port:%s"
      },
      {
        // RFC version 26 for SCTP over DTLS
        // https://tools.ietf.org/html/draft-ietf-mmusic-sctp-sdp-26#section-6
        name: "maxMessageSize",
        reg: /^max-message-size:(\d+)$/,
        format: "max-message-size:%s"
      },
      {
        // RFC7273
        // a=ts-refclk:ptp=IEEE1588-2008:39-A7-94-FF-FE-07-CB-D0:37
        push: "tsRefClocks",
        reg: /^ts-refclk:([^\s=]*)(?:=(\S*))?/,
        names: ["clksrc", "clksrcExt"],
        format: function(e) {
          return "ts-refclk:%s" + (e.clksrcExt != null ? "=%s" : "");
        }
      },
      {
        // RFC7273
        // a=mediaclk:direct=963214424
        name: "mediaClk",
        reg: /^mediaclk:(?:id=(\S*))? *([^\s=]*)(?:=(\S*))?(?: *rate=(\d+)\/(\d+))?/,
        names: ["id", "mediaClockName", "mediaClockValue", "rateNumerator", "rateDenominator"],
        format: function(e) {
          var t = "mediaclk:";
          return t += e.id != null ? "id=%s %s" : "%v%s", t += e.mediaClockValue != null ? "=%s" : "", t += e.rateNumerator != null ? " rate=%s" : "", t += e.rateDenominator != null ? "/%s" : "", t;
        }
      },
      {
        // a=keywds:keywords
        name: "keywords",
        reg: /^keywds:(.+)$/,
        format: "keywds:%s"
      },
      {
        // a=content:main
        name: "content",
        reg: /^content:(.+)/,
        format: "content:%s"
      },
      // BFCP https://tools.ietf.org/html/rfc4583
      {
        // a=floorctrl:c-s
        name: "bfcpFloorCtrl",
        reg: /^floorctrl:(c-only|s-only|c-s)/,
        format: "floorctrl:%s"
      },
      {
        // a=confid:1
        name: "bfcpConfId",
        reg: /^confid:(\d+)/,
        format: "confid:%s"
      },
      {
        // a=userid:1
        name: "bfcpUserId",
        reg: /^userid:(\d+)/,
        format: "userid:%s"
      },
      {
        // a=floorid:1
        name: "bfcpFloorId",
        reg: /^floorid:(.+) (?:m-stream|mstrm):(.+)/,
        names: ["id", "mStream"],
        format: "floorid:%s mstrm:%s"
      },
      {
        // any a= that we don't understand is kept verbatim on media.invalid
        push: "invalid",
        names: ["value"]
      }
    ]
  };
  return Object.keys(n).forEach(function(e) {
    var t = n[e];
    t.forEach(function(i) {
      i.reg || (i.reg = /(.*)/), i.format || (i.format = "%s");
    });
  }), Ps.exports;
}
var uo;
function Vp() {
  return uo || (uo = 1, (function(n) {
    var e = function(a) {
      return String(Number(a)) === a ? Number(a) : a;
    }, t = function(a, c, d, l) {
      if (l && !d)
        c[l] = e(a[1]);
      else
        for (var u = 0; u < d.length; u += 1)
          a[u + 1] != null && (c[d[u]] = e(a[u + 1]));
    }, i = function(a, c, d) {
      var l = a.name && a.names;
      a.push && !c[a.push] ? c[a.push] = [] : l && !c[a.name] && (c[a.name] = {});
      var u = a.push ? {} : (
        // blank object that will be pushed
        l ? c[a.name] : c
      );
      t(d.match(a.reg), u, a.names, a.name), a.push && c[a.push].push(u);
    }, s = Gr(), r = RegExp.prototype.test.bind(/^([a-z])=(.*)/);
    n.parse = function(a) {
      var c = {}, d = [], l = c;
      return a.split(/(\r\n|\r|\n)/).filter(r).forEach(function(u) {
        var h = u[0], p = u.slice(2);
        h === "m" && (d.push({
          rtp: [],
          fmtp: []
        }), l = d[d.length - 1]);
        for (var b = 0; b < (s[h] || []).length; b += 1) {
          var v = s[h][b];
          if (v.reg.test(p))
            return i(v, l, p);
        }
      }), c.media = d, c;
    };
    var o = function(a, c) {
      var d = c.split(/=(.+)/, 2);
      return d.length === 2 ? a[d[0]] = e(d[1]) : d.length === 1 && c.length > 1 && (a[d[0]] = void 0), a;
    };
    n.parseParams = function(a) {
      return a.split(/;\s?/).reduce(o, {});
    }, n.parseFmtpConfig = n.parseParams, n.parsePayloads = function(a) {
      return a.toString().split(" ").map(Number);
    }, n.parseRemoteCandidates = function(a) {
      for (var c = [], d = a.split(" ").map(e), l = 0; l < d.length; l += 3)
        c.push({
          component: d[l],
          ip: d[l + 1],
          port: d[l + 2]
        });
      return c;
    }, n.parseImageAttributes = function(a) {
      return a.split(" ").map(function(c) {
        return c.substring(1, c.length - 1).split(",").reduce(o, {});
      });
    }, n.parseSimulcastStreamList = function(a) {
      return a.split(";").map(function(c) {
        return c.split(",").map(function(d) {
          var l, u = !1;
          return d[0] !== "~" ? l = e(d) : (l = e(d.substring(1, d.length)), u = !0), {
            scid: l,
            paused: u
          };
        });
      });
    };
  })(Is)), Is;
}
var xs, ho;
function Bp() {
  if (ho) return xs;
  ho = 1;
  var n = Gr(), e = /%[sdv%]/g, t = function(o) {
    var a = 1, c = arguments, d = c.length;
    return o.replace(e, function(l) {
      if (a >= d)
        return l;
      var u = c[a];
      switch (a += 1, l) {
        case "%%":
          return "%";
        case "%s":
          return String(u);
        case "%d":
          return Number(u);
        case "%v":
          return "";
      }
    });
  }, i = function(o, a, c) {
    var d = a.format instanceof Function ? a.format(a.push ? c : c[a.name]) : a.format, l = [o + "=" + d];
    if (a.names)
      for (var u = 0; u < a.names.length; u += 1) {
        var h = a.names[u];
        a.name ? l.push(c[a.name][h]) : l.push(c[a.names[u]]);
      }
    else
      l.push(c[a.name]);
    return t.apply(null, l);
  }, s = ["v", "o", "s", "i", "u", "e", "p", "c", "b", "t", "r", "z", "a"], r = ["i", "c", "b", "a"];
  return xs = function(o, a) {
    a = a || {}, o.version == null && (o.version = 0), o.name == null && (o.name = " "), o.media.forEach(function(u) {
      u.payloads == null && (u.payloads = "");
    });
    var c = a.outerOrder || s, d = a.innerOrder || r, l = [];
    return c.forEach(function(u) {
      n[u].forEach(function(h) {
        h.name in o && o[h.name] != null ? l.push(i(u, h, o)) : h.push in o && o[h.push] != null && o[h.push].forEach(function(p) {
          l.push(i(u, h, p));
        });
      });
    }), o.media.forEach(function(u) {
      l.push(i("m", n.m[0], u)), d.forEach(function(h) {
        n[h].forEach(function(p) {
          p.name in u && u[p.name] != null ? l.push(i(h, p, u)) : p.push in u && u[p.push] != null && u[p.push].forEach(function(b) {
            l.push(i(h, p, b));
          });
        });
      });
    }), l.join(`\r
`) + `\r
`;
  }, xs;
}
var po;
function jp() {
  if (po) return mt;
  po = 1;
  var n = Vp(), e = Bp(), t = Gr();
  return mt.grammar = t, mt.write = e, mt.parse = n.parse, mt.parseParams = n.parseParams, mt.parseFmtpConfig = n.parseFmtpConfig, mt.parsePayloads = n.parsePayloads, mt.parseRemoteCandidates = n.parseRemoteCandidates, mt.parseImageAttributes = n.parseImageAttributes, mt.parseSimulcastStreamList = n.parseSimulcastStreamList, mt;
}
var Ht = jp();
function Jr(n) {
  let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 50, t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
  var i, s;
  let r;
  const o = (i = t.isImmediate) !== null && i !== void 0 ? i : !1, a = (s = t.callback) !== null && s !== void 0 ? s : !1, c = t.maxWait;
  let d = Date.now(), l = [];
  function u() {
    if (c !== void 0) {
      const p = Date.now() - d;
      if (p + e >= c)
        return c - p;
    }
    return e;
  }
  const h = function() {
    for (var p = arguments.length, b = new Array(p), v = 0; v < p; v++)
      b[v] = arguments[v];
    const C = this;
    return new Promise((T, P) => {
      const R = function() {
        if (r = void 0, d = Date.now(), !o) {
          const f = n.apply(C, b);
          a && a(f), l.forEach((k) => {
            let {
              resolve: w
            } = k;
            return w(f);
          }), l = [];
        }
      }, g = o && r === void 0;
      if (r !== void 0 && Be.clearTimeout(r), r = Be.setTimeout(R, u()), g) {
        const f = n.apply(C, b);
        return a && a(f), T(f);
      }
      l.push({
        resolve: T,
        reject: P
      });
    });
  };
  return h.cancel = function(p) {
    r !== void 0 && Be.clearTimeout(r), l.forEach((b) => {
      let {
        reject: v
      } = b;
      return v(p);
    }), l = [];
  }, h;
}
const qp = 0.7, Hp = 20, di = {
  NegotiationStarted: "negotiationStarted",
  NegotiationComplete: "negotiationComplete",
  RTPVideoPayloadTypes: "rtpVideoPayloadTypes"
};
class mo extends Pt.EventEmitter {
  get pc() {
    return this._pc || (this._pc = this.createPC()), this._pc;
  }
  constructor(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var i;
    super(), this.log = se, this.ddExtID = 0, this.latestOfferId = 0, this.pendingCandidates = [], this.restartingIce = !1, this.renegotiate = !1, this.trackBitrates = [], this.remoteStereoMids = [], this.remoteNackMids = [], this.negotiate = Jr((s) => m(this, void 0, void 0, function* () {
      this.emit(di.NegotiationStarted);
      try {
        yield this.createAndSendOffer();
      } catch (r) {
        if (s)
          s(r);
        else
          throw r;
      }
    }), Hp), this.close = () => {
      this._pc && (this._pc.close(), this._pc.onconnectionstatechange = null, this._pc.oniceconnectionstatechange = null, this._pc.onicegatheringstatechange = null, this._pc.ondatachannel = null, this._pc.onnegotiationneeded = null, this._pc.onsignalingstatechange = null, this._pc.onicecandidate = null, this._pc.ondatachannel = null, this._pc.ontrack = null, this._pc.onconnectionstatechange = null, this._pc.oniceconnectionstatechange = null, this._pc = null);
    }, this.log = St((i = t.loggerName) !== null && i !== void 0 ? i : at.PCTransport), this.loggerOptions = t, this.config = e, this._pc = this.createPC(), this.offerLock = new Ze();
  }
  createPC() {
    const e = new RTCPeerConnection(this.config);
    return e.onicecandidate = (t) => {
      var i;
      t.candidate && ((i = this.onIceCandidate) === null || i === void 0 || i.call(this, t.candidate));
    }, e.onicecandidateerror = (t) => {
      var i;
      (i = this.onIceCandidateError) === null || i === void 0 || i.call(this, t);
    }, e.oniceconnectionstatechange = () => {
      var t;
      (t = this.onIceConnectionStateChange) === null || t === void 0 || t.call(this, e.iceConnectionState);
    }, e.onsignalingstatechange = () => {
      var t;
      (t = this.onSignalingStatechange) === null || t === void 0 || t.call(this, e.signalingState);
    }, e.onconnectionstatechange = () => {
      var t;
      (t = this.onConnectionStateChange) === null || t === void 0 || t.call(this, e.connectionState);
    }, e.ondatachannel = (t) => {
      var i;
      (i = this.onDataChannel) === null || i === void 0 || i.call(this, t);
    }, e.ontrack = (t) => {
      var i;
      (i = this.onTrack) === null || i === void 0 || i.call(this, t);
    }, e;
  }
  get logContext() {
    var e, t;
    return Object.assign({}, (t = (e = this.loggerOptions).loggerContextCb) === null || t === void 0 ? void 0 : t.call(e));
  }
  get isICEConnected() {
    return this._pc !== null && (this.pc.iceConnectionState === "connected" || this.pc.iceConnectionState === "completed");
  }
  addIceCandidate(e) {
    return m(this, void 0, void 0, function* () {
      if (this.pc.remoteDescription && !this.restartingIce)
        return this.pc.addIceCandidate(e);
      this.pendingCandidates.push(e);
    });
  }
  setRemoteDescription(e, t) {
    return m(this, void 0, void 0, function* () {
      var i;
      if (e.type === "answer" && this.latestOfferId > 0 && t > 0 && t !== this.latestOfferId)
        return this.log.warn("ignoring answer for old offer", Object.assign(Object.assign({}, this.logContext), {
          offerId: t,
          latestOfferId: this.latestOfferId
        })), !1;
      let s;
      if (e.type === "offer") {
        let {
          stereoMids: r,
          nackMids: o
        } = Wp(e);
        this.remoteStereoMids = r, this.remoteNackMids = o;
      } else if (e.type === "answer") {
        const r = Ht.parse((i = e.sdp) !== null && i !== void 0 ? i : "");
        r.media.forEach((o) => {
          const a = Yr(o.mid);
          o.type === "audio" && this.trackBitrates.some((c) => {
            if (!c.transceiver || a != c.transceiver.mid)
              return !1;
            let d = 0;
            if (o.rtp.some((u) => u.codec.toUpperCase() === c.codec.toUpperCase() ? (d = u.payload, !0) : !1), d === 0)
              return !0;
            let l = !1;
            for (const u of o.fmtp)
              if (u.payload === d) {
                u.config = u.config.split(";").filter((h) => !h.includes("maxaveragebitrate")).join(";"), c.maxbr > 0 && (u.config += ";maxaveragebitrate=".concat(c.maxbr * 1e3)), l = !0;
                break;
              }
            return l || c.maxbr > 0 && o.fmtp.push({
              payload: d,
              config: "maxaveragebitrate=".concat(c.maxbr * 1e3)
            }), !0;
          });
        }), s = Ht.write(r);
      }
      return yield this.setMungedSDP(e, s, !0), this.pendingCandidates.forEach((r) => {
        this.pc.addIceCandidate(r);
      }), this.pendingCandidates = [], this.restartingIce = !1, this.renegotiate ? (this.renegotiate = !1, yield this.createAndSendOffer()) : e.type === "answer" && (this.emit(di.NegotiationComplete), e.sdp && Ht.parse(e.sdp).media.forEach((o) => {
        o.type === "video" && this.emit(di.RTPVideoPayloadTypes, o.rtp);
      })), !0;
    });
  }
  createAndSendOffer(e) {
    return m(this, void 0, void 0, function* () {
      var t;
      const i = yield this.offerLock.lock();
      try {
        if (this.onOffer === void 0)
          return;
        if (e != null && e.iceRestart && (this.log.debug("restarting ICE", this.logContext), this.restartingIce = !0), this._pc && this._pc.signalingState === "have-local-offer") {
          const a = this._pc.remoteDescription;
          if (e != null && e.iceRestart && a)
            yield this._pc.setRemoteDescription(a);
          else {
            this.renegotiate = !0, this.log.debug("requesting renegotiation", Object.assign({}, this.logContext));
            return;
          }
        } else if (!this._pc || this._pc.signalingState === "closed") {
          this.log.warn("could not createOffer with closed peer connection", this.logContext);
          return;
        }
        this.log.debug("starting to negotiate", this.logContext);
        const s = this.latestOfferId + 1;
        this.latestOfferId = s;
        const r = yield this.pc.createOffer(e);
        this.log.debug("original offer", Object.assign({
          sdp: r.sdp
        }, this.logContext));
        const o = Ht.parse((t = r.sdp) !== null && t !== void 0 ? t : "");
        if (o.media.forEach((a) => {
          go(a), a.type === "audio" ? fo(a, ["all"], []) : a.type === "video" && this.trackBitrates.some((c) => {
            if (!a.msid || !c.cid || !a.msid.includes(c.cid))
              return !1;
            let d = 0;
            if (a.rtp.some((u) => u.codec.toUpperCase() === c.codec.toUpperCase() ? (d = u.payload, !0) : !1), d === 0 || (bt(c.codec) && !hi() && this.ensureVideoDDExtensionForSVC(a, o), !bt(c.codec)))
              return !0;
            const l = Math.round(c.maxbr * qp);
            for (const u of a.fmtp)
              if (u.payload === d) {
                u.config.includes("x-google-start-bitrate") || (u.config += ";x-google-start-bitrate=".concat(l));
                break;
              }
            return !0;
          });
        }), this.latestOfferId > s) {
          this.log.warn("latestOfferId mismatch", Object.assign(Object.assign({}, this.logContext), {
            latestOfferId: this.latestOfferId,
            offerId: s
          }));
          return;
        }
        yield this.setMungedSDP(r, Ht.write(o)), this.onOffer(r, this.latestOfferId);
      } finally {
        i();
      }
    });
  }
  createAndSetAnswer() {
    return m(this, void 0, void 0, function* () {
      var e;
      const t = yield this.pc.createAnswer(), i = Ht.parse((e = t.sdp) !== null && e !== void 0 ? e : "");
      return i.media.forEach((s) => {
        go(s), s.type === "audio" && fo(s, this.remoteStereoMids, this.remoteNackMids);
      }), yield this.setMungedSDP(t, Ht.write(i)), t;
    });
  }
  createDataChannel(e, t) {
    return this.pc.createDataChannel(e, t);
  }
  addTransceiver(e, t) {
    return this.pc.addTransceiver(e, t);
  }
  addTransceiverOfKind(e, t) {
    return this.pc.addTransceiver(e, t);
  }
  addTrack(e) {
    if (!this._pc)
      throw new De("PC closed, cannot add track");
    return this._pc.addTrack(e);
  }
  setTrackCodecBitrate(e) {
    this.trackBitrates.push(e);
  }
  setConfiguration(e) {
    var t;
    if (!this._pc)
      throw new De("PC closed, cannot configure");
    return (t = this._pc) === null || t === void 0 ? void 0 : t.setConfiguration(e);
  }
  canRemoveTrack() {
    var e;
    return !!(!((e = this._pc) === null || e === void 0) && e.removeTrack);
  }
  removeTrack(e) {
    var t;
    return (t = this._pc) === null || t === void 0 ? void 0 : t.removeTrack(e);
  }
  getConnectionState() {
    var e, t;
    return (t = (e = this._pc) === null || e === void 0 ? void 0 : e.connectionState) !== null && t !== void 0 ? t : "closed";
  }
  getICEConnectionState() {
    var e, t;
    return (t = (e = this._pc) === null || e === void 0 ? void 0 : e.iceConnectionState) !== null && t !== void 0 ? t : "closed";
  }
  getSignallingState() {
    var e, t;
    return (t = (e = this._pc) === null || e === void 0 ? void 0 : e.signalingState) !== null && t !== void 0 ? t : "closed";
  }
  getTransceivers() {
    var e, t;
    return (t = (e = this._pc) === null || e === void 0 ? void 0 : e.getTransceivers()) !== null && t !== void 0 ? t : [];
  }
  getSenders() {
    var e, t;
    return (t = (e = this._pc) === null || e === void 0 ? void 0 : e.getSenders()) !== null && t !== void 0 ? t : [];
  }
  getLocalDescription() {
    var e;
    return (e = this._pc) === null || e === void 0 ? void 0 : e.localDescription;
  }
  getRemoteDescription() {
    var e;
    return (e = this.pc) === null || e === void 0 ? void 0 : e.remoteDescription;
  }
  getStats() {
    return this.pc.getStats();
  }
  getConnectedAddress() {
    return m(this, void 0, void 0, function* () {
      var e;
      if (!this._pc)
        return;
      let t = "";
      const i = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map();
      if ((yield this._pc.getStats()).forEach((a) => {
        switch (a.type) {
          case "transport":
            t = a.selectedCandidatePairId;
            break;
          case "candidate-pair":
            t === "" && a.selected && (t = a.id), i.set(a.id, a);
            break;
          case "remote-candidate":
            s.set(a.id, "".concat(a.address, ":").concat(a.port));
            break;
        }
      }), t === "")
        return;
      const o = (e = i.get(t)) === null || e === void 0 ? void 0 : e.remoteCandidateId;
      if (o !== void 0)
        return s.get(o);
    });
  }
  setMungedSDP(e, t, i) {
    return m(this, void 0, void 0, function* () {
      if (t) {
        const s = e.sdp;
        e.sdp = t;
        try {
          this.log.debug("setting munged ".concat(i ? "remote" : "local", " description"), this.logContext), i ? yield this.pc.setRemoteDescription(e) : yield this.pc.setLocalDescription(e);
          return;
        } catch (r) {
          this.log.warn("not able to set ".concat(e.type, ", falling back to unmodified sdp"), Object.assign(Object.assign({}, this.logContext), {
            error: r,
            sdp: t
          })), e.sdp = s;
        }
      }
      try {
        i ? yield this.pc.setRemoteDescription(e) : yield this.pc.setLocalDescription(e);
      } catch (s) {
        let r = "unknown error";
        s instanceof Error ? r = s.message : typeof s == "string" && (r = s);
        const o = {
          error: r,
          sdp: e.sdp
        };
        throw !i && this.pc.remoteDescription && (o.remoteSdp = this.pc.remoteDescription), this.log.error("unable to set ".concat(e.type), Object.assign(Object.assign({}, this.logContext), {
          fields: o
        })), new oi(r);
      }
    });
  }
  ensureVideoDDExtensionForSVC(e, t) {
    var i, s;
    if (!((i = e.ext) === null || i === void 0 ? void 0 : i.some((o) => o.uri === Ya))) {
      if (this.ddExtID === 0) {
        let o = 0;
        t.media.forEach((a) => {
          var c;
          a.type === "video" && ((c = a.ext) === null || c === void 0 || c.forEach((d) => {
            d.value > o && (o = d.value);
          }));
        }), this.ddExtID = o + 1;
      }
      (s = e.ext) === null || s === void 0 || s.push({
        value: this.ddExtID,
        uri: Ya
      });
    }
  }
}
function fo(n, e, t) {
  const i = Yr(n.mid);
  let s = 0;
  n.rtp.some((r) => r.codec === "opus" ? (s = r.payload, !0) : !1), s > 0 && (n.rtcpFb || (n.rtcpFb = []), t.includes(i) && !n.rtcpFb.some((r) => r.payload === s && r.type === "nack") && n.rtcpFb.push({
    payload: s,
    type: "nack"
  }), (e.includes(i) || e.length === 1 && e[0] === "all") && n.fmtp.some((r) => r.payload === s ? (r.config.includes("stereo=1") || (r.config += ";stereo=1"), !0) : !1));
}
function Wp(n) {
  var e;
  const t = [], i = [], s = Ht.parse((e = n.sdp) !== null && e !== void 0 ? e : "");
  let r = 0;
  return s.media.forEach((o) => {
    var a;
    const c = Yr(o.mid);
    o.type === "audio" && (o.rtp.some((d) => d.codec === "opus" ? (r = d.payload, !0) : !1), !((a = o.rtcpFb) === null || a === void 0) && a.some((d) => d.payload === r && d.type === "nack") && i.push(c), o.fmtp.some((d) => d.payload === r ? (d.config.includes("sprop-stereo=1") && t.push(c), !0) : !1));
  }), {
    stereoMids: t,
    nackMids: i
  };
}
function go(n) {
  if (n.connection) {
    const e = n.connection.ip.indexOf(":") >= 0;
    (n.connection.version === 4 && e || n.connection.version === 6 && !e) && (n.connection.ip = "0.0.0.0", n.connection.version = 4);
  }
}
function Yr(n) {
  return typeof n == "number" ? n.toFixed(0) : n;
}
const mr = "vp8", $p = {
  audioPreset: rr.music,
  dtx: !0,
  red: !0,
  forceStereo: !1,
  simulcast: !0,
  screenShareEncoding: Wr.h1080fps15.encoding,
  stopMicTrackOnMute: !1,
  videoCodec: mr,
  backupCodec: !0,
  preConnectBuffer: !1
}, Ld = {
  deviceId: {
    ideal: "default"
  },
  autoGainControl: !0,
  echoCancellation: !0,
  noiseSuppression: !0,
  voiceIsolation: !0
}, Nd = {
  deviceId: {
    ideal: "default"
  },
  resolution: ln.h720.resolution
}, zp = {
  adaptiveStream: !1,
  dynacast: !1,
  stopLocalTrackOnUnpublish: !0,
  reconnectPolicy: new Kc(),
  disconnectOnPageLeave: !0,
  webAudioMix: !1,
  singlePeerConnection: !0
}, Qr = {
  autoSubscribe: !0,
  maxRetries: 1,
  peerConnectionTimeout: 15e3,
  websocketTimeout: 15e3
};
var Me;
(function(n) {
  n[n.NEW = 0] = "NEW", n[n.CONNECTING = 1] = "CONNECTING", n[n.CONNECTED = 2] = "CONNECTED", n[n.FAILED = 3] = "FAILED", n[n.CLOSING = 4] = "CLOSING", n[n.CLOSED = 5] = "CLOSED";
})(Me || (Me = {}));
class Kp {
  get needsPublisher() {
    return this.isPublisherConnectionRequired;
  }
  get needsSubscriber() {
    return this.isSubscriberConnectionRequired;
  }
  get currentState() {
    return this.state;
  }
  get mode() {
    return this._mode;
  }
  constructor(e, t, i) {
    var s;
    this.peerConnectionTimeout = Qr.peerConnectionTimeout, this.log = se, this.updateState = () => {
      var r, o;
      const a = this.state, c = this.requiredTransports.map((d) => d.getConnectionState());
      c.every((d) => d === "connected") ? this.state = Me.CONNECTED : c.some((d) => d === "failed") ? this.state = Me.FAILED : c.some((d) => d === "connecting") ? this.state = Me.CONNECTING : c.every((d) => d === "closed") ? this.state = Me.CLOSED : c.some((d) => d === "closed") ? this.state = Me.CLOSING : c.every((d) => d === "new") && (this.state = Me.NEW), a !== this.state && (this.log.debug("pc state change: from ".concat(Me[a], " to ").concat(Me[this.state]), this.logContext), (r = this.onStateChange) === null || r === void 0 || r.call(this, this.state, this.publisher.getConnectionState(), (o = this.subscriber) === null || o === void 0 ? void 0 : o.getConnectionState()));
    }, this.log = St((s = i.loggerName) !== null && s !== void 0 ? s : at.PCManager), this.loggerOptions = i, this.isPublisherConnectionRequired = t !== "subscriber-primary", this.isSubscriberConnectionRequired = t === "subscriber-primary", this.publisher = new mo(e, i), this._mode = t, t !== "publisher-only" && (this.subscriber = new mo(e, i), this.subscriber.onConnectionStateChange = this.updateState, this.subscriber.onIceConnectionStateChange = this.updateState, this.subscriber.onSignalingStatechange = this.updateState, this.subscriber.onIceCandidate = (r) => {
      var o;
      (o = this.onIceCandidate) === null || o === void 0 || o.call(this, r, vt.SUBSCRIBER);
    }, this.subscriber.onDataChannel = (r) => {
      var o;
      (o = this.onDataChannel) === null || o === void 0 || o.call(this, r);
    }, this.subscriber.onTrack = (r) => {
      var o;
      (o = this.onTrack) === null || o === void 0 || o.call(this, r);
    }), this.publisher.onConnectionStateChange = this.updateState, this.publisher.onIceConnectionStateChange = this.updateState, this.publisher.onSignalingStatechange = this.updateState, this.publisher.onIceCandidate = (r) => {
      var o;
      (o = this.onIceCandidate) === null || o === void 0 || o.call(this, r, vt.PUBLISHER);
    }, this.publisher.onTrack = (r) => {
      var o;
      (o = this.onTrack) === null || o === void 0 || o.call(this, r);
    }, this.publisher.onOffer = (r, o) => {
      var a;
      (a = this.onPublisherOffer) === null || a === void 0 || a.call(this, r, o);
    }, this.state = Me.NEW, this.connectionLock = new Ze(), this.remoteOfferLock = new Ze();
  }
  get logContext() {
    var e, t;
    return Object.assign({}, (t = (e = this.loggerOptions).loggerContextCb) === null || t === void 0 ? void 0 : t.call(e));
  }
  requirePublisher() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
    this.isPublisherConnectionRequired = e, this.updateState();
  }
  createAndSendPublisherOffer(e) {
    return this.publisher.createAndSendOffer(e);
  }
  setPublisherAnswer(e, t) {
    return this.publisher.setRemoteDescription(e, t);
  }
  removeTrack(e) {
    return this.publisher.removeTrack(e);
  }
  close() {
    return m(this, void 0, void 0, function* () {
      var e;
      if (this.publisher && this.publisher.getSignallingState() !== "closed") {
        const t = this.publisher;
        for (const i of t.getSenders())
          try {
            t.canRemoveTrack() && t.removeTrack(i);
          } catch (s) {
            this.log.warn("could not removeTrack", Object.assign(Object.assign({}, this.logContext), {
              error: s
            }));
          }
      }
      yield Promise.all([this.publisher.close(), (e = this.subscriber) === null || e === void 0 ? void 0 : e.close()]), this.updateState();
    });
  }
  triggerIceRestart() {
    return m(this, void 0, void 0, function* () {
      this.subscriber && (this.subscriber.restartingIce = !0), this.needsPublisher && (yield this.createAndSendPublisherOffer({
        iceRestart: !0
      }));
    });
  }
  addIceCandidate(e, t) {
    return m(this, void 0, void 0, function* () {
      var i;
      t === vt.PUBLISHER ? yield this.publisher.addIceCandidate(e) : yield (i = this.subscriber) === null || i === void 0 ? void 0 : i.addIceCandidate(e);
    });
  }
  createSubscriberAnswerFromOffer(e, t) {
    return m(this, void 0, void 0, function* () {
      var i, s, r;
      this.log.debug("received server offer", Object.assign(Object.assign({}, this.logContext), {
        RTCSdpType: e.type,
        sdp: e.sdp,
        signalingState: (i = this.subscriber) === null || i === void 0 ? void 0 : i.getSignallingState().toString()
      }));
      const o = yield this.remoteOfferLock.lock();
      try {
        return (yield (s = this.subscriber) === null || s === void 0 ? void 0 : s.setRemoteDescription(e, t)) ? yield (r = this.subscriber) === null || r === void 0 ? void 0 : r.createAndSetAnswer() : void 0;
      } finally {
        o();
      }
    });
  }
  updateConfiguration(e, t) {
    var i;
    this.publisher.setConfiguration(e), (i = this.subscriber) === null || i === void 0 || i.setConfiguration(e), t && this.triggerIceRestart();
  }
  ensurePCTransportConnection(e, t) {
    return m(this, void 0, void 0, function* () {
      var i;
      const s = yield this.connectionLock.lock();
      try {
        this.isPublisherConnectionRequired && this.publisher.getConnectionState() !== "connected" && this.publisher.getConnectionState() !== "connecting" && (this.log.debug("negotiation required, start negotiating", this.logContext), this.publisher.negotiate()), yield Promise.all((i = this.requiredTransports) === null || i === void 0 ? void 0 : i.map((r) => this.ensureTransportConnected(r, e, t)));
      } finally {
        s();
      }
    });
  }
  negotiate(e) {
    return m(this, void 0, void 0, function* () {
      return new Je((t, i) => m(this, void 0, void 0, function* () {
        let s = setTimeout(() => {
          i(new oi("negotiation timed out"));
        }, this.peerConnectionTimeout);
        const r = () => {
          clearTimeout(s), this.publisher.off(di.NegotiationStarted, a), e.signal.removeEventListener("abort", o);
        }, o = () => {
          r(), i(new oi("negotiation aborted"));
        }, a = () => {
          e.signal.aborted || (clearTimeout(s), s = setTimeout(() => {
            r(), i(new oi("negotiation timed out"));
          }, this.peerConnectionTimeout));
        };
        e.signal.addEventListener("abort", o), this.publisher.on(di.NegotiationStarted, a), this.publisher.once(di.NegotiationComplete, () => {
          r(), t();
        }), yield this.publisher.negotiate((c) => {
          r(), c instanceof Error ? i(c) : i(new Error(String(c)));
        });
      }));
    });
  }
  addPublisherTransceiver(e, t) {
    return this.publisher.addTransceiver(e, t);
  }
  addPublisherTransceiverOfKind(e, t) {
    return this.publisher.addTransceiverOfKind(e, t);
  }
  getMidForReceiver(e) {
    const i = (this.subscriber ? this.subscriber.getTransceivers() : this.publisher.getTransceivers()).find((s) => s.receiver === e);
    return i == null ? void 0 : i.mid;
  }
  addPublisherTrack(e) {
    return this.publisher.addTrack(e);
  }
  createPublisherDataChannel(e, t) {
    return this.publisher.createDataChannel(e, t);
  }
  /**
   * Returns the first required transport's address if no explicit target is specified
   */
  getConnectedAddress(e) {
    return e === vt.PUBLISHER ? this.publisher.getConnectedAddress() : e === vt.SUBSCRIBER ? this.publisher.getConnectedAddress() : this.requiredTransports[0].getConnectedAddress();
  }
  get requiredTransports() {
    const e = [];
    return this.isPublisherConnectionRequired && e.push(this.publisher), this.isSubscriberConnectionRequired && this.subscriber && e.push(this.subscriber), e;
  }
  ensureTransportConnected(e, t) {
    return m(this, arguments, void 0, function(i, s) {
      var r = this;
      let o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.peerConnectionTimeout;
      return (function* () {
        if (i.getConnectionState() !== "connected")
          return new Promise((c, d) => m(r, void 0, void 0, function* () {
            const l = () => {
              this.log.warn("abort transport connection", this.logContext), Be.clearTimeout(u), d(Z.cancelled("room connection has been cancelled"));
            };
            s != null && s.signal.aborted && l(), s == null || s.signal.addEventListener("abort", l);
            const u = Be.setTimeout(() => {
              s == null || s.signal.removeEventListener("abort", l), d(Z.internal("could not establish pc connection"));
            }, o);
            for (; this.state !== Me.CONNECTED; )
              if (yield ze(50), s != null && s.signal.aborted) {
                d(Z.cancelled("room connection has been cancelled"));
                return;
              }
            Be.clearTimeout(u), s == null || s.signal.removeEventListener("abort", l), c();
          }));
      })();
    });
  }
}
const Ud = 5e3, Gp = 3e4;
class ye {
  static fetchRegionSettings(e, t, i) {
    return m(this, void 0, void 0, function* () {
      const s = yield ye.fetchLock.lock();
      try {
        const r = yield fetch("".concat(Jp(e), "/regions"), {
          headers: {
            authorization: "Bearer ".concat(t)
          },
          signal: i
        });
        if (r.ok) {
          const o = vp(r.headers), a = o ? o * 1e3 : Ud;
          return {
            regionSettings: yield r.json(),
            updatedAtInMs: Date.now(),
            maxAgeInMs: a
          };
        } else
          throw r.status === 401 ? Z.notAllowed("Could not fetch region settings: ".concat(r.statusText), r.status) : Z.internal("Could not fetch region settings: ".concat(r.statusText));
      } catch (r) {
        throw r instanceof Z ? r : i != null && i.aborted ? Z.cancelled("Region fetching was aborted") : Z.serverUnreachable("Could not fetch region settings, ".concat(r instanceof Error ? "".concat(r.name, ": ").concat(r.message) : r));
      } finally {
        s();
      }
    });
  }
  static scheduleRefetch(e, t, i) {
    return m(this, void 0, void 0, function* () {
      const s = ye.settingsTimeouts.get(e.hostname);
      clearTimeout(s), ye.settingsTimeouts.set(e.hostname, setTimeout(() => m(this, void 0, void 0, function* () {
        try {
          const r = yield ye.fetchRegionSettings(e, t);
          ye.updateCachedRegionSettings(e, t, r);
        } catch (r) {
          if (r instanceof Z && r.reason === Re.NotAllowed) {
            se.debug("token is not valid, cancelling auto region refresh");
            return;
          }
          se.debug("auto refetching of region settings failed", {
            error: r
          }), ye.scheduleRefetch(e, t, i);
        }
      }), i));
    });
  }
  static updateCachedRegionSettings(e, t, i) {
    ye.cache.set(e.hostname, i), ye.scheduleRefetch(e, t, i.maxAgeInMs);
  }
  static stopRefetch(e) {
    const t = ye.settingsTimeouts.get(e);
    t && (clearTimeout(t), ye.settingsTimeouts.delete(e));
  }
  static scheduleCleanup(e) {
    let t = ye.connectionTrackers.get(e);
    t && (t.cleanupTimeout && clearTimeout(t.cleanupTimeout), t.cleanupTimeout = setTimeout(() => {
      const i = ye.connectionTrackers.get(e);
      i && i.connectionCount === 0 && (se.debug("stopping region refetch after disconnect delay", {
        hostname: e
      }), ye.stopRefetch(e)), i && (i.cleanupTimeout = void 0);
    }, Gp));
  }
  static cancelCleanup(e) {
    const t = ye.connectionTrackers.get(e);
    t != null && t.cleanupTimeout && (clearTimeout(t.cleanupTimeout), t.cleanupTimeout = void 0);
  }
  notifyConnected() {
    const e = this.serverUrl.hostname;
    let t = ye.connectionTrackers.get(e);
    t || (t = {
      connectionCount: 0
    }, ye.connectionTrackers.set(e, t)), t.connectionCount++, ye.cancelCleanup(e);
  }
  notifyDisconnected() {
    const e = this.serverUrl.hostname, t = ye.connectionTrackers.get(e);
    t && (t.connectionCount = Math.max(0, t.connectionCount - 1), t.connectionCount === 0 && ye.scheduleCleanup(e));
  }
  constructor(e, t) {
    this.attemptedRegions = [], this.serverUrl = new URL(e), this.token = t;
  }
  updateToken(e) {
    this.token = e;
  }
  isCloud() {
    return Vi(this.serverUrl);
  }
  getServerUrl() {
    return this.serverUrl;
  }
  /** @internal */
  fetchRegionSettings(e) {
    return m(this, void 0, void 0, function* () {
      return ye.fetchRegionSettings(this.serverUrl, this.token, e);
    });
  }
  getNextBestRegionUrl(e) {
    return m(this, void 0, void 0, function* () {
      if (!this.isCloud())
        throw Error("region availability is only supported for LiveKit Cloud domains");
      let t = ye.cache.get(this.serverUrl.hostname);
      (!t || Date.now() - t.updatedAtInMs > t.maxAgeInMs) && (t = yield this.fetchRegionSettings(e), ye.updateCachedRegionSettings(this.serverUrl, this.token, t));
      const i = t.regionSettings.regions.filter((s) => !this.attemptedRegions.find((r) => r.url === s.url));
      if (i.length > 0) {
        const s = i[0];
        return this.attemptedRegions.push(s), se.debug("next region: ".concat(s.region)), s.url;
      } else
        return null;
    });
  }
  resetAttempts() {
    this.attemptedRegions = [];
  }
  setServerReportedRegions(e) {
    ye.updateCachedRegionSettings(this.serverUrl, this.token, e);
  }
}
ye.cache = /* @__PURE__ */ new Map();
ye.settingsTimeouts = /* @__PURE__ */ new Map();
ye.connectionTrackers = /* @__PURE__ */ new Map();
ye.fetchLock = new Ze();
function Jp(n) {
  return "".concat(n.protocol.replace("ws", "http"), "//").concat(n.host, "/settings");
}
class Oe extends Error {
  /**
   * Creates an error object with the given code and message, plus an optional data payload.
   *
   * If thrown in an RPC method handler, the error will be sent back to the caller.
   *
   * Error codes 1001-1999 are reserved for built-in errors (see RpcError.ErrorCode for their meanings).
   */
  constructor(e, t, i) {
    super(t), this.code = e, this.message = vo(t, Oe.MAX_MESSAGE_BYTES), this.data = i ? vo(i, Oe.MAX_DATA_BYTES) : void 0;
  }
  /**
   * @internal
   */
  static fromProto(e) {
    return new Oe(e.code, e.message, e.data);
  }
  /**
   * @internal
   */
  toProto() {
    return new _c({
      code: this.code,
      message: this.message,
      data: this.data
    });
  }
  /**
   * Creates an error object from the code, with an auto-populated message.
   *
   * @internal
   */
  static builtIn(e, t) {
    return new Oe(Oe.ErrorCode[e], Oe.ErrorMessage[e], t);
  }
}
Oe.MAX_MESSAGE_BYTES = 256;
Oe.MAX_DATA_BYTES = 15360;
Oe.ErrorCode = {
  APPLICATION_ERROR: 1500,
  CONNECTION_TIMEOUT: 1501,
  RESPONSE_TIMEOUT: 1502,
  RECIPIENT_DISCONNECTED: 1503,
  RESPONSE_PAYLOAD_TOO_LARGE: 1504,
  SEND_FAILED: 1505,
  UNSUPPORTED_METHOD: 1400,
  RECIPIENT_NOT_FOUND: 1401,
  REQUEST_PAYLOAD_TOO_LARGE: 1402,
  UNSUPPORTED_SERVER: 1403,
  UNSUPPORTED_VERSION: 1404
};
Oe.ErrorMessage = {
  APPLICATION_ERROR: "Application error in method handler",
  CONNECTION_TIMEOUT: "Connection timeout",
  RESPONSE_TIMEOUT: "Response timeout",
  RECIPIENT_DISCONNECTED: "Recipient disconnected",
  RESPONSE_PAYLOAD_TOO_LARGE: "Response payload too large",
  SEND_FAILED: "Failed to send",
  UNSUPPORTED_METHOD: "Method not supported at destination",
  RECIPIENT_NOT_FOUND: "Recipient not found",
  REQUEST_PAYLOAD_TOO_LARGE: "Request payload too large",
  UNSUPPORTED_SERVER: "RPC not supported by server",
  UNSUPPORTED_VERSION: "Unsupported RPC version"
};
const Fd = 15360;
function Xr(n) {
  return new TextEncoder().encode(n).length;
}
function vo(n, e) {
  if (Xr(n) <= e)
    return n;
  let t = 0, i = n.length;
  const s = new TextEncoder();
  for (; t < i; ) {
    const r = Math.floor((t + i + 1) / 2);
    s.encode(n.slice(0, r)).length <= e ? t = r : i = r - 1;
  }
  return n.slice(0, t);
}
const Zr = 2e3;
function ds(n, e) {
  if (!e)
    return 0;
  let t, i;
  return "bytesReceived" in n ? (t = n.bytesReceived, i = e.bytesReceived) : "bytesSent" in n && (t = n.bytesSent, i = e.bytesSent), t === void 0 || i === void 0 || n.timestamp === void 0 || e.timestamp === void 0 ? 0 : (t - i) * 8 * 1e3 / (n.timestamp - e.timestamp);
}
const ea = typeof MediaRecorder != "undefined";
class Yp {
  constructor() {
    throw new Error("MediaRecorder is not available in this environment");
  }
}
const Qp = ea ? MediaRecorder : Yp;
class Xp extends Qp {
  constructor(e, t) {
    if (!ea)
      throw new Error("MediaRecorder is not available in this environment");
    super(new MediaStream([e.mediaStreamTrack]), t);
    let i, s;
    const r = () => s === void 0, o = () => {
      this.removeEventListener("dataavailable", i), this.removeEventListener("stop", o), this.removeEventListener("error", a), s == null || s.close(), s = void 0;
    }, a = (c) => {
      s == null || s.error(c), this.removeEventListener("dataavailable", i), this.removeEventListener("stop", o), this.removeEventListener("error", a), s = void 0;
    };
    this.byteStream = new ReadableStream({
      start: (c) => {
        s = c, i = (d) => m(this, void 0, void 0, function* () {
          let l;
          if (d.data.arrayBuffer) {
            const u = yield d.data.arrayBuffer();
            l = new Uint8Array(u);
          } else if (d.data.byteArray)
            l = d.data.byteArray;
          else
            throw new Error("no data available!");
          r() || c.enqueue(l);
        }), this.addEventListener("dataavailable", i);
      },
      cancel: () => {
        o();
      }
    }), this.addEventListener("stop", o), this.addEventListener("error", a);
  }
}
function Zp() {
  return ea;
}
const em = 1e3, tm = 1e4;
class Vd extends E {
  /** @internal */
  get sender() {
    return this._sender;
  }
  /** @internal */
  set sender(e) {
    this._sender = e;
  }
  get constraints() {
    return this._constraints;
  }
  get hasPreConnectBuffer() {
    return !!this.localTrackRecorder;
  }
  /**
   *
   * @param mediaTrack
   * @param kind
   * @param constraints MediaTrackConstraints that are being used when restarting or reacquiring tracks
   * @param userProvidedTrack Signals to the SDK whether or not the mediaTrack should be managed (i.e. released and reacquired) internally by the SDK
   */
  constructor(e, t, i) {
    let s = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1, r = arguments.length > 4 ? arguments[4] : void 0;
    super(e, t, r), this.manuallyStopped = !1, this.pendingDeviceChange = !1, this._isUpstreamPaused = !1, this.handleTrackMuteEvent = () => this.debouncedTrackMuteHandler().catch(() => this.log.debug("track mute bounce got cancelled by an unmute event", this.logContext)), this.debouncedTrackMuteHandler = Jr(() => m(this, void 0, void 0, function* () {
      yield this.pauseUpstream();
    }), 5e3), this.handleTrackUnmuteEvent = () => m(this, void 0, void 0, function* () {
      this.debouncedTrackMuteHandler.cancel("unmute"), yield this.resumeUpstream();
    }), this.handleEnded = () => {
      this.isInBackground && (this.reacquireTrack = !0), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent), this.emit(U.Ended, this);
    }, this.reacquireTrack = !1, this.providedByUser = s, this.muteLock = new Ze(), this.pauseUpstreamLock = new Ze(), this.trackChangeLock = new Ze(), this.trackChangeLock.lock().then((o) => m(this, void 0, void 0, function* () {
      try {
        yield this.setMediaStreamTrack(e, !0);
      } finally {
        o();
      }
    })), this._constraints = e.getConstraints(), i && (this._constraints = i);
  }
  get id() {
    return this._mediaStreamTrack.id;
  }
  get dimensions() {
    if (this.kind !== E.Kind.Video)
      return;
    const {
      width: e,
      height: t
    } = this._mediaStreamTrack.getSettings();
    if (e && t)
      return {
        width: e,
        height: t
      };
  }
  get isUpstreamPaused() {
    return this._isUpstreamPaused;
  }
  get isUserProvided() {
    return this.providedByUser;
  }
  get mediaStreamTrack() {
    var e, t;
    return (t = (e = this.processor) === null || e === void 0 ? void 0 : e.processedTrack) !== null && t !== void 0 ? t : this._mediaStreamTrack;
  }
  get isLocal() {
    return !0;
  }
  /**
   * @internal
   * returns mediaStreamTrack settings of the capturing mediastreamtrack source - ignoring processors
   */
  getSourceTrackSettings() {
    return this._mediaStreamTrack.getSettings();
  }
  setMediaStreamTrack(e, t, i) {
    return m(this, void 0, void 0, function* () {
      var s;
      if (e === this._mediaStreamTrack && !t)
        return;
      this._mediaStreamTrack && (this.attachedElements.forEach((o) => {
        Oi(this._mediaStreamTrack, o);
      }), this.debouncedTrackMuteHandler.cancel("new-track"), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent)), this.mediaStream = new MediaStream([e]), e && (e.addEventListener("ended", this.handleEnded), e.addEventListener("mute", this.handleTrackMuteEvent), e.addEventListener("unmute", this.handleTrackUnmuteEvent), this._constraints = e.getConstraints());
      let r;
      if (this.processor && e) {
        if (this.log.debug("restarting processor", this.logContext), this.kind === "unknown")
          throw TypeError("cannot set processor on track of unknown kind");
        this.processorElement && (Ri(e, this.processorElement), this.processorElement.muted = !0), yield this.processor.restart({
          track: e,
          kind: this.kind,
          element: this.processorElement
        }), r = this.processor.processedTrack;
      }
      this.sender && ((s = this.sender.transport) === null || s === void 0 ? void 0 : s.state) !== "closed" && (yield this.sender.replaceTrack(r != null ? r : e)), !this.providedByUser && this._mediaStreamTrack !== e && this._mediaStreamTrack.stop(), this._mediaStreamTrack = e, e && (this._mediaStreamTrack.enabled = i ? !0 : !this.isMuted, yield this.resumeUpstream(), this.attachedElements.forEach((o) => {
        Ri(r != null ? r : e, o);
      }));
    });
  }
  waitForDimensions() {
    return m(this, arguments, void 0, function() {
      var e = this;
      let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : em;
      return (function* () {
        var i;
        if (e.kind === E.Kind.Audio)
          throw new Error("cannot get dimensions for audio tracks");
        ((i = nt()) === null || i === void 0 ? void 0 : i.os) === "iOS" && (yield ze(10));
        const s = Date.now();
        for (; Date.now() - s < t; ) {
          const r = e.dimensions;
          if (r)
            return r;
          yield ze(50);
        }
        throw new Ut("unable to get track dimensions after timeout");
      })();
    });
  }
  setDeviceId(e) {
    return m(this, void 0, void 0, function* () {
      return this._constraints.deviceId === e && this._mediaStreamTrack.getSettings().deviceId === ci(e) ? !0 : (this._constraints.deviceId = e, this.isMuted ? (this.pendingDeviceChange = !0, !0) : (yield this.restartTrack(), ci(e) === this._mediaStreamTrack.getSettings().deviceId));
    });
  }
  /**
   * @returns DeviceID of the device that is currently being used for this track
   */
  getDeviceId() {
    return m(this, arguments, void 0, function() {
      var e = this;
      let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
      return (function* () {
        if (e.source === E.Source.ScreenShare)
          return;
        const {
          deviceId: i,
          groupId: s
        } = e._mediaStreamTrack.getSettings(), r = e.kind === E.Kind.Audio ? "audioinput" : "videoinput";
        return t ? We.getInstance().normalizeDeviceId(r, i, s) : i;
      })();
    });
  }
  mute() {
    return m(this, void 0, void 0, function* () {
      return this.setTrackMuted(!0), this;
    });
  }
  unmute() {
    return m(this, void 0, void 0, function* () {
      return this.setTrackMuted(!1), this;
    });
  }
  replaceTrack(e, t) {
    return m(this, void 0, void 0, function* () {
      const i = yield this.trackChangeLock.lock();
      try {
        if (!this.sender)
          throw new Ut("unable to replace an unpublished track");
        let s, r;
        return typeof t == "boolean" ? s = t : t !== void 0 && (s = t.userProvidedTrack, r = t.stopProcessor), this.providedByUser = s != null ? s : !0, this.log.debug("replace MediaStreamTrack", this.logContext), yield this.setMediaStreamTrack(e), r && this.processor && (yield this.internalStopProcessor()), this;
      } finally {
        i();
      }
    });
  }
  restart(e, t) {
    return m(this, void 0, void 0, function* () {
      this.manuallyStopped = !1;
      const i = yield this.trackChangeLock.lock();
      try {
        e || (e = this._constraints);
        const {
          deviceId: s,
          facingMode: r
        } = e, o = _h(e, ["deviceId", "facingMode"]);
        this.log.debug("restarting track with constraints", Object.assign(Object.assign({}, this.logContext), {
          constraints: e
        }));
        const a = {
          audio: !1,
          video: !1
        };
        this.kind === E.Kind.Video ? a.video = s || r ? {
          deviceId: s,
          facingMode: r
        } : !0 : a.audio = s ? Object.assign({
          deviceId: s
        }, o) : !0, this.attachedElements.forEach((l) => {
          Oi(this.mediaStreamTrack, l);
        }), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.stop();
        const d = (yield navigator.mediaDevices.getUserMedia(a)).getTracks()[0];
        return this.kind === E.Kind.Video && (yield d.applyConstraints(o)), d.addEventListener("ended", this.handleEnded), this.log.debug("re-acquired MediaStreamTrack", this.logContext), yield this.setMediaStreamTrack(d, !1, t), this._constraints = e, this.pendingDeviceChange = !1, this.emit(U.Restarted, this), this.manuallyStopped && (this.log.warn("track was stopped during a restart, stopping restarted track", this.logContext), this.stop()), this;
      } finally {
        i();
      }
    });
  }
  setTrackMuted(e) {
    this.log.debug("setting ".concat(this.kind, " track ").concat(e ? "muted" : "unmuted"), this.logContext), !(this.isMuted === e && this._mediaStreamTrack.enabled !== e) && (this.isMuted = e, this._mediaStreamTrack.enabled = !e, this.emit(e ? U.Muted : U.Unmuted, this));
  }
  get needsReAcquisition() {
    return this._mediaStreamTrack.readyState !== "live" || this._mediaStreamTrack.muted || !this._mediaStreamTrack.enabled || this.reacquireTrack;
  }
  handleAppVisibilityChanged() {
    const e = Object.create(null, {
      handleAppVisibilityChanged: {
        get: () => super.handleAppVisibilityChanged
      }
    });
    return m(this, void 0, void 0, function* () {
      yield e.handleAppVisibilityChanged.call(this), Md() && (this.log.debug("visibility changed, is in Background: ".concat(this.isInBackground), this.logContext), !this.isInBackground && this.needsReAcquisition && !this.isUserProvided && !this.isMuted && (this.log.debug("track needs to be reacquired, restarting ".concat(this.source), this.logContext), yield this.restart(), this.reacquireTrack = !1));
    });
  }
  stop() {
    var e;
    this.manuallyStopped = !0, super.stop(), this._mediaStreamTrack.removeEventListener("ended", this.handleEnded), this._mediaStreamTrack.removeEventListener("mute", this.handleTrackMuteEvent), this._mediaStreamTrack.removeEventListener("unmute", this.handleTrackUnmuteEvent), (e = this.processor) === null || e === void 0 || e.destroy(), this.processor = void 0;
  }
  /**
   * pauses publishing to the server without disabling the local MediaStreamTrack
   * this is used to display a user's own video locally while pausing publishing to
   * the server.
   * this API is unsupported on Safari < 12 due to a bug
   **/
  pauseUpstream() {
    return m(this, void 0, void 0, function* () {
      var e;
      const t = yield this.pauseUpstreamLock.lock();
      try {
        if (this._isUpstreamPaused === !0)
          return;
        if (!this.sender) {
          this.log.warn("unable to pause upstream for an unpublished track", this.logContext);
          return;
        }
        this._isUpstreamPaused = !0, this.emit(U.UpstreamPaused, this);
        const i = nt();
        if ((i == null ? void 0 : i.name) === "Safari" && It(i.version, "12.0") < 0)
          throw new Hr("pauseUpstream is not supported on Safari < 12.");
        ((e = this.sender.transport) === null || e === void 0 ? void 0 : e.state) !== "closed" && (yield this.sender.replaceTrack(null));
      } finally {
        t();
      }
    });
  }
  resumeUpstream() {
    return m(this, void 0, void 0, function* () {
      var e;
      const t = yield this.pauseUpstreamLock.lock();
      try {
        if (this._isUpstreamPaused === !1)
          return;
        if (!this.sender) {
          this.log.warn("unable to resume upstream for an unpublished track", this.logContext);
          return;
        }
        this._isUpstreamPaused = !1, this.emit(U.UpstreamResumed, this), ((e = this.sender.transport) === null || e === void 0 ? void 0 : e.state) !== "closed" && (yield this.sender.replaceTrack(this.mediaStreamTrack));
      } finally {
        t();
      }
    });
  }
  /**
   * Gets the RTCStatsReport for the LocalTrack's underlying RTCRtpSender
   * See https://developer.mozilla.org/en-US/docs/Web/API/RTCStatsReport
   *
   * @returns Promise<RTCStatsReport> | undefined
   */
  getRTCStatsReport() {
    return m(this, void 0, void 0, function* () {
      var e;
      return !((e = this.sender) === null || e === void 0) && e.getStats ? yield this.sender.getStats() : void 0;
    });
  }
  /**
   * Sets a processor on this track.
   * See https://github.com/livekit/track-processors-js for example usage
   *
   * @param processor
   * @param showProcessedStreamLocally
   * @returns
   */
  setProcessor(e) {
    return m(this, arguments, void 0, function(t) {
      var i = this;
      let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
      return (function* () {
        var r;
        const o = yield i.trackChangeLock.lock();
        try {
          i.log.debug("setting up processor", i.logContext);
          const a = document.createElement(i.kind), c = {
            kind: i.kind,
            track: i._mediaStreamTrack,
            element: a,
            audioContext: i.audioContext
          };
          if (yield t.init(c), i.log.debug("processor initialized", i.logContext), i.processor && (yield i.internalStopProcessor()), i.kind === "unknown")
            throw TypeError("cannot set processor on track of unknown kind");
          if (Ri(i._mediaStreamTrack, a), a.muted = !0, a.play().catch((d) => {
            d instanceof DOMException && d.name === "AbortError" ? (i.log.warn("failed to play processor element, retrying", Object.assign(Object.assign({}, i.logContext), {
              error: d
            })), setTimeout(() => {
              a.play().catch((l) => {
                i.log.error("failed to play processor element", Object.assign(Object.assign({}, i.logContext), {
                  err: l
                }));
              });
            }, 100)) : i.log.error("failed to play processor element", Object.assign(Object.assign({}, i.logContext), {
              error: d
            }));
          }), i.processor = t, i.processorElement = a, i.processor.processedTrack) {
            for (const d of i.attachedElements)
              d !== i.processorElement && s && (Oi(i._mediaStreamTrack, d), Ri(i.processor.processedTrack, d));
            yield (r = i.sender) === null || r === void 0 ? void 0 : r.replaceTrack(i.processor.processedTrack);
          }
          i.emit(U.TrackProcessorUpdate, i.processor);
        } finally {
          o();
        }
      })();
    });
  }
  getProcessor() {
    return this.processor;
  }
  /**
   * Stops the track processor
   * See https://github.com/livekit/track-processors-js for example usage
   *
   */
  stopProcessor() {
    return m(this, arguments, void 0, function() {
      var e = this;
      let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
      return (function* () {
        const i = yield e.trackChangeLock.lock();
        try {
          yield e.internalStopProcessor(t);
        } finally {
          i();
        }
      })();
    });
  }
  /**
   * @internal
   * This method assumes the caller has acquired a trackChangeLock already.
   * The public facing method for stopping the processor is `stopProcessor` and it wraps this method in the trackChangeLock.
   */
  internalStopProcessor() {
    return m(this, arguments, void 0, function() {
      var e = this;
      let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
      return (function* () {
        var i, s;
        e.processor && (e.log.debug("stopping processor", e.logContext), (i = e.processor.processedTrack) === null || i === void 0 || i.stop(), yield e.processor.destroy(), e.processor = void 0, t || ((s = e.processorElement) === null || s === void 0 || s.remove(), e.processorElement = void 0), yield e._mediaStreamTrack.applyConstraints(e._constraints), yield e.setMediaStreamTrack(e._mediaStreamTrack, !0), e.emit(U.TrackProcessorUpdate));
      })();
    });
  }
  /** @internal */
  startPreConnectBuffer() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 100;
    if (!Zp()) {
      this.log.warn("MediaRecorder is not available, cannot start preconnect buffer", this.logContext);
      return;
    }
    if (this.localTrackRecorder) {
      this.log.warn("preconnect buffer already started");
      return;
    } else {
      let t = "audio/webm;codecs=opus";
      MediaRecorder.isTypeSupported(t) || (t = "video/mp4"), this.localTrackRecorder = new Xp(this, {
        mimeType: t
      });
    }
    this.localTrackRecorder.start(e), this.autoStopPreConnectBuffer = setTimeout(() => {
      this.log.warn("preconnect buffer timed out, stopping recording automatically", this.logContext), this.stopPreConnectBuffer();
    }, tm);
  }
  /** @internal */
  stopPreConnectBuffer() {
    clearTimeout(this.autoStopPreConnectBuffer), this.localTrackRecorder && (this.localTrackRecorder.stop(), this.localTrackRecorder = void 0);
  }
  /** @internal */
  getPreConnectBuffer() {
    var e;
    return (e = this.localTrackRecorder) === null || e === void 0 ? void 0 : e.byteStream;
  }
  getPreConnectBufferMimeType() {
    var e;
    return (e = this.localTrackRecorder) === null || e === void 0 ? void 0 : e.mimeType;
  }
}
class Gn extends Vd {
  /**
   * boolean indicating whether enhanced noise cancellation is currently being used on this track
   */
  get enhancedNoiseCancellation() {
    return this.isKrispNoiseFilterEnabled;
  }
  /**
   *
   * @param mediaTrack
   * @param constraints MediaTrackConstraints that are being used when restarting or reacquiring tracks
   * @param userProvidedTrack Signals to the SDK whether or not the mediaTrack should be managed (i.e. released and reacquired) internally by the SDK
   */
  constructor(e, t) {
    let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, s = arguments.length > 3 ? arguments[3] : void 0, r = arguments.length > 4 ? arguments[4] : void 0;
    super(e, E.Kind.Audio, t, i, r), this.stopOnMute = !1, this.isKrispNoiseFilterEnabled = !1, this.monitorSender = () => m(this, void 0, void 0, function* () {
      if (!this.sender) {
        this._currentBitrate = 0;
        return;
      }
      let o;
      try {
        o = yield this.getSenderStats();
      } catch (a) {
        this.log.error("could not get audio sender stats", Object.assign(Object.assign({}, this.logContext), {
          error: a
        }));
        return;
      }
      o && this.prevStats && (this._currentBitrate = ds(o, this.prevStats)), this.prevStats = o;
    }), this.handleKrispNoiseFilterEnable = () => {
      this.isKrispNoiseFilterEnabled = !0, this.log.debug("Krisp noise filter enabled", this.logContext), this.emit(U.AudioTrackFeatureUpdate, this, He.TF_ENHANCED_NOISE_CANCELLATION, !0);
    }, this.handleKrispNoiseFilterDisable = () => {
      this.isKrispNoiseFilterEnabled = !1, this.log.debug("Krisp noise filter disabled", this.logContext), this.emit(U.AudioTrackFeatureUpdate, this, He.TF_ENHANCED_NOISE_CANCELLATION, !1);
    }, this.audioContext = s, this.checkForSilence();
  }
  mute() {
    const e = Object.create(null, {
      mute: {
        get: () => super.mute
      }
    });
    return m(this, void 0, void 0, function* () {
      const t = yield this.muteLock.lock();
      try {
        return this.isMuted ? (this.log.debug("Track already muted", this.logContext), this) : (this.source === E.Source.Microphone && this.stopOnMute && !this.isUserProvided && (this.log.debug("stopping mic track", this.logContext), this._mediaStreamTrack.stop()), yield e.mute.call(this), this);
      } finally {
        t();
      }
    });
  }
  unmute() {
    const e = Object.create(null, {
      unmute: {
        get: () => super.unmute
      }
    });
    return m(this, void 0, void 0, function* () {
      const t = yield this.muteLock.lock();
      try {
        return this.isMuted ? (this.source === E.Source.Microphone && (this.stopOnMute || this._mediaStreamTrack.readyState === "ended" || this.pendingDeviceChange) && !this.isUserProvided && (this.log.debug("reacquiring mic track", this.logContext), yield this.restart(void 0, !0)), yield e.unmute.call(this), this) : (this.log.debug("Track already unmuted", this.logContext), this);
      } finally {
        t();
      }
    });
  }
  restartTrack(e) {
    return m(this, void 0, void 0, function* () {
      let t;
      if (e) {
        const i = $r({
          audio: e
        });
        typeof i.audio != "boolean" && (t = i.audio);
      }
      yield this.restart(t);
    });
  }
  restart(e, t) {
    const i = Object.create(null, {
      restart: {
        get: () => super.restart
      }
    });
    return m(this, void 0, void 0, function* () {
      const s = yield i.restart.call(this, e, t);
      return this.checkForSilence(), s;
    });
  }
  /* @internal */
  startMonitor() {
    it() && (this.monitorInterval || (this.monitorInterval = setInterval(() => {
      this.monitorSender();
    }, Zr)));
  }
  setProcessor(e) {
    return m(this, void 0, void 0, function* () {
      var t;
      const i = yield this.trackChangeLock.lock();
      try {
        if (!Rt() && !this.audioContext)
          throw Error("Audio context needs to be set on LocalAudioTrack in order to enable processors");
        this.processor && (yield this.internalStopProcessor());
        const s = {
          kind: this.kind,
          track: this._mediaStreamTrack,
          // RN won't have or use AudioContext
          audioContext: this.audioContext
        };
        this.log.debug("setting up audio processor ".concat(e.name), this.logContext), yield e.init(s), this.processor = e, this.processor.processedTrack && (yield (t = this.sender) === null || t === void 0 ? void 0 : t.replaceTrack(this.processor.processedTrack), this.processor.processedTrack.addEventListener("enable-lk-krisp-noise-filter", this.handleKrispNoiseFilterEnable), this.processor.processedTrack.addEventListener("disable-lk-krisp-noise-filter", this.handleKrispNoiseFilterDisable)), this.emit(U.TrackProcessorUpdate, this.processor);
      } finally {
        i();
      }
    });
  }
  /**
   * @internal
   * @experimental
   */
  setAudioContext(e) {
    this.audioContext = e;
  }
  getSenderStats() {
    return m(this, void 0, void 0, function* () {
      var e;
      if (!(!((e = this.sender) === null || e === void 0) && e.getStats))
        return;
      const t = yield this.sender.getStats();
      let i;
      return t.forEach((s) => {
        s.type === "outbound-rtp" && (i = {
          type: "audio",
          streamId: s.id,
          packetsSent: s.packetsSent,
          packetsLost: s.packetsLost,
          bytesSent: s.bytesSent,
          timestamp: s.timestamp,
          roundTripTime: s.roundTripTime,
          jitter: s.jitter
        });
      }), i;
    });
  }
  checkForSilence() {
    return m(this, void 0, void 0, function* () {
      const e = yield Id(this);
      return e && (this.isMuted || this.log.debug("silence detected on local audio track", this.logContext), this.emit(U.AudioSilenceDetected)), e;
    });
  }
}
function im(n, e, t) {
  switch (n.kind) {
    case "audio":
      return new Gn(n, e, !1, void 0, t);
    case "video":
      return new Jn(n, e, !1, t);
    default:
      throw new Ut("unsupported track type: ".concat(n.kind));
  }
}
const nm = Object.values(ln), sm = Object.values(ar), rm = Object.values(Wr), am = [ln.h180, ln.h360], om = [ar.h180, ar.h360], cm = (n) => [{
  scaleResolutionDownBy: 2,
  fps: n.encoding.maxFramerate
}].map((t) => {
  var i, s;
  return new we(Math.floor(n.width / t.scaleResolutionDownBy), Math.floor(n.height / t.scaleResolutionDownBy), Math.max(15e4, Math.floor(n.encoding.maxBitrate / (Math.pow(t.scaleResolutionDownBy, 2) * (((i = n.encoding.maxFramerate) !== null && i !== void 0 ? i : 30) / ((s = t.fps) !== null && s !== void 0 ? s : 30))))), t.fps, n.encoding.priority);
}), fr = ["q", "h", "f"];
function gr(n, e, t, i) {
  var s, r;
  let o = i == null ? void 0 : i.videoEncoding;
  n && (o = i == null ? void 0 : i.screenShareEncoding);
  const a = i == null ? void 0 : i.simulcast, c = i == null ? void 0 : i.scalabilityMode, d = i == null ? void 0 : i.videoCodec;
  if (!o && !a && !c || !e || !t)
    return [{}];
  o || (o = lm(n, e, t, d), se.debug("using video encoding", o));
  const l = o.maxFramerate, u = new we(e, t, o.maxBitrate, o.maxFramerate, o.priority);
  if (c && bt(d)) {
    const b = new Bd(c), v = [];
    if (b.spatial > 3)
      throw new Error("unsupported scalabilityMode: ".concat(c));
    const C = nt();
    if (un() || // Even tho RN runs M114, it does not produce SVC layers when a single encoding
    // is provided. So we'll use the legacy SVC specification for now.
    // TODO: when we upstream libwebrtc, this will need additional verification
    Rt() || (C == null ? void 0 : C.name) === "Chrome" && It(C == null ? void 0 : C.version, "113") < 0) {
      const T = b.suffix == "h" ? 2 : 3, P = rp(C);
      for (let R = 0; R < b.spatial; R += 1)
        v.push({
          rid: fr[2 - R],
          maxBitrate: o.maxBitrate / Math.pow(T, R),
          maxFramerate: u.encoding.maxFramerate,
          scaleResolutionDownBy: P ? Math.pow(2, R) : void 0
        });
      v[0].scalabilityMode = c;
    } else
      v.push({
        maxBitrate: o.maxBitrate,
        maxFramerate: u.encoding.maxFramerate,
        /* @ts-ignore */
        scalabilityMode: c
      });
    return u.encoding.priority && (v[0].priority = u.encoding.priority, v[0].networkPriority = u.encoding.priority), se.debug("using svc encoding", {
      encodings: v
    }), v;
  }
  if (!a)
    return [o];
  let h = [];
  n ? h = (s = yo(i == null ? void 0 : i.screenShareSimulcastLayers)) !== null && s !== void 0 ? s : bo(n, u) : h = (r = yo(i == null ? void 0 : i.videoSimulcastLayers)) !== null && r !== void 0 ? r : bo(n, u);
  let p;
  if (h.length > 0) {
    const b = h[0];
    h.length > 1 && ([, p] = h);
    const v = Math.max(e, t);
    if (v >= 960 && p)
      return Ms(e, t, [b, p, u], l);
    if (v >= 480)
      return Ms(e, t, [b, u], l);
  }
  return Ms(e, t, [u]);
}
function dm(n, e, t) {
  var i, s, r, o;
  if (!t.backupCodec || t.backupCodec === !0 || t.backupCodec.codec === t.videoCodec)
    return;
  e !== t.backupCodec.codec && se.warn("requested a different codec than specified as backup", {
    serverRequested: e,
    backup: t.backupCodec.codec
  }), t.videoCodec = e, t.videoEncoding = t.backupCodec.encoding;
  const a = n.mediaStreamTrack.getSettings(), c = (i = a.width) !== null && i !== void 0 ? i : (s = n.dimensions) === null || s === void 0 ? void 0 : s.width, d = (r = a.height) !== null && r !== void 0 ? r : (o = n.dimensions) === null || o === void 0 ? void 0 : o.height;
  return n.source === E.Source.ScreenShare && t.simulcast && (t.simulcast = !1), gr(n.source === E.Source.ScreenShare, c, d, t);
}
function lm(n, e, t, i) {
  const s = um(n, e, t);
  let {
    encoding: r
  } = s[0];
  const o = Math.max(e, t);
  for (let a = 0; a < s.length; a += 1) {
    const c = s[a];
    if (r = c.encoding, c.width >= o)
      break;
  }
  if (i)
    switch (i) {
      case "av1":
      case "h265":
        r = Object.assign({}, r), r.maxBitrate = r.maxBitrate * 0.7;
        break;
      case "vp9":
        r = Object.assign({}, r), r.maxBitrate = r.maxBitrate * 0.85;
        break;
    }
  return r;
}
function um(n, e, t) {
  if (n)
    return rm;
  const i = e > t ? e / t : t / e;
  return Math.abs(i - 16 / 9) < Math.abs(i - 4 / 3) ? nm : sm;
}
function bo(n, e) {
  if (n)
    return cm(e);
  const {
    width: t,
    height: i
  } = e, s = t > i ? t / i : i / t;
  return Math.abs(s - 16 / 9) < Math.abs(s - 4 / 3) ? am : om;
}
function Ms(n, e, t, i) {
  const s = [];
  if (t.forEach((r, o) => {
    if (o >= fr.length)
      return;
    const a = Math.min(n, e), d = {
      rid: fr[o],
      scaleResolutionDownBy: Math.max(1, a / Math.min(r.width, r.height)),
      maxBitrate: r.encoding.maxBitrate
    }, l = i && r.encoding.maxFramerate ? Math.min(i, r.encoding.maxFramerate) : r.encoding.maxFramerate;
    l && (d.maxFramerate = l);
    const u = ui() || o === 0;
    r.encoding.priority && u && (d.priority = r.encoding.priority, d.networkPriority = r.encoding.priority), s.push(d);
  }), Rt() && Od() === "ios") {
    let r;
    s.forEach((a) => {
      r ? a.maxFramerate && a.maxFramerate > r && (r = a.maxFramerate) : r = a.maxFramerate;
    });
    let o = !0;
    s.forEach((a) => {
      var c;
      a.maxFramerate != r && (o && (o = !1, se.info("Simulcast on iOS React-Native requires all encodings to share the same framerate.")), se.info('Setting framerate of encoding "'.concat((c = a.rid) !== null && c !== void 0 ? c : "", '" to ').concat(r)), a.maxFramerate = r);
    });
  }
  return s;
}
function yo(n) {
  if (n)
    return n.sort((e, t) => {
      const {
        encoding: i
      } = e, {
        encoding: s
      } = t;
      return i.maxBitrate > s.maxBitrate ? 1 : i.maxBitrate < s.maxBitrate ? -1 : i.maxBitrate === s.maxBitrate && i.maxFramerate && s.maxFramerate ? i.maxFramerate > s.maxFramerate ? 1 : -1 : 0;
    });
}
class Bd {
  constructor(e) {
    const t = e.match(/^L(\d)T(\d)(h|_KEY|_KEY_SHIFT){0,1}$/);
    if (!t)
      throw new Error("invalid scalability mode");
    if (this.spatial = parseInt(t[1]), this.temporal = parseInt(t[2]), t.length > 3)
      switch (t[3]) {
        case "h":
        case "_KEY":
        case "_KEY_SHIFT":
          this.suffix = t[3];
      }
  }
  toString() {
    var e;
    return "L".concat(this.spatial, "T").concat(this.temporal).concat((e = this.suffix) !== null && e !== void 0 ? e : "");
  }
}
function hm(n) {
  return n.source === E.Source.ScreenShare || n.constraints.height && ci(n.constraints.height) >= 1080 ? "maintain-resolution" : "balanced";
}
const pm = 5e3;
class Jn extends Vd {
  get sender() {
    return this._sender;
  }
  set sender(e) {
    this._sender = e, this.degradationPreference && this.setDegradationPreference(this.degradationPreference);
  }
  /**
   *
   * @param mediaTrack
   * @param constraints MediaTrackConstraints that are being used when restarting or reacquiring tracks
   * @param userProvidedTrack Signals to the SDK whether or not the mediaTrack should be managed (i.e. released and reacquired) internally by the SDK
   */
  constructor(e, t) {
    let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, s = arguments.length > 3 ? arguments[3] : void 0;
    super(e, E.Kind.Video, t, i, s), this.simulcastCodecs = /* @__PURE__ */ new Map(), this.degradationPreference = "balanced", this.isCpuConstrained = !1, this.optimizeForPerformance = !1, this.monitorSender = () => m(this, void 0, void 0, function* () {
      if (!this.sender) {
        this._currentBitrate = 0;
        return;
      }
      let r;
      try {
        r = yield this.getSenderStats();
      } catch (c) {
        this.log.error("could not get video sender stats", Object.assign(Object.assign({}, this.logContext), {
          error: c
        }));
        return;
      }
      const o = new Map(r.map((c) => [c.rid, c])), a = r.some((c) => c.qualityLimitationReason === "cpu");
      if (a !== this.isCpuConstrained && (this.isCpuConstrained = a, this.isCpuConstrained && this.emit(U.CpuConstrained)), this.prevStats) {
        let c = 0;
        o.forEach((d, l) => {
          var u;
          const h = (u = this.prevStats) === null || u === void 0 ? void 0 : u.get(l);
          c += ds(d, h);
        }), this._currentBitrate = c;
      }
      this.prevStats = o;
    }), this.senderLock = new Ze();
  }
  get isSimulcast() {
    return !!(this.sender && this.sender.getParameters().encodings.length > 1);
  }
  /* @internal */
  startMonitor(e) {
    var t;
    if (this.signalClient = e, !it())
      return;
    const i = (t = this.sender) === null || t === void 0 ? void 0 : t.getParameters();
    i && (this.encodings = i.encodings), !this.monitorInterval && (this.monitorInterval = setInterval(() => {
      this.monitorSender();
    }, Zr));
  }
  stop() {
    this._mediaStreamTrack.getConstraints(), this.simulcastCodecs.forEach((e) => {
      e.mediaStreamTrack.stop();
    }), super.stop();
  }
  pauseUpstream() {
    const e = Object.create(null, {
      pauseUpstream: {
        get: () => super.pauseUpstream
      }
    });
    return m(this, void 0, void 0, function* () {
      var t, i, s, r, o;
      yield e.pauseUpstream.call(this);
      try {
        for (var a = !0, c = Nt(this.simulcastCodecs.values()), d; d = yield c.next(), t = d.done, !t; a = !0)
          r = d.value, a = !1, yield (o = r.sender) === null || o === void 0 ? void 0 : o.replaceTrack(null);
      } catch (l) {
        i = {
          error: l
        };
      } finally {
        try {
          !a && !t && (s = c.return) && (yield s.call(c));
        } finally {
          if (i) throw i.error;
        }
      }
    });
  }
  resumeUpstream() {
    const e = Object.create(null, {
      resumeUpstream: {
        get: () => super.resumeUpstream
      }
    });
    return m(this, void 0, void 0, function* () {
      var t, i, s, r, o;
      yield e.resumeUpstream.call(this);
      try {
        for (var a = !0, c = Nt(this.simulcastCodecs.values()), d; d = yield c.next(), t = d.done, !t; a = !0) {
          r = d.value, a = !1;
          const l = r;
          yield (o = l.sender) === null || o === void 0 ? void 0 : o.replaceTrack(l.mediaStreamTrack);
        }
      } catch (l) {
        i = {
          error: l
        };
      } finally {
        try {
          !a && !t && (s = c.return) && (yield s.call(c));
        } finally {
          if (i) throw i.error;
        }
      }
    });
  }
  mute() {
    const e = Object.create(null, {
      mute: {
        get: () => super.mute
      }
    });
    return m(this, void 0, void 0, function* () {
      const t = yield this.muteLock.lock();
      try {
        return this.isMuted ? (this.log.debug("Track already muted", this.logContext), this) : (this.source === E.Source.Camera && !this.isUserProvided && (this.log.debug("stopping camera track", this.logContext), this._mediaStreamTrack.stop()), yield e.mute.call(this), this);
      } finally {
        t();
      }
    });
  }
  unmute() {
    const e = Object.create(null, {
      unmute: {
        get: () => super.unmute
      }
    });
    return m(this, void 0, void 0, function* () {
      const t = yield this.muteLock.lock();
      try {
        return this.isMuted ? (this.source === E.Source.Camera && !this.isUserProvided && (this.log.debug("reacquiring camera track", this.logContext), yield this.restart(void 0, !0)), yield e.unmute.call(this), this) : (this.log.debug("Track already unmuted", this.logContext), this);
      } finally {
        t();
      }
    });
  }
  setTrackMuted(e) {
    super.setTrackMuted(e);
    for (const t of this.simulcastCodecs.values())
      t.mediaStreamTrack.enabled = !e;
  }
  getSenderStats() {
    return m(this, void 0, void 0, function* () {
      var e;
      if (!(!((e = this.sender) === null || e === void 0) && e.getStats))
        return [];
      const t = [], i = yield this.sender.getStats();
      return i.forEach((s) => {
        var r;
        if (s.type === "outbound-rtp") {
          const o = {
            type: "video",
            streamId: s.id,
            frameHeight: s.frameHeight,
            frameWidth: s.frameWidth,
            framesPerSecond: s.framesPerSecond,
            framesSent: s.framesSent,
            firCount: s.firCount,
            pliCount: s.pliCount,
            nackCount: s.nackCount,
            packetsSent: s.packetsSent,
            bytesSent: s.bytesSent,
            qualityLimitationReason: s.qualityLimitationReason,
            qualityLimitationDurations: s.qualityLimitationDurations,
            qualityLimitationResolutionChanges: s.qualityLimitationResolutionChanges,
            rid: (r = s.rid) !== null && r !== void 0 ? r : s.id,
            retransmittedPacketsSent: s.retransmittedPacketsSent,
            targetBitrate: s.targetBitrate,
            timestamp: s.timestamp
          }, a = i.get(s.remoteId);
          a && (o.jitter = a.jitter, o.packetsLost = a.packetsLost, o.roundTripTime = a.roundTripTime), t.push(o);
        }
      }), t.sort((s, r) => {
        var o, a;
        return ((o = r.frameWidth) !== null && o !== void 0 ? o : 0) - ((a = s.frameWidth) !== null && a !== void 0 ? a : 0);
      }), t;
    });
  }
  setPublishingQuality(e) {
    const t = [];
    for (let i = rt.LOW; i <= rt.HIGH; i += 1)
      t.push(new Fr({
        quality: i,
        enabled: i <= e
      }));
    this.log.debug("setting publishing quality. max quality ".concat(e), this.logContext), this.setPublishingLayers(bt(this.codec), t);
  }
  restartTrack(e) {
    return m(this, void 0, void 0, function* () {
      var t, i, s, r, o;
      let a;
      if (e) {
        const u = $r({
          video: e
        });
        typeof u.video != "boolean" && (a = u.video);
      }
      yield this.restart(a), this.isCpuConstrained = !1;
      try {
        for (var c = !0, d = Nt(this.simulcastCodecs.values()), l; l = yield d.next(), t = l.done, !t; c = !0) {
          r = l.value, c = !1;
          const u = r;
          u.sender && ((o = u.sender.transport) === null || o === void 0 ? void 0 : o.state) !== "closed" && (u.mediaStreamTrack = this.mediaStreamTrack.clone(), yield u.sender.replaceTrack(u.mediaStreamTrack));
        }
      } catch (u) {
        i = {
          error: u
        };
      } finally {
        try {
          !c && !t && (s = d.return) && (yield s.call(d));
        } finally {
          if (i) throw i.error;
        }
      }
    });
  }
  setProcessor(e) {
    const t = Object.create(null, {
      setProcessor: {
        get: () => super.setProcessor
      }
    });
    return m(this, arguments, void 0, function(i) {
      var s = this;
      let r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
      return (function* () {
        var o, a, c, d, l, u;
        if (yield t.setProcessor.call(s, i, r), !((l = s.processor) === null || l === void 0) && l.processedTrack)
          try {
            for (var h = !0, p = Nt(s.simulcastCodecs.values()), b; b = yield p.next(), o = b.done, !o; h = !0)
              d = b.value, h = !1, yield (u = d.sender) === null || u === void 0 ? void 0 : u.replaceTrack(s.processor.processedTrack);
          } catch (v) {
            a = {
              error: v
            };
          } finally {
            try {
              !h && !o && (c = p.return) && (yield c.call(p));
            } finally {
              if (a) throw a.error;
            }
          }
      })();
    });
  }
  setDegradationPreference(e) {
    return m(this, void 0, void 0, function* () {
      if (this.degradationPreference = e, this.sender)
        try {
          this.log.debug("setting degradationPreference to ".concat(e), this.logContext);
          const t = this.sender.getParameters();
          t.degradationPreference = e, this.sender.setParameters(t);
        } catch (t) {
          this.log.warn("failed to set degradationPreference", Object.assign({
            error: t
          }, this.logContext));
        }
    });
  }
  addSimulcastTrack(e, t) {
    if (this.simulcastCodecs.has(e)) {
      this.log.error("".concat(e, " already added, skipping adding simulcast codec"), this.logContext);
      return;
    }
    const i = {
      codec: e,
      mediaStreamTrack: this.mediaStreamTrack.clone(),
      sender: void 0,
      encodings: t
    };
    return this.simulcastCodecs.set(e, i), i;
  }
  setSimulcastTrackSender(e, t) {
    const i = this.simulcastCodecs.get(e);
    i && (i.sender = t, setTimeout(() => {
      this.subscribedCodecs && this.setPublishingCodecs(this.subscribedCodecs);
    }, pm));
  }
  /**
   * @internal
   * Sets codecs that should be publishing, returns new codecs that have not yet
   * been published
   */
  setPublishingCodecs(e) {
    return m(this, void 0, void 0, function* () {
      var t, i, s, r, o, a, c;
      if (this.log.debug("setting publishing codecs", Object.assign(Object.assign({}, this.logContext), {
        codecs: e,
        currentCodec: this.codec
      })), !this.codec && e.length > 0)
        return yield this.setPublishingLayers(bt(e[0].codec), e[0].qualities), [];
      this.subscribedCodecs = e;
      const d = [];
      try {
        for (t = !0, i = Nt(e); s = yield i.next(), r = s.done, !r; t = !0) {
          c = s.value, t = !1;
          const l = c;
          if (!this.codec || this.codec === l.codec)
            yield this.setPublishingLayers(bt(l.codec), l.qualities);
          else {
            const u = this.simulcastCodecs.get(l.codec);
            if (this.log.debug("try setPublishingCodec for ".concat(l.codec), Object.assign(Object.assign({}, this.logContext), {
              simulcastCodecInfo: u
            })), !u || !u.sender) {
              for (const h of l.qualities)
                if (h.enabled) {
                  d.push(l.codec);
                  break;
                }
            } else u.encodings && (this.log.debug("try setPublishingLayersForSender ".concat(l.codec), this.logContext), yield So(u.sender, u.encodings, l.qualities, this.senderLock, bt(l.codec), this.log, this.logContext));
          }
        }
      } catch (l) {
        o = {
          error: l
        };
      } finally {
        try {
          !t && !r && (a = i.return) && (yield a.call(i));
        } finally {
          if (o) throw o.error;
        }
      }
      return d;
    });
  }
  /**
   * @internal
   * Sets layers that should be publishing
   */
  setPublishingLayers(e, t) {
    return m(this, void 0, void 0, function* () {
      if (this.optimizeForPerformance) {
        this.log.info("skipping setPublishingLayers due to optimized publishing performance", Object.assign(Object.assign({}, this.logContext), {
          qualities: t
        }));
        return;
      }
      this.log.debug("setting publishing layers", Object.assign(Object.assign({}, this.logContext), {
        qualities: t
      })), !(!this.sender || !this.encodings) && (yield So(this.sender, this.encodings, t, this.senderLock, e, this.log, this.logContext));
    });
  }
  /**
   * Designed for lower powered devices, reduces video publishing quality and disables simulcast.
   * @experimental
   */
  prioritizePerformance() {
    return m(this, void 0, void 0, function* () {
      if (!this.sender)
        throw new Error("sender not found");
      const e = yield this.senderLock.lock();
      try {
        this.optimizeForPerformance = !0;
        const t = this.sender.getParameters();
        t.encodings = t.encodings.map((i, s) => {
          var r;
          return Object.assign(Object.assign({}, i), {
            active: s === 0,
            scaleResolutionDownBy: Math.max(1, Math.ceil(((r = this.mediaStreamTrack.getSettings().height) !== null && r !== void 0 ? r : 360) / 360)),
            scalabilityMode: s === 0 && bt(this.codec) ? "L1T3" : void 0,
            maxFramerate: s === 0 ? 15 : 0,
            maxBitrate: s === 0 ? i.maxBitrate : 0
          });
        }), this.log.debug("setting performance optimised encodings", Object.assign(Object.assign({}, this.logContext), {
          encodings: t.encodings
        })), this.encodings = t.encodings, yield this.sender.setParameters(t);
      } catch (t) {
        this.log.error("failed to set performance optimised encodings", Object.assign(Object.assign({}, this.logContext), {
          error: t
        })), this.optimizeForPerformance = !1;
      } finally {
        e();
      }
    });
  }
  handleAppVisibilityChanged() {
    const e = Object.create(null, {
      handleAppVisibilityChanged: {
        get: () => super.handleAppVisibilityChanged
      }
    });
    return m(this, void 0, void 0, function* () {
      yield e.handleAppVisibilityChanged.call(this), Md() && this.isInBackground && this.source === E.Source.Camera && (this._mediaStreamTrack.enabled = !1);
    });
  }
}
function So(n, e, t, i, s, r, o) {
  return m(this, void 0, void 0, function* () {
    const a = yield i.lock();
    r.debug("setPublishingLayersForSender", Object.assign(Object.assign({}, o), {
      sender: n,
      qualities: t,
      senderEncodings: e
    }));
    try {
      const c = n.getParameters(), {
        encodings: d
      } = c;
      if (!d)
        return;
      if (d.length !== e.length) {
        r.warn("cannot set publishing layers, encodings mismatch", Object.assign(Object.assign({}, o), {
          encodings: d,
          senderEncodings: e
        }));
        return;
      }
      let l = !1;
      !1 && d[0].scalabilityMode || (s && t.some((p) => p.enabled) && t.forEach((p) => p.enabled = !0), d.forEach((h, p) => {
        var b;
        let v = (b = h.rid) !== null && b !== void 0 ? b : "";
        v === "" && (v = "q");
        const C = jd(v), T = t.find((P) => P.quality === C);
        T && h.active !== T.enabled && (l = !0, h.active = T.enabled, r.debug("setting layer ".concat(T.quality, " to ").concat(h.active ? "enabled" : "disabled"), o), ui() && (T.enabled ? (h.scaleResolutionDownBy = e[p].scaleResolutionDownBy, h.maxBitrate = e[p].maxBitrate, h.maxFrameRate = e[p].maxFrameRate) : (h.scaleResolutionDownBy = 4, h.maxBitrate = 10, h.maxFrameRate = 2)));
      })), l && (c.encodings = d, r.debug("setting encodings", Object.assign(Object.assign({}, o), {
        encodings: c.encodings
      })), yield n.setParameters(c));
    } finally {
      a();
    }
  });
}
function jd(n) {
  switch (n) {
    case "f":
      return rt.HIGH;
    case "h":
      return rt.MEDIUM;
    case "q":
      return rt.LOW;
    default:
      return rt.HIGH;
  }
}
function ko(n, e, t, i) {
  if (!t)
    return [new Kt({
      quality: rt.HIGH,
      width: n,
      height: e,
      bitrate: 0,
      ssrc: 0
    })];
  if (i) {
    const s = t[0].scalabilityMode, r = new Bd(s), o = [], a = r.suffix == "h" ? 1.5 : 2, c = r.suffix == "h" ? 2 : 3;
    for (let d = 0; d < r.spatial; d += 1)
      o.push(new Kt({
        quality: Math.min(rt.HIGH, r.spatial - 1) - d,
        width: Math.ceil(n / Math.pow(a, d)),
        height: Math.ceil(e / Math.pow(a, d)),
        bitrate: t[0].maxBitrate ? Math.ceil(t[0].maxBitrate / Math.pow(c, d)) : 0,
        ssrc: 0
      }));
    return o;
  }
  return t.map((s) => {
    var r, o, a;
    const c = (r = s.scaleResolutionDownBy) !== null && r !== void 0 ? r : 1;
    let d = jd((o = s.rid) !== null && o !== void 0 ? o : "");
    return new Kt({
      quality: d,
      width: Math.ceil(n / c),
      height: Math.ceil(e / c),
      bitrate: (a = s.maxBitrate) !== null && a !== void 0 ? a : 0,
      ssrc: 0
    });
  });
}
const To = "_lossy", Co = "_reliable", mm = 2 * 1e3, As = "leave-reconnect", fm = 3e4, gm = 8 * 1024, vm = 256 * 1024;
var lt;
(function(n) {
  n[n.New = 0] = "New", n[n.Connected = 1] = "Connected", n[n.Disconnected = 2] = "Disconnected", n[n.Reconnecting = 3] = "Reconnecting", n[n.Closed = 4] = "Closed";
})(lt || (lt = {}));
class bm extends Pt.EventEmitter {
  get isClosed() {
    return this._isClosed;
  }
  get pendingReconnect() {
    return !!this.reconnectTimeout;
  }
  constructor(e) {
    var t;
    super(), this.options = e, this.rtcConfig = {}, this.peerConnectionTimeout = Qr.peerConnectionTimeout, this.fullReconnectOnNext = !1, this.latestRemoteOfferId = 0, this.subscriberPrimary = !1, this.pcState = lt.New, this._isClosed = !0, this.pendingTrackResolvers = {}, this.reconnectAttempts = 0, this.reconnectStart = 0, this.attemptingReconnect = !1, this.joinAttempts = 0, this.maxJoinAttempts = 1, this.shouldFailNext = !1, this.log = se, this.reliableDataSequence = 1, this.reliableMessageBuffer = new co(), this.reliableReceivedState = new Fp(fm), this.lossyDataStatCurrentBytes = 0, this.lossyDataStatByterate = 0, this.lossyDataDropCount = 0, this.midToTrackId = {}, this.isWaitingForNetworkReconnect = !1, this.handleDataChannel = (i) => m(this, [i], void 0, function(s) {
      var r = this;
      let {
        channel: o
      } = s;
      return (function* () {
        if (o) {
          if (o.label === Co)
            r.reliableDCSub = o;
          else if (o.label === To)
            r.lossyDCSub = o;
          else
            return;
          r.log.debug("on data channel ".concat(o.id, ", ").concat(o.label), r.logContext), o.onmessage = r.handleDataMessage;
        }
      })();
    }), this.handleDataMessage = (i) => m(this, void 0, void 0, function* () {
      var s, r, o, a, c;
      const d = yield this.dataProcessLock.lock();
      try {
        let l;
        if (i.data instanceof ArrayBuffer)
          l = i.data;
        else if (i.data instanceof Blob)
          l = yield i.data.arrayBuffer();
        else {
          this.log.error("unsupported data type", Object.assign(Object.assign({}, this.logContext), {
            data: i.data
          }));
          return;
        }
        const u = Xe.fromBinary(new Uint8Array(l));
        if (u.sequence > 0 && u.participantSid !== "") {
          const h = this.reliableReceivedState.get(u.participantSid);
          if (h && u.sequence <= h)
            return;
          this.reliableReceivedState.set(u.participantSid, u.sequence);
        }
        if (((s = u.value) === null || s === void 0 ? void 0 : s.case) === "speaker")
          this.emit(H.ActiveSpeakersUpdate, u.value.value.speakers);
        else if (((r = u.value) === null || r === void 0 ? void 0 : r.case) === "encryptedPacket") {
          if (!this.e2eeManager) {
            this.log.error("Received encrypted packet but E2EE not set up", this.logContext);
            return;
          }
          const h = yield (o = this.e2eeManager) === null || o === void 0 ? void 0 : o.handleEncryptedData(u.value.value.encryptedValue, u.value.value.iv, u.participantIdentity, u.value.value.keyIndex), p = kc.fromBinary(h.payload), b = new Xe({
            value: p.value,
            participantIdentity: u.participantIdentity,
            participantSid: u.participantSid
          });
          ((a = b.value) === null || a === void 0 ? void 0 : a.case) === "user" && _o(b, b.value.value), this.emit(H.DataPacketReceived, b, u.value.value.encryptionType);
        } else
          ((c = u.value) === null || c === void 0 ? void 0 : c.case) === "user" && _o(u, u.value.value), this.emit(H.DataPacketReceived, u, Ne.NONE);
      } finally {
        d();
      }
    }), this.handleDataError = (i) => {
      const r = i.currentTarget.maxRetransmits === 0 ? "lossy" : "reliable";
      if (i instanceof ErrorEvent && i.error) {
        const {
          error: o
        } = i.error;
        this.log.error("DataChannel error on ".concat(r, ": ").concat(i.message), Object.assign(Object.assign({}, this.logContext), {
          error: o
        }));
      } else
        this.log.error("Unknown DataChannel error on ".concat(r), Object.assign(Object.assign({}, this.logContext), {
          event: i
        }));
    }, this.handleBufferedAmountLow = (i) => {
      const r = i.currentTarget.maxRetransmits === 0 ? oe.LOSSY : oe.RELIABLE;
      this.updateAndEmitDCBufferStatus(r);
    }, this.handleDisconnect = (i, s) => {
      if (this._isClosed)
        return;
      this.log.warn("".concat(i, " disconnected"), this.logContext), this.reconnectAttempts === 0 && (this.reconnectStart = Date.now());
      const r = (c) => {
        this.log.warn("could not recover connection after ".concat(this.reconnectAttempts, " attempts, ").concat(c, "ms. giving up"), this.logContext), this.emit(H.Disconnected), this.close();
      }, o = Date.now() - this.reconnectStart;
      let a = this.getNextRetryDelay({
        elapsedMs: o,
        retryCount: this.reconnectAttempts
      });
      if (a === null) {
        r(o);
        return;
      }
      i === As && (a = 0), this.log.debug("reconnecting in ".concat(a, "ms"), this.logContext), this.clearReconnectTimeout(), this.token && this.regionUrlProvider && this.regionUrlProvider.updateToken(this.token), this.reconnectTimeout = Be.setTimeout(() => this.attemptReconnect(s).finally(() => this.reconnectTimeout = void 0), a);
    }, this.waitForRestarted = () => new Promise((i, s) => {
      this.pcState === lt.Connected && i();
      const r = () => {
        this.off(H.Disconnected, o), i();
      }, o = () => {
        this.off(H.Restarted, r), s();
      };
      this.once(H.Restarted, r), this.once(H.Disconnected, o);
    }), this.updateAndEmitDCBufferStatus = (i) => {
      if (i === oe.RELIABLE) {
        const r = this.dataChannelForKind(i);
        r && this.reliableMessageBuffer.alignBufferedAmount(r.bufferedAmount);
      }
      const s = this.isBufferStatusLow(i);
      typeof s != "undefined" && s !== this.dcBufferStatus.get(i) && (this.dcBufferStatus.set(i, s), this.emit(H.DCBufferStatusChanged, s, i));
    }, this.isBufferStatusLow = (i) => {
      const s = this.dataChannelForKind(i);
      if (s)
        return s.bufferedAmount <= s.bufferedAmountLowThreshold;
    }, this.handleBrowserOnLine = () => m(this, void 0, void 0, function* () {
      !this.url || !(yield fetch(hn(this.url), {
        method: "HEAD"
      }).then((s) => s.ok).catch(() => !1)) || (this.log.info("detected network reconnected"), // in case the engine is currently reconnecting, attempt a reconnect immediately after the browser state has changed to 'onLine'
      (this.client.currentState === Ee.RECONNECTING || // also if the browser went offline before and the engine still thinks it's in a connected state, treat it as a network interruption that we haven't noticed yet
      this.isWaitingForNetworkReconnect && this.client.currentState === Ee.CONNECTED) && (this.clearReconnectTimeout(), this.attemptReconnect(si.RR_SIGNAL_DISCONNECTED), this.isWaitingForNetworkReconnect = !1));
    }), this.handleBrowserOffline = () => m(this, void 0, void 0, function* () {
      if (this.url)
        try {
          yield Promise.race([
            fetch(hn(this.url), {
              method: "HEAD"
            }),
            // if there's no internet connection the fetch rejects immediately, so we only use a short timeout here
            ze(4e3).then(() => Promise.reject())
          ]);
        } catch {
          window.navigator.onLine === !1 && (this.log.info("detected network interruption"), this.isWaitingForNetworkReconnect = !0);
        }
    }), this.log = St((t = e.loggerName) !== null && t !== void 0 ? t : at.Engine), this.loggerOptions = {
      loggerName: e.loggerName,
      loggerContextCb: () => this.logContext
    }, this.client = new Kr(void 0, this.loggerOptions), this.client.signalLatency = this.options.expSignalLatency, this.reconnectPolicy = this.options.reconnectPolicy, this.closingLock = new Ze(), this.dataProcessLock = new Ze(), this.dcBufferStatus = /* @__PURE__ */ new Map([[oe.LOSSY, !0], [oe.RELIABLE, !0]]), this.client.onParticipantUpdate = (i) => this.emit(H.ParticipantUpdate, i), this.client.onConnectionQuality = (i) => this.emit(H.ConnectionQualityUpdate, i), this.client.onRoomUpdate = (i) => this.emit(H.RoomUpdate, i), this.client.onSubscriptionError = (i) => this.emit(H.SubscriptionError, i), this.client.onSubscriptionPermissionUpdate = (i) => this.emit(H.SubscriptionPermissionUpdate, i), this.client.onSpeakersChanged = (i) => this.emit(H.SpeakersChanged, i), this.client.onStreamStateUpdate = (i) => this.emit(H.StreamStateChanged, i), this.client.onRequestResponse = (i) => this.emit(H.SignalRequestResponse, i);
  }
  /** @internal */
  get logContext() {
    var e, t, i, s, r, o;
    return {
      room: (t = (e = this.latestJoinResponse) === null || e === void 0 ? void 0 : e.room) === null || t === void 0 ? void 0 : t.name,
      roomID: (s = (i = this.latestJoinResponse) === null || i === void 0 ? void 0 : i.room) === null || s === void 0 ? void 0 : s.sid,
      participant: (o = (r = this.latestJoinResponse) === null || r === void 0 ? void 0 : r.participant) === null || o === void 0 ? void 0 : o.identity,
      pID: this.participantSid
    };
  }
  join(e, t, i, s) {
    return m(this, arguments, void 0, function(r, o, a, c) {
      var d = this;
      let l = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1;
      return (function* () {
        d.url = r, d.token = o, d.signalOpts = a, d.maxJoinAttempts = a.maxRetries;
        try {
          d.joinAttempts += 1, d.setupSignalClientCallbacks();
          const u = yield d.client.join(r, o, a, c, l);
          return d._isClosed = !1, d.latestJoinResponse = u, d.subscriberPrimary = u.subscriberPrimary, d.pcManager || (yield d.configure(u, !l)), (!d.subscriberPrimary || u.fastPublish) && d.negotiate().catch((h) => {
            se.error(h, d.logContext);
          }), d.registerOnLineListener(), d.clientConfiguration = u.clientConfiguration, d.emit(H.SignalConnected, u), u;
        } catch (u) {
          if (u instanceof Z) {
            if (u.reason === Re.ServerUnreachable) {
              if (d.log.warn("Couldn't connect to server, attempt ".concat(d.joinAttempts, " of ").concat(d.maxJoinAttempts), d.logContext), d.joinAttempts < d.maxJoinAttempts)
                return d.join(r, o, a, c, l);
            } else if (u.reason === Re.ServiceNotFound)
              return d.log.warn("Initial connection failed: ".concat(u.message, " – Retrying")), d.join(r, o, a, c, !0);
          }
          throw u;
        }
      })();
    });
  }
  close() {
    return m(this, void 0, void 0, function* () {
      const e = yield this.closingLock.lock();
      if (this.isClosed) {
        e();
        return;
      }
      try {
        this._isClosed = !0, this.joinAttempts = 0, this.emit(H.Closing), this.removeAllListeners(), this.deregisterOnLineListener(), this.clearPendingReconnect(), this.cleanupLossyDataStats(), yield this.cleanupPeerConnections(), yield this.cleanupClient();
      } finally {
        e();
      }
    });
  }
  cleanupPeerConnections() {
    return m(this, void 0, void 0, function* () {
      var e;
      yield (e = this.pcManager) === null || e === void 0 ? void 0 : e.close(), this.pcManager = void 0;
      const t = (i) => {
        i && (i.close(), i.onbufferedamountlow = null, i.onclose = null, i.onclosing = null, i.onerror = null, i.onmessage = null, i.onopen = null);
      };
      t(this.lossyDC), t(this.lossyDCSub), t(this.reliableDC), t(this.reliableDCSub), this.lossyDC = void 0, this.lossyDCSub = void 0, this.reliableDC = void 0, this.reliableDCSub = void 0, this.reliableMessageBuffer = new co(), this.reliableDataSequence = 1, this.reliableReceivedState.clear();
    });
  }
  cleanupLossyDataStats() {
    this.lossyDataStatByterate = 0, this.lossyDataStatCurrentBytes = 0, this.lossyDataStatInterval && (clearInterval(this.lossyDataStatInterval), this.lossyDataStatInterval = void 0), this.lossyDataDropCount = 0;
  }
  cleanupClient() {
    return m(this, void 0, void 0, function* () {
      yield this.client.close(), this.client.resetCallbacks();
    });
  }
  addTrack(e) {
    if (this.pendingTrackResolvers[e.cid])
      throw new Ut("a track with the same ID has already been published");
    return new Promise((t, i) => {
      const s = setTimeout(() => {
        delete this.pendingTrackResolvers[e.cid], i(Z.timeout("publication of local track timed out, no response from server"));
      }, 1e4);
      this.pendingTrackResolvers[e.cid] = {
        resolve: (r) => {
          clearTimeout(s), t(r);
        },
        reject: () => {
          clearTimeout(s), i(new Error("Cancelled publication by calling unpublish"));
        }
      }, this.client.sendAddTrack(e);
    });
  }
  /**
   * Removes sender from PeerConnection, returning true if it was removed successfully
   * and a negotiation is necessary
   * @param sender
   * @returns
   */
  removeTrack(e) {
    if (e.track && this.pendingTrackResolvers[e.track.id]) {
      const {
        reject: t
      } = this.pendingTrackResolvers[e.track.id];
      t && t(), delete this.pendingTrackResolvers[e.track.id];
    }
    try {
      return this.pcManager.removeTrack(e), !0;
    } catch (t) {
      this.log.warn("failed to remove track", Object.assign(Object.assign({}, this.logContext), {
        error: t
      }));
    }
    return !1;
  }
  updateMuteStatus(e, t) {
    this.client.sendMuteTrack(e, t);
  }
  get dataSubscriberReadyState() {
    var e;
    return (e = this.reliableDCSub) === null || e === void 0 ? void 0 : e.readyState;
  }
  getConnectedServerAddress() {
    return m(this, void 0, void 0, function* () {
      var e;
      return (e = this.pcManager) === null || e === void 0 ? void 0 : e.getConnectedAddress();
    });
  }
  /* @internal */
  setRegionUrlProvider(e) {
    this.regionUrlProvider = e;
  }
  configure(e, t) {
    return m(this, void 0, void 0, function* () {
      var i, s;
      if (this.pcManager && this.pcManager.currentState !== Me.NEW)
        return;
      this.participantSid = (i = e.participant) === null || i === void 0 ? void 0 : i.sid;
      const r = this.makeRTCConfiguration(e);
      this.pcManager = new Kp(r, t ? "publisher-only" : e.subscriberPrimary ? "subscriber-primary" : "publisher-primary", this.loggerOptions), this.emit(H.TransportsCreated, this.pcManager.publisher, this.pcManager.subscriber), this.pcManager.onIceCandidate = (o, a) => {
        this.client.sendIceCandidate(o, a);
      }, this.pcManager.onPublisherOffer = (o, a) => {
        this.client.sendOffer(o, a);
      }, this.pcManager.onDataChannel = this.handleDataChannel, this.pcManager.onStateChange = (o, a, c) => m(this, void 0, void 0, function* () {
        if (this.log.debug("primary PC state changed ".concat(o), this.logContext), ["closed", "disconnected", "failed"].includes(a) && (this.publisherConnectionPromise = void 0), o === Me.CONNECTED) {
          const u = this.pcState === lt.New;
          this.pcState = lt.Connected, u && this.emit(H.Connected, e);
        } else o === Me.FAILED && (this.pcState === lt.Connected || this.pcState === lt.Reconnecting) && (this.pcState = lt.Disconnected, this.handleDisconnect("peerconnection failed", c === "failed" ? si.RR_SUBSCRIBER_FAILED : si.RR_PUBLISHER_FAILED));
        const d = this.client.isDisconnected || this.client.currentState === Ee.RECONNECTING, l = [Me.FAILED, Me.CLOSING, Me.CLOSED].includes(o);
        d && l && !this._isClosed && this.emit(H.Offline);
      }), this.pcManager.onTrack = (o) => {
        o.streams.length !== 0 && this.emit(H.MediaTrackAdded, o.track, o.streams[0], o.receiver);
      }, ym((s = e.serverInfo) === null || s === void 0 ? void 0 : s.protocol) || this.createDataChannels();
    });
  }
  setupSignalClientCallbacks() {
    this.client.onAnswer = (e, t, i) => m(this, void 0, void 0, function* () {
      this.pcManager && (this.log.debug("received server answer", Object.assign(Object.assign({}, this.logContext), {
        RTCSdpType: e.type,
        sdp: e.sdp,
        midToTrackId: i
      })), this.midToTrackId = i, yield this.pcManager.setPublisherAnswer(e, t));
    }), this.client.onTrickle = (e, t) => {
      this.pcManager && (this.log.debug("got ICE candidate from peer", Object.assign(Object.assign({}, this.logContext), {
        candidate: e,
        target: t
      })), this.pcManager.addIceCandidate(e, t));
    }, this.client.onOffer = (e, t, i) => m(this, void 0, void 0, function* () {
      if (this.latestRemoteOfferId = t, !this.pcManager)
        return;
      this.midToTrackId = i;
      const s = yield this.pcManager.createSubscriberAnswerFromOffer(e, t);
      s && this.client.sendAnswer(s, t);
    }), this.client.onLocalTrackPublished = (e) => {
      var t;
      if (this.log.debug("received trackPublishedResponse", Object.assign(Object.assign({}, this.logContext), {
        cid: e.cid,
        track: (t = e.track) === null || t === void 0 ? void 0 : t.sid
      })), !this.pendingTrackResolvers[e.cid]) {
        this.log.error("missing track resolver for ".concat(e.cid), Object.assign(Object.assign({}, this.logContext), {
          cid: e.cid
        }));
        return;
      }
      const {
        resolve: i
      } = this.pendingTrackResolvers[e.cid];
      delete this.pendingTrackResolvers[e.cid], i(e.track);
    }, this.client.onLocalTrackUnpublished = (e) => {
      this.emit(H.LocalTrackUnpublished, e);
    }, this.client.onLocalTrackSubscribed = (e) => {
      this.emit(H.LocalTrackSubscribed, e);
    }, this.client.onTokenRefresh = (e) => {
      var t;
      this.token = e, (t = this.regionUrlProvider) === null || t === void 0 || t.updateToken(e);
    }, this.client.onRemoteMuteChanged = (e, t) => {
      this.emit(H.RemoteMute, e, t);
    }, this.client.onSubscribedQualityUpdate = (e) => {
      this.emit(H.SubscribedQualityUpdate, e);
    }, this.client.onRoomMoved = (e) => {
      var t;
      this.participantSid = (t = e.participant) === null || t === void 0 ? void 0 : t.sid, this.latestJoinResponse && (this.latestJoinResponse.room = e.room), this.emit(H.RoomMoved, e);
    }, this.client.onMediaSectionsRequirement = (e) => {
      var t, i;
      const s = {
        direction: "recvonly"
      };
      for (let r = 0; r < e.numAudios; r++)
        (t = this.pcManager) === null || t === void 0 || t.addPublisherTransceiverOfKind("audio", s);
      for (let r = 0; r < e.numVideos; r++)
        (i = this.pcManager) === null || i === void 0 || i.addPublisherTransceiverOfKind("video", s);
      this.negotiate();
    }, this.client.onClose = () => {
      this.handleDisconnect("signal", si.RR_SIGNAL_DISCONNECTED);
    }, this.client.onLeave = (e) => {
      switch (this.log.debug("client leave request", Object.assign(Object.assign({}, this.logContext), {
        reason: e == null ? void 0 : e.reason
      })), e.regions && this.regionUrlProvider && (this.log.debug("updating regions", this.logContext), this.regionUrlProvider.setServerReportedRegions({
        updatedAtInMs: Date.now(),
        maxAgeInMs: Ud,
        regionSettings: e.regions
      })), e.action) {
        case Mi.DISCONNECT:
          this.emit(H.Disconnected, e == null ? void 0 : e.reason), this.close();
          break;
        case Mi.RECONNECT:
          this.fullReconnectOnNext = !0, this.handleDisconnect(As);
          break;
        case Mi.RESUME:
          this.handleDisconnect(As);
      }
    };
  }
  makeRTCConfiguration(e) {
    var t;
    const i = Object.assign({}, this.rtcConfig);
    if (!((t = this.signalOpts) === null || t === void 0) && t.e2eeEnabled && (this.log.debug("E2EE - setting up transports with insertable streams", this.logContext), i.encodedInsertableStreams = !0), e.iceServers && !i.iceServers) {
      const s = [];
      e.iceServers.forEach((r) => {
        const o = {
          urls: r.urls
        };
        r.username && (o.username = r.username), r.credential && (o.credential = r.credential), s.push(o);
      }), i.iceServers = s;
    }
    return e.clientConfiguration && e.clientConfiguration.forceRelay === on.ENABLED && (i.iceTransportPolicy = "relay"), i.sdpSemantics = "unified-plan", i.continualGatheringPolicy = "gather_continually", i;
  }
  createDataChannels() {
    this.pcManager && (this.lossyDC && (this.lossyDC.onmessage = null, this.lossyDC.onerror = null), this.reliableDC && (this.reliableDC.onmessage = null, this.reliableDC.onerror = null), this.lossyDC = this.pcManager.createPublisherDataChannel(To, {
      ordered: !1,
      maxRetransmits: 0
    }), this.reliableDC = this.pcManager.createPublisherDataChannel(Co, {
      ordered: !0
    }), this.lossyDC.onmessage = this.handleDataMessage, this.reliableDC.onmessage = this.handleDataMessage, this.lossyDC.onerror = this.handleDataError, this.reliableDC.onerror = this.handleDataError, this.lossyDC.bufferedAmountLowThreshold = 65535, this.reliableDC.bufferedAmountLowThreshold = 65535, this.lossyDC.onbufferedamountlow = this.handleBufferedAmountLow, this.reliableDC.onbufferedamountlow = this.handleBufferedAmountLow, this.cleanupLossyDataStats(), this.lossyDataStatInterval = setInterval(() => {
      this.lossyDataStatByterate = this.lossyDataStatCurrentBytes, this.lossyDataStatCurrentBytes = 0;
      const e = this.dataChannelForKind(oe.LOSSY);
      if (e) {
        const t = this.lossyDataStatByterate / 10;
        e.bufferedAmountLowThreshold = Math.min(Math.max(t, gm), vm);
      }
    }, 1e3));
  }
  createSender(e, t, i) {
    return m(this, void 0, void 0, function* () {
      if (dr())
        return yield this.createTransceiverRTCRtpSender(e, t, i);
      if (lr())
        return this.log.warn("using add-track fallback", this.logContext), yield this.createRTCRtpSender(e.mediaStreamTrack);
      throw new De("Required webRTC APIs not supported on this device");
    });
  }
  createSimulcastSender(e, t, i, s) {
    return m(this, void 0, void 0, function* () {
      if (dr())
        return this.createSimulcastTransceiverSender(e, t, i, s);
      if (lr())
        return this.log.debug("using add-track fallback", this.logContext), this.createRTCRtpSender(e.mediaStreamTrack);
      throw new De("Cannot stream on this device");
    });
  }
  createTransceiverRTCRtpSender(e, t, i) {
    return m(this, void 0, void 0, function* () {
      if (!this.pcManager)
        throw new De("publisher is closed");
      const s = [];
      e.mediaStream && s.push(e.mediaStream), Zt(e) && (e.codec = t.videoCodec);
      const r = {
        direction: "sendonly",
        streams: s
      };
      return i && (r.sendEncodings = i), (yield this.pcManager.addPublisherTransceiver(e.mediaStreamTrack, r)).sender;
    });
  }
  createSimulcastTransceiverSender(e, t, i, s) {
    return m(this, void 0, void 0, function* () {
      if (!this.pcManager)
        throw new De("publisher is closed");
      const r = {
        direction: "sendonly"
      };
      s && (r.sendEncodings = s);
      const o = yield this.pcManager.addPublisherTransceiver(t.mediaStreamTrack, r);
      if (i.videoCodec)
        return e.setSimulcastTrackSender(i.videoCodec, o.sender), o.sender;
    });
  }
  createRTCRtpSender(e) {
    return m(this, void 0, void 0, function* () {
      if (!this.pcManager)
        throw new De("publisher is closed");
      return this.pcManager.addPublisherTrack(e);
    });
  }
  attemptReconnect(e) {
    return m(this, void 0, void 0, function* () {
      var t, i, s;
      if (!this._isClosed) {
        if (this.attemptingReconnect) {
          se.warn("already attempting reconnect, returning early", this.logContext);
          return;
        }
        (((t = this.clientConfiguration) === null || t === void 0 ? void 0 : t.resumeConnection) === on.DISABLED || // signaling state could change to closed due to hardware sleep
        // those connections cannot be resumed
        ((s = (i = this.pcManager) === null || i === void 0 ? void 0 : i.currentState) !== null && s !== void 0 ? s : Me.NEW) === Me.NEW) && (this.fullReconnectOnNext = !0);
        try {
          this.attemptingReconnect = !0, this.fullReconnectOnNext ? yield this.restartConnection() : yield this.resumeConnection(e), this.clearPendingReconnect(), this.fullReconnectOnNext = !1;
        } catch (r) {
          this.reconnectAttempts += 1;
          let o = !0;
          r instanceof De ? (this.log.debug("received unrecoverable error", Object.assign(Object.assign({}, this.logContext), {
            error: r
          })), o = !1) : r instanceof vi || (this.fullReconnectOnNext = !0), o ? this.handleDisconnect("reconnect", si.RR_UNKNOWN) : (this.log.info("could not recover connection after ".concat(this.reconnectAttempts, " attempts, ").concat(Date.now() - this.reconnectStart, "ms. giving up"), this.logContext), this.emit(H.Disconnected), yield this.close());
        } finally {
          this.attemptingReconnect = !1;
        }
      }
    });
  }
  getNextRetryDelay(e) {
    try {
      return this.reconnectPolicy.nextRetryDelayInMs(e);
    } catch (t) {
      this.log.warn("encountered error in reconnect policy", Object.assign(Object.assign({}, this.logContext), {
        error: t
      }));
    }
    return null;
  }
  restartConnection(e) {
    return m(this, void 0, void 0, function* () {
      var t, i, s;
      try {
        if (!this.url || !this.token)
          throw new De("could not reconnect, url or token not saved");
        this.log.info("reconnecting, attempt: ".concat(this.reconnectAttempts), this.logContext), this.emit(H.Restarting), this.client.isDisconnected || (yield this.client.sendLeave()), yield this.cleanupPeerConnections(), yield this.cleanupClient();
        let r;
        try {
          if (!this.signalOpts)
            throw this.log.warn("attempted connection restart, without signal options present", this.logContext), new vi();
          r = yield this.join(e != null ? e : this.url, this.token, this.signalOpts, void 0, !this.options.singlePeerConnection);
        } catch (o) {
          throw o instanceof Z && o.reason === Re.NotAllowed ? new De("could not reconnect, token might be expired") : new vi();
        }
        if (this.shouldFailNext)
          throw this.shouldFailNext = !1, new Error("simulated failure");
        if (this.client.setReconnected(), this.emit(H.SignalRestarted, r), yield this.waitForPCReconnected(), this.client.currentState !== Ee.CONNECTED)
          throw new vi("Signal connection got severed during reconnect");
        (t = this.regionUrlProvider) === null || t === void 0 || t.resetAttempts(), this.emit(H.Restarted);
      } catch (r) {
        const o = yield (i = this.regionUrlProvider) === null || i === void 0 ? void 0 : i.getNextBestRegionUrl();
        if (o) {
          yield this.restartConnection(o);
          return;
        } else
          throw (s = this.regionUrlProvider) === null || s === void 0 || s.resetAttempts(), r;
      }
    });
  }
  resumeConnection(e) {
    return m(this, void 0, void 0, function* () {
      var t;
      if (!this.url || !this.token)
        throw new De("could not reconnect, url or token not saved");
      if (!this.pcManager)
        throw new De("publisher and subscriber connections unset");
      this.log.info("resuming signal connection, attempt ".concat(this.reconnectAttempts), this.logContext), this.emit(H.Resuming);
      let i;
      try {
        this.setupSignalClientCallbacks(), i = yield this.client.reconnect(this.url, this.token, this.participantSid, e);
      } catch (s) {
        let r = "";
        throw s instanceof Error && (r = s.message, this.log.error(s.message, Object.assign(Object.assign({}, this.logContext), {
          error: s
        }))), s instanceof Z && s.reason === Re.NotAllowed ? new De("could not reconnect, token might be expired") : s instanceof Z && s.reason === Re.LeaveRequest ? s : new vi(r);
      }
      if (this.emit(H.SignalResumed), i) {
        const s = this.makeRTCConfiguration(i);
        this.pcManager.updateConfiguration(s), this.latestJoinResponse && (this.latestJoinResponse.serverInfo = i.serverInfo);
      } else
        this.log.warn("Did not receive reconnect response", this.logContext);
      if (this.shouldFailNext)
        throw this.shouldFailNext = !1, new Error("simulated failure");
      if (yield this.pcManager.triggerIceRestart(), yield this.waitForPCReconnected(), this.client.currentState !== Ee.CONNECTED)
        throw new vi("Signal connection got severed during reconnect");
      this.client.setReconnected(), ((t = this.reliableDC) === null || t === void 0 ? void 0 : t.readyState) === "open" && this.reliableDC.id === null && this.createDataChannels(), i != null && i.lastMessageSeq && this.resendReliableMessagesForResume(i.lastMessageSeq), this.emit(H.Resumed);
    });
  }
  waitForPCInitialConnection(e, t) {
    return m(this, void 0, void 0, function* () {
      if (!this.pcManager)
        throw new De("PC manager is closed");
      yield this.pcManager.ensurePCTransportConnection(t, e);
    });
  }
  waitForPCReconnected() {
    return m(this, void 0, void 0, function* () {
      this.pcState = lt.Reconnecting, this.log.debug("waiting for peer connection to reconnect", this.logContext);
      try {
        if (yield ze(mm), !this.pcManager)
          throw new De("PC manager is closed");
        yield this.pcManager.ensurePCTransportConnection(void 0, this.peerConnectionTimeout), this.pcState = lt.Connected;
      } catch (e) {
        throw this.pcState = lt.Disconnected, Z.internal("could not establish PC connection, ".concat(e.message));
      }
    });
  }
  /** @internal */
  publishRpcResponse(e, t, i, s) {
    return m(this, void 0, void 0, function* () {
      const r = new Xe({
        destinationIdentities: [e],
        kind: oe.RELIABLE,
        value: {
          case: "rpcResponse",
          value: new Dr({
            requestId: t,
            value: s ? {
              case: "error",
              value: s.toProto()
            } : {
              case: "payload",
              value: i != null ? i : ""
            }
          })
        }
      });
      yield this.sendDataPacket(r, oe.RELIABLE);
    });
  }
  /** @internal */
  publishRpcAck(e, t) {
    return m(this, void 0, void 0, function* () {
      const i = new Xe({
        destinationIdentities: [e],
        kind: oe.RELIABLE,
        value: {
          case: "rpcAck",
          value: new Or({
            requestId: t
          })
        }
      });
      yield this.sendDataPacket(i, oe.RELIABLE);
    });
  }
  /* @internal */
  sendDataPacket(e, t) {
    return m(this, void 0, void 0, function* () {
      if (yield this.ensurePublisherConnected(t), this.e2eeManager && this.e2eeManager.isDataChannelEncryptionEnabled) {
        const r = Rp(e);
        if (r) {
          const o = yield this.e2eeManager.encryptData(r.toBinary());
          e.value = {
            case: "encryptedPacket",
            value: new Sc({
              encryptedValue: o.payload,
              iv: o.iv,
              keyIndex: o.keyIndex
            })
          };
        }
      }
      t === oe.RELIABLE && (e.sequence = this.reliableDataSequence, this.reliableDataSequence += 1);
      const i = e.toBinary(), s = this.dataChannelForKind(t);
      if (s) {
        if (t === oe.RELIABLE)
          yield this.waitForBufferStatusLow(t), this.reliableMessageBuffer.push({
            data: i,
            sequence: e.sequence
          });
        else {
          if (!this.isBufferStatusLow(t)) {
            this.lossyDataDropCount += 1, this.lossyDataDropCount % 100 === 0 && this.log.warn("dropping lossy data channel messages, total dropped: ".concat(this.lossyDataDropCount), this.logContext);
            return;
          }
          this.lossyDataStatCurrentBytes += i.byteLength;
        }
        if (this.attemptingReconnect)
          return;
        s.send(i);
      }
      this.updateAndEmitDCBufferStatus(t);
    });
  }
  resendReliableMessagesForResume(e) {
    return m(this, void 0, void 0, function* () {
      yield this.ensurePublisherConnected(oe.RELIABLE);
      const t = this.dataChannelForKind(oe.RELIABLE);
      t && (this.reliableMessageBuffer.popToSequence(e), this.reliableMessageBuffer.getAll().forEach((i) => {
        t.send(i.data);
      })), this.updateAndEmitDCBufferStatus(oe.RELIABLE);
    });
  }
  waitForBufferStatusLow(e) {
    return new Je((t, i) => m(this, void 0, void 0, function* () {
      if (this.isBufferStatusLow(e))
        t();
      else {
        const s = () => i(new De("engine closed"));
        for (this.once(H.Closing, s); !this.dcBufferStatus.get(e); )
          yield ze(10);
        this.off(H.Closing, s), t();
      }
    }));
  }
  /**
   * @internal
   */
  ensureDataTransportConnected(e) {
    return m(this, arguments, void 0, function(t) {
      var i = this;
      let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.subscriberPrimary;
      return (function* () {
        var r;
        if (!i.pcManager)
          throw new De("PC manager is closed");
        const o = s ? i.pcManager.subscriber : i.pcManager.publisher, a = s ? "Subscriber" : "Publisher";
        if (!o)
          throw Z.internal("".concat(a, " connection not set"));
        let c = !1;
        !s && !i.dataChannelForKind(t, s) && (i.createDataChannels(), c = !0), !c && !s && !i.pcManager.publisher.isICEConnected && i.pcManager.publisher.getICEConnectionState() !== "checking" && (c = !0), c && i.negotiate().catch((u) => {
          se.error(u, i.logContext);
        });
        const d = i.dataChannelForKind(t, s);
        if ((d == null ? void 0 : d.readyState) === "open")
          return;
        const l = (/* @__PURE__ */ new Date()).getTime() + i.peerConnectionTimeout;
        for (; (/* @__PURE__ */ new Date()).getTime() < l; ) {
          if (o.isICEConnected && ((r = i.dataChannelForKind(t, s)) === null || r === void 0 ? void 0 : r.readyState) === "open")
            return;
          yield ze(50);
        }
        throw Z.internal("could not establish ".concat(a, " connection, state: ").concat(o.getICEConnectionState()));
      })();
    });
  }
  ensurePublisherConnected(e) {
    return m(this, void 0, void 0, function* () {
      this.publisherConnectionPromise || (this.publisherConnectionPromise = this.ensureDataTransportConnected(e, !1)), yield this.publisherConnectionPromise;
    });
  }
  /* @internal */
  verifyTransport() {
    return !(!this.pcManager || ![Me.CONNECTING, Me.CONNECTED].includes(this.pcManager.currentState) || !this.client.ws || this.client.ws.readyState === WebSocket.CLOSED);
  }
  /** @internal */
  negotiate() {
    return m(this, void 0, void 0, function* () {
      return new Je((e, t) => m(this, void 0, void 0, function* () {
        if (!this.pcManager) {
          t(new oi("PC manager is closed"));
          return;
        }
        this.pcManager.requirePublisher(), this.pcManager.publisher.getTransceivers().length == 0 && !this.lossyDC && !this.reliableDC && this.createDataChannels();
        const i = new AbortController(), s = () => {
          i.abort(), this.log.debug("engine disconnected while negotiation was ongoing", this.logContext), e();
        };
        this.isClosed && t(new oi("cannot negotiate on closed engine")), this.on(H.Closing, s), this.on(H.Restarting, s), this.pcManager.publisher.once(di.RTPVideoPayloadTypes, (r) => {
          const o = /* @__PURE__ */ new Map();
          r.forEach((a) => {
            const c = a.codec.toLowerCase();
            lp(c) && o.set(a.payload, c);
          }), this.emit(H.RTPVideoMapUpdate, o);
        });
        try {
          yield this.pcManager.negotiate(i), e();
        } catch (r) {
          if (i.signal.aborted) {
            e();
            return;
          }
          r instanceof oi && (this.fullReconnectOnNext = !0), this.handleDisconnect("negotiation", si.RR_UNKNOWN), r instanceof Error ? t(r) : t(new Error(String(r)));
        } finally {
          this.off(H.Closing, s), this.off(H.Restarting, s);
        }
      }));
    });
  }
  dataChannelForKind(e, t) {
    if (t) {
      if (e === oe.LOSSY)
        return this.lossyDCSub;
      if (e === oe.RELIABLE)
        return this.reliableDCSub;
    } else {
      if (e === oe.LOSSY)
        return this.lossyDC;
      if (e === oe.RELIABLE)
        return this.reliableDC;
    }
  }
  /** @internal */
  sendSyncState(e, t) {
    var i, s, r, o;
    if (!this.pcManager) {
      this.log.warn("sync state cannot be sent without peer connection setup", this.logContext);
      return;
    }
    const a = this.pcManager.publisher.getLocalDescription(), c = this.pcManager.publisher.getRemoteDescription(), d = (i = this.pcManager.subscriber) === null || i === void 0 ? void 0 : i.getRemoteDescription(), l = (s = this.pcManager.subscriber) === null || s === void 0 ? void 0 : s.getLocalDescription(), u = (o = (r = this.signalOpts) === null || r === void 0 ? void 0 : r.autoSubscribe) !== null && o !== void 0 ? o : !0, h = new Array(), p = new Array();
    e.forEach((b) => {
      b.isDesired !== u && h.push(b.trackSid), b.isEnabled || p.push(b.trackSid);
    }), this.client.sendSyncState(new Vr({
      answer: this.pcManager.mode === "publisher-only" ? c ? Ii({
        sdp: c.sdp,
        type: c.type
      }) : void 0 : l ? Ii({
        sdp: l.sdp,
        type: l.type
      }) : void 0,
      offer: this.pcManager.mode === "publisher-only" ? a ? Ii({
        sdp: a.sdp,
        type: a.type
      }) : void 0 : d ? Ii({
        sdp: d.sdp,
        type: d.type
      }) : void 0,
      subscription: new as({
        trackSids: h,
        subscribe: !u,
        participantTracks: []
      }),
      publishTracks: Kh(t),
      dataChannels: this.dataChannelsInfo(),
      trackSidsDisabled: p,
      datachannelReceiveStates: this.reliableReceivedState.map((b, v) => new Hc({
        publisherSid: v,
        lastSeq: b
      }))
    }));
  }
  /* @internal */
  failNext() {
    this.shouldFailNext = !0;
  }
  dataChannelsInfo() {
    const e = [], t = (i, s) => {
      (i == null ? void 0 : i.id) !== void 0 && i.id !== null && e.push(new Wc({
        label: i.label,
        id: i.id,
        target: s
      }));
    };
    return t(this.dataChannelForKind(oe.LOSSY), vt.PUBLISHER), t(this.dataChannelForKind(oe.RELIABLE), vt.PUBLISHER), t(this.dataChannelForKind(oe.LOSSY, !0), vt.SUBSCRIBER), t(this.dataChannelForKind(oe.RELIABLE, !0), vt.SUBSCRIBER), e;
  }
  clearReconnectTimeout() {
    this.reconnectTimeout && Be.clearTimeout(this.reconnectTimeout);
  }
  clearPendingReconnect() {
    this.clearReconnectTimeout(), this.reconnectAttempts = 0;
  }
  registerOnLineListener() {
    it() && (window.addEventListener("online", this.handleBrowserOnLine), window.addEventListener("offline", this.handleBrowserOffline));
  }
  deregisterOnLineListener() {
    it() && (window.removeEventListener("online", this.handleBrowserOnLine), window.removeEventListener("offline", this.handleBrowserOffline));
  }
  getTrackIdForReceiver(e) {
    var t;
    const i = (t = this.pcManager) === null || t === void 0 ? void 0 : t.getMidForReceiver(e);
    if (i) {
      const s = Object.entries(this.midToTrackId).find((r) => {
        let [o] = r;
        return o === i;
      });
      if (s)
        return s[1];
    }
  }
}
function ym(n) {
  return n !== void 0 && n > 13;
}
function _o(n, e) {
  const t = n.participantIdentity ? n.participantIdentity : e.participantIdentity;
  n.participantIdentity = t, e.participantIdentity = t;
  const i = n.destinationIdentities.length !== 0 ? n.destinationIdentities : e.destinationIdentities;
  n.destinationIdentities = i, e.destinationIdentities = i;
}
class qd {
  get info() {
    return this._info;
  }
  /** @internal */
  validateBytesReceived() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1;
    if (!(typeof this.totalByteSize != "number" || this.totalByteSize === 0)) {
      if (e && this.bytesReceived < this.totalByteSize)
        throw new ut("Not enough chunk(s) received - expected ".concat(this.totalByteSize, " bytes of data total, only received ").concat(this.bytesReceived, " bytes"), Qe.Incomplete);
      if (this.bytesReceived > this.totalByteSize)
        throw new ut("Extra chunk(s) received - expected ".concat(this.totalByteSize, " bytes of data total, received ").concat(this.bytesReceived, " bytes"), Qe.LengthExceeded);
    }
  }
  constructor(e, t, i) {
    this.reader = t, this.totalByteSize = i, this._info = e, this.bytesReceived = 0;
  }
}
class Sm extends qd {
  handleChunkReceived(e) {
    var t;
    this.bytesReceived += e.content.byteLength, this.validateBytesReceived();
    const i = this.totalByteSize ? this.bytesReceived / this.totalByteSize : void 0;
    (t = this.onProgress) === null || t === void 0 || t.call(this, i);
  }
  [Symbol.asyncIterator]() {
    const e = this.reader.getReader();
    e.closed.catch(() => {
    });
    const t = () => {
      e.releaseLock(), this.signal = void 0;
    };
    return {
      next: () => m(this, void 0, void 0, function* () {
        try {
          const i = this.signal;
          if (i != null && i.aborted)
            throw i.reason;
          const s = yield new Promise((r, o) => {
            if (i) {
              const a = () => o(i.reason);
              i.addEventListener("abort", a, {
                once: !0
              }), e.read().then(r, o).finally(() => {
                i.removeEventListener("abort", a);
              });
            } else
              e.read().then(r, o);
          });
          return s.done ? (this.validateBytesReceived(!0), {
            done: !0,
            value: void 0
          }) : (this.handleChunkReceived(s.value), {
            done: !1,
            value: s.value.content
          });
        } catch (i) {
          throw t(), i;
        }
      }),
      // note: `return` runs only for premature exits, see:
      // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Iteration_protocols#errors_during_iteration
      return() {
        return m(this, void 0, void 0, function* () {
          return t(), {
            done: !0,
            value: void 0
          };
        });
      }
    };
  }
  /**
   * Injects an AbortSignal, which if aborted, will terminate the currently active
   * stream iteration operation.
   *
   * Note that when using AbortSignal.timeout(...), the timeout applies across
   * the whole iteration operation, not just one individual chunk read.
   */
  withAbortSignal(e) {
    return this.signal = e, this;
  }
  readAll() {
    return m(this, arguments, void 0, function() {
      var e = this;
      let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      return (function* () {
        var i, s, r, o;
        let a = /* @__PURE__ */ new Set();
        const c = t.signal ? e.withAbortSignal(t.signal) : e;
        try {
          for (var d = !0, l = Nt(c), u; u = yield l.next(), i = u.done, !i; d = !0) {
            o = u.value, d = !1;
            const h = o;
            a.add(h);
          }
        } catch (h) {
          s = {
            error: h
          };
        } finally {
          try {
            !d && !i && (r = l.return) && (yield r.call(l));
          } finally {
            if (s) throw s.error;
          }
        }
        return Array.from(a);
      })();
    });
  }
}
class km extends qd {
  /**
   * A TextStreamReader instance can be used as an AsyncIterator that returns the entire string
   * that has been received up to the current point in time.
   */
  constructor(e, t, i) {
    super(e, t, i), this.receivedChunks = /* @__PURE__ */ new Map();
  }
  handleChunkReceived(e) {
    var t;
    const i = Nn(e.chunkIndex), s = this.receivedChunks.get(i);
    if (s && s.version > e.version)
      return;
    this.receivedChunks.set(i, e), this.bytesReceived += e.content.byteLength, this.validateBytesReceived();
    const r = this.totalByteSize ? this.bytesReceived / this.totalByteSize : void 0;
    (t = this.onProgress) === null || t === void 0 || t.call(this, r);
  }
  /**
   * Async iterator implementation to allow usage of `for await...of` syntax.
   * Yields structured chunks from the stream.
   *
   */
  [Symbol.asyncIterator]() {
    const e = this.reader.getReader();
    e.closed.catch(() => {
    });
    const t = new TextDecoder("utf-8", {
      fatal: !0
    }), i = this.signal, s = () => {
      e.releaseLock(), this.signal = void 0;
    };
    return {
      next: () => m(this, void 0, void 0, function* () {
        try {
          if (i != null && i.aborted)
            throw i.reason;
          const r = yield new Promise((o, a) => {
            if (i) {
              const c = () => a(i.reason);
              i.addEventListener("abort", c, {
                once: !0
              }), e.read().then(o, a).finally(() => {
                i.removeEventListener("abort", c);
              });
            } else
              e.read().then(o, a);
          });
          if (r.done)
            return this.validateBytesReceived(!0), {
              done: !0,
              value: void 0
            };
          {
            this.handleChunkReceived(r.value);
            let o;
            try {
              o = t.decode(r.value.content);
            } catch (a) {
              throw new ut("Cannot decode datastream chunk ".concat(r.value.chunkIndex, " as text: ").concat(a), Qe.DecodeFailed);
            }
            return {
              done: !1,
              value: o
            };
          }
        } catch (r) {
          throw s(), r;
        }
      }),
      // note: `return` runs only for premature exits, see:
      // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Iteration_protocols#errors_during_iteration
      return() {
        return m(this, void 0, void 0, function* () {
          return s(), {
            done: !0,
            value: void 0
          };
        });
      }
    };
  }
  /**
   * Injects an AbortSignal, which if aborted, will terminate the currently active
   * stream iteration operation.
   *
   * Note that when using AbortSignal.timeout(...), the timeout applies across
   * the whole iteration operation, not just one individual chunk read.
   */
  withAbortSignal(e) {
    return this.signal = e, this;
  }
  readAll() {
    return m(this, arguments, void 0, function() {
      var e = this;
      let t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      return (function* () {
        var i, s, r, o;
        let a = "";
        const c = t.signal ? e.withAbortSignal(t.signal) : e;
        try {
          for (var d = !0, l = Nt(c), u; u = yield l.next(), i = u.done, !i; d = !0)
            o = u.value, d = !1, a += o;
        } catch (h) {
          s = {
            error: h
          };
        } finally {
          try {
            !d && !i && (r = l.return) && (yield r.call(l));
          } finally {
            if (s) throw s.error;
          }
        }
        return a;
      })();
    });
  }
}
class Tm {
  constructor() {
    this.log = se, this.byteStreamControllers = /* @__PURE__ */ new Map(), this.textStreamControllers = /* @__PURE__ */ new Map(), this.byteStreamHandlers = /* @__PURE__ */ new Map(), this.textStreamHandlers = /* @__PURE__ */ new Map();
  }
  registerTextStreamHandler(e, t) {
    if (this.textStreamHandlers.has(e))
      throw new ut('A text stream handler for topic "'.concat(e, '" has already been set.'), Qe.HandlerAlreadyRegistered);
    this.textStreamHandlers.set(e, t);
  }
  unregisterTextStreamHandler(e) {
    this.textStreamHandlers.delete(e);
  }
  registerByteStreamHandler(e, t) {
    if (this.byteStreamHandlers.has(e))
      throw new ut('A byte stream handler for topic "'.concat(e, '" has already been set.'), Qe.HandlerAlreadyRegistered);
    this.byteStreamHandlers.set(e, t);
  }
  unregisterByteStreamHandler(e) {
    this.byteStreamHandlers.delete(e);
  }
  clearControllers() {
    this.byteStreamControllers.clear(), this.textStreamControllers.clear();
  }
  validateParticipantHasNoActiveDataStreams(e) {
    const t = Array.from(this.textStreamControllers.entries()).filter((s) => s[1].sendingParticipantIdentity === e), i = Array.from(this.byteStreamControllers.entries()).filter((s) => s[1].sendingParticipantIdentity === e);
    if (t.length > 0 || i.length > 0) {
      const s = new ut("Participant ".concat(e, " unexpectedly disconnected in the middle of sending data"), Qe.AbnormalEnd);
      for (const [r, o] of i)
        o.controller.error(s), this.byteStreamControllers.delete(r);
      for (const [r, o] of t)
        o.controller.error(s), this.textStreamControllers.delete(r);
    }
  }
  handleDataStreamPacket(e, t) {
    return m(this, void 0, void 0, function* () {
      switch (e.value.case) {
        case "streamHeader":
          return this.handleStreamHeader(e.value.value, e.participantIdentity, t);
        case "streamChunk":
          return this.handleStreamChunk(e.value.value, t);
        case "streamTrailer":
          return this.handleStreamTrailer(e.value.value, t);
        default:
          throw new Error('DataPacket of value "'.concat(e.value.case, '" is not data stream related!'));
      }
    });
  }
  handleStreamHeader(e, t, i) {
    return m(this, void 0, void 0, function* () {
      var s;
      if (e.contentHeader.case === "byteHeader") {
        const r = this.byteStreamHandlers.get(e.topic);
        if (!r) {
          this.log.debug("ignoring incoming byte stream due to no handler for topic", e.topic);
          return;
        }
        let o;
        const a = {
          id: e.streamId,
          name: (s = e.contentHeader.value.name) !== null && s !== void 0 ? s : "unknown",
          mimeType: e.mimeType,
          size: e.totalLength ? Number(e.totalLength) : void 0,
          topic: e.topic,
          timestamp: Nn(e.timestamp),
          attributes: e.attributes,
          encryptionType: i
        }, c = new ReadableStream({
          start: (d) => {
            if (o = d, this.textStreamControllers.has(e.streamId))
              throw new ut("A data stream read is already in progress for a stream with id ".concat(e.streamId, "."), Qe.AlreadyOpened);
            this.byteStreamControllers.set(e.streamId, {
              info: a,
              controller: o,
              startTime: Date.now(),
              sendingParticipantIdentity: t
            });
          }
        });
        r(new Sm(a, c, Nn(e.totalLength)), {
          identity: t
        });
      } else if (e.contentHeader.case === "textHeader") {
        const r = this.textStreamHandlers.get(e.topic);
        if (!r) {
          this.log.debug("ignoring incoming text stream due to no handler for topic", e.topic);
          return;
        }
        let o;
        const a = {
          id: e.streamId,
          mimeType: e.mimeType,
          size: e.totalLength ? Number(e.totalLength) : void 0,
          topic: e.topic,
          timestamp: Number(e.timestamp),
          attributes: e.attributes,
          encryptionType: i,
          attachedStreamIds: e.contentHeader.value.attachedStreamIds
        }, c = new ReadableStream({
          start: (d) => {
            if (o = d, this.textStreamControllers.has(e.streamId))
              throw new ut("A data stream read is already in progress for a stream with id ".concat(e.streamId, "."), Qe.AlreadyOpened);
            this.textStreamControllers.set(e.streamId, {
              info: a,
              controller: o,
              startTime: Date.now(),
              sendingParticipantIdentity: t
            });
          }
        });
        r(new km(a, c, Nn(e.totalLength)), {
          identity: t
        });
      }
    });
  }
  handleStreamChunk(e, t) {
    const i = this.byteStreamControllers.get(e.streamId);
    i && (i.info.encryptionType !== t ? (i.controller.error(new ut("Encryption type mismatch for stream ".concat(e.streamId, ". Expected ").concat(t, ", got ").concat(i.info.encryptionType), Qe.EncryptionTypeMismatch)), this.byteStreamControllers.delete(e.streamId)) : e.content.length > 0 && i.controller.enqueue(e));
    const s = this.textStreamControllers.get(e.streamId);
    s && (s.info.encryptionType !== t ? (s.controller.error(new ut("Encryption type mismatch for stream ".concat(e.streamId, ". Expected ").concat(t, ", got ").concat(s.info.encryptionType), Qe.EncryptionTypeMismatch)), this.textStreamControllers.delete(e.streamId)) : e.content.length > 0 && s.controller.enqueue(e));
  }
  handleStreamTrailer(e, t) {
    const i = this.textStreamControllers.get(e.streamId);
    i && (i.info.encryptionType !== t ? i.controller.error(new ut("Encryption type mismatch for stream ".concat(e.streamId, ". Expected ").concat(t, ", got ").concat(i.info.encryptionType), Qe.EncryptionTypeMismatch)) : (i.info.attributes = Object.assign(Object.assign({}, i.info.attributes), e.attributes), i.controller.close(), this.textStreamControllers.delete(e.streamId)));
    const s = this.byteStreamControllers.get(e.streamId);
    s && (s.info.encryptionType !== t ? s.controller.error(new ut("Encryption type mismatch for stream ".concat(e.streamId, ". Expected ").concat(t, ", got ").concat(s.info.encryptionType), Qe.EncryptionTypeMismatch)) : (s.info.attributes = Object.assign(Object.assign({}, s.info.attributes), e.attributes), s.controller.close()), this.byteStreamControllers.delete(e.streamId));
  }
}
class Hd {
  constructor(e, t, i) {
    this.writableStream = e, this.defaultWriter = e.getWriter(), this.onClose = i, this.info = t;
  }
  write(e) {
    return this.defaultWriter.write(e);
  }
  close() {
    return m(this, void 0, void 0, function* () {
      var e;
      yield this.defaultWriter.close(), this.defaultWriter.releaseLock(), (e = this.onClose) === null || e === void 0 || e.call(this);
    });
  }
}
class Cm extends Hd {
}
class _m extends Hd {
}
const wo = 15e3;
class wm {
  constructor(e, t) {
    this.engine = e, this.log = t;
  }
  setupEngine(e) {
    this.engine = e;
  }
  /** {@inheritDoc LocalParticipant.sendText} */
  sendText(e, t) {
    return m(this, void 0, void 0, function* () {
      var i;
      const s = crypto.randomUUID(), o = new TextEncoder().encode(e).byteLength, a = (i = t == null ? void 0 : t.attachments) === null || i === void 0 ? void 0 : i.map(() => crypto.randomUUID()), c = new Array(a ? a.length + 1 : 1).fill(0), d = (u, h) => {
        var p;
        c[h] = u;
        const b = c.reduce((v, C) => v + C, 0);
        (p = t == null ? void 0 : t.onProgress) === null || p === void 0 || p.call(t, b);
      }, l = yield this.streamText({
        streamId: s,
        totalSize: o,
        destinationIdentities: t == null ? void 0 : t.destinationIdentities,
        topic: t == null ? void 0 : t.topic,
        attachedStreamIds: a,
        attributes: t == null ? void 0 : t.attributes
      });
      return yield l.write(e), d(1, 0), yield l.close(), t != null && t.attachments && a && (yield Promise.all(t.attachments.map((u, h) => m(this, void 0, void 0, function* () {
        return this._sendFile(a[h], u, {
          topic: t.topic,
          mimeType: u.type,
          onProgress: (p) => {
            d(p, h + 1);
          }
        });
      })))), l.info;
    });
  }
  /**
   * @internal
   */
  streamText(e) {
    return m(this, void 0, void 0, function* () {
      var t, i, s;
      const r = (t = e == null ? void 0 : e.streamId) !== null && t !== void 0 ? t : crypto.randomUUID(), o = {
        id: r,
        mimeType: "text/plain",
        timestamp: Date.now(),
        topic: (i = e == null ? void 0 : e.topic) !== null && i !== void 0 ? i : "",
        size: e == null ? void 0 : e.totalSize,
        attributes: e == null ? void 0 : e.attributes,
        encryptionType: !((s = this.engine.e2eeManager) === null || s === void 0) && s.isDataChannelEncryptionEnabled ? Ne.GCM : Ne.NONE,
        attachedStreamIds: e == null ? void 0 : e.attachedStreamIds
      }, a = new Wn({
        streamId: r,
        mimeType: o.mimeType,
        topic: o.topic,
        timestamp: ri(o.timestamp),
        totalLength: ri(e == null ? void 0 : e.totalSize),
        attributes: o.attributes,
        contentHeader: {
          case: "textHeader",
          value: new Ac({
            version: e == null ? void 0 : e.version,
            attachedStreamIds: o.attachedStreamIds,
            replyToStreamId: e == null ? void 0 : e.replyToStreamId,
            operationType: (e == null ? void 0 : e.type) === "update" ? Gs.UPDATE : Gs.CREATE
          })
        }
      }), c = e == null ? void 0 : e.destinationIdentities, d = new Xe({
        destinationIdentities: c,
        value: {
          case: "streamHeader",
          value: a
        }
      });
      yield this.engine.sendDataPacket(d, oe.RELIABLE);
      let l = 0;
      const u = this.engine, h = new WritableStream({
        // Implement the sink
        write(v) {
          return m(this, void 0, void 0, function* () {
            for (const C of gp(v, wo)) {
              const T = new $n({
                content: C,
                streamId: r,
                chunkIndex: ri(l)
              }), P = new Xe({
                destinationIdentities: c,
                value: {
                  case: "streamChunk",
                  value: T
                }
              });
              yield u.sendDataPacket(P, oe.RELIABLE), l += 1;
            }
          });
        },
        close() {
          return m(this, void 0, void 0, function* () {
            const v = new zn({
              streamId: r
            }), C = new Xe({
              destinationIdentities: c,
              value: {
                case: "streamTrailer",
                value: v
              }
            });
            yield u.sendDataPacket(C, oe.RELIABLE);
          });
        },
        abort(v) {
          console.log("Sink error:", v);
        }
      });
      let p = () => m(this, void 0, void 0, function* () {
        yield b.close();
      });
      u.once(H.Closing, p);
      const b = new Cm(h, o, () => this.engine.off(H.Closing, p));
      return b;
    });
  }
  sendFile(e, t) {
    return m(this, void 0, void 0, function* () {
      const i = crypto.randomUUID();
      return yield this._sendFile(i, e, t), {
        id: i
      };
    });
  }
  _sendFile(e, t, i) {
    return m(this, void 0, void 0, function* () {
      var s;
      const r = yield this.streamBytes({
        streamId: e,
        totalSize: t.size,
        name: t.name,
        mimeType: (s = i == null ? void 0 : i.mimeType) !== null && s !== void 0 ? s : t.type,
        topic: i == null ? void 0 : i.topic,
        destinationIdentities: i == null ? void 0 : i.destinationIdentities
      }), o = t.stream().getReader();
      for (; ; ) {
        const {
          done: a,
          value: c
        } = yield o.read();
        if (a)
          break;
        yield r.write(c);
      }
      return yield r.close(), r.info;
    });
  }
  streamBytes(e) {
    return m(this, void 0, void 0, function* () {
      var t, i, s, r, o, a;
      const c = (t = e == null ? void 0 : e.streamId) !== null && t !== void 0 ? t : crypto.randomUUID(), d = e == null ? void 0 : e.destinationIdentities, l = {
        id: c,
        mimeType: (i = e == null ? void 0 : e.mimeType) !== null && i !== void 0 ? i : "application/octet-stream",
        topic: (s = e == null ? void 0 : e.topic) !== null && s !== void 0 ? s : "",
        timestamp: Date.now(),
        attributes: e == null ? void 0 : e.attributes,
        size: e == null ? void 0 : e.totalSize,
        name: (r = e == null ? void 0 : e.name) !== null && r !== void 0 ? r : "unknown",
        encryptionType: !((o = this.engine.e2eeManager) === null || o === void 0) && o.isDataChannelEncryptionEnabled ? Ne.GCM : Ne.NONE
      }, u = new Wn({
        totalLength: ri((a = l.size) !== null && a !== void 0 ? a : 0),
        mimeType: l.mimeType,
        streamId: c,
        topic: l.topic,
        timestamp: ri(Date.now()),
        attributes: l.attributes,
        contentHeader: {
          case: "byteHeader",
          value: new Oc({
            name: l.name
          })
        }
      }), h = new Xe({
        destinationIdentities: d,
        value: {
          case: "streamHeader",
          value: u
        }
      });
      yield this.engine.sendDataPacket(h, oe.RELIABLE);
      let p = 0;
      const b = new Ze(), v = this.engine, C = this.log, T = new WritableStream({
        write(R) {
          return m(this, void 0, void 0, function* () {
            const g = yield b.lock();
            let f = 0;
            try {
              for (; f < R.byteLength; ) {
                const k = R.slice(f, f + wo), w = new Xe({
                  destinationIdentities: d,
                  value: {
                    case: "streamChunk",
                    value: new $n({
                      content: k,
                      streamId: c,
                      chunkIndex: ri(p)
                    })
                  }
                });
                yield v.sendDataPacket(w, oe.RELIABLE), p += 1, f += k.byteLength;
              }
            } finally {
              g();
            }
          });
        },
        close() {
          return m(this, void 0, void 0, function* () {
            const R = new zn({
              streamId: c
            }), g = new Xe({
              destinationIdentities: d,
              value: {
                case: "streamTrailer",
                value: R
              }
            });
            yield v.sendDataPacket(g, oe.RELIABLE);
          });
        },
        abort(R) {
          C.error("Sink error:", R);
        }
      });
      return new _m(T, l);
    });
  }
}
class Wd extends E {
  constructor(e, t, i, s, r) {
    super(e, i, r), this.sid = t, this.receiver = s;
  }
  get isLocal() {
    return !1;
  }
  /** @internal */
  setMuted(e) {
    this.isMuted !== e && (this.isMuted = e, this._mediaStreamTrack.enabled = !e, this.emit(e ? U.Muted : U.Unmuted, this));
  }
  /** @internal */
  setMediaStream(e) {
    this.mediaStream = e;
    const t = (i) => {
      i.track === this._mediaStreamTrack && (e.removeEventListener("removetrack", t), this.receiver && "playoutDelayHint" in this.receiver && (this.receiver.playoutDelayHint = void 0), this.receiver = void 0, this._currentBitrate = 0, this.emit(U.Ended, this));
    };
    e.addEventListener("removetrack", t);
  }
  start() {
    this.startMonitor(), super.enable();
  }
  stop() {
    this.stopMonitor(), super.disable();
  }
  /**
   * Gets the RTCStatsReport for the RemoteTrack's underlying RTCRtpReceiver
   * See https://developer.mozilla.org/en-US/docs/Web/API/RTCStatsReport
   *
   * @returns Promise<RTCStatsReport> | undefined
   */
  getRTCStatsReport() {
    return m(this, void 0, void 0, function* () {
      var e;
      return !((e = this.receiver) === null || e === void 0) && e.getStats ? yield this.receiver.getStats() : void 0;
    });
  }
  /**
   * Allows to set a playout delay (in seconds) for this track.
   * A higher value allows for more buffering of the track in the browser
   * and will result in a delay of media being played back of `delayInSeconds`
   */
  setPlayoutDelay(e) {
    this.receiver ? "playoutDelayHint" in this.receiver ? this.receiver.playoutDelayHint = e : this.log.warn("Playout delay not supported in this browser") : this.log.warn("Cannot set playout delay, track already ended");
  }
  /**
   * Returns the current playout delay (in seconds) of this track.
   */
  getPlayoutDelay() {
    if (this.receiver) {
      if ("playoutDelayHint" in this.receiver)
        return this.receiver.playoutDelayHint;
      this.log.warn("Playout delay not supported in this browser");
    } else
      this.log.warn("Cannot get playout delay, track already ended");
    return 0;
  }
  /* @internal */
  startMonitor() {
    this.monitorInterval || (this.monitorInterval = setInterval(() => this.monitorReceiver(), Zr)), Gh() && this.registerTimeSyncUpdate();
  }
  registerTimeSyncUpdate() {
    const e = () => {
      var t;
      this.timeSyncHandle = requestAnimationFrame(() => e());
      const i = (t = this.receiver) === null || t === void 0 ? void 0 : t.getSynchronizationSources()[0];
      if (i) {
        const {
          timestamp: s,
          rtpTimestamp: r
        } = i;
        r && this.rtpTimestamp !== r && (this.emit(U.TimeSyncUpdate, {
          timestamp: s,
          rtpTimestamp: r
        }), this.rtpTimestamp = r);
      }
    };
    e();
  }
}
class Em extends Wd {
  constructor(e, t, i, s, r, o) {
    super(e, t, E.Kind.Audio, i, o), this.monitorReceiver = () => m(this, void 0, void 0, function* () {
      if (!this.receiver) {
        this._currentBitrate = 0;
        return;
      }
      const a = yield this.getReceiverStats();
      a && this.prevStats && this.receiver && (this._currentBitrate = ds(a, this.prevStats)), this.prevStats = a;
    }), this.audioContext = s, this.webAudioPluginNodes = [], r && (this.sinkId = r.deviceId);
  }
  /**
   * sets the volume for all attached audio elements
   */
  setVolume(e) {
    var t;
    for (const i of this.attachedElements)
      this.audioContext ? (t = this.gainNode) === null || t === void 0 || t.gain.setTargetAtTime(e, 0, 0.1) : i.volume = e;
    Rt() && this._mediaStreamTrack._setVolume(e), this.elementVolume = e;
  }
  /**
   * gets the volume of attached audio elements (loudest)
   */
  getVolume() {
    if (this.elementVolume)
      return this.elementVolume;
    if (Rt())
      return 1;
    let e = 0;
    return this.attachedElements.forEach((t) => {
      t.volume > e && (e = t.volume);
    }), e;
  }
  /**
   * calls setSinkId on all attached elements, if supported
   * @param deviceId audio output device
   */
  setSinkId(e) {
    return m(this, void 0, void 0, function* () {
      this.sinkId = e, yield Promise.all(this.attachedElements.map((t) => {
        if (ur(t))
          return t.setSinkId(e);
      }));
    });
  }
  attach(e) {
    const t = this.attachedElements.length === 0;
    return e ? super.attach(e) : e = super.attach(), this.sinkId && ur(e) && e.setSinkId(this.sinkId).catch((i) => {
      this.log.error("Failed to set sink id on remote audio track", i, this.logContext);
    }), this.audioContext && t && (this.log.debug("using audio context mapping", this.logContext), this.connectWebAudio(this.audioContext, e), e.volume = 0, e.muted = !0), this.elementVolume && this.setVolume(this.elementVolume), e;
  }
  detach(e) {
    let t;
    return e ? (t = super.detach(e), this.audioContext && (this.attachedElements.length > 0 ? this.connectWebAudio(this.audioContext, this.attachedElements[0]) : this.disconnectWebAudio())) : (t = super.detach(), this.disconnectWebAudio()), t;
  }
  /**
   * @internal
   * @experimental
   */
  setAudioContext(e) {
    this.audioContext = e, e && this.attachedElements.length > 0 ? this.connectWebAudio(e, this.attachedElements[0]) : e || this.disconnectWebAudio();
  }
  /**
   * @internal
   * @experimental
   * @param {AudioNode[]} nodes - An array of WebAudio nodes. These nodes should not be connected to each other when passed, as the sdk will take care of connecting them in the order of the array.
   */
  setWebAudioPlugins(e) {
    this.webAudioPluginNodes = e, this.attachedElements.length > 0 && this.audioContext && this.connectWebAudio(this.audioContext, this.attachedElements[0]);
  }
  connectWebAudio(e, t) {
    this.disconnectWebAudio(), this.sourceNode = e.createMediaStreamSource(t.srcObject);
    let i = this.sourceNode;
    this.webAudioPluginNodes.forEach((s) => {
      i.connect(s), i = s;
    }), this.gainNode = e.createGain(), i.connect(this.gainNode), this.gainNode.connect(e.destination), this.elementVolume && this.gainNode.gain.setTargetAtTime(this.elementVolume, 0, 0.1), e.state !== "running" && e.resume().then(() => {
      e.state !== "running" && this.emit(U.AudioPlaybackFailed, new Error("Audio Context couldn't be started automatically"));
    }).catch((s) => {
      this.emit(U.AudioPlaybackFailed, s);
    });
  }
  disconnectWebAudio() {
    var e, t;
    (e = this.gainNode) === null || e === void 0 || e.disconnect(), (t = this.sourceNode) === null || t === void 0 || t.disconnect(), this.gainNode = void 0, this.sourceNode = void 0;
  }
  getReceiverStats() {
    return m(this, void 0, void 0, function* () {
      if (!this.receiver || !this.receiver.getStats)
        return;
      const e = yield this.receiver.getStats();
      let t;
      return e.forEach((i) => {
        i.type === "inbound-rtp" && (t = {
          type: "audio",
          streamId: i.id,
          timestamp: i.timestamp,
          jitter: i.jitter,
          bytesReceived: i.bytesReceived,
          concealedSamples: i.concealedSamples,
          concealmentEvents: i.concealmentEvents,
          silentConcealedSamples: i.silentConcealedSamples,
          silentConcealmentEvents: i.silentConcealmentEvents,
          totalAudioEnergy: i.totalAudioEnergy,
          totalSamplesDuration: i.totalSamplesDuration
        });
      }), t;
    });
  }
}
const Os = 100;
class Rm extends Wd {
  constructor(e, t, i, s, r) {
    super(e, t, E.Kind.Video, i, r), this.elementInfos = [], this.monitorReceiver = () => m(this, void 0, void 0, function* () {
      if (!this.receiver) {
        this._currentBitrate = 0;
        return;
      }
      const o = yield this.getReceiverStats();
      o && this.prevStats && this.receiver && (this._currentBitrate = ds(o, this.prevStats)), this.prevStats = o;
    }), this.debouncedHandleResize = Jr(() => {
      this.updateDimensions();
    }, Os), this.adaptiveStreamSettings = s;
  }
  get isAdaptiveStream() {
    return this.adaptiveStreamSettings !== void 0;
  }
  setStreamState(e) {
    super.setStreamState(e), this.log.debug("setStreamState", e), this.isAdaptiveStream && e === E.StreamState.Active && this.updateVisibility();
  }
  /**
   * Note: When using adaptiveStream, you need to use remoteVideoTrack.attach() to add the track to a HTMLVideoElement, otherwise your video tracks might never start
   */
  get mediaStreamTrack() {
    return this._mediaStreamTrack;
  }
  /** @internal */
  setMuted(e) {
    super.setMuted(e), this.attachedElements.forEach((t) => {
      e ? Oi(this._mediaStreamTrack, t) : Ri(this._mediaStreamTrack, t);
    });
  }
  attach(e) {
    if (e ? super.attach(e) : e = super.attach(), this.adaptiveStreamSettings && this.elementInfos.find((t) => t.element === e) === void 0) {
      const t = new Im(e);
      this.observeElementInfo(t);
    }
    return e;
  }
  /**
   * Observe an ElementInfo for changes when adaptive streaming.
   * @param elementInfo
   * @internal
   */
  observeElementInfo(e) {
    this.adaptiveStreamSettings && this.elementInfos.find((t) => t === e) === void 0 ? (e.handleResize = () => {
      this.debouncedHandleResize();
    }, e.handleVisibilityChanged = () => {
      this.updateVisibility();
    }, this.elementInfos.push(e), e.observe(), this.debouncedHandleResize(), this.updateVisibility()) : this.log.warn("visibility resize observer not triggered", this.logContext);
  }
  /**
   * Stop observing an ElementInfo for changes.
   * @param elementInfo
   * @internal
   */
  stopObservingElementInfo(e) {
    if (!this.isAdaptiveStream) {
      this.log.warn("stopObservingElementInfo ignored", this.logContext);
      return;
    }
    const t = this.elementInfos.filter((i) => i === e);
    for (const i of t)
      i.stopObserving();
    this.elementInfos = this.elementInfos.filter((i) => i !== e), this.updateVisibility(), this.debouncedHandleResize();
  }
  detach(e) {
    let t = [];
    if (e)
      return this.stopObservingElement(e), super.detach(e);
    t = super.detach();
    for (const i of t)
      this.stopObservingElement(i);
    return t;
  }
  /** @internal */
  getDecoderImplementation() {
    var e;
    return (e = this.prevStats) === null || e === void 0 ? void 0 : e.decoderImplementation;
  }
  getReceiverStats() {
    return m(this, void 0, void 0, function* () {
      if (!this.receiver || !this.receiver.getStats)
        return;
      const e = yield this.receiver.getStats();
      let t, i = "", s = /* @__PURE__ */ new Map();
      return e.forEach((r) => {
        r.type === "inbound-rtp" ? (i = r.codecId, t = {
          type: "video",
          streamId: r.id,
          framesDecoded: r.framesDecoded,
          framesDropped: r.framesDropped,
          framesReceived: r.framesReceived,
          packetsReceived: r.packetsReceived,
          packetsLost: r.packetsLost,
          frameWidth: r.frameWidth,
          frameHeight: r.frameHeight,
          pliCount: r.pliCount,
          firCount: r.firCount,
          nackCount: r.nackCount,
          jitter: r.jitter,
          timestamp: r.timestamp,
          bytesReceived: r.bytesReceived,
          decoderImplementation: r.decoderImplementation
        }) : r.type === "codec" && s.set(r.id, r);
      }), t && i !== "" && s.get(i) && (t.mimeType = s.get(i).mimeType), t;
    });
  }
  stopObservingElement(e) {
    const t = this.elementInfos.filter((i) => i.element === e);
    for (const i of t)
      this.stopObservingElementInfo(i);
  }
  handleAppVisibilityChanged() {
    const e = Object.create(null, {
      handleAppVisibilityChanged: {
        get: () => super.handleAppVisibilityChanged
      }
    });
    return m(this, void 0, void 0, function* () {
      yield e.handleAppVisibilityChanged.call(this), this.isAdaptiveStream && this.updateVisibility();
    });
  }
  updateVisibility(e) {
    var t, i;
    const s = this.elementInfos.reduce((c, d) => Math.max(c, d.visibilityChangedAt || 0), 0), r = !((i = (t = this.adaptiveStreamSettings) === null || t === void 0 ? void 0 : t.pauseVideoInBackground) !== null && i !== void 0) || i ? this.isInBackground : !1, o = this.elementInfos.some((c) => c.pictureInPicture), a = this.elementInfos.some((c) => c.visible) && !r || o;
    if (!(this.lastVisible === a && !e)) {
      if (!a && Date.now() - s < Os) {
        Be.setTimeout(() => {
          this.updateVisibility();
        }, Os);
        return;
      }
      this.lastVisible = a, this.emit(U.VisibilityChanged, a, this);
    }
  }
  updateDimensions() {
    var e, t;
    let i = 0, s = 0;
    const r = this.getPixelDensity();
    for (const o of this.elementInfos) {
      const a = o.width() * r, c = o.height() * r;
      a + c > i + s && (i = a, s = c);
    }
    ((e = this.lastDimensions) === null || e === void 0 ? void 0 : e.width) === i && ((t = this.lastDimensions) === null || t === void 0 ? void 0 : t.height) === s || (this.lastDimensions = {
      width: i,
      height: s
    }, this.emit(U.VideoDimensionsChanged, this.lastDimensions, this));
  }
  getPixelDensity() {
    var e;
    const t = (e = this.adaptiveStreamSettings) === null || e === void 0 ? void 0 : e.pixelDensity;
    return t === "screen" ? Xa() : t || (Xa() > 2 ? 2 : 1);
  }
}
class Im {
  get visible() {
    return this.isPiP || this.isIntersecting;
  }
  get pictureInPicture() {
    return this.isPiP;
  }
  constructor(e, t) {
    this.onVisibilityChanged = (i) => {
      var s;
      const {
        target: r,
        isIntersecting: o
      } = i;
      r === this.element && (this.isIntersecting = o, this.isPiP = Ji(this.element), this.visibilityChangedAt = Date.now(), (s = this.handleVisibilityChanged) === null || s === void 0 || s.call(this));
    }, this.onEnterPiP = () => {
      var i, s, r;
      (s = (i = window.documentPictureInPicture) === null || i === void 0 ? void 0 : i.window) === null || s === void 0 || s.addEventListener("pagehide", this.onLeavePiP), this.isPiP = Ji(this.element), (r = this.handleVisibilityChanged) === null || r === void 0 || r.call(this);
    }, this.onLeavePiP = () => {
      var i;
      this.isPiP = Ji(this.element), (i = this.handleVisibilityChanged) === null || i === void 0 || i.call(this);
    }, this.element = e, this.isIntersecting = t != null ? t : vr(e), this.isPiP = it() && Ji(e), this.visibilityChangedAt = 0;
  }
  width() {
    return this.element.clientWidth;
  }
  height() {
    return this.element.clientHeight;
  }
  observe() {
    var e, t, i;
    this.isIntersecting = vr(this.element), this.isPiP = Ji(this.element), this.element.handleResize = () => {
      var s;
      (s = this.handleResize) === null || s === void 0 || s.call(this);
    }, this.element.handleVisibilityChanged = this.onVisibilityChanged, eo().observe(this.element), Za().observe(this.element), this.element.addEventListener("enterpictureinpicture", this.onEnterPiP), this.element.addEventListener("leavepictureinpicture", this.onLeavePiP), (e = window.documentPictureInPicture) === null || e === void 0 || e.addEventListener("enter", this.onEnterPiP), (i = (t = window.documentPictureInPicture) === null || t === void 0 ? void 0 : t.window) === null || i === void 0 || i.addEventListener("pagehide", this.onLeavePiP);
  }
  stopObserving() {
    var e, t, i, s, r;
    (e = eo()) === null || e === void 0 || e.unobserve(this.element), (t = Za()) === null || t === void 0 || t.unobserve(this.element), this.element.removeEventListener("enterpictureinpicture", this.onEnterPiP), this.element.removeEventListener("leavepictureinpicture", this.onLeavePiP), (i = window.documentPictureInPicture) === null || i === void 0 || i.removeEventListener("enter", this.onEnterPiP), (r = (s = window.documentPictureInPicture) === null || s === void 0 ? void 0 : s.window) === null || r === void 0 || r.removeEventListener("pagehide", this.onLeavePiP);
  }
}
function Ji(n) {
  var e, t;
  return document.pictureInPictureElement === n ? !0 : !((e = window.documentPictureInPicture) === null || e === void 0) && e.window ? vr(n, (t = window.documentPictureInPicture) === null || t === void 0 ? void 0 : t.window) : !1;
}
function vr(n, e) {
  const t = e || window;
  let i = n.offsetTop, s = n.offsetLeft;
  const r = n.offsetWidth, o = n.offsetHeight, {
    hidden: a
  } = n, {
    display: c
  } = getComputedStyle(n);
  for (; n.offsetParent; )
    n = n.offsetParent, i += n.offsetTop, s += n.offsetLeft;
  return i < t.pageYOffset + t.innerHeight && s < t.pageXOffset + t.innerWidth && i + o > t.pageYOffset && s + r > t.pageXOffset && !a && c !== "none";
}
class Ot extends Pt.EventEmitter {
  constructor(e, t, i, s) {
    var r;
    super(), this.metadataMuted = !1, this.encryption = Ne.NONE, this.log = se, this.handleMuted = () => {
      this.emit(U.Muted);
    }, this.handleUnmuted = () => {
      this.emit(U.Unmuted);
    }, this.log = St((r = s == null ? void 0 : s.loggerName) !== null && r !== void 0 ? r : at.Publication), this.loggerContextCb = this.loggerContextCb, this.setMaxListeners(100), this.kind = e, this.trackSid = t, this.trackName = i, this.source = E.Source.Unknown;
  }
  /** @internal */
  setTrack(e) {
    this.track && (this.track.off(U.Muted, this.handleMuted), this.track.off(U.Unmuted, this.handleUnmuted)), this.track = e, e && (e.on(U.Muted, this.handleMuted), e.on(U.Unmuted, this.handleUnmuted));
  }
  get logContext() {
    var e;
    return Object.assign(Object.assign({}, (e = this.loggerContextCb) === null || e === void 0 ? void 0 : e.call(this)), ue(this));
  }
  get isMuted() {
    return this.metadataMuted;
  }
  get isEnabled() {
    return !0;
  }
  get isSubscribed() {
    return this.track !== void 0;
  }
  get isEncrypted() {
    return this.encryption !== Ne.NONE;
  }
  /**
   * an [AudioTrack] if this publication holds an audio track
   */
  get audioTrack() {
    if (Et(this.track))
      return this.track;
  }
  /**
   * an [VideoTrack] if this publication holds a video track
   */
  get videoTrack() {
    if (Zt(this.track))
      return this.track;
  }
  /** @internal */
  updateInfo(e) {
    this.trackSid = e.sid, this.trackName = e.name, this.source = E.sourceFromProto(e.source), this.mimeType = e.mimeType, this.kind === E.Kind.Video && e.width > 0 && (this.dimensions = {
      width: e.width,
      height: e.height
    }, this.simulcasted = e.simulcast), this.encryption = e.encryption, this.trackInfo = e, this.log.debug("update publication info", Object.assign(Object.assign({}, this.logContext), {
      info: e
    }));
  }
}
(function(n) {
  (function(e) {
    e.Desired = "desired", e.Subscribed = "subscribed", e.Unsubscribed = "unsubscribed";
  })(n.SubscriptionStatus || (n.SubscriptionStatus = {})), (function(e) {
    e.Allowed = "allowed", e.NotAllowed = "not_allowed";
  })(n.PermissionStatus || (n.PermissionStatus = {}));
})(Ot || (Ot = {}));
class br extends Ot {
  get isUpstreamPaused() {
    var e;
    return (e = this.track) === null || e === void 0 ? void 0 : e.isUpstreamPaused;
  }
  constructor(e, t, i, s) {
    super(e, t.sid, t.name, s), this.track = void 0, this.handleTrackEnded = () => {
      this.emit(U.Ended);
    }, this.handleCpuConstrained = () => {
      this.track && Zt(this.track) && this.emit(U.CpuConstrained, this.track);
    }, this.updateInfo(t), this.setTrack(i);
  }
  setTrack(e) {
    this.track && (this.track.off(U.Ended, this.handleTrackEnded), this.track.off(U.CpuConstrained, this.handleCpuConstrained)), super.setTrack(e), e && (e.on(U.Ended, this.handleTrackEnded), e.on(U.CpuConstrained, this.handleCpuConstrained));
  }
  get isMuted() {
    return this.track ? this.track.isMuted : super.isMuted;
  }
  get audioTrack() {
    return super.audioTrack;
  }
  get videoTrack() {
    return super.videoTrack;
  }
  get isLocal() {
    return !0;
  }
  /**
   * Mute the track associated with this publication
   */
  mute() {
    return m(this, void 0, void 0, function* () {
      var e;
      return (e = this.track) === null || e === void 0 ? void 0 : e.mute();
    });
  }
  /**
   * Unmute track associated with this publication
   */
  unmute() {
    return m(this, void 0, void 0, function* () {
      var e;
      return (e = this.track) === null || e === void 0 ? void 0 : e.unmute();
    });
  }
  /**
   * Pauses the media stream track associated with this publication from being sent to the server
   * and signals "muted" event to other participants
   * Useful if you want to pause the stream without pausing the local media stream track
   */
  pauseUpstream() {
    return m(this, void 0, void 0, function* () {
      var e;
      yield (e = this.track) === null || e === void 0 ? void 0 : e.pauseUpstream();
    });
  }
  /**
   * Resumes sending the media stream track associated with this publication to the server after a call to [[pauseUpstream()]]
   * and signals "unmuted" event to other participants (unless the track is explicitly muted)
   */
  resumeUpstream() {
    return m(this, void 0, void 0, function* () {
      var e;
      yield (e = this.track) === null || e === void 0 ? void 0 : e.resumeUpstream();
    });
  }
  getTrackFeatures() {
    var e;
    if (Et(this.track)) {
      const t = this.track.getSourceTrackSettings(), i = /* @__PURE__ */ new Set();
      return t.autoGainControl && i.add(He.TF_AUTO_GAIN_CONTROL), t.echoCancellation && i.add(He.TF_ECHO_CANCELLATION), t.noiseSuppression && i.add(He.TF_NOISE_SUPPRESSION), t.channelCount && t.channelCount > 1 && i.add(He.TF_STEREO), !((e = this.options) === null || e === void 0) && e.dtx || i.add(He.TF_NO_DTX), this.track.enhancedNoiseCancellation && i.add(He.TF_ENHANCED_NOISE_CANCELLATION), Array.from(i.values());
    } else return [];
  }
}
function ls(n, e) {
  return m(this, void 0, void 0, function* () {
    n != null || (n = {});
    let t = !1;
    const {
      audioProcessor: i,
      videoProcessor: s,
      optionsWithoutProcessor: r
    } = xd(n);
    let o = r.audio, a = r.video;
    if (i && typeof r.audio == "object" && (r.audio.processor = i), s && typeof r.video == "object" && (r.video.processor = s), n.audio && typeof r.audio == "object" && typeof r.audio.deviceId == "string") {
      const u = r.audio.deviceId;
      r.audio.deviceId = {
        exact: u
      }, t = !0, o = Object.assign(Object.assign({}, r.audio), {
        deviceId: {
          ideal: u
        }
      });
    }
    if (r.video && typeof r.video == "object" && typeof r.video.deviceId == "string") {
      const u = r.video.deviceId;
      r.video.deviceId = {
        exact: u
      }, t = !0, a = Object.assign(Object.assign({}, r.video), {
        deviceId: {
          ideal: u
        }
      });
    }
    r.audio === !0 ? r.audio = {
      deviceId: "default"
    } : typeof r.audio == "object" && r.audio !== null && (r.audio = Object.assign(Object.assign({}, r.audio), {
      deviceId: r.audio.deviceId || "default"
    })), r.video === !0 ? r.video = {
      deviceId: "default"
    } : typeof r.video == "object" && !r.video.deviceId && (r.video.deviceId = "default");
    const c = Rd(r, Ld, Nd), d = $r(c), l = navigator.mediaDevices.getUserMedia(d);
    r.audio && (We.userMediaPromiseMap.set("audioinput", l), l.catch(() => We.userMediaPromiseMap.delete("audioinput"))), r.video && (We.userMediaPromiseMap.set("videoinput", l), l.catch(() => We.userMediaPromiseMap.delete("videoinput")));
    try {
      const u = yield l;
      return yield Promise.all(u.getTracks().map((h) => m(this, void 0, void 0, function* () {
        const p = h.kind === "audio";
        let b = p ? c.audio : c.video;
        (typeof b == "boolean" || !b) && (b = {});
        let v;
        const C = p ? d.audio : d.video;
        typeof C != "boolean" && (v = C);
        const T = h.getSettings().deviceId;
        v != null && v.deviceId && ci(v.deviceId) !== T ? v.deviceId = T : v || (v = {
          deviceId: T
        });
        const P = im(h, v, e);
        return P.kind === E.Kind.Video ? P.source = E.Source.Camera : P.kind === E.Kind.Audio && (P.source = E.Source.Microphone), P.mediaStream = u, Et(P) && i ? yield P.setProcessor(i) : Zt(P) && s && (yield P.setProcessor(s)), P;
      })));
    } catch (u) {
      if (!t)
        throw u;
      return ls(Object.assign(Object.assign({}, n), {
        audio: o,
        video: a
      }), e);
    }
  });
}
function Pm(n) {
  return m(this, void 0, void 0, function* () {
    return (yield ls({
      audio: !1,
      video: !0
    }))[0];
  });
}
function xm(n) {
  return m(this, void 0, void 0, function* () {
    return (yield ls({
      audio: !0,
      video: !1
    }))[0];
  });
}
var Wt;
(function(n) {
  n.Excellent = "excellent", n.Good = "good", n.Poor = "poor", n.Lost = "lost", n.Unknown = "unknown";
})(Wt || (Wt = {}));
function Mm(n) {
  switch (n) {
    case en.EXCELLENT:
      return Wt.Excellent;
    case en.GOOD:
      return Wt.Good;
    case en.POOR:
      return Wt.Poor;
    case en.LOST:
      return Wt.Lost;
    default:
      return Wt.Unknown;
  }
}
class $d extends Pt.EventEmitter {
  get logContext() {
    var e, t;
    return Object.assign({}, (t = (e = this.loggerOptions) === null || e === void 0 ? void 0 : e.loggerContextCb) === null || t === void 0 ? void 0 : t.call(e));
  }
  get isEncrypted() {
    return this.trackPublications.size > 0 && Array.from(this.trackPublications.values()).every((e) => e.isEncrypted);
  }
  get isAgent() {
    var e;
    return ((e = this.permissions) === null || e === void 0 ? void 0 : e.agent) || this.kind === cn.AGENT;
  }
  get isActive() {
    var e;
    return ((e = this.participantInfo) === null || e === void 0 ? void 0 : e.state) === xi.ACTIVE;
  }
  get kind() {
    return this._kind;
  }
  /** participant attributes, similar to metadata, but as a key/value map */
  get attributes() {
    return Object.freeze(Object.assign({}, this._attributes));
  }
  /** @internal */
  constructor(e, t, i, s, r, o) {
    let a = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : cn.STANDARD;
    var c;
    super(), this.audioLevel = 0, this.isSpeaking = !1, this._connectionQuality = Wt.Unknown, this.log = se, this.log = St((c = o == null ? void 0 : o.loggerName) !== null && c !== void 0 ? c : at.Participant), this.loggerOptions = o, this.setMaxListeners(100), this.sid = e, this.identity = t, this.name = i, this.metadata = s, this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.trackPublications = /* @__PURE__ */ new Map(), this._kind = a, this._attributes = r != null ? r : {};
  }
  getTrackPublications() {
    return Array.from(this.trackPublications.values());
  }
  /**
   * Finds the first track that matches the source filter, for example, getting
   * the user's camera track with getTrackBySource(Track.Source.Camera).
   */
  getTrackPublication(e) {
    for (const [, t] of this.trackPublications)
      if (t.source === e)
        return t;
  }
  /**
   * Finds the first track that matches the track's name.
   */
  getTrackPublicationByName(e) {
    for (const [, t] of this.trackPublications)
      if (t.trackName === e)
        return t;
  }
  /**
   * Waits until the participant is active and ready to receive data messages
   * @returns a promise that resolves when the participant is active
   */
  waitUntilActive() {
    return this.isActive ? Promise.resolve() : this.activeFuture ? this.activeFuture.promise : (this.activeFuture = new $t(), this.once(W.Active, () => {
      var e, t;
      (t = (e = this.activeFuture) === null || e === void 0 ? void 0 : e.resolve) === null || t === void 0 || t.call(e), this.activeFuture = void 0;
    }), this.activeFuture.promise);
  }
  get connectionQuality() {
    return this._connectionQuality;
  }
  get isCameraEnabled() {
    var e;
    const t = this.getTrackPublication(E.Source.Camera);
    return !(!((e = t == null ? void 0 : t.isMuted) !== null && e !== void 0) || e);
  }
  get isMicrophoneEnabled() {
    var e;
    const t = this.getTrackPublication(E.Source.Microphone);
    return !(!((e = t == null ? void 0 : t.isMuted) !== null && e !== void 0) || e);
  }
  get isScreenShareEnabled() {
    return !!this.getTrackPublication(E.Source.ScreenShare);
  }
  get isLocal() {
    return !1;
  }
  /** when participant joined the room */
  get joinedAt() {
    return this.participantInfo ? new Date(Number.parseInt(this.participantInfo.joinedAt.toString()) * 1e3) : /* @__PURE__ */ new Date();
  }
  /** @internal */
  updateInfo(e) {
    var t;
    return this.participantInfo && this.participantInfo.sid === e.sid && this.participantInfo.version > e.version ? !1 : (this.identity = e.identity, this.sid = e.sid, this._setName(e.name), this._setMetadata(e.metadata), this._setAttributes(e.attributes), e.state === xi.ACTIVE && ((t = this.participantInfo) === null || t === void 0 ? void 0 : t.state) !== xi.ACTIVE && this.emit(W.Active), e.permission && this.setPermissions(e.permission), this.participantInfo = e, !0);
  }
  /**
   * Updates metadata from server
   **/
  _setMetadata(e) {
    const t = this.metadata !== e, i = this.metadata;
    this.metadata = e, t && this.emit(W.ParticipantMetadataChanged, i);
  }
  _setName(e) {
    const t = this.name !== e;
    this.name = e, t && this.emit(W.ParticipantNameChanged, e);
  }
  /**
   * Updates metadata from server
   **/
  _setAttributes(e) {
    const t = Jh(this.attributes, e);
    this._attributes = e, Object.keys(t).length > 0 && this.emit(W.AttributesChanged, t);
  }
  /** @internal */
  setPermissions(e) {
    var t, i, s, r, o, a;
    const c = this.permissions, d = e.canPublish !== ((t = this.permissions) === null || t === void 0 ? void 0 : t.canPublish) || e.canSubscribe !== ((i = this.permissions) === null || i === void 0 ? void 0 : i.canSubscribe) || e.canPublishData !== ((s = this.permissions) === null || s === void 0 ? void 0 : s.canPublishData) || e.hidden !== ((r = this.permissions) === null || r === void 0 ? void 0 : r.hidden) || e.recorder !== ((o = this.permissions) === null || o === void 0 ? void 0 : o.recorder) || e.canPublishSources.length !== this.permissions.canPublishSources.length || e.canPublishSources.some((l, u) => {
      var h;
      return l !== ((h = this.permissions) === null || h === void 0 ? void 0 : h.canPublishSources[u]);
    }) || e.canSubscribeMetrics !== ((a = this.permissions) === null || a === void 0 ? void 0 : a.canSubscribeMetrics);
    return this.permissions = e, d && this.emit(W.ParticipantPermissionsChanged, c), d;
  }
  /** @internal */
  setIsSpeaking(e) {
    e !== this.isSpeaking && (this.isSpeaking = e, e && (this.lastSpokeAt = /* @__PURE__ */ new Date()), this.emit(W.IsSpeakingChanged, e));
  }
  /** @internal */
  setConnectionQuality(e) {
    const t = this._connectionQuality;
    this._connectionQuality = Mm(e), t !== this._connectionQuality && this.emit(W.ConnectionQualityChanged, this._connectionQuality);
  }
  /**
   * @internal
   */
  setDisconnected() {
    var e, t;
    this.activeFuture && ((t = (e = this.activeFuture).reject) === null || t === void 0 || t.call(e, new Error("Participant disconnected")), this.activeFuture = void 0);
  }
  /**
   * @internal
   */
  setAudioContext(e) {
    this.audioContext = e, this.audioTrackPublications.forEach((t) => Et(t.track) && t.track.setAudioContext(e));
  }
  addTrackPublication(e) {
    e.on(U.Muted, () => {
      this.emit(W.TrackMuted, e);
    }), e.on(U.Unmuted, () => {
      this.emit(W.TrackUnmuted, e);
    });
    const t = e;
    switch (t.track && (t.track.sid = e.trackSid), this.trackPublications.set(e.trackSid, e), e.kind) {
      case E.Kind.Audio:
        this.audioTrackPublications.set(e.trackSid, e);
        break;
      case E.Kind.Video:
        this.videoTrackPublications.set(e.trackSid, e);
        break;
    }
  }
}
function Am(n) {
  var e, t, i;
  if (!n.participantSid && !n.participantIdentity)
    throw new Error("Invalid track permission, must provide at least one of participantIdentity and participantSid");
  return new jc({
    participantIdentity: (e = n.participantIdentity) !== null && e !== void 0 ? e : "",
    participantSid: (t = n.participantSid) !== null && t !== void 0 ? t : "",
    allTracks: (i = n.allowAll) !== null && i !== void 0 ? i : !1,
    trackSids: n.allowedTrackSids || []
  });
}
class Om extends $d {
  /** @internal */
  constructor(e, t, i, s, r, o) {
    super(e, t, void 0, void 0, void 0, {
      loggerName: s.loggerName,
      loggerContextCb: () => this.engine.logContext
    }), this.pendingPublishing = /* @__PURE__ */ new Set(), this.pendingPublishPromises = /* @__PURE__ */ new Map(), this.participantTrackPermissions = [], this.allParticipantsAllowedToSubscribe = !0, this.encryptionType = Ne.NONE, this.enabledPublishVideoCodecs = [], this.pendingAcks = /* @__PURE__ */ new Map(), this.pendingResponses = /* @__PURE__ */ new Map(), this.handleReconnecting = () => {
      this.reconnectFuture || (this.reconnectFuture = new $t());
    }, this.handleReconnected = () => {
      var a, c;
      (c = (a = this.reconnectFuture) === null || a === void 0 ? void 0 : a.resolve) === null || c === void 0 || c.call(a), this.reconnectFuture = void 0, this.updateTrackSubscriptionPermissions();
    }, this.handleClosing = () => {
      var a, c, d, l, u, h;
      this.reconnectFuture && (this.reconnectFuture.promise.catch((p) => this.log.warn(p.message, this.logContext)), (c = (a = this.reconnectFuture) === null || a === void 0 ? void 0 : a.reject) === null || c === void 0 || c.call(a, new Error("Got disconnected during reconnection attempt")), this.reconnectFuture = void 0), this.signalConnectedFuture && ((l = (d = this.signalConnectedFuture).reject) === null || l === void 0 || l.call(d, new Error("Got disconnected without signal connected")), this.signalConnectedFuture = void 0), (h = (u = this.activeAgentFuture) === null || u === void 0 ? void 0 : u.reject) === null || h === void 0 || h.call(u, new Error("Got disconnected without active agent present")), this.activeAgentFuture = void 0, this.firstActiveAgent = void 0;
    }, this.handleSignalConnected = (a) => {
      var c, d;
      a.participant && this.updateInfo(a.participant), this.signalConnectedFuture || (this.signalConnectedFuture = new $t()), (d = (c = this.signalConnectedFuture).resolve) === null || d === void 0 || d.call(c);
    }, this.handleSignalRequestResponse = (a) => {
      const {
        requestId: c,
        reason: d,
        message: l
      } = a, u = this.pendingSignalRequests.get(c);
      u && (d !== Br.OK && u.reject(new Ka(l, d)), this.pendingSignalRequests.delete(c));
    }, this.handleDataPacket = (a) => {
      switch (a.value.case) {
        case "rpcResponse":
          let c = a.value.value, d = null, l = null;
          c.value.case === "payload" ? d = c.value.value : c.value.case === "error" && (l = Oe.fromProto(c.value.value)), this.handleIncomingRpcResponse(c.requestId, d, l);
          break;
        case "rpcAck":
          let u = a.value.value;
          this.handleIncomingRpcAck(u.requestId);
          break;
      }
    }, this.updateTrackSubscriptionPermissions = () => {
      this.log.debug("updating track subscription permissions", Object.assign(Object.assign({}, this.logContext), {
        allParticipantsAllowed: this.allParticipantsAllowedToSubscribe,
        participantTrackPermissions: this.participantTrackPermissions
      })), this.engine.client.sendUpdateSubscriptionPermissions(this.allParticipantsAllowedToSubscribe, this.participantTrackPermissions.map((a) => Am(a)));
    }, this.onTrackUnmuted = (a) => {
      this.onTrackMuted(a, a.isUpstreamPaused);
    }, this.onTrackMuted = (a, c) => {
      if (c === void 0 && (c = !0), !a.sid) {
        this.log.error("could not update mute status for unpublished track", Object.assign(Object.assign({}, this.logContext), ue(a)));
        return;
      }
      this.engine.updateMuteStatus(a.sid, c);
    }, this.onTrackUpstreamPaused = (a) => {
      this.log.debug("upstream paused", Object.assign(Object.assign({}, this.logContext), ue(a))), this.onTrackMuted(a, !0);
    }, this.onTrackUpstreamResumed = (a) => {
      this.log.debug("upstream resumed", Object.assign(Object.assign({}, this.logContext), ue(a))), this.onTrackMuted(a, a.isMuted);
    }, this.onTrackFeatureUpdate = (a) => {
      const c = this.audioTrackPublications.get(a.sid);
      if (!c) {
        this.log.warn("Could not update local audio track settings, missing publication for track ".concat(a.sid), this.logContext);
        return;
      }
      this.engine.client.sendUpdateLocalAudioTrack(c.trackSid, c.getTrackFeatures());
    }, this.onTrackCpuConstrained = (a, c) => {
      this.log.debug("track cpu constrained", Object.assign(Object.assign({}, this.logContext), ue(c))), this.emit(W.LocalTrackCpuConstrained, a, c);
    }, this.handleSubscribedQualityUpdate = (a) => m(this, void 0, void 0, function* () {
      var c, d, l, u, h;
      if (!(!((h = this.roomOptions) === null || h === void 0) && h.dynacast))
        return;
      const p = this.videoTrackPublications.get(a.trackSid);
      if (!p) {
        this.log.warn("received subscribed quality update for unknown track", Object.assign(Object.assign({}, this.logContext), {
          trackSid: a.trackSid
        }));
        return;
      }
      if (!p.videoTrack)
        return;
      const b = yield p.videoTrack.setPublishingCodecs(a.subscribedCodecs);
      try {
        for (var v = !0, C = Nt(b), T; T = yield C.next(), c = T.done, !c; v = !0) {
          u = T.value, v = !1;
          const P = u;
          Wh(P) && (this.log.debug("publish ".concat(P, " for ").concat(p.videoTrack.sid), Object.assign(Object.assign({}, this.logContext), ue(p))), yield this.publishAdditionalCodecForTrack(p.videoTrack, P, p.options));
        }
      } catch (P) {
        d = {
          error: P
        };
      } finally {
        try {
          !v && !c && (l = C.return) && (yield l.call(C));
        } finally {
          if (d) throw d.error;
        }
      }
    }), this.handleLocalTrackUnpublished = (a) => {
      const c = this.trackPublications.get(a.trackSid);
      if (!c) {
        this.log.warn("received unpublished event for unknown track", Object.assign(Object.assign({}, this.logContext), {
          trackSid: a.trackSid
        }));
        return;
      }
      this.unpublishTrack(c.track);
    }, this.handleTrackEnded = (a) => m(this, void 0, void 0, function* () {
      if (a.source === E.Source.ScreenShare || a.source === E.Source.ScreenShareAudio)
        this.log.debug("unpublishing local track due to TrackEnded", Object.assign(Object.assign({}, this.logContext), ue(a))), this.unpublishTrack(a);
      else if (a.isUserProvided)
        yield a.mute();
      else if (At(a) || jt(a))
        try {
          if (it())
            try {
              const c = yield navigator == null ? void 0 : navigator.permissions.query({
                // the permission query for camera and microphone currently not supported in Safari and Firefox
                // @ts-ignore
                name: a.source === E.Source.Camera ? "camera" : "microphone"
              });
              if (c && c.state === "denied")
                throw this.log.warn("user has revoked access to ".concat(a.source), Object.assign(Object.assign({}, this.logContext), ue(a))), c.onchange = () => {
                  c.state !== "denied" && (a.isMuted || a.restartTrack(), c.onchange = null);
                }, new Error("GetUserMedia Permission denied");
            } catch {
            }
          a.isMuted || (this.log.debug("track ended, attempting to use a different device", Object.assign(Object.assign({}, this.logContext), ue(a))), At(a) ? yield a.restartTrack({
            deviceId: "default"
          }) : yield a.restartTrack());
        } catch {
          this.log.warn("could not restart track, muting instead", Object.assign(Object.assign({}, this.logContext), ue(a))), yield a.mute();
        }
    }), this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.trackPublications = /* @__PURE__ */ new Map(), this.engine = i, this.roomOptions = s, this.setupEngine(i), this.activeDeviceMap = /* @__PURE__ */ new Map([["audioinput", "default"], ["videoinput", "default"], ["audiooutput", "default"]]), this.pendingSignalRequests = /* @__PURE__ */ new Map(), this.rpcHandlers = r, this.roomOutgoingDataStreamManager = o;
  }
  get lastCameraError() {
    return this.cameraError;
  }
  get lastMicrophoneError() {
    return this.microphoneError;
  }
  get isE2EEEnabled() {
    return this.encryptionType !== Ne.NONE;
  }
  getTrackPublication(e) {
    const t = super.getTrackPublication(e);
    if (t)
      return t;
  }
  getTrackPublicationByName(e) {
    const t = super.getTrackPublicationByName(e);
    if (t)
      return t;
  }
  /**
   * @internal
   */
  setupEngine(e) {
    var t;
    this.engine = e, this.engine.on(H.RemoteMute, (i, s) => {
      const r = this.trackPublications.get(i);
      !r || !r.track || (s ? r.mute() : r.unmute());
    }), !((t = this.signalConnectedFuture) === null || t === void 0) && t.isResolved && (this.signalConnectedFuture = void 0), this.engine.on(H.Connected, this.handleReconnected).on(H.SignalConnected, this.handleSignalConnected).on(H.SignalRestarted, this.handleReconnected).on(H.SignalResumed, this.handleReconnected).on(H.Restarting, this.handleReconnecting).on(H.Resuming, this.handleReconnecting).on(H.LocalTrackUnpublished, this.handleLocalTrackUnpublished).on(H.SubscribedQualityUpdate, this.handleSubscribedQualityUpdate).on(H.Closing, this.handleClosing).on(H.SignalRequestResponse, this.handleSignalRequestResponse).on(H.DataPacketReceived, this.handleDataPacket);
  }
  /**
   * Sets and updates the metadata of the local participant.
   * Note: this requires `canUpdateOwnMetadata` permission.
   * method will throw if the user doesn't have the required permissions
   * @param metadata
   */
  setMetadata(e) {
    return m(this, void 0, void 0, function* () {
      yield this.requestMetadataUpdate({
        metadata: e
      });
    });
  }
  /**
   * Sets and updates the name of the local participant.
   * Note: this requires `canUpdateOwnMetadata` permission.
   * method will throw if the user doesn't have the required permissions
   * @param metadata
   */
  setName(e) {
    return m(this, void 0, void 0, function* () {
      yield this.requestMetadataUpdate({
        name: e
      });
    });
  }
  /**
   * Set or update participant attributes. It will make updates only to keys that
   * are present in `attributes`, and will not override others.
   * Note: this requires `canUpdateOwnMetadata` permission.
   * @param attributes attributes to update
   */
  setAttributes(e) {
    return m(this, void 0, void 0, function* () {
      yield this.requestMetadataUpdate({
        attributes: e
      });
    });
  }
  requestMetadataUpdate(e) {
    return m(this, arguments, void 0, function(t) {
      var i = this;
      let {
        metadata: s,
        name: r,
        attributes: o
      } = t;
      return (function* () {
        return new Je((a, c) => m(i, void 0, void 0, function* () {
          var d, l;
          try {
            let u = !1;
            const h = yield this.engine.client.sendUpdateLocalMetadata((d = s != null ? s : this.metadata) !== null && d !== void 0 ? d : "", (l = r != null ? r : this.name) !== null && l !== void 0 ? l : "", o), p = performance.now();
            for (this.pendingSignalRequests.set(h, {
              resolve: a,
              reject: (b) => {
                c(b), u = !0;
              },
              values: {
                name: r,
                metadata: s,
                attributes: o
              }
            }); performance.now() - p < 5e3 && !u; ) {
              if ((!r || this.name === r) && (!s || this.metadata === s) && (!o || Object.entries(o).every((b) => {
                let [v, C] = b;
                return this.attributes[v] === C || C === "" && !this.attributes[v];
              }))) {
                this.pendingSignalRequests.delete(h), a();
                return;
              }
              yield ze(50);
            }
            c(new Ka("Request to update local metadata timed out", "TimeoutError"));
          } catch (u) {
            u instanceof Error ? c(u) : c(new Error(String(u)));
          }
        }));
      })();
    });
  }
  /**
   * Enable or disable a participant's camera track.
   *
   * If a track has already published, it'll mute or unmute the track.
   * Resolves with a `LocalTrackPublication` instance if successful and `undefined` otherwise
   */
  setCameraEnabled(e, t, i) {
    return this.setTrackEnabled(E.Source.Camera, e, t, i);
  }
  /**
   * Enable or disable a participant's microphone track.
   *
   * If a track has already published, it'll mute or unmute the track.
   * Resolves with a `LocalTrackPublication` instance if successful and `undefined` otherwise
   */
  setMicrophoneEnabled(e, t, i) {
    return this.setTrackEnabled(E.Source.Microphone, e, t, i);
  }
  /**
   * Start or stop sharing a participant's screen
   * Resolves with a `LocalTrackPublication` instance if successful and `undefined` otherwise
   */
  setScreenShareEnabled(e, t, i) {
    return this.setTrackEnabled(E.Source.ScreenShare, e, t, i);
  }
  /** @internal */
  setE2EEEnabled(e) {
    return m(this, void 0, void 0, function* () {
      this.encryptionType = e ? Ne.GCM : Ne.NONE, yield this.republishAllTracks(void 0, !1);
    });
  }
  setTrackEnabled(e, t, i, s) {
    return m(this, void 0, void 0, function* () {
      var r, o;
      this.log.debug("setTrackEnabled", Object.assign(Object.assign({}, this.logContext), {
        source: e,
        enabled: t
      })), this.republishPromise && (yield this.republishPromise);
      let a = this.getTrackPublication(e);
      if (t)
        if (a)
          yield a.unmute();
        else {
          let c;
          if (this.pendingPublishing.has(e)) {
            const d = yield this.waitForPendingPublicationOfSource(e);
            return d || this.log.info("waiting for pending publication promise timed out", Object.assign(Object.assign({}, this.logContext), {
              source: e
            })), yield d == null ? void 0 : d.unmute(), d;
          }
          this.pendingPublishing.add(e);
          try {
            switch (e) {
              case E.Source.Camera:
                c = yield this.createTracks({
                  video: (r = i) !== null && r !== void 0 ? r : !0
                });
                break;
              case E.Source.Microphone:
                c = yield this.createTracks({
                  audio: (o = i) !== null && o !== void 0 ? o : !0
                });
                break;
              case E.Source.ScreenShare:
                c = yield this.createScreenTracks(Object.assign({}, i));
                break;
              default:
                throw new Ut(e);
            }
          } catch (d) {
            throw c == null || c.forEach((l) => {
              l.stop();
            }), d instanceof Error && this.emit(W.MediaDevicesError, d, cr(e)), this.pendingPublishing.delete(e), d;
          }
          for (const d of c) {
            const l = Object.assign(Object.assign({}, this.roomOptions.publishDefaults), i);
            e === E.Source.Microphone && Et(d) && l.preConnectBuffer && (this.log.info("starting preconnect buffer for microphone", Object.assign({}, this.logContext)), d.startPreConnectBuffer());
          }
          try {
            const d = [];
            for (const u of c)
              this.log.info("publishing track", Object.assign(Object.assign({}, this.logContext), ue(u))), d.push(this.publishTrack(u, s));
            [a] = yield Promise.all(d);
          } catch (d) {
            throw c == null || c.forEach((l) => {
              l.stop();
            }), d;
          } finally {
            this.pendingPublishing.delete(e);
          }
        }
      else if (!(a != null && a.track) && this.pendingPublishing.has(e) && (a = yield this.waitForPendingPublicationOfSource(e), a || this.log.info("waiting for pending publication promise timed out", Object.assign(Object.assign({}, this.logContext), {
        source: e
      }))), a && a.track)
        if (e === E.Source.ScreenShare) {
          a = yield this.unpublishTrack(a.track);
          const c = this.getTrackPublication(E.Source.ScreenShareAudio);
          c && c.track && this.unpublishTrack(c.track);
        } else
          yield a.mute();
      return a;
    });
  }
  /**
   * Publish both camera and microphone at the same time. This is useful for
   * displaying a single Permission Dialog box to the end user.
   */
  enableCameraAndMicrophone() {
    return m(this, void 0, void 0, function* () {
      if (!(this.pendingPublishing.has(E.Source.Camera) || this.pendingPublishing.has(E.Source.Microphone))) {
        this.pendingPublishing.add(E.Source.Camera), this.pendingPublishing.add(E.Source.Microphone);
        try {
          const e = yield this.createTracks({
            audio: !0,
            video: !0
          });
          yield Promise.all(e.map((t) => this.publishTrack(t)));
        } finally {
          this.pendingPublishing.delete(E.Source.Camera), this.pendingPublishing.delete(E.Source.Microphone);
        }
      }
    });
  }
  /**
   * Create local camera and/or microphone tracks
   * @param options
   * @returns
   */
  createTracks(e) {
    return m(this, void 0, void 0, function* () {
      var t, i;
      e != null || (e = {});
      const s = Rd(e, (t = this.roomOptions) === null || t === void 0 ? void 0 : t.audioCaptureDefaults, (i = this.roomOptions) === null || i === void 0 ? void 0 : i.videoCaptureDefaults);
      try {
        return (yield ls(s, {
          loggerName: this.roomOptions.loggerName,
          loggerContextCb: () => this.logContext
        })).map((a) => (Et(a) && (this.microphoneError = void 0, a.setAudioContext(this.audioContext), a.source = E.Source.Microphone, this.emit(W.AudioStreamAcquired)), Zt(a) && (this.cameraError = void 0, a.source = E.Source.Camera), a));
      } catch (r) {
        throw r instanceof Error && (e.audio && (this.microphoneError = r), e.video && (this.cameraError = r)), r;
      }
    });
  }
  /**
   * Creates a screen capture tracks with getDisplayMedia().
   * A LocalVideoTrack is always created and returned.
   * If { audio: true }, and the browser supports audio capture, a LocalAudioTrack is also created.
   */
  createScreenTracks(e) {
    return m(this, void 0, void 0, function* () {
      if (e === void 0 && (e = {}), navigator.mediaDevices.getDisplayMedia === void 0)
        throw new Hr("getDisplayMedia not supported");
      e.resolution === void 0 && !sp() && (e.resolution = Wr.h1080fps30.resolution);
      const t = zh(e), i = yield navigator.mediaDevices.getDisplayMedia(t), s = i.getVideoTracks();
      if (s.length === 0)
        throw new Ut("no video track found");
      const r = new Jn(s[0], void 0, !1, {
        loggerName: this.roomOptions.loggerName,
        loggerContextCb: () => this.logContext
      });
      r.source = E.Source.ScreenShare, e.contentHint && (r.mediaStreamTrack.contentHint = e.contentHint);
      const o = [r];
      if (i.getAudioTracks().length > 0) {
        this.emit(W.AudioStreamAcquired);
        const a = new Gn(i.getAudioTracks()[0], void 0, !1, this.audioContext, {
          loggerName: this.roomOptions.loggerName,
          loggerContextCb: () => this.logContext
        });
        a.source = E.Source.ScreenShareAudio, o.push(a);
      }
      return o;
    });
  }
  /**
   * Publish a new track to the room
   * @param track
   * @param options
   */
  publishTrack(e, t) {
    return m(this, void 0, void 0, function* () {
      return this.publishOrRepublishTrack(e, t);
    });
  }
  publishOrRepublishTrack(e, t) {
    return m(this, arguments, void 0, function(i, s) {
      var r = this;
      let o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
      return (function* () {
        var a, c, d, l;
        At(i) && i.setAudioContext(r.audioContext), yield (a = r.reconnectFuture) === null || a === void 0 ? void 0 : a.promise, r.republishPromise && !o && (yield r.republishPromise), Di(i) && r.pendingPublishPromises.has(i) && (yield r.pendingPublishPromises.get(i));
        let u;
        if (i instanceof MediaStreamTrack)
          u = i.getConstraints();
        else {
          u = i.constraints;
          let T;
          switch (i.source) {
            case E.Source.Microphone:
              T = "audioinput";
              break;
            case E.Source.Camera:
              T = "videoinput";
          }
          T && r.activeDeviceMap.has(T) && (u = Object.assign(Object.assign({}, u), {
            deviceId: r.activeDeviceMap.get(T)
          }));
        }
        if (i instanceof MediaStreamTrack)
          switch (i.kind) {
            case "audio":
              i = new Gn(i, u, !0, r.audioContext, {
                loggerName: r.roomOptions.loggerName,
                loggerContextCb: () => r.logContext
              });
              break;
            case "video":
              i = new Jn(i, u, !0, {
                loggerName: r.roomOptions.loggerName,
                loggerContextCb: () => r.logContext
              });
              break;
            default:
              throw new Ut("unsupported MediaStreamTrack kind ".concat(i.kind));
          }
        else
          i.updateLoggerOptions({
            loggerName: r.roomOptions.loggerName,
            loggerContextCb: () => r.logContext
          });
        let h;
        if (r.trackPublications.forEach((T) => {
          T.track && T.track === i && (h = T);
        }), h)
          return r.log.warn("track has already been published, skipping", Object.assign(Object.assign({}, r.logContext), ue(h))), h;
        const p = Object.assign(Object.assign({}, r.roomOptions.publishDefaults), s), b = "channelCount" in i.mediaStreamTrack.getSettings() && // @ts-ignore `channelCount` on getSettings() is currently only available for Safari, but is generally the best way to determine a stereo track https://developer.mozilla.org/en-US/docs/Web/API/MediaTrackSettings/channelCount
        i.mediaStreamTrack.getSettings().channelCount === 2 || i.mediaStreamTrack.getConstraints().channelCount === 2, v = (c = p.forceStereo) !== null && c !== void 0 ? c : b;
        v && (p.dtx === void 0 && r.log.info("Opus DTX will be disabled for stereo tracks by default. Enable them explicitly to make it work.", Object.assign(Object.assign({}, r.logContext), ue(i))), p.red === void 0 && r.log.info("Opus RED will be disabled for stereo tracks by default. Enable them explicitly to make it work."), (d = p.dtx) !== null && d !== void 0 || (p.dtx = !1), (l = p.red) !== null && l !== void 0 || (p.red = !1)), !ap() && r.roomOptions.e2ee && (r.log.info("End-to-end encryption is set up, simulcast publishing will be disabled on Safari versions and iOS browsers running iOS < v17.2", Object.assign({}, r.logContext)), p.simulcast = !1), p.source && (i.source = p.source);
        const C = new Promise((T, P) => m(r, void 0, void 0, function* () {
          try {
            if (this.engine.client.currentState !== Ee.CONNECTED) {
              this.log.debug("deferring track publication until signal is connected", Object.assign(Object.assign({}, this.logContext), {
                track: ue(i)
              }));
              let R = !1;
              const g = setTimeout(() => {
                R = !0, i.stop(), P(new za("publishing rejected as engine not connected within timeout", 408));
              }, 15e3);
              if (yield this.waitUntilEngineConnected(), clearTimeout(g), R)
                return;
              const f = yield this.publish(i, p, v);
              T(f);
            } else
              try {
                const R = yield this.publish(i, p, v);
                T(R);
              } catch (R) {
                P(R);
              }
          } catch (R) {
            P(R);
          }
        }));
        r.pendingPublishPromises.set(i, C);
        try {
          return yield C;
        } catch (T) {
          throw T;
        } finally {
          r.pendingPublishPromises.delete(i);
        }
      })();
    });
  }
  waitUntilEngineConnected() {
    return this.signalConnectedFuture || (this.signalConnectedFuture = new $t()), this.signalConnectedFuture.promise;
  }
  hasPermissionsToPublish(e) {
    if (!this.permissions)
      return this.log.warn("no permissions present for publishing track", Object.assign(Object.assign({}, this.logContext), ue(e))), !1;
    const {
      canPublish: t,
      canPublishSources: i
    } = this.permissions;
    return t && (i.length === 0 || i.map((s) => Yh(s)).includes(e.source)) ? !0 : (this.log.warn("insufficient permissions to publish", Object.assign(Object.assign({}, this.logContext), ue(e))), !1);
  }
  publish(e, t, i) {
    return m(this, void 0, void 0, function* () {
      var s, r, o, a, c, d, l, u, h, p;
      if (!this.hasPermissionsToPublish(e))
        throw new za("failed to publish track, insufficient permissions", 403);
      Array.from(this.trackPublications.values()).find((A) => Di(e) && A.source === e.source) && e.source !== E.Source.Unknown && this.log.info("publishing a second track with the same source: ".concat(e.source), Object.assign(Object.assign({}, this.logContext), ue(e))), t.stopMicTrackOnMute && Et(e) && (e.stopOnMute = !0), e.source === E.Source.ScreenShare && ui() && (t.simulcast = !1), t.videoCodec === "av1" && !tp() && (t.videoCodec = void 0), t.videoCodec === "vp9" && !ip() && (t.videoCodec = void 0), t.videoCodec === void 0 && (t.videoCodec = mr), this.enabledPublishVideoCodecs.length > 0 && (this.enabledPublishVideoCodecs.some((A) => t.videoCodec === rn(A.mime)) || (t.videoCodec = rn(this.enabledPublishVideoCodecs[0].mime)));
      const v = t.videoCodec;
      e.on(U.Muted, this.onTrackMuted), e.on(U.Unmuted, this.onTrackUnmuted), e.on(U.Ended, this.handleTrackEnded), e.on(U.UpstreamPaused, this.onTrackUpstreamPaused), e.on(U.UpstreamResumed, this.onTrackUpstreamResumed), e.on(U.AudioTrackFeatureUpdate, this.onTrackFeatureUpdate);
      const C = [], T = !(!((s = t.dtx) !== null && s !== void 0) || s), P = e.getSourceTrackSettings();
      P.autoGainControl && C.push(He.TF_AUTO_GAIN_CONTROL), P.echoCancellation && C.push(He.TF_ECHO_CANCELLATION), P.noiseSuppression && C.push(He.TF_NOISE_SUPPRESSION), P.channelCount && P.channelCount > 1 && C.push(He.TF_STEREO), T && C.push(He.TF_NO_DTX), At(e) && e.hasPreConnectBuffer && C.push(He.TF_PRECONNECT_BUFFER);
      const R = new dn({
        // get local track id for use during publishing
        cid: e.mediaStreamTrack.id,
        name: t.name,
        type: E.kindToProto(e.kind),
        muted: e.isMuted,
        source: E.sourceToProto(e.source),
        disableDtx: T,
        encryption: this.encryptionType,
        stereo: i,
        disableRed: this.isE2EEEnabled || !(!((r = t.red) !== null && r !== void 0) || r),
        stream: t == null ? void 0 : t.stream,
        backupCodecPolicy: t == null ? void 0 : t.backupCodecPolicy,
        audioFeatures: C
      });
      let g;
      if (e.kind === E.Kind.Video) {
        let A = {
          width: 0,
          height: 0
        };
        try {
          A = yield e.waitForDimensions();
        } catch {
          const N = (a = (o = this.roomOptions.videoCaptureDefaults) === null || o === void 0 ? void 0 : o.resolution) !== null && a !== void 0 ? a : ln.h720.resolution;
          A = {
            width: N.width,
            height: N.height
          }, this.log.error("could not determine track dimensions, using defaults", Object.assign(Object.assign(Object.assign({}, this.logContext), ue(e)), {
            dims: A
          }));
        }
        R.width = A.width, R.height = A.height, jt(e) && (bt(v) && (e.source === E.Source.ScreenShare && (t.scalabilityMode = "L1T3", "contentHint" in e.mediaStreamTrack && (e.mediaStreamTrack.contentHint = "motion", this.log.info("forcing contentHint to motion for screenshare with SVC codecs", Object.assign(Object.assign({}, this.logContext), ue(e))))), t.scalabilityMode = (c = t.scalabilityMode) !== null && c !== void 0 ? c : "L3T3_KEY"), R.simulcastCodecs = [new Ys({
          codec: v,
          cid: e.mediaStreamTrack.id
        })], t.backupCodec === !0 && (t.backupCodec = {
          codec: mr
        }), t.backupCodec && v !== t.backupCodec.codec && // TODO remove this once e2ee is supported for backup codecs
        R.encryption === Ne.NONE && (this.roomOptions.dynacast || (this.roomOptions.dynacast = !0), R.simulcastCodecs.push(new Ys({
          codec: t.backupCodec.codec,
          cid: ""
        })))), g = gr(e.source === E.Source.ScreenShare, R.width, R.height, t), R.layers = ko(R.width, R.height, g, bt(t.videoCodec));
      } else e.kind === E.Kind.Audio && (g = [{
        maxBitrate: (d = t.audioPreset) === null || d === void 0 ? void 0 : d.maxBitrate,
        priority: (u = (l = t.audioPreset) === null || l === void 0 ? void 0 : l.priority) !== null && u !== void 0 ? u : "high",
        networkPriority: (p = (h = t.audioPreset) === null || h === void 0 ? void 0 : h.priority) !== null && p !== void 0 ? p : "high"
      }]);
      if (!this.engine || this.engine.isClosed)
        throw new De("cannot publish track when not connected");
      const f = () => m(this, void 0, void 0, function* () {
        var A, O, N;
        if (!this.engine.pcManager)
          throw new De("pcManager is not ready");
        if (e.sender = yield this.engine.createSender(e, t, g), this.emit(W.LocalSenderCreated, e.sender, e), jt(e) && ((A = t.degradationPreference) !== null && A !== void 0 || (t.degradationPreference = hm(e)), e.setDegradationPreference(t.degradationPreference)), g)
          if (ui() && e.kind === E.Kind.Audio) {
            let L;
            for (const B of this.engine.pcManager.publisher.getTransceivers())
              if (B.sender === e.sender) {
                L = B;
                break;
              }
            L && this.engine.pcManager.publisher.setTrackCodecBitrate({
              transceiver: L,
              codec: "opus",
              maxbr: !((O = g[0]) === null || O === void 0) && O.maxBitrate ? g[0].maxBitrate / 1e3 : 0
            });
          } else e.codec && bt(e.codec) && (!((N = g[0]) === null || N === void 0) && N.maxBitrate) && this.engine.pcManager.publisher.setTrackCodecBitrate({
            cid: R.cid,
            codec: e.codec,
            maxbr: g[0].maxBitrate / 1e3
          });
        yield this.engine.negotiate();
      });
      let k;
      const w = new Promise((A, O) => m(this, void 0, void 0, function* () {
        var N;
        try {
          k = yield this.engine.addTrack(R), A(k);
        } catch (L) {
          e.sender && (!((N = this.engine.pcManager) === null || N === void 0) && N.publisher) && (this.engine.pcManager.publisher.removeTrack(e.sender), yield this.engine.negotiate().catch((B) => {
            this.log.error("failed to negotiate after removing track due to failed add track request", Object.assign(Object.assign(Object.assign({}, this.logContext), ue(e)), {
              error: B
            }));
          })), O(L);
        }
      }));
      if (this.enabledPublishVideoCodecs.length > 0)
        k = (yield Promise.all([w, f()]))[0];
      else {
        k = yield w;
        let A;
        if (k.codecs.forEach((O) => {
          A === void 0 && (A = O.mimeType);
        }), A && e.kind === E.Kind.Video) {
          const O = rn(A);
          O !== v && (this.log.debug("falling back to server selected codec", Object.assign(Object.assign(Object.assign({}, this.logContext), ue(e)), {
            codec: O
          })), t.videoCodec = O, g = gr(e.source === E.Source.ScreenShare, R.width, R.height, t));
        }
        yield f();
      }
      const D = new br(e.kind, k, e, {
        loggerName: this.roomOptions.loggerName,
        loggerContextCb: () => this.logContext
      });
      if (D.on(U.CpuConstrained, (A) => this.onTrackCpuConstrained(A, D)), D.options = t, e.sid = k.sid, this.log.debug("publishing ".concat(e.kind, " with encodings"), Object.assign(Object.assign({}, this.logContext), {
        encodings: g,
        trackInfo: k
      })), jt(e) ? e.startMonitor(this.engine.client) : At(e) && e.startMonitor(), this.addTrackPublication(D), this.emit(W.LocalTrackPublished, D), At(e) && k.audioFeatures.includes(He.TF_PRECONNECT_BUFFER)) {
        const A = e.getPreConnectBuffer(), O = e.getPreConnectBufferMimeType();
        this.on(W.LocalTrackSubscribed, (N) => {
          if (N.trackSid === k.sid) {
            if (!e.hasPreConnectBuffer) {
              this.log.warn("subscribe event came to late, buffer already closed", this.logContext);
              return;
            }
            this.log.debug("finished recording preconnect buffer", Object.assign(Object.assign({}, this.logContext), ue(e))), e.stopPreConnectBuffer();
          }
        }), A && new Promise((L, B) => m(this, void 0, void 0, function* () {
          var Q, ae, re, K, xe, Ie;
          try {
            this.log.debug("waiting for agent", Object.assign(Object.assign({}, this.logContext), ue(e)));
            const je = setTimeout(() => {
              B(new Error("agent not active within 10 seconds"));
            }, 1e4), ot = yield this.waitUntilActiveAgentPresent();
            clearTimeout(je), this.log.debug("sending preconnect buffer", Object.assign(Object.assign({}, this.logContext), ue(e)));
            const ce = yield this.streamBytes({
              name: "preconnect-buffer",
              mimeType: O,
              topic: "lk.agent.pre-connect-audio-buffer",
              destinationIdentities: [ot.identity],
              attributes: {
                trackId: D.trackSid,
                sampleRate: String((xe = P.sampleRate) !== null && xe !== void 0 ? xe : "48000"),
                channels: String((Ie = P.channelCount) !== null && Ie !== void 0 ? Ie : "1")
              }
            });
            try {
              for (var $ = !0, $e = Nt(A), _e; _e = yield $e.next(), Q = _e.done, !Q; $ = !0) {
                K = _e.value, $ = !1;
                const Ke = K;
                yield ce.write(Ke);
              }
            } catch (Ke) {
              ae = {
                error: Ke
              };
            } finally {
              try {
                !$ && !Q && (re = $e.return) && (yield re.call($e));
              } finally {
                if (ae) throw ae.error;
              }
            }
            yield ce.close(), L();
          } catch (je) {
            B(je);
          }
        })).then(() => {
          this.log.debug("preconnect buffer sent successfully", Object.assign(Object.assign({}, this.logContext), ue(e)));
        }).catch((L) => {
          this.log.error("error sending preconnect buffer", Object.assign(Object.assign(Object.assign({}, this.logContext), ue(e)), {
            error: L
          }));
        });
      }
      return D;
    });
  }
  get isLocal() {
    return !0;
  }
  /** @internal
   * publish additional codec to existing track
   */
  publishAdditionalCodecForTrack(e, t, i) {
    return m(this, void 0, void 0, function* () {
      var s;
      if (this.encryptionType !== Ne.NONE)
        return;
      let r;
      if (this.trackPublications.forEach((p) => {
        p.track && p.track === e && (r = p);
      }), !r)
        throw new Ut("track is not published");
      if (!jt(e))
        throw new Ut("track is not a video track");
      const o = Object.assign(Object.assign({}, (s = this.roomOptions) === null || s === void 0 ? void 0 : s.publishDefaults), i), a = dm(e, t, o);
      if (!a) {
        this.log.info("backup codec has been disabled, ignoring request to add additional codec for track", Object.assign(Object.assign({}, this.logContext), ue(e)));
        return;
      }
      const c = e.addSimulcastTrack(t, a);
      if (!c)
        return;
      const d = new dn({
        cid: c.mediaStreamTrack.id,
        type: E.kindToProto(e.kind),
        muted: e.isMuted,
        source: E.sourceToProto(e.source),
        sid: e.sid,
        simulcastCodecs: [{
          codec: o.videoCodec,
          cid: c.mediaStreamTrack.id
        }]
      });
      if (d.layers = ko(d.width, d.height, a), !this.engine || this.engine.isClosed)
        throw new De("cannot publish track when not connected");
      const l = () => m(this, void 0, void 0, function* () {
        yield this.engine.createSimulcastSender(e, c, o, a), yield this.engine.negotiate();
      }), h = (yield Promise.all([this.engine.addTrack(d), l()]))[0];
      this.log.debug("published ".concat(t, " for track ").concat(e.sid), Object.assign(Object.assign({}, this.logContext), {
        encodings: a,
        trackInfo: h
      }));
    });
  }
  unpublishTrack(e, t) {
    return m(this, void 0, void 0, function* () {
      var i, s;
      if (Di(e)) {
        const d = this.pendingPublishPromises.get(e);
        d && (this.log.info("awaiting publish promise before attempting to unpublish", Object.assign(Object.assign({}, this.logContext), ue(e))), yield d);
      }
      const r = this.getPublicationForTrack(e), o = r ? ue(r) : void 0;
      if (this.log.debug("unpublishing track", Object.assign(Object.assign({}, this.logContext), o)), !r || !r.track) {
        this.log.warn("track was not unpublished because no publication was found", Object.assign(Object.assign({}, this.logContext), o));
        return;
      }
      e = r.track, e.off(U.Muted, this.onTrackMuted), e.off(U.Unmuted, this.onTrackUnmuted), e.off(U.Ended, this.handleTrackEnded), e.off(U.UpstreamPaused, this.onTrackUpstreamPaused), e.off(U.UpstreamResumed, this.onTrackUpstreamResumed), e.off(U.AudioTrackFeatureUpdate, this.onTrackFeatureUpdate), t === void 0 && (t = (s = (i = this.roomOptions) === null || i === void 0 ? void 0 : i.stopLocalTrackOnUnpublish) !== null && s !== void 0 ? s : !0), t ? e.stop() : e.stopMonitor();
      let a = !1;
      const c = e.sender;
      if (e.sender = void 0, this.engine.pcManager && this.engine.pcManager.currentState < Me.FAILED && c)
        try {
          for (const d of this.engine.pcManager.publisher.getTransceivers())
            d.sender === c && (d.direction = "inactive", a = !0);
          if (this.engine.removeTrack(c) && (a = !0), jt(e)) {
            for (const [, d] of e.simulcastCodecs)
              d.sender && (this.engine.removeTrack(d.sender) && (a = !0), d.sender = void 0);
            e.simulcastCodecs.clear();
          }
        } catch (d) {
          this.log.warn("failed to unpublish track", Object.assign(Object.assign(Object.assign({}, this.logContext), o), {
            error: d
          }));
        }
      switch (this.trackPublications.delete(r.trackSid), r.kind) {
        case E.Kind.Audio:
          this.audioTrackPublications.delete(r.trackSid);
          break;
        case E.Kind.Video:
          this.videoTrackPublications.delete(r.trackSid);
          break;
      }
      return this.emit(W.LocalTrackUnpublished, r), r.setTrack(void 0), a && (yield this.engine.negotiate()), r;
    });
  }
  unpublishTracks(e) {
    return m(this, void 0, void 0, function* () {
      return (yield Promise.all(e.map((i) => this.unpublishTrack(i)))).filter((i) => !!i);
    });
  }
  republishAllTracks(e) {
    return m(this, arguments, void 0, function(t) {
      var i = this;
      let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
      return (function* () {
        i.republishPromise && (yield i.republishPromise), i.republishPromise = new Je((r, o) => m(i, void 0, void 0, function* () {
          try {
            const a = [];
            this.trackPublications.forEach((c) => {
              c.track && (t && (c.options = Object.assign(Object.assign({}, c.options), t)), a.push(c));
            }), yield Promise.all(a.map((c) => m(this, void 0, void 0, function* () {
              const d = c.track;
              yield this.unpublishTrack(d, !1), s && !d.isMuted && d.source !== E.Source.ScreenShare && d.source !== E.Source.ScreenShareAudio && (At(d) || jt(d)) && !d.isUserProvided && (this.log.debug("restarting existing track", Object.assign(Object.assign({}, this.logContext), {
                track: c.trackSid
              })), yield d.restartTrack()), yield this.publishOrRepublishTrack(d, c.options, !0);
            }))), r();
          } catch (a) {
            a instanceof Error ? o(a) : o(new Error(String(a)));
          } finally {
            this.republishPromise = void 0;
          }
        })), yield i.republishPromise;
      })();
    });
  }
  /**
   * Publish a new data payload to the room. Data will be forwarded to each
   * participant in the room if the destination field in publishOptions is empty
   *
   * @param data Uint8Array of the payload. To send string data, use TextEncoder.encode
   * @param options optionally specify a `reliable`, `topic` and `destination`
   */
  publishData(e) {
    return m(this, arguments, void 0, function(t) {
      var i = this;
      let s = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      return (function* () {
        const r = s.reliable ? oe.RELIABLE : oe.LOSSY, o = s.destinationIdentities, a = s.topic;
        let c = new Mr({
          participantIdentity: i.identity,
          payload: t,
          destinationIdentities: o,
          topic: a
        });
        const d = new Xe({
          kind: r,
          value: {
            case: "user",
            value: c
          }
        });
        yield i.engine.sendDataPacket(d, r);
      })();
    });
  }
  /**
   * Publish SIP DTMF message to the room.
   *
   * @param code DTMF code
   * @param digit DTMF digit
   */
  publishDtmf(e, t) {
    return m(this, void 0, void 0, function* () {
      const i = new Xe({
        kind: oe.RELIABLE,
        value: {
          case: "sipDtmf",
          value: new Cc({
            code: e,
            digit: t
          })
        }
      });
      yield this.engine.sendDataPacket(i, oe.RELIABLE);
    });
  }
  /** @deprecated Consider migrating to {@link sendText} */
  sendChatMessage(e, t) {
    return m(this, void 0, void 0, function* () {
      const i = {
        id: crypto.randomUUID(),
        message: e,
        timestamp: Date.now(),
        attachedFiles: t == null ? void 0 : t.attachments
      }, s = new Xe({
        value: {
          case: "chatMessage",
          value: new Hn(Object.assign(Object.assign({}, i), {
            timestamp: Pe.parse(i.timestamp)
          }))
        }
      });
      return yield this.engine.sendDataPacket(s, oe.RELIABLE), this.emit(W.ChatMessage, i), i;
    });
  }
  /** @deprecated Consider migrating to {@link sendText} */
  editChatMessage(e, t) {
    return m(this, void 0, void 0, function* () {
      const i = Object.assign(Object.assign({}, t), {
        message: e,
        editTimestamp: Date.now()
      }), s = new Xe({
        value: {
          case: "chatMessage",
          value: new Hn(Object.assign(Object.assign({}, i), {
            timestamp: Pe.parse(i.timestamp),
            editTimestamp: Pe.parse(i.editTimestamp)
          }))
        }
      });
      return yield this.engine.sendDataPacket(s, oe.RELIABLE), this.emit(W.ChatMessage, i), i;
    });
  }
  /**
   * Sends the given string to participants in the room via the data channel.
   * For longer messages, consider using {@link streamText} instead.
   *
   * @param text The text payload
   * @param options.topic Topic identifier used to route the stream to appropriate handlers.
   */
  sendText(e, t) {
    return m(this, void 0, void 0, function* () {
      return this.roomOutgoingDataStreamManager.sendText(e, t);
    });
  }
  /**
   * Creates a new TextStreamWriter which can be used to stream text incrementally
   * to participants in the room via the data channel.
   *
   * @param options.topic Topic identifier used to route the stream to appropriate handlers.
   *
   * @internal
   * @experimental CAUTION, might get removed in a minor release
   */
  streamText(e) {
    return m(this, void 0, void 0, function* () {
      return this.roomOutgoingDataStreamManager.streamText(e);
    });
  }
  /** Send a File to all participants in the room via the data channel.
   * @param file The File object payload
   * @param options.topic Topic identifier used to route the stream to appropriate handlers.
   * @param options.onProgress A callback function used to monitor the upload progress percentage.
   */
  sendFile(e, t) {
    return m(this, void 0, void 0, function* () {
      return this.roomOutgoingDataStreamManager.sendFile(e, t);
    });
  }
  /**
   * Stream bytes incrementally to participants in the room via the data channel.
   * For sending files, consider using {@link sendFile} instead.
   *
   * @param options.topic Topic identifier used to route the stream to appropriate handlers.
   */
  streamBytes(e) {
    return m(this, void 0, void 0, function* () {
      return this.roomOutgoingDataStreamManager.streamBytes(e);
    });
  }
  /**
   * Initiate an RPC call to a remote participant
   * @param params - Parameters for initiating the RPC call, see {@link PerformRpcParams}
   * @returns A promise that resolves with the response payload or rejects with an error.
   * @throws Error on failure. Details in `message`.
   */
  performRpc(e) {
    let {
      destinationIdentity: t,
      method: i,
      payload: s,
      responseTimeout: r = 15e3
    } = e;
    const o = 7e3, a = o + 1e3;
    return new Je((c, d) => m(this, void 0, void 0, function* () {
      var l, u, h, p;
      if (Xr(s) > Fd) {
        d(Oe.builtIn("REQUEST_PAYLOAD_TOO_LARGE"));
        return;
      }
      if (!((u = (l = this.engine.latestJoinResponse) === null || l === void 0 ? void 0 : l.serverInfo) === null || u === void 0) && u.version && It((p = (h = this.engine.latestJoinResponse) === null || h === void 0 ? void 0 : h.serverInfo) === null || p === void 0 ? void 0 : p.version, "1.8.0") < 0) {
        d(Oe.builtIn("UNSUPPORTED_SERVER"));
        return;
      }
      const b = Math.max(r, a), v = crypto.randomUUID();
      yield this.publishRpcRequest(t, v, i, s, b);
      const C = setTimeout(() => {
        this.pendingAcks.delete(v), d(Oe.builtIn("CONNECTION_TIMEOUT")), this.pendingResponses.delete(v), clearTimeout(T);
      }, o);
      this.pendingAcks.set(v, {
        resolve: () => {
          clearTimeout(C);
        },
        participantIdentity: t
      });
      const T = setTimeout(() => {
        this.pendingResponses.delete(v), d(Oe.builtIn("RESPONSE_TIMEOUT"));
      }, r);
      this.pendingResponses.set(v, {
        resolve: (P, R) => {
          clearTimeout(T), this.pendingAcks.has(v) && (this.log.warn("RPC response received before ack", v), this.pendingAcks.delete(v), clearTimeout(C)), R ? d(R) : c(P != null ? P : "");
        },
        participantIdentity: t
      });
    }));
  }
  /**
   * @deprecated use `room.registerRpcMethod` instead
   */
  registerRpcMethod(e, t) {
    this.rpcHandlers.has(e) && this.log.warn("you're overriding the RPC handler for method ".concat(e, ", in the future this will throw an error")), this.rpcHandlers.set(e, t);
  }
  /**
   * @deprecated use `room.unregisterRpcMethod` instead
   */
  unregisterRpcMethod(e) {
    this.rpcHandlers.delete(e);
  }
  /**
   * Control who can subscribe to LocalParticipant's published tracks.
   *
   * By default, all participants can subscribe. This allows fine-grained control over
   * who is able to subscribe at a participant and track level.
   *
   * Note: if access is given at a track-level (i.e. both [allParticipantsAllowed] and
   * [ParticipantTrackPermission.allTracksAllowed] are false), any newer published tracks
   * will not grant permissions to any participants and will require a subsequent
   * permissions update to allow subscription.
   *
   * @param allParticipantsAllowed Allows all participants to subscribe all tracks.
   *  Takes precedence over [[participantTrackPermissions]] if set to true.
   *  By default this is set to true.
   * @param participantTrackPermissions Full list of individual permissions per
   *  participant/track. Any omitted participants will not receive any permissions.
   */
  setTrackSubscriptionPermissions(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
    this.participantTrackPermissions = t, this.allParticipantsAllowedToSubscribe = e, this.engine.client.isDisconnected || this.updateTrackSubscriptionPermissions();
  }
  handleIncomingRpcAck(e) {
    const t = this.pendingAcks.get(e);
    t ? (t.resolve(), this.pendingAcks.delete(e)) : console.error("Ack received for unexpected RPC request", e);
  }
  handleIncomingRpcResponse(e, t, i) {
    const s = this.pendingResponses.get(e);
    s ? (s.resolve(t, i), this.pendingResponses.delete(e)) : console.error("Response received for unexpected RPC request", e);
  }
  /** @internal */
  publishRpcRequest(e, t, i, s, r) {
    return m(this, void 0, void 0, function* () {
      const o = new Xe({
        destinationIdentities: [e],
        kind: oe.RELIABLE,
        value: {
          case: "rpcRequest",
          value: new Ar({
            id: t,
            method: i,
            payload: s,
            responseTimeoutMs: r,
            version: 1
          })
        }
      });
      yield this.engine.sendDataPacket(o, oe.RELIABLE);
    });
  }
  /** @internal */
  handleParticipantDisconnected(e) {
    for (const [t, {
      participantIdentity: i
    }] of this.pendingAcks)
      i === e && this.pendingAcks.delete(t);
    for (const [t, {
      participantIdentity: i,
      resolve: s
    }] of this.pendingResponses)
      i === e && (s(null, Oe.builtIn("RECIPIENT_DISCONNECTED")), this.pendingResponses.delete(t));
  }
  /** @internal */
  setEnabledPublishCodecs(e) {
    this.enabledPublishVideoCodecs = e.filter((t) => t.mime.split("/")[0].toLowerCase() === "video");
  }
  /** @internal */
  updateInfo(e) {
    return super.updateInfo(e) ? (e.tracks.forEach((t) => {
      var i, s;
      const r = this.trackPublications.get(t.sid);
      if (r) {
        const o = r.isMuted || ((s = (i = r.track) === null || i === void 0 ? void 0 : i.isUpstreamPaused) !== null && s !== void 0 ? s : !1);
        o !== t.muted && (this.log.debug("updating server mute state after reconcile", Object.assign(Object.assign(Object.assign({}, this.logContext), ue(r)), {
          mutedOnServer: o
        })), this.engine.client.sendMuteTrack(t.sid, o));
      }
    }), !0) : !1;
  }
  /** @internal */
  setActiveAgent(e) {
    var t, i, s, r;
    this.firstActiveAgent = e, e && !this.firstActiveAgent && (this.firstActiveAgent = e), e ? (i = (t = this.activeAgentFuture) === null || t === void 0 ? void 0 : t.resolve) === null || i === void 0 || i.call(t, e) : (r = (s = this.activeAgentFuture) === null || s === void 0 ? void 0 : s.reject) === null || r === void 0 || r.call(s, new Error("Agent disconnected")), this.activeAgentFuture = void 0;
  }
  waitUntilActiveAgentPresent() {
    return this.firstActiveAgent ? Promise.resolve(this.firstActiveAgent) : (this.activeAgentFuture || (this.activeAgentFuture = new $t()), this.activeAgentFuture.promise);
  }
  getPublicationForTrack(e) {
    let t;
    return this.trackPublications.forEach((i) => {
      const s = i.track;
      s && (e instanceof MediaStreamTrack ? (At(s) || jt(s)) && s.mediaStreamTrack === e && (t = i) : e === s && (t = i));
    }), t;
  }
  waitForPendingPublicationOfSource(e) {
    return m(this, void 0, void 0, function* () {
      const i = Date.now();
      for (; Date.now() < i + 1e4; ) {
        const s = Array.from(this.pendingPublishPromises.entries()).find((r) => {
          let [o] = r;
          return o.source === e;
        });
        if (s)
          return s[1];
        yield ze(20);
      }
    });
  }
}
class Dm extends Ot {
  constructor(e, t, i, s) {
    super(e, t.sid, t.name, s), this.track = void 0, this.allowed = !0, this.requestedDisabled = void 0, this.visible = !0, this.handleEnded = (r) => {
      this.setTrack(void 0), this.emit(U.Ended, r);
    }, this.handleVisibilityChange = (r) => {
      this.log.debug("adaptivestream video visibility ".concat(this.trackSid, ", visible=").concat(r), this.logContext), this.visible = r, this.emitTrackUpdate();
    }, this.handleVideoDimensionsChange = (r) => {
      this.log.debug("adaptivestream video dimensions ".concat(r.width, "x").concat(r.height), this.logContext), this.videoDimensionsAdaptiveStream = r, this.emitTrackUpdate();
    }, this.subscribed = i, this.updateInfo(t);
  }
  /**
   * Subscribe or unsubscribe to this remote track
   * @param subscribed true to subscribe to a track, false to unsubscribe
   */
  setSubscribed(e) {
    const t = this.subscriptionStatus, i = this.permissionStatus;
    this.subscribed = e, e && (this.allowed = !0);
    const s = new as({
      trackSids: [this.trackSid],
      subscribe: this.subscribed,
      participantTracks: [new wc({
        // sending an empty participant id since TrackPublication doesn't keep it
        // this is filled in by the participant that receives this message
        participantSid: "",
        trackSids: [this.trackSid]
      })]
    });
    this.emit(U.UpdateSubscription, s), this.emitSubscriptionUpdateIfChanged(t), this.emitPermissionUpdateIfChanged(i);
  }
  get subscriptionStatus() {
    return this.subscribed === !1 ? Ot.SubscriptionStatus.Unsubscribed : super.isSubscribed ? Ot.SubscriptionStatus.Subscribed : Ot.SubscriptionStatus.Desired;
  }
  get permissionStatus() {
    return this.allowed ? Ot.PermissionStatus.Allowed : Ot.PermissionStatus.NotAllowed;
  }
  /**
   * Returns true if track is subscribed, and ready for playback
   */
  get isSubscribed() {
    return this.subscribed === !1 ? !1 : super.isSubscribed;
  }
  // returns client's desire to subscribe to a track, also true if autoSubscribe is enabled
  get isDesired() {
    return this.subscribed !== !1;
  }
  get isEnabled() {
    return this.requestedDisabled !== void 0 ? !this.requestedDisabled : this.isAdaptiveStream ? this.visible : !0;
  }
  get isLocal() {
    return !1;
  }
  /**
   * disable server from sending down data for this track. this is useful when
   * the participant is off screen, you may disable streaming down their video
   * to reduce bandwidth requirements
   * @param enabled
   */
  setEnabled(e) {
    !this.isManualOperationAllowed() || this.requestedDisabled === !e || (this.requestedDisabled = !e, this.emitTrackUpdate());
  }
  /**
   * for tracks that support simulcasting, adjust subscribed quality
   *
   * This indicates the highest quality the client can accept. if network
   * bandwidth does not allow, server will automatically reduce quality to
   * optimize for uninterrupted video
   */
  setVideoQuality(e) {
    !this.isManualOperationAllowed() || this.requestedMaxQuality === e || (this.requestedMaxQuality = e, this.requestedVideoDimensions = void 0, this.emitTrackUpdate());
  }
  /**
   * Explicitly set the video dimensions for this track.
   *
   * This will take precedence over adaptive stream dimensions.
   *
   * @param dimensions The video dimensions to set.
   */
  setVideoDimensions(e) {
    var t, i;
    this.isManualOperationAllowed() && (((t = this.requestedVideoDimensions) === null || t === void 0 ? void 0 : t.width) === e.width && ((i = this.requestedVideoDimensions) === null || i === void 0 ? void 0 : i.height) === e.height || (Es(this.track) && (this.requestedVideoDimensions = e), this.requestedMaxQuality = void 0, this.emitTrackUpdate()));
  }
  setVideoFPS(e) {
    this.isManualOperationAllowed() && Es(this.track) && this.fps !== e && (this.fps = e, this.emitTrackUpdate());
  }
  get videoQuality() {
    var e;
    return (e = this.requestedMaxQuality) !== null && e !== void 0 ? e : rt.HIGH;
  }
  /** @internal */
  setTrack(e) {
    const t = this.subscriptionStatus, i = this.permissionStatus, s = this.track;
    s !== e && (s && (s.off(U.VideoDimensionsChanged, this.handleVideoDimensionsChange), s.off(U.VisibilityChanged, this.handleVisibilityChange), s.off(U.Ended, this.handleEnded), s.detach(), s.stopMonitor(), this.emit(U.Unsubscribed, s)), super.setTrack(e), e && (e.sid = this.trackSid, e.on(U.VideoDimensionsChanged, this.handleVideoDimensionsChange), e.on(U.VisibilityChanged, this.handleVisibilityChange), e.on(U.Ended, this.handleEnded), this.emit(U.Subscribed, e)), this.emitPermissionUpdateIfChanged(i), this.emitSubscriptionUpdateIfChanged(t));
  }
  /** @internal */
  setAllowed(e) {
    const t = this.subscriptionStatus, i = this.permissionStatus;
    this.allowed = e, this.emitPermissionUpdateIfChanged(i), this.emitSubscriptionUpdateIfChanged(t);
  }
  /** @internal */
  setSubscriptionError(e) {
    this.emit(U.SubscriptionFailed, e);
  }
  /** @internal */
  updateInfo(e) {
    super.updateInfo(e);
    const t = this.metadataMuted;
    this.metadataMuted = e.muted, this.track ? this.track.setMuted(e.muted) : t !== e.muted && this.emit(e.muted ? U.Muted : U.Unmuted);
  }
  emitSubscriptionUpdateIfChanged(e) {
    const t = this.subscriptionStatus;
    e !== t && this.emit(U.SubscriptionStatusChanged, t, e);
  }
  emitPermissionUpdateIfChanged(e) {
    this.permissionStatus !== e && this.emit(U.SubscriptionPermissionChanged, this.permissionStatus, e);
  }
  isManualOperationAllowed() {
    return this.isDesired ? !0 : (this.log.warn("cannot update track settings when not subscribed", this.logContext), !1);
  }
  get isAdaptiveStream() {
    return Es(this.track) && this.track.isAdaptiveStream;
  }
  /* @internal */
  emitTrackUpdate() {
    const e = new Uc({
      trackSids: [this.trackSid],
      disabled: !this.isEnabled,
      fps: this.fps
    });
    if (this.kind === E.Kind.Video) {
      let t = this.requestedVideoDimensions;
      if (this.videoDimensionsAdaptiveStream !== void 0)
        if (t)
          Ja(this.videoDimensionsAdaptiveStream, t) && (this.log.debug("using adaptive stream dimensions instead of requested", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream);
        else if (this.requestedMaxQuality !== void 0 && this.trackInfo) {
          const i = Qh(this.trackInfo, this.requestedMaxQuality);
          i && Ja(this.videoDimensionsAdaptiveStream, i) && (this.log.debug("using adaptive stream dimensions instead of max quality layer", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream);
        } else
          this.log.debug("using adaptive stream dimensions", Object.assign(Object.assign({}, this.logContext), this.videoDimensionsAdaptiveStream)), t = this.videoDimensionsAdaptiveStream;
      t ? (e.width = Math.ceil(t.width), e.height = Math.ceil(t.height)) : this.requestedMaxQuality !== void 0 ? (this.log.debug("using requested max quality", Object.assign(Object.assign({}, this.logContext), {
        quality: this.requestedMaxQuality
      })), e.quality = this.requestedMaxQuality) : (this.log.debug("using default quality", Object.assign(Object.assign({}, this.logContext), {
        quality: rt.HIGH
      })), e.quality = rt.HIGH);
    }
    this.emit(U.UpdateSettings, e);
  }
}
class Yn extends $d {
  /** @internal */
  static fromParticipantInfo(e, t, i) {
    return new Yn(e, t.sid, t.identity, t.name, t.metadata, t.attributes, i, t.kind);
  }
  get logContext() {
    return Object.assign(Object.assign({}, super.logContext), {
      rpID: this.sid,
      remoteParticipant: this.identity
    });
  }
  /** @internal */
  constructor(e, t, i, s, r, o, a) {
    let c = arguments.length > 7 && arguments[7] !== void 0 ? arguments[7] : cn.STANDARD;
    super(t, i || "", s, r, o, a, c), this.signalClient = e, this.trackPublications = /* @__PURE__ */ new Map(), this.audioTrackPublications = /* @__PURE__ */ new Map(), this.videoTrackPublications = /* @__PURE__ */ new Map(), this.volumeMap = /* @__PURE__ */ new Map();
  }
  addTrackPublication(e) {
    super.addTrackPublication(e), e.on(U.UpdateSettings, (t) => {
      this.log.debug("send update settings", Object.assign(Object.assign(Object.assign({}, this.logContext), ue(e)), {
        settings: t
      })), this.signalClient.sendUpdateTrackSettings(t);
    }), e.on(U.UpdateSubscription, (t) => {
      t.participantTracks.forEach((i) => {
        i.participantSid = this.sid;
      }), this.signalClient.sendUpdateSubscription(t);
    }), e.on(U.SubscriptionPermissionChanged, (t) => {
      this.emit(W.TrackSubscriptionPermissionChanged, e, t);
    }), e.on(U.SubscriptionStatusChanged, (t) => {
      this.emit(W.TrackSubscriptionStatusChanged, e, t);
    }), e.on(U.Subscribed, (t) => {
      this.emit(W.TrackSubscribed, t, e);
    }), e.on(U.Unsubscribed, (t) => {
      this.emit(W.TrackUnsubscribed, t, e);
    }), e.on(U.SubscriptionFailed, (t) => {
      this.emit(W.TrackSubscriptionFailed, e.trackSid, t);
    });
  }
  getTrackPublication(e) {
    const t = super.getTrackPublication(e);
    if (t)
      return t;
  }
  getTrackPublicationByName(e) {
    const t = super.getTrackPublicationByName(e);
    if (t)
      return t;
  }
  /**
   * sets the volume on the participant's audio track
   * by default, this affects the microphone publication
   * a different source can be passed in as a second argument
   * if no track exists the volume will be applied when the microphone track is added
   */
  setVolume(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : E.Source.Microphone;
    this.volumeMap.set(t, e);
    const i = this.getTrackPublication(t);
    i && i.track && i.track.setVolume(e);
  }
  /**
   * gets the volume on the participant's microphone track
   */
  getVolume() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : E.Source.Microphone;
    const t = this.getTrackPublication(e);
    return t && t.track ? t.track.getVolume() : this.volumeMap.get(e);
  }
  /** @internal */
  addSubscribedMediaTrack(e, t, i, s, r, o) {
    let a = this.getTrackPublicationBySid(t);
    if (a || t.startsWith("TR") || this.trackPublications.forEach((l) => {
      !a && e.kind === l.kind.toString() && (a = l);
    }), !a) {
      if (o === 0) {
        this.log.error("could not find published track", Object.assign(Object.assign({}, this.logContext), {
          trackSid: t
        })), this.emit(W.TrackSubscriptionFailed, t);
        return;
      }
      o === void 0 && (o = 20), setTimeout(() => {
        this.addSubscribedMediaTrack(e, t, i, s, r, o - 1);
      }, 150);
      return;
    }
    if (e.readyState === "ended") {
      this.log.error("unable to subscribe because MediaStreamTrack is ended. Do not call MediaStreamTrack.stop()", Object.assign(Object.assign({}, this.logContext), ue(a))), this.emit(W.TrackSubscriptionFailed, t);
      return;
    }
    const c = e.kind === "video";
    let d;
    return c ? d = new Rm(e, t, s, r) : d = new Em(e, t, s, this.audioContext, this.audioOutput), d.source = a.source, d.isMuted = a.isMuted, d.setMediaStream(i), d.start(), a.setTrack(d), this.volumeMap.has(a.source) && hr(d) && Et(d) && d.setVolume(this.volumeMap.get(a.source)), a;
  }
  /** @internal */
  get hasMetadata() {
    return !!this.participantInfo;
  }
  /**
   * @internal
   */
  getTrackPublicationBySid(e) {
    return this.trackPublications.get(e);
  }
  /** @internal */
  updateInfo(e) {
    if (!super.updateInfo(e))
      return !1;
    const t = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
    return e.tracks.forEach((s) => {
      var r, o;
      let a = this.getTrackPublicationBySid(s.sid);
      if (a)
        a.updateInfo(s);
      else {
        const c = E.kindFromProto(s.type);
        if (!c)
          return;
        a = new Dm(c, s, (r = this.signalClient.connectOptions) === null || r === void 0 ? void 0 : r.autoSubscribe, {
          loggerContextCb: () => this.logContext,
          loggerName: (o = this.loggerOptions) === null || o === void 0 ? void 0 : o.loggerName
        }), a.updateInfo(s), i.set(s.sid, a);
        const d = Array.from(this.trackPublications.values()).find((l) => l.source === (a == null ? void 0 : a.source));
        d && a.source !== E.Source.Unknown && this.log.debug("received a second track publication for ".concat(this.identity, " with the same source: ").concat(a.source), Object.assign(Object.assign({}, this.logContext), {
          oldTrack: ue(d),
          newTrack: ue(a)
        })), this.addTrackPublication(a);
      }
      t.set(s.sid, a);
    }), this.trackPublications.forEach((s) => {
      t.has(s.trackSid) || (this.log.trace("detected removed track on remote participant, unpublishing", Object.assign(Object.assign({}, this.logContext), ue(s))), this.unpublishTrack(s.trackSid, !0));
    }), i.forEach((s) => {
      this.emit(W.TrackPublished, s);
    }), !0;
  }
  /** @internal */
  unpublishTrack(e, t) {
    const i = this.trackPublications.get(e);
    if (!i)
      return;
    const {
      track: s
    } = i;
    switch (s && (s.stop(), i.setTrack(void 0)), this.trackPublications.delete(e), i.kind) {
      case E.Kind.Audio:
        this.audioTrackPublications.delete(e);
        break;
      case E.Kind.Video:
        this.videoTrackPublications.delete(e);
        break;
    }
    t && this.emit(W.TrackUnpublished, i);
  }
  /**
   * @internal
   */
  setAudioOutput(e) {
    return m(this, void 0, void 0, function* () {
      this.audioOutput = e;
      const t = [];
      this.audioTrackPublications.forEach((i) => {
        var s;
        Et(i.track) && hr(i.track) && t.push(i.track.setSinkId((s = e.deviceId) !== null && s !== void 0 ? s : "default"));
      }), yield Promise.all(t);
    });
  }
  /** @internal */
  emit(e) {
    for (var t = arguments.length, i = new Array(t > 1 ? t - 1 : 0), s = 1; s < t; s++)
      i[s - 1] = arguments[s];
    return this.log.trace("participant event", Object.assign(Object.assign({}, this.logContext), {
      event: e,
      args: i
    })), super.emit(e, ...i);
  }
}
var fe;
(function(n) {
  n.Disconnected = "disconnected", n.Connecting = "connecting", n.Connected = "connected", n.Reconnecting = "reconnecting", n.SignalReconnecting = "signalReconnecting";
})(fe || (fe = {}));
const Lm = 4 * 1e3;
class Bi extends Pt.EventEmitter {
  get hasE2EESetup() {
    return this.e2eeManager !== void 0;
  }
  /**
   * Creates a new Room, the primary construct for a LiveKit session.
   * @param options
   */
  constructor(e) {
    var t, i, s, r, o;
    if (super(), t = this, this.state = fe.Disconnected, this.activeSpeakers = [], this.isE2EEEnabled = !1, this.audioEnabled = !0, this.isVideoPlaybackBlocked = !1, this.log = se, this.bufferedEvents = [], this.isResuming = !1, this.rpcHandlers = /* @__PURE__ */ new Map(), this.connect = (a, c, d) => m(this, void 0, void 0, function* () {
      var l;
      if (!np())
        throw Rt() ? Error("WebRTC isn't detected, have you called registerGlobals?") : Error("LiveKit doesn't seem to be supported on this browser. Try to update your browser and make sure no browser extensions are disabling webRTC.");
      const u = yield this.disconnectLock.lock();
      if (this.state === fe.Connected)
        return this.log.info("already connected to room ".concat(this.name), this.logContext), u(), Promise.resolve();
      if (this.connectFuture)
        return u(), this.connectFuture.promise;
      this.setAndEmitConnectionState(fe.Connecting), ((l = this.regionUrlProvider) === null || l === void 0 ? void 0 : l.getServerUrl().toString()) !== Dd(a) && (this.regionUrl = void 0, this.regionUrlProvider = void 0), Vi(new URL(a)) && (this.regionUrlProvider === void 0 ? this.regionUrlProvider = new ye(a, c) : this.regionUrlProvider.updateToken(c), this.regionUrlProvider.fetchRegionSettings().then((b) => {
        var v;
        (v = this.regionUrlProvider) === null || v === void 0 || v.setServerReportedRegions(b);
      }).catch((b) => {
        this.log.warn("could not fetch region settings", Object.assign(Object.assign({}, this.logContext), {
          error: b
        }));
      }));
      const h = (b, v, C) => m(this, void 0, void 0, function* () {
        var T, P;
        this.abortController && this.abortController.abort();
        const R = new AbortController();
        this.abortController = R, u == null || u();
        try {
          if (yield Li.getInstance().getBackOffPromise(a), R.signal.aborted)
            throw Z.cancelled("Connection attempt aborted");
          yield this.attemptConnection(C != null ? C : a, c, d, R), this.abortController = void 0, b();
        } catch (g) {
          if (this.regionUrlProvider && g instanceof Z && g.reason !== Re.Cancelled && g.reason !== Re.NotAllowed) {
            let f = null;
            try {
              this.log.debug("Fetching next region"), f = yield this.regionUrlProvider.getNextBestRegionUrl((T = this.abortController) === null || T === void 0 ? void 0 : T.signal);
            } catch (k) {
              if (k instanceof Z && (k.status === 401 || k.reason === Re.Cancelled)) {
                this.handleDisconnect(this.options.stopLocalTrackOnUnpublish), v(k);
                return;
              }
            }
            // making sure we only register failed attempts on things we actually care about
            [Re.InternalError, Re.ServerUnreachable, Re.Timeout].includes(g.reason) && (this.log.debug("Adding failed connection attempt to back off"), Li.getInstance().addFailedConnectionAttempt(a)), f && !(!((P = this.abortController) === null || P === void 0) && P.signal.aborted) ? (this.log.info("Initial connection failed with ConnectionError: ".concat(g.message, ". Retrying with another region: ").concat(f), this.logContext), this.recreateEngine(!0), yield h(b, v, f)) : (this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, io(g)), v(g));
          } else {
            let f = yt.UNKNOWN_REASON;
            g instanceof Z && (f = io(g)), this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, f), v(g);
          }
        }
      }), p = this.regionUrl;
      return this.regionUrl = void 0, this.connectFuture = new $t((b, v) => {
        h(b, v, p);
      }, () => {
        this.clearConnectionFutures();
      }), this.connectFuture.promise;
    }), this.connectSignal = (a, c, d, l, u, h) => m(this, void 0, void 0, function* () {
      var p, b, v;
      const C = yield d.join(a, c, {
        autoSubscribe: l.autoSubscribe,
        adaptiveStream: typeof u.adaptiveStream == "object" ? !0 : u.adaptiveStream,
        maxRetries: l.maxRetries,
        e2eeEnabled: !!this.e2eeManager,
        websocketTimeout: l.websocketTimeout
      }, h.signal, !u.singlePeerConnection);
      let T = C.serverInfo;
      if (T || (T = {
        version: C.serverVersion,
        region: C.serverRegion
      }), this.serverInfo = T, this.log.debug("connected to Livekit Server ".concat(Object.entries(T).map((P) => {
        let [R, g] = P;
        return "".concat(R, ": ").concat(g);
      }).join(", ")), {
        room: (p = C.room) === null || p === void 0 ? void 0 : p.name,
        roomSid: (b = C.room) === null || b === void 0 ? void 0 : b.sid,
        identity: (v = C.participant) === null || v === void 0 ? void 0 : v.identity
      }), !T.version)
        throw new Vh("unknown server version");
      return T.version === "0.15.1" && this.options.dynacast && (this.log.debug("disabling dynacast due to server version", this.logContext), u.dynacast = !1), C;
    }), this.applyJoinResponse = (a) => {
      const c = a.participant;
      if (this.localParticipant.sid = c.sid, this.localParticipant.identity = c.identity, this.localParticipant.setEnabledPublishCodecs(a.enabledPublishCodecs), this.e2eeManager)
        try {
          this.e2eeManager.setSifTrailer(a.sifTrailer);
        } catch (d) {
          this.log.error(d instanceof Error ? d.message : "Could not set SifTrailer", Object.assign(Object.assign({}, this.logContext), {
            error: d
          }));
        }
      this.handleParticipantUpdates([c, ...a.otherParticipants]), a.room && this.handleRoomUpdate(a.room);
    }, this.attemptConnection = (a, c, d, l) => m(this, void 0, void 0, function* () {
      var u, h;
      this.state === fe.Reconnecting || this.isResuming || !((u = this.engine) === null || u === void 0) && u.pendingReconnect ? (this.log.info("Reconnection attempt replaced by new connection attempt", this.logContext), this.recreateEngine(!0)) : this.maybeCreateEngine(), !((h = this.regionUrlProvider) === null || h === void 0) && h.isCloud() && this.engine.setRegionUrlProvider(this.regionUrlProvider), this.acquireAudioContext(), this.connOptions = Object.assign(Object.assign({}, Qr), d), this.connOptions.rtcConfig && (this.engine.rtcConfig = this.connOptions.rtcConfig), this.connOptions.peerConnectionTimeout && (this.engine.peerConnectionTimeout = this.connOptions.peerConnectionTimeout);
      try {
        const p = yield this.connectSignal(a, c, this.engine, this.connOptions, this.options, l);
        this.applyJoinResponse(p), this.setupLocalParticipantEvents(), this.emit(x.SignalConnected);
      } catch (p) {
        yield this.engine.close(), this.recreateEngine();
        const b = l.signal.aborted ? Z.cancelled("Signal connection aborted") : Z.serverUnreachable("could not establish signal connection");
        throw p instanceof Error && (b.message = "".concat(b.message, ": ").concat(p.message)), p instanceof Z && (b.reason = p.reason, b.status = p.status), this.log.debug("error trying to establish signal connection", Object.assign(Object.assign({}, this.logContext), {
          error: p
        })), b;
      }
      if (l.signal.aborted)
        throw yield this.engine.close(), this.recreateEngine(), Z.cancelled("Connection attempt aborted");
      try {
        yield this.engine.waitForPCInitialConnection(this.connOptions.peerConnectionTimeout, l);
      } catch (p) {
        throw yield this.engine.close(), this.recreateEngine(), p;
      }
      it() && this.options.disconnectOnPageLeave && (window.addEventListener("pagehide", this.onPageLeave), window.addEventListener("beforeunload", this.onPageLeave)), it() && window.addEventListener("freeze", this.onPageLeave), this.setAndEmitConnectionState(fe.Connected), this.emit(x.Connected), Li.getInstance().resetFailedConnectionAttempts(a), this.registerConnectionReconcile(), this.regionUrlProvider && this.regionUrlProvider.notifyConnected();
    }), this.disconnect = function() {
      for (var a = arguments.length, c = new Array(a), d = 0; d < a; d++)
        c[d] = arguments[d];
      return m(t, [...c], void 0, function() {
        var l = this;
        let u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
        return (function* () {
          var h, p, b;
          const v = yield l.disconnectLock.lock();
          try {
            if (l.state === fe.Disconnected) {
              l.log.debug("already disconnected", l.logContext);
              return;
            }
            if (l.log.info("disconnect from room", Object.assign({}, l.logContext)), l.state === fe.Connecting || l.state === fe.Reconnecting || l.isResuming) {
              const C = "Abort connection attempt due to user initiated disconnect";
              l.log.warn(C, l.logContext), (h = l.abortController) === null || h === void 0 || h.abort(C), (b = (p = l.connectFuture) === null || p === void 0 ? void 0 : p.reject) === null || b === void 0 || b.call(p, Z.cancelled("Client initiated disconnect")), l.connectFuture = void 0;
            }
            l.engine && (l.engine.client.isDisconnected || (yield l.engine.client.sendLeave()), yield l.engine.close()), l.handleDisconnect(u, yt.CLIENT_INITIATED), l.engine = void 0;
          } finally {
            v();
          }
        })();
      });
    }, this.onPageLeave = () => m(this, void 0, void 0, function* () {
      this.log.info("Page leave detected, disconnecting", this.logContext), yield this.disconnect();
    }), this.startAudio = () => m(this, void 0, void 0, function* () {
      const a = [], c = nt();
      if (c && c.os === "iOS") {
        const d = "livekit-dummy-audio-el";
        let l = document.getElementById(d);
        if (!l) {
          l = document.createElement("audio"), l.id = d, l.autoplay = !0, l.hidden = !0;
          const u = ws();
          u.enabled = !0;
          const h = new MediaStream([u]);
          l.srcObject = h, document.addEventListener("visibilitychange", () => {
            l && (l.srcObject = document.hidden ? null : h, document.hidden || (this.log.debug("page visible again, triggering startAudio to resume playback and update playback status", this.logContext), this.startAudio()));
          }), document.body.append(l), this.once(x.Disconnected, () => {
            l == null || l.remove(), l = null;
          });
        }
        a.push(l);
      }
      this.remoteParticipants.forEach((d) => {
        d.audioTrackPublications.forEach((l) => {
          l.track && l.track.attachedElements.forEach((u) => {
            a.push(u);
          });
        });
      });
      try {
        yield Promise.all([this.acquireAudioContext(), ...a.map((d) => (d.muted = !1, d.play()))]), this.handleAudioPlaybackStarted();
      } catch (d) {
        throw this.handleAudioPlaybackFailed(d), d;
      }
    }), this.startVideo = () => m(this, void 0, void 0, function* () {
      const a = [];
      for (const c of this.remoteParticipants.values())
        c.videoTrackPublications.forEach((d) => {
          var l;
          (l = d.track) === null || l === void 0 || l.attachedElements.forEach((u) => {
            a.includes(u) || a.push(u);
          });
        });
      yield Promise.all(a.map((c) => c.play())).then(() => {
        this.handleVideoPlaybackStarted();
      }).catch((c) => {
        c.name === "NotAllowedError" ? this.handleVideoPlaybackFailed() : this.log.warn("Resuming video playback failed, make sure you call `startVideo` directly in a user gesture handler", this.logContext);
      });
    }), this.handleRestarting = () => {
      this.clearConnectionReconcile(), this.isResuming = !1;
      for (const a of this.remoteParticipants.values())
        this.handleParticipantDisconnected(a.identity, a);
      this.setAndEmitConnectionState(fe.Reconnecting) && this.emit(x.Reconnecting);
    }, this.handleSignalRestarted = (a) => m(this, void 0, void 0, function* () {
      this.log.debug("signal reconnected to server, region ".concat(a.serverRegion), Object.assign(Object.assign({}, this.logContext), {
        region: a.serverRegion
      })), this.bufferedEvents = [], this.applyJoinResponse(a);
      try {
        yield this.localParticipant.republishAllTracks(void 0, !0);
      } catch (c) {
        this.log.error("error trying to re-publish tracks after reconnection", Object.assign(Object.assign({}, this.logContext), {
          error: c
        }));
      }
      try {
        yield this.engine.waitForRestarted(), this.log.debug("fully reconnected to server", Object.assign(Object.assign({}, this.logContext), {
          region: a.serverRegion
        }));
      } catch {
        return;
      }
      this.setAndEmitConnectionState(fe.Connected), this.emit(x.Reconnected), this.registerConnectionReconcile(), this.emitBufferedEvents();
    }), this.handleParticipantUpdates = (a) => {
      a.forEach((c) => {
        var d;
        if (c.identity === this.localParticipant.identity) {
          this.localParticipant.updateInfo(c);
          return;
        }
        c.identity === "" && (c.identity = (d = this.sidToIdentity.get(c.sid)) !== null && d !== void 0 ? d : "");
        let l = this.remoteParticipants.get(c.identity);
        c.state === xi.DISCONNECTED ? this.handleParticipantDisconnected(c.identity, l) : l = this.getOrCreateParticipant(c.identity, c);
      });
    }, this.handleActiveSpeakersUpdate = (a) => {
      const c = [], d = {};
      a.forEach((l) => {
        if (d[l.sid] = !0, l.sid === this.localParticipant.sid)
          this.localParticipant.audioLevel = l.level, this.localParticipant.setIsSpeaking(!0), c.push(this.localParticipant);
        else {
          const u = this.getRemoteParticipantBySid(l.sid);
          u && (u.audioLevel = l.level, u.setIsSpeaking(!0), c.push(u));
        }
      }), d[this.localParticipant.sid] || (this.localParticipant.audioLevel = 0, this.localParticipant.setIsSpeaking(!1)), this.remoteParticipants.forEach((l) => {
        d[l.sid] || (l.audioLevel = 0, l.setIsSpeaking(!1));
      }), this.activeSpeakers = c, this.emitWhenConnected(x.ActiveSpeakersChanged, c);
    }, this.handleSpeakersChanged = (a) => {
      const c = /* @__PURE__ */ new Map();
      this.activeSpeakers.forEach((l) => {
        const u = this.remoteParticipants.get(l.identity);
        u && u.sid !== l.sid || c.set(l.sid, l);
      }), a.forEach((l) => {
        let u = this.getRemoteParticipantBySid(l.sid);
        l.sid === this.localParticipant.sid && (u = this.localParticipant), u && (u.audioLevel = l.level, u.setIsSpeaking(l.active), l.active ? c.set(l.sid, u) : c.delete(l.sid));
      });
      const d = Array.from(c.values());
      d.sort((l, u) => u.audioLevel - l.audioLevel), this.activeSpeakers = d, this.emitWhenConnected(x.ActiveSpeakersChanged, d);
    }, this.handleStreamStateUpdate = (a) => {
      a.streamStates.forEach((c) => {
        const d = this.getRemoteParticipantBySid(c.participantSid);
        if (!d)
          return;
        const l = d.getTrackPublicationBySid(c.trackSid);
        if (!l || !l.track)
          return;
        const u = E.streamStateFromProto(c.state);
        l.track.setStreamState(u), u !== l.track.streamState && (d.emit(W.TrackStreamStateChanged, l, l.track.streamState), this.emitWhenConnected(x.TrackStreamStateChanged, l, l.track.streamState, d));
      });
    }, this.handleSubscriptionPermissionUpdate = (a) => {
      const c = this.getRemoteParticipantBySid(a.participantSid);
      if (!c)
        return;
      const d = c.getTrackPublicationBySid(a.trackSid);
      d && d.setAllowed(a.allowed);
    }, this.handleSubscriptionError = (a) => {
      const c = Array.from(this.remoteParticipants.values()).find((l) => l.trackPublications.has(a.trackSid));
      if (!c)
        return;
      const d = c.getTrackPublicationBySid(a.trackSid);
      d && d.setSubscriptionError(a.err);
    }, this.handleDataPacket = (a, c) => {
      const d = this.remoteParticipants.get(a.participantIdentity);
      if (a.value.case === "user")
        this.handleUserPacket(d, a.value.value, a.kind, c);
      else if (a.value.case === "transcription")
        this.handleTranscription(d, a.value.value);
      else if (a.value.case === "sipDtmf")
        this.handleSipDtmf(d, a.value.value);
      else if (a.value.case === "chatMessage")
        this.handleChatMessage(d, a.value.value);
      else if (a.value.case === "metrics")
        this.handleMetrics(a.value.value, d);
      else if (a.value.case === "streamHeader" || a.value.case === "streamChunk" || a.value.case === "streamTrailer")
        this.handleDataStream(a, c);
      else if (a.value.case === "rpcRequest") {
        const l = a.value.value;
        this.handleIncomingRpcRequest(a.participantIdentity, l.id, l.method, l.payload, l.responseTimeoutMs, l.version);
      }
    }, this.handleUserPacket = (a, c, d, l) => {
      this.emit(x.DataReceived, c.payload, a, d, c.topic, l), a == null || a.emit(W.DataReceived, c.payload, d, l);
    }, this.handleSipDtmf = (a, c) => {
      this.emit(x.SipDTMFReceived, c, a), a == null || a.emit(W.SipDTMFReceived, c);
    }, this.handleTranscription = (a, c) => {
      const d = c.transcribedParticipantIdentity === this.localParticipant.identity ? this.localParticipant : this.getParticipantByIdentity(c.transcribedParticipantIdentity), l = d == null ? void 0 : d.trackPublications.get(c.trackId), u = hp(c, this.transcriptionReceivedTimes);
      l == null || l.emit(U.TranscriptionReceived, u), d == null || d.emit(W.TranscriptionReceived, u, l), this.emit(x.TranscriptionReceived, u, d, l);
    }, this.handleChatMessage = (a, c) => {
      const d = pp(c);
      this.emit(x.ChatMessage, d, a);
    }, this.handleMetrics = (a, c) => {
      this.emit(x.MetricsReceived, a, c);
    }, this.handleDataStream = (a, c) => {
      this.incomingDataStreamManager.handleDataStreamPacket(a, c);
    }, this.bufferedSegments = /* @__PURE__ */ new Map(), this.handleAudioPlaybackStarted = () => {
      this.canPlaybackAudio || (this.audioEnabled = !0, this.emit(x.AudioPlaybackStatusChanged, !0));
    }, this.handleAudioPlaybackFailed = (a) => {
      this.log.warn("could not playback audio", Object.assign(Object.assign({}, this.logContext), {
        error: a
      })), this.canPlaybackAudio && (this.audioEnabled = !1, this.emit(x.AudioPlaybackStatusChanged, !1));
    }, this.handleVideoPlaybackStarted = () => {
      this.isVideoPlaybackBlocked && (this.isVideoPlaybackBlocked = !1, this.emit(x.VideoPlaybackStatusChanged, !0));
    }, this.handleVideoPlaybackFailed = () => {
      this.isVideoPlaybackBlocked || (this.isVideoPlaybackBlocked = !0, this.emit(x.VideoPlaybackStatusChanged, !1));
    }, this.handleDeviceChange = () => m(this, void 0, void 0, function* () {
      var a;
      ((a = nt()) === null || a === void 0 ? void 0 : a.os) !== "iOS" && (yield this.selectDefaultDevices()), this.emit(x.MediaDevicesChanged);
    }), this.handleRoomUpdate = (a) => {
      const c = this.roomInfo;
      this.roomInfo = a, c && c.metadata !== a.metadata && this.emitWhenConnected(x.RoomMetadataChanged, a.metadata), (c == null ? void 0 : c.activeRecording) !== a.activeRecording && this.emitWhenConnected(x.RecordingStatusChanged, a.activeRecording);
    }, this.handleConnectionQualityUpdate = (a) => {
      a.updates.forEach((c) => {
        if (c.participantSid === this.localParticipant.sid) {
          this.localParticipant.setConnectionQuality(c.quality);
          return;
        }
        const d = this.getRemoteParticipantBySid(c.participantSid);
        d && d.setConnectionQuality(c.quality);
      });
    }, this.onLocalParticipantMetadataChanged = (a) => {
      this.emit(x.ParticipantMetadataChanged, a, this.localParticipant);
    }, this.onLocalParticipantNameChanged = (a) => {
      this.emit(x.ParticipantNameChanged, a, this.localParticipant);
    }, this.onLocalAttributesChanged = (a) => {
      this.emit(x.ParticipantAttributesChanged, a, this.localParticipant);
    }, this.onLocalTrackMuted = (a) => {
      this.emit(x.TrackMuted, a, this.localParticipant);
    }, this.onLocalTrackUnmuted = (a) => {
      this.emit(x.TrackUnmuted, a, this.localParticipant);
    }, this.onTrackProcessorUpdate = (a) => {
      var c;
      (c = a == null ? void 0 : a.onPublish) === null || c === void 0 || c.call(a, this);
    }, this.onLocalTrackPublished = (a) => m(this, void 0, void 0, function* () {
      var c, d, l, u, h, p;
      (c = a.track) === null || c === void 0 || c.on(U.TrackProcessorUpdate, this.onTrackProcessorUpdate), (d = a.track) === null || d === void 0 || d.on(U.Restarted, this.onLocalTrackRestarted), (h = (u = (l = a.track) === null || l === void 0 ? void 0 : l.getProcessor()) === null || u === void 0 ? void 0 : u.onPublish) === null || h === void 0 || h.call(u, this), this.emit(x.LocalTrackPublished, a, this.localParticipant), At(a.track) && (yield a.track.checkForSilence()) && this.emit(x.LocalAudioSilenceDetected, a);
      const b = yield (p = a.track) === null || p === void 0 ? void 0 : p.getDeviceId(!1), v = cr(a.source);
      v && b && b !== this.localParticipant.activeDeviceMap.get(v) && (this.localParticipant.activeDeviceMap.set(v, b), this.emit(x.ActiveDeviceChanged, v, b));
    }), this.onLocalTrackUnpublished = (a) => {
      var c, d;
      (c = a.track) === null || c === void 0 || c.off(U.TrackProcessorUpdate, this.onTrackProcessorUpdate), (d = a.track) === null || d === void 0 || d.off(U.Restarted, this.onLocalTrackRestarted), this.emit(x.LocalTrackUnpublished, a, this.localParticipant);
    }, this.onLocalTrackRestarted = (a) => m(this, void 0, void 0, function* () {
      const c = yield a.getDeviceId(!1), d = cr(a.source);
      d && c && c !== this.localParticipant.activeDeviceMap.get(d) && (this.log.debug("local track restarted, setting ".concat(d, " ").concat(c, " active"), this.logContext), this.localParticipant.activeDeviceMap.set(d, c), this.emit(x.ActiveDeviceChanged, d, c));
    }), this.onLocalConnectionQualityChanged = (a) => {
      this.emit(x.ConnectionQualityChanged, a, this.localParticipant);
    }, this.onMediaDevicesError = (a, c) => {
      this.emit(x.MediaDevicesError, a, c);
    }, this.onLocalParticipantPermissionsChanged = (a) => {
      this.emit(x.ParticipantPermissionsChanged, a, this.localParticipant);
    }, this.onLocalChatMessageSent = (a) => {
      this.emit(x.ChatMessage, a, this.localParticipant);
    }, this.setMaxListeners(100), this.remoteParticipants = /* @__PURE__ */ new Map(), this.sidToIdentity = /* @__PURE__ */ new Map(), this.options = Object.assign(Object.assign({}, zp), e), this.log = St((i = this.options.loggerName) !== null && i !== void 0 ? i : at.Room), this.transcriptionReceivedTimes = /* @__PURE__ */ new Map(), this.options.audioCaptureDefaults = Object.assign(Object.assign({}, Ld), e == null ? void 0 : e.audioCaptureDefaults), this.options.videoCaptureDefaults = Object.assign(Object.assign({}, Nd), e == null ? void 0 : e.videoCaptureDefaults), this.options.publishDefaults = Object.assign(Object.assign({}, $p), e == null ? void 0 : e.publishDefaults), this.maybeCreateEngine(), this.incomingDataStreamManager = new Tm(), this.outgoingDataStreamManager = new wm(this.engine, this.log), this.disconnectLock = new Ze(), this.localParticipant = new Om("", "", this.engine, this.options, this.rpcHandlers, this.outgoingDataStreamManager), (this.options.e2ee || this.options.encryption) && this.setupE2EE(), this.engine.e2eeManager = this.e2eeManager, this.options.videoCaptureDefaults.deviceId && this.localParticipant.activeDeviceMap.set("videoinput", ci(this.options.videoCaptureDefaults.deviceId)), this.options.audioCaptureDefaults.deviceId && this.localParticipant.activeDeviceMap.set("audioinput", ci(this.options.audioCaptureDefaults.deviceId)), !((s = this.options.audioOutput) === null || s === void 0) && s.deviceId && this.switchActiveDevice("audiooutput", ci(this.options.audioOutput.deviceId)).catch((a) => this.log.warn("Could not set audio output: ".concat(a.message), this.logContext)), it()) {
      const a = new AbortController();
      (o = (r = navigator.mediaDevices) === null || r === void 0 ? void 0 : r.addEventListener) === null || o === void 0 || o.call(r, "devicechange", this.handleDeviceChange, {
        signal: a.signal
      }), Bi.cleanupRegistry && Bi.cleanupRegistry.register(this, () => {
        a.abort();
      });
    }
  }
  registerTextStreamHandler(e, t) {
    return this.incomingDataStreamManager.registerTextStreamHandler(e, t);
  }
  unregisterTextStreamHandler(e) {
    return this.incomingDataStreamManager.unregisterTextStreamHandler(e);
  }
  registerByteStreamHandler(e, t) {
    return this.incomingDataStreamManager.registerByteStreamHandler(e, t);
  }
  unregisterByteStreamHandler(e) {
    return this.incomingDataStreamManager.unregisterByteStreamHandler(e);
  }
  /**
   * Establishes the participant as a receiver for calls of the specified RPC method.
   *
   * @param method - The name of the indicated RPC method
   * @param handler - Will be invoked when an RPC request for this method is received
   * @returns A promise that resolves when the method is successfully registered
   * @throws {Error} If a handler for this method is already registered (must call unregisterRpcMethod first)
   *
   * @example
   * ```typescript
   * room.localParticipant?.registerRpcMethod(
   *   'greet',
   *   async (data: RpcInvocationData) => {
   *     console.log(`Received greeting from ${data.callerIdentity}: ${data.payload}`);
   *     return `Hello, ${data.callerIdentity}!`;
   *   }
   * );
   * ```
   *
   * The handler should return a Promise that resolves to a string.
   * If unable to respond within `responseTimeout`, the request will result in an error on the caller's side.
   *
   * You may throw errors of type `RpcError` with a string `message` in the handler,
   * and they will be received on the caller's side with the message intact.
   * Other errors thrown in your handler will not be transmitted as-is, and will instead arrive to the caller as `1500` ("Application Error").
   */
  registerRpcMethod(e, t) {
    if (this.rpcHandlers.has(e))
      throw Error("RPC handler already registered for method ".concat(e, ", unregisterRpcMethod before trying to register again"));
    this.rpcHandlers.set(e, t);
  }
  /**
   * Unregisters a previously registered RPC method.
   *
   * @param method - The name of the RPC method to unregister
   */
  unregisterRpcMethod(e) {
    this.rpcHandlers.delete(e);
  }
  /**
   * @experimental
   */
  setE2EEEnabled(e) {
    return m(this, void 0, void 0, function* () {
      if (this.e2eeManager)
        yield Promise.all([this.localParticipant.setE2EEEnabled(e)]), this.localParticipant.identity !== "" && this.e2eeManager.setParticipantCryptorEnabled(e, this.localParticipant.identity);
      else
        throw Error("e2ee not configured, please set e2ee settings within the room options");
    });
  }
  setupE2EE() {
    var e;
    const t = !!this.options.encryption, i = this.options.encryption || this.options.e2ee;
    i && ("e2eeManager" in i ? (this.e2eeManager = i.e2eeManager, this.e2eeManager.isDataChannelEncryptionEnabled = t) : this.e2eeManager = new Ip(i, t), this.e2eeManager.on(zt.ParticipantEncryptionStatusChanged, (s, r) => {
      fp(r) && (this.isE2EEEnabled = s), this.emit(x.ParticipantEncryptionStatusChanged, s, r);
    }), this.e2eeManager.on(zt.EncryptionError, (s, r) => {
      const o = r ? this.getParticipantByIdentity(r) : void 0;
      this.emit(x.EncryptionError, s, o);
    }), (e = this.e2eeManager) === null || e === void 0 || e.setup(this));
  }
  get logContext() {
    var e;
    return {
      room: this.name,
      roomID: (e = this.roomInfo) === null || e === void 0 ? void 0 : e.sid,
      participant: this.localParticipant.identity,
      pID: this.localParticipant.sid
    };
  }
  /**
   * if the current room has a participant with `recorder: true` in its JWT grant
   **/
  get isRecording() {
    var e, t;
    return (t = (e = this.roomInfo) === null || e === void 0 ? void 0 : e.activeRecording) !== null && t !== void 0 ? t : !1;
  }
  /**
   * server assigned unique room id.
   * returns once a sid has been issued by the server.
   */
  getSid() {
    return this.state === fe.Disconnected ? Je.resolve("") : this.roomInfo && this.roomInfo.sid !== "" ? Je.resolve(this.roomInfo.sid) : new Je((e, t) => {
      const i = (s) => {
        s.sid !== "" && (this.engine.off(H.RoomUpdate, i), e(s.sid));
      };
      this.engine.on(H.RoomUpdate, i), this.once(x.Disconnected, () => {
        this.engine.off(H.RoomUpdate, i), t(new De("Room disconnected before room server id was available"));
      });
    });
  }
  /** user assigned name, derived from JWT token */
  get name() {
    var e, t;
    return (t = (e = this.roomInfo) === null || e === void 0 ? void 0 : e.name) !== null && t !== void 0 ? t : "";
  }
  /** room metadata */
  get metadata() {
    var e;
    return (e = this.roomInfo) === null || e === void 0 ? void 0 : e.metadata;
  }
  get numParticipants() {
    var e, t;
    return (t = (e = this.roomInfo) === null || e === void 0 ? void 0 : e.numParticipants) !== null && t !== void 0 ? t : 0;
  }
  get numPublishers() {
    var e, t;
    return (t = (e = this.roomInfo) === null || e === void 0 ? void 0 : e.numPublishers) !== null && t !== void 0 ? t : 0;
  }
  maybeCreateEngine() {
    this.engine && !this.engine.isClosed || (this.engine = new bm(this.options), this.engine.e2eeManager = this.e2eeManager, this.engine.on(H.ParticipantUpdate, this.handleParticipantUpdates).on(H.RoomUpdate, this.handleRoomUpdate).on(H.SpeakersChanged, this.handleSpeakersChanged).on(H.StreamStateChanged, this.handleStreamStateUpdate).on(H.ConnectionQualityUpdate, this.handleConnectionQualityUpdate).on(H.SubscriptionError, this.handleSubscriptionError).on(H.SubscriptionPermissionUpdate, this.handleSubscriptionPermissionUpdate).on(H.MediaTrackAdded, (e, t, i) => {
      this.onTrackAdded(e, t, i);
    }).on(H.Disconnected, (e) => {
      this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, e);
    }).on(H.ActiveSpeakersUpdate, this.handleActiveSpeakersUpdate).on(H.DataPacketReceived, this.handleDataPacket).on(H.Resuming, () => {
      this.clearConnectionReconcile(), this.isResuming = !0, this.log.info("Resuming signal connection", this.logContext), this.setAndEmitConnectionState(fe.SignalReconnecting) && this.emit(x.SignalReconnecting);
    }).on(H.Resumed, () => {
      this.registerConnectionReconcile(), this.isResuming = !1, this.log.info("Resumed signal connection", this.logContext), this.updateSubscriptions(), this.emitBufferedEvents(), this.setAndEmitConnectionState(fe.Connected) && this.emit(x.Reconnected);
    }).on(H.SignalResumed, () => {
      this.bufferedEvents = [], (this.state === fe.Reconnecting || this.isResuming) && this.sendSyncState();
    }).on(H.Restarting, this.handleRestarting).on(H.SignalRestarted, this.handleSignalRestarted).on(H.Offline, () => {
      this.setAndEmitConnectionState(fe.Reconnecting) && this.emit(x.Reconnecting);
    }).on(H.DCBufferStatusChanged, (e, t) => {
      this.emit(x.DCBufferStatusChanged, e, t);
    }).on(H.LocalTrackSubscribed, (e) => {
      const t = this.localParticipant.getTrackPublications().find((i) => {
        let {
          trackSid: s
        } = i;
        return s === e;
      });
      if (!t) {
        this.log.warn("could not find local track subscription for subscribed event", this.logContext);
        return;
      }
      this.localParticipant.emit(W.LocalTrackSubscribed, t), this.emitWhenConnected(x.LocalTrackSubscribed, t, this.localParticipant);
    }).on(H.RoomMoved, (e) => {
      this.log.debug("room moved", e), e.room && this.handleRoomUpdate(e.room), this.remoteParticipants.forEach((t, i) => {
        this.handleParticipantDisconnected(i, t);
      }), this.emit(x.Moved, e.room.name), e.participant ? this.handleParticipantUpdates([e.participant, ...e.otherParticipants]) : this.handleParticipantUpdates(e.otherParticipants);
    }), this.localParticipant && this.localParticipant.setupEngine(this.engine), this.e2eeManager && this.e2eeManager.setupEngine(this.engine), this.outgoingDataStreamManager && this.outgoingDataStreamManager.setupEngine(this.engine));
  }
  /**
   * getLocalDevices abstracts navigator.mediaDevices.enumerateDevices.
   * In particular, it requests device permissions by default if needed
   * and makes sure the returned device does not consist of dummy devices
   * @param kind
   * @returns a list of available local devices
   */
  static getLocalDevices(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    return We.getInstance().getDevices(e, t);
  }
  /**
   * prepareConnection should be called as soon as the page is loaded, in order
   * to speed up the connection attempt. This function will
   * - perform DNS resolution and pre-warm the DNS cache
   * - establish TLS connection and cache TLS keys
   *
   * With LiveKit Cloud, it will also determine the best edge data center for
   * the current client to connect to if a token is provided.
   */
  prepareConnection(e, t) {
    return m(this, void 0, void 0, function* () {
      if (this.state === fe.Disconnected) {
        this.log.debug("prepareConnection to ".concat(e), this.logContext);
        try {
          if (Vi(new URL(e)) && t) {
            this.regionUrlProvider = new ye(e, t);
            const i = yield this.regionUrlProvider.getNextBestRegionUrl();
            i && this.state === fe.Disconnected && (this.regionUrl = i, yield fetch(hn(i), {
              method: "HEAD"
            }), this.log.debug("prepared connection to ".concat(i), this.logContext));
          } else
            yield fetch(hn(e), {
              method: "HEAD"
            });
        } catch (i) {
          this.log.warn("could not prepare connection", Object.assign(Object.assign({}, this.logContext), {
            error: i
          }));
        }
      }
    });
  }
  /**
   * retrieves a participant by identity
   * @param identity
   * @returns
   */
  getParticipantByIdentity(e) {
    return this.localParticipant.identity === e ? this.localParticipant : this.remoteParticipants.get(e);
  }
  clearConnectionFutures() {
    this.connectFuture = void 0;
  }
  /**
   * @internal for testing
   */
  simulateScenario(e, t) {
    return m(this, void 0, void 0, function* () {
      let i = () => m(this, void 0, void 0, function* () {
      }), s;
      switch (e) {
        case "signal-reconnect":
          yield this.engine.client.handleOnClose("simulate disconnect");
          break;
        case "speaker":
          s = new kt({
            scenario: {
              case: "speakerUpdate",
              value: 3
            }
          });
          break;
        case "node-failure":
          s = new kt({
            scenario: {
              case: "nodeFailure",
              value: !0
            }
          });
          break;
        case "server-leave":
          s = new kt({
            scenario: {
              case: "serverLeave",
              value: !0
            }
          });
          break;
        case "migration":
          s = new kt({
            scenario: {
              case: "migration",
              value: !0
            }
          });
          break;
        case "resume-reconnect":
          this.engine.failNext(), yield this.engine.client.handleOnClose("simulate resume-disconnect");
          break;
        case "disconnect-signal-on-resume":
          i = () => m(this, void 0, void 0, function* () {
            yield this.engine.client.handleOnClose("simulate resume-disconnect");
          }), s = new kt({
            scenario: {
              case: "disconnectSignalOnResume",
              value: !0
            }
          });
          break;
        case "disconnect-signal-on-resume-no-messages":
          i = () => m(this, void 0, void 0, function* () {
            yield this.engine.client.handleOnClose("simulate resume-disconnect");
          }), s = new kt({
            scenario: {
              case: "disconnectSignalOnResumeNoMessages",
              value: !0
            }
          });
          break;
        case "full-reconnect":
          this.engine.fullReconnectOnNext = !0, yield this.engine.client.handleOnClose("simulate full-reconnect");
          break;
        case "force-tcp":
        case "force-tls":
          s = new kt({
            scenario: {
              case: "switchCandidateProtocol",
              value: e === "force-tls" ? 2 : 1
            }
          }), i = () => m(this, void 0, void 0, function* () {
            const r = this.engine.client.onLeave;
            r && r(new os({
              reason: yt.CLIENT_INITIATED,
              action: Mi.RECONNECT
            }));
          });
          break;
        case "subscriber-bandwidth":
          if (t === void 0 || typeof t != "number")
            throw new Error("subscriber-bandwidth requires a number as argument");
          s = new kt({
            scenario: {
              case: "subscriberBandwidth",
              value: ri(t)
            }
          });
          break;
        case "leave-full-reconnect":
          s = new kt({
            scenario: {
              case: "leaveRequestFullReconnect",
              value: !0
            }
          });
      }
      s && (yield this.engine.client.sendSimulateScenario(s), yield i());
    });
  }
  /**
   * Returns true if audio playback is enabled
   */
  get canPlaybackAudio() {
    return this.audioEnabled;
  }
  /**
   * Returns true if video playback is enabled
   */
  get canPlaybackVideo() {
    return !this.isVideoPlaybackBlocked;
  }
  getActiveDevice(e) {
    return this.localParticipant.activeDeviceMap.get(e);
  }
  /**
   * Switches all active devices used in this room to the given device.
   *
   * Note: setting AudioOutput is not supported on some browsers. See [setSinkId](https://developer.mozilla.org/en-US/docs/Web/API/HTMLMediaElement/setSinkId#browser_compatibility)
   *
   * @param kind use `videoinput` for camera track,
   *  `audioinput` for microphone track,
   *  `audiooutput` to set speaker for all incoming audio tracks
   * @param deviceId
   */
  switchActiveDevice(e, t) {
    return m(this, arguments, void 0, function(i, s) {
      var r = this;
      let o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
      return (function* () {
        var a, c, d, l, u, h, p;
        let b = !0, v = !1;
        const C = o ? {
          exact: s
        } : s;
        if (i === "audioinput") {
          v = r.localParticipant.audioTrackPublications.size === 0;
          const T = (a = r.getActiveDevice(i)) !== null && a !== void 0 ? a : r.options.audioCaptureDefaults.deviceId;
          r.options.audioCaptureDefaults.deviceId = C;
          const P = Array.from(r.localParticipant.audioTrackPublications.values()).filter((g) => g.source === E.Source.Microphone);
          try {
            b = (yield Promise.all(P.map((g) => {
              var f;
              return (f = g.audioTrack) === null || f === void 0 ? void 0 : f.setDeviceId(C);
            }))).every((g) => g === !0);
          } catch (g) {
            throw r.options.audioCaptureDefaults.deviceId = T, g;
          }
          const R = P.some((g) => {
            var f, k;
            return (k = (f = g.track) === null || f === void 0 ? void 0 : f.isMuted) !== null && k !== void 0 ? k : !1;
          });
          b && R && (v = !0);
        } else if (i === "videoinput") {
          v = r.localParticipant.videoTrackPublications.size === 0;
          const T = (c = r.getActiveDevice(i)) !== null && c !== void 0 ? c : r.options.videoCaptureDefaults.deviceId;
          r.options.videoCaptureDefaults.deviceId = C;
          const P = Array.from(r.localParticipant.videoTrackPublications.values()).filter((g) => g.source === E.Source.Camera);
          try {
            b = (yield Promise.all(P.map((g) => {
              var f;
              return (f = g.videoTrack) === null || f === void 0 ? void 0 : f.setDeviceId(C);
            }))).every((g) => g === !0);
          } catch (g) {
            throw r.options.videoCaptureDefaults.deviceId = T, g;
          }
          const R = P.some((g) => {
            var f, k;
            return (k = (f = g.track) === null || f === void 0 ? void 0 : f.isMuted) !== null && k !== void 0 ? k : !1;
          });
          b && R && (v = !0);
        } else if (i === "audiooutput") {
          if (v = !0, !ur() && !r.options.webAudioMix || r.options.webAudioMix && r.audioContext && !("setSinkId" in r.audioContext))
            throw new Error("cannot switch audio output, the current browser does not support it");
          r.options.webAudioMix && (s = (d = yield We.getInstance().normalizeDeviceId("audiooutput", s)) !== null && d !== void 0 ? d : ""), (l = (p = r.options).audioOutput) !== null && l !== void 0 || (p.audioOutput = {});
          const T = (u = r.getActiveDevice(i)) !== null && u !== void 0 ? u : r.options.audioOutput.deviceId;
          r.options.audioOutput.deviceId = s;
          try {
            r.options.webAudioMix && ((h = r.audioContext) === null || h === void 0 || h.setSinkId(s)), yield Promise.all(Array.from(r.remoteParticipants.values()).map((P) => P.setAudioOutput({
              deviceId: s
            })));
          } catch (P) {
            throw r.options.audioOutput.deviceId = T, P;
          }
        }
        return v && (r.localParticipant.activeDeviceMap.set(i, s), r.emit(x.ActiveDeviceChanged, i, s)), b;
      })();
    });
  }
  setupLocalParticipantEvents() {
    this.localParticipant.on(W.ParticipantMetadataChanged, this.onLocalParticipantMetadataChanged).on(W.ParticipantNameChanged, this.onLocalParticipantNameChanged).on(W.AttributesChanged, this.onLocalAttributesChanged).on(W.TrackMuted, this.onLocalTrackMuted).on(W.TrackUnmuted, this.onLocalTrackUnmuted).on(W.LocalTrackPublished, this.onLocalTrackPublished).on(W.LocalTrackUnpublished, this.onLocalTrackUnpublished).on(W.ConnectionQualityChanged, this.onLocalConnectionQualityChanged).on(W.MediaDevicesError, this.onMediaDevicesError).on(W.AudioStreamAcquired, this.startAudio).on(W.ChatMessage, this.onLocalChatMessageSent).on(W.ParticipantPermissionsChanged, this.onLocalParticipantPermissionsChanged);
  }
  recreateEngine(e) {
    const t = this.engine;
    e && t && !t.client.isDisconnected ? t.client.sendLeave().finally(() => t.close()) : t == null || t.close(), this.engine = void 0, this.isResuming = !1, this.remoteParticipants.clear(), this.sidToIdentity.clear(), this.bufferedEvents = [], this.maybeCreateEngine();
  }
  onTrackAdded(e, t, i) {
    if (this.state === fe.Connecting || this.state === fe.Reconnecting) {
      const u = () => {
        this.log.debug("deferring on track for later", {
          mediaTrackId: e.id,
          mediaStreamId: t.id,
          tracksInStream: t.getTracks().map((p) => p.id)
        }), this.onTrackAdded(e, t, i), h();
      }, h = () => {
        this.off(x.Reconnected, u), this.off(x.Connected, u), this.off(x.Disconnected, h);
      };
      this.once(x.Reconnected, u), this.once(x.Connected, u), this.once(x.Disconnected, h);
      return;
    }
    if (this.state === fe.Disconnected) {
      this.log.warn("skipping incoming track after Room disconnected", this.logContext);
      return;
    }
    if (e.readyState === "ended") {
      this.log.info("skipping incoming track as it already ended", this.logContext);
      return;
    }
    const s = ep(t.id), r = s[0];
    let o = s[1], a = e.id;
    if (o && o.startsWith("TR") && (a = o), r === this.localParticipant.sid) {
      this.log.warn("tried to create RemoteParticipant for local participant", this.logContext);
      return;
    }
    const c = Array.from(this.remoteParticipants.values()).find((u) => u.sid === r);
    if (!c) {
      this.log.error("Tried to add a track for a participant, that's not present. Sid: ".concat(r), this.logContext);
      return;
    }
    if (!a.startsWith("TR")) {
      const u = this.engine.getTrackIdForReceiver(i);
      if (!u) {
        this.log.error("Tried to add a track whose 'sid' could not be found for a participant, that's not present. Sid: ".concat(r), this.logContext);
        return;
      }
      a = u;
    }
    a.startsWith("TR") || this.log.warn("Tried to add a track whose 'sid' could not be determined for a participant, that's not present. Sid: ".concat(r, ", streamId: ").concat(o, ", trackId: ").concat(a), Object.assign(Object.assign({}, this.logContext), {
      rpID: r,
      streamId: o,
      trackId: a
    }));
    let d;
    this.options.adaptiveStream && (typeof this.options.adaptiveStream == "object" ? d = this.options.adaptiveStream : d = {});
    const l = c.addSubscribedMediaTrack(e, a, t, i, d);
    l != null && l.isEncrypted && !this.e2eeManager && this.emit(x.EncryptionError, new Error("Encrypted ".concat(l.source, " track received from participant ").concat(c.sid, ", but room does not have encryption enabled!")));
  }
  handleDisconnect() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, t = arguments.length > 1 ? arguments[1] : void 0;
    var i, s;
    if (this.clearConnectionReconcile(), this.isResuming = !1, this.bufferedEvents = [], this.transcriptionReceivedTimes.clear(), this.incomingDataStreamManager.clearControllers(), this.state !== fe.Disconnected) {
      this.regionUrl = void 0, this.regionUrlProvider && this.regionUrlProvider.notifyDisconnected();
      try {
        this.remoteParticipants.forEach((r) => {
          r.trackPublications.forEach((o) => {
            r.unpublishTrack(o.trackSid);
          });
        }), this.localParticipant.trackPublications.forEach((r) => {
          var o, a, c;
          r.track && this.localParticipant.unpublishTrack(r.track, e), e ? ((o = r.track) === null || o === void 0 || o.detach(), (a = r.track) === null || a === void 0 || a.stop()) : (c = r.track) === null || c === void 0 || c.stopMonitor();
        }), this.localParticipant.off(W.ParticipantMetadataChanged, this.onLocalParticipantMetadataChanged).off(W.ParticipantNameChanged, this.onLocalParticipantNameChanged).off(W.AttributesChanged, this.onLocalAttributesChanged).off(W.TrackMuted, this.onLocalTrackMuted).off(W.TrackUnmuted, this.onLocalTrackUnmuted).off(W.LocalTrackPublished, this.onLocalTrackPublished).off(W.LocalTrackUnpublished, this.onLocalTrackUnpublished).off(W.ConnectionQualityChanged, this.onLocalConnectionQualityChanged).off(W.MediaDevicesError, this.onMediaDevicesError).off(W.AudioStreamAcquired, this.startAudio).off(W.ChatMessage, this.onLocalChatMessageSent).off(W.ParticipantPermissionsChanged, this.onLocalParticipantPermissionsChanged), this.localParticipant.trackPublications.clear(), this.localParticipant.videoTrackPublications.clear(), this.localParticipant.audioTrackPublications.clear(), this.remoteParticipants.clear(), this.sidToIdentity.clear(), this.activeSpeakers = [], this.audioContext && typeof this.options.webAudioMix == "boolean" && (this.audioContext.close(), this.audioContext = void 0), it() && (window.removeEventListener("beforeunload", this.onPageLeave), window.removeEventListener("pagehide", this.onPageLeave), window.removeEventListener("freeze", this.onPageLeave), (s = (i = navigator.mediaDevices) === null || i === void 0 ? void 0 : i.removeEventListener) === null || s === void 0 || s.call(i, "devicechange", this.handleDeviceChange));
      } finally {
        this.setAndEmitConnectionState(fe.Disconnected), this.emit(x.Disconnected, t);
      }
    }
  }
  handleParticipantDisconnected(e, t) {
    var i;
    this.remoteParticipants.delete(e), t && (this.incomingDataStreamManager.validateParticipantHasNoActiveDataStreams(e), t.trackPublications.forEach((s) => {
      t.unpublishTrack(s.trackSid, !0);
    }), this.emit(x.ParticipantDisconnected, t), t.setDisconnected(), (i = this.localParticipant) === null || i === void 0 || i.handleParticipantDisconnected(t.identity));
  }
  handleIncomingRpcRequest(e, t, i, s, r, o) {
    return m(this, void 0, void 0, function* () {
      if (yield this.engine.publishRpcAck(e, t), o !== 1) {
        yield this.engine.publishRpcResponse(e, t, null, Oe.builtIn("UNSUPPORTED_VERSION"));
        return;
      }
      const a = this.rpcHandlers.get(i);
      if (!a) {
        yield this.engine.publishRpcResponse(e, t, null, Oe.builtIn("UNSUPPORTED_METHOD"));
        return;
      }
      let c = null, d = null;
      try {
        const l = yield a({
          requestId: t,
          callerIdentity: e,
          payload: s,
          responseTimeout: r
        });
        Xr(l) > Fd ? (c = Oe.builtIn("RESPONSE_PAYLOAD_TOO_LARGE"), this.log.warn("RPC Response payload too large for ".concat(i))) : d = l;
      } catch (l) {
        l instanceof Oe ? c = l : (this.log.warn("Uncaught error returned by RPC handler for ".concat(i, ". Returning APPLICATION_ERROR instead."), l), c = Oe.builtIn("APPLICATION_ERROR"));
      }
      yield this.engine.publishRpcResponse(e, t, d, c);
    });
  }
  /**
   * attempt to select the default devices if the previously selected devices are no longer available after a device change event
   */
  selectDefaultDevices() {
    return m(this, void 0, void 0, function* () {
      var e, t, i;
      const s = We.getInstance().previousDevices, r = yield We.getInstance().getDevices(void 0, !1), o = nt();
      if ((o == null ? void 0 : o.name) === "Chrome" && o.os !== "iOS")
        for (let c of r) {
          const d = s.find((l) => l.deviceId === c.deviceId);
          d && d.label !== "" && d.kind === c.kind && d.label !== c.label && this.getActiveDevice(c.kind) === "default" && this.emit(x.ActiveDeviceChanged, c.kind, c.deviceId);
        }
      const a = ["audiooutput", "audioinput", "videoinput"];
      for (let c of a) {
        const d = $h(c), l = this.localParticipant.getTrackPublication(d);
        if (l && (!((e = l.track) === null || e === void 0) && e.isUserProvided))
          continue;
        const u = r.filter((p) => p.kind === c), h = this.getActiveDevice(c);
        if (h === ((t = s.filter((p) => p.kind === c)[0]) === null || t === void 0 ? void 0 : t.deviceId) && u.length > 0 && ((i = u[0]) === null || i === void 0 ? void 0 : i.deviceId) !== h) {
          yield this.switchActiveDevice(c, u[0].deviceId);
          continue;
        }
        c === "audioinput" && !un() || c === "videoinput" || u.length > 0 && !u.find((p) => p.deviceId === this.getActiveDevice(c)) && // avoid switching audio output on safari without explicit user action as it leads to slowed down audio playback
        (c !== "audiooutput" || !un()) && (yield this.switchActiveDevice(c, u[0].deviceId));
      }
    });
  }
  acquireAudioContext() {
    return m(this, void 0, void 0, function* () {
      var e, t;
      if (typeof this.options.webAudioMix != "boolean" && this.options.webAudioMix.audioContext ? this.audioContext = this.options.webAudioMix.audioContext : (!this.audioContext || this.audioContext.state === "closed") && (this.audioContext = (e = Pd()) !== null && e !== void 0 ? e : void 0), this.options.webAudioMix && this.remoteParticipants.forEach((s) => s.setAudioContext(this.audioContext)), this.localParticipant.setAudioContext(this.audioContext), this.audioContext && this.audioContext.state === "suspended")
        try {
          yield Promise.race([this.audioContext.resume(), ze(200)]);
        } catch (s) {
          this.log.warn("Could not resume audio context", Object.assign(Object.assign({}, this.logContext), {
            error: s
          }));
        }
      const i = ((t = this.audioContext) === null || t === void 0 ? void 0 : t.state) === "running";
      i !== this.canPlaybackAudio && (this.audioEnabled = i, this.emit(x.AudioPlaybackStatusChanged, i));
    });
  }
  createParticipant(e, t) {
    var i;
    let s;
    return t ? s = Yn.fromParticipantInfo(this.engine.client, t, {
      loggerContextCb: () => this.logContext,
      loggerName: this.options.loggerName
    }) : s = new Yn(this.engine.client, "", e, void 0, void 0, void 0, {
      loggerContextCb: () => this.logContext,
      loggerName: this.options.loggerName
    }), this.options.webAudioMix && s.setAudioContext(this.audioContext), !((i = this.options.audioOutput) === null || i === void 0) && i.deviceId && s.setAudioOutput(this.options.audioOutput).catch((r) => this.log.warn("Could not set audio output: ".concat(r.message), this.logContext)), s;
  }
  getOrCreateParticipant(e, t) {
    if (this.remoteParticipants.has(e)) {
      const s = this.remoteParticipants.get(e);
      return t && s.updateInfo(t) && this.sidToIdentity.set(t.sid, t.identity), s;
    }
    const i = this.createParticipant(e, t);
    return this.remoteParticipants.set(e, i), this.sidToIdentity.set(t.sid, t.identity), this.emitWhenConnected(x.ParticipantConnected, i), i.on(W.TrackPublished, (s) => {
      this.emitWhenConnected(x.TrackPublished, s, i);
    }).on(W.TrackSubscribed, (s, r) => {
      s.kind === E.Kind.Audio ? (s.on(U.AudioPlaybackStarted, this.handleAudioPlaybackStarted), s.on(U.AudioPlaybackFailed, this.handleAudioPlaybackFailed)) : s.kind === E.Kind.Video && (s.on(U.VideoPlaybackFailed, this.handleVideoPlaybackFailed), s.on(U.VideoPlaybackStarted, this.handleVideoPlaybackStarted)), this.emit(x.TrackSubscribed, s, r, i);
    }).on(W.TrackUnpublished, (s) => {
      this.emit(x.TrackUnpublished, s, i);
    }).on(W.TrackUnsubscribed, (s, r) => {
      this.emit(x.TrackUnsubscribed, s, r, i);
    }).on(W.TrackMuted, (s) => {
      this.emitWhenConnected(x.TrackMuted, s, i);
    }).on(W.TrackUnmuted, (s) => {
      this.emitWhenConnected(x.TrackUnmuted, s, i);
    }).on(W.ParticipantMetadataChanged, (s) => {
      this.emitWhenConnected(x.ParticipantMetadataChanged, s, i);
    }).on(W.ParticipantNameChanged, (s) => {
      this.emitWhenConnected(x.ParticipantNameChanged, s, i);
    }).on(W.AttributesChanged, (s) => {
      this.emitWhenConnected(x.ParticipantAttributesChanged, s, i);
    }).on(W.ConnectionQualityChanged, (s) => {
      this.emitWhenConnected(x.ConnectionQualityChanged, s, i);
    }).on(W.ParticipantPermissionsChanged, (s) => {
      this.emitWhenConnected(x.ParticipantPermissionsChanged, s, i);
    }).on(W.TrackSubscriptionStatusChanged, (s, r) => {
      this.emitWhenConnected(x.TrackSubscriptionStatusChanged, s, r, i);
    }).on(W.TrackSubscriptionFailed, (s, r) => {
      this.emit(x.TrackSubscriptionFailed, s, i, r);
    }).on(W.TrackSubscriptionPermissionChanged, (s, r) => {
      this.emitWhenConnected(x.TrackSubscriptionPermissionChanged, s, r, i);
    }).on(W.Active, () => {
      this.emitWhenConnected(x.ParticipantActive, i), i.kind === cn.AGENT && this.localParticipant.setActiveAgent(i);
    }), t && i.updateInfo(t), i;
  }
  sendSyncState() {
    const e = Array.from(this.remoteParticipants.values()).reduce((i, s) => (i.push(...s.getTrackPublications()), i), []), t = this.localParticipant.getTrackPublications();
    this.engine.sendSyncState(e, t);
  }
  /**
   * After resuming, we'll need to notify the server of the current
   * subscription settings.
   */
  updateSubscriptions() {
    for (const e of this.remoteParticipants.values())
      for (const t of e.videoTrackPublications.values())
        t.isSubscribed && mp(t) && t.emitTrackUpdate();
  }
  getRemoteParticipantBySid(e) {
    const t = this.sidToIdentity.get(e);
    if (t)
      return this.remoteParticipants.get(t);
  }
  registerConnectionReconcile() {
    this.clearConnectionReconcile();
    let e = 0;
    this.connectionReconcileInterval = Be.setInterval(() => {
      // ensure we didn't tear it down
      !this.engine || // engine detected close, but Room missed it
      this.engine.isClosed || // transports failed without notifying engine
      !this.engine.verifyTransport() ? (e++, this.log.warn("detected connection state mismatch", Object.assign(Object.assign({}, this.logContext), {
        numFailures: e,
        engine: this.engine ? {
          closed: this.engine.isClosed,
          transportsConnectedOrConnecting: this.engine.verifyTransport()
        } : void 0
      })), e >= 3 && (this.recreateEngine(), this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, yt.STATE_MISMATCH))) : e = 0;
    }, Lm);
  }
  clearConnectionReconcile() {
    this.connectionReconcileInterval && Be.clearInterval(this.connectionReconcileInterval);
  }
  setAndEmitConnectionState(e) {
    return e === this.state ? !1 : (this.state = e, this.emit(x.ConnectionStateChanged, this.state), !0);
  }
  emitBufferedEvents() {
    this.bufferedEvents.forEach((e) => {
      let [t, i] = e;
      this.emit(t, ...i);
    }), this.bufferedEvents = [];
  }
  emitWhenConnected(e) {
    for (var t = arguments.length, i = new Array(t > 1 ? t - 1 : 0), s = 1; s < t; s++)
      i[s - 1] = arguments[s];
    if (this.state === fe.Reconnecting || this.isResuming || !this.engine || this.engine.pendingReconnect)
      this.bufferedEvents.push([e, i]);
    else if (this.state === fe.Connected)
      return this.emit(e, ...i);
    return !1;
  }
  /**
   * Allows to populate a room with simulated participants.
   * No actual connection to a server will be established, all state is
   * @experimental
   */
  simulateParticipants(e) {
    return m(this, void 0, void 0, function* () {
      var t, i, s, r;
      const o = Object.assign({
        audio: !0,
        video: !0,
        useRealTracks: !1
      }, e.publish), a = Object.assign({
        count: 9,
        audio: !1,
        video: !0,
        aspectRatios: [1.66, 1.7, 1.3]
      }, e.participants);
      if (this.handleDisconnect(), this.roomInfo = new ns({
        sid: "RM_SIMULATED",
        name: "simulated-room",
        emptyTimeout: 0,
        maxParticipants: 0,
        creationTime: Pe.parse((/* @__PURE__ */ new Date()).getTime()),
        metadata: "",
        numParticipants: 1,
        numPublishers: 1,
        turnPassword: "",
        enabledCodecs: [],
        activeRecording: !1
      }), this.localParticipant.updateInfo(new li({
        identity: "simulated-local",
        name: "local-name"
      })), this.setupLocalParticipantEvents(), this.emit(x.SignalConnected), this.emit(x.Connected), this.setAndEmitConnectionState(fe.Connected), o.video) {
        const c = new br(E.Kind.Video, new Ei({
          source: Fe.CAMERA,
          sid: Math.floor(Math.random() * 1e4).toString(),
          type: gt.AUDIO,
          name: "video-dummy"
        }), new Jn(o.useRealTracks && (!((t = window.navigator.mediaDevices) === null || t === void 0) && t.getUserMedia) ? (yield window.navigator.mediaDevices.getUserMedia({
          video: !0
        })).getVideoTracks()[0] : to(160 * ((i = a.aspectRatios[0]) !== null && i !== void 0 ? i : 1), 160, !0, !0), void 0, !1, {
          loggerName: this.options.loggerName,
          loggerContextCb: () => this.logContext
        }), {
          loggerName: this.options.loggerName,
          loggerContextCb: () => this.logContext
        });
        this.localParticipant.addTrackPublication(c), this.localParticipant.emit(W.LocalTrackPublished, c);
      }
      if (o.audio) {
        const c = new br(E.Kind.Audio, new Ei({
          source: Fe.MICROPHONE,
          sid: Math.floor(Math.random() * 1e4).toString(),
          type: gt.AUDIO
        }), new Gn(o.useRealTracks && (!((s = navigator.mediaDevices) === null || s === void 0) && s.getUserMedia) ? (yield navigator.mediaDevices.getUserMedia({
          audio: !0
        })).getAudioTracks()[0] : ws(), void 0, !1, this.audioContext, {
          loggerName: this.options.loggerName,
          loggerContextCb: () => this.logContext
        }), {
          loggerName: this.options.loggerName,
          loggerContextCb: () => this.logContext
        });
        this.localParticipant.addTrackPublication(c), this.localParticipant.emit(W.LocalTrackPublished, c);
      }
      for (let c = 0; c < a.count - 1; c += 1) {
        let d = new li({
          sid: Math.floor(Math.random() * 1e4).toString(),
          identity: "simulated-".concat(c),
          state: xi.ACTIVE,
          tracks: [],
          joinedAt: Pe.parse(Date.now())
        });
        const l = this.getOrCreateParticipant(d.identity, d);
        if (a.video) {
          const u = to(160 * ((r = a.aspectRatios[c % a.aspectRatios.length]) !== null && r !== void 0 ? r : 1), 160, !1, !0), h = new Ei({
            source: Fe.CAMERA,
            sid: Math.floor(Math.random() * 1e4).toString(),
            type: gt.AUDIO
          });
          l.addSubscribedMediaTrack(u, h.sid, new MediaStream([u]), new RTCRtpReceiver()), d.tracks = [...d.tracks, h];
        }
        if (a.audio) {
          const u = ws(), h = new Ei({
            source: Fe.MICROPHONE,
            sid: Math.floor(Math.random() * 1e4).toString(),
            type: gt.AUDIO
          });
          l.addSubscribedMediaTrack(u, h.sid, new MediaStream([u]), new RTCRtpReceiver()), d.tracks = [...d.tracks, h];
        }
        l.updateInfo(d);
      }
    });
  }
  // /** @internal */
  emit(e) {
    for (var t = arguments.length, i = new Array(t > 1 ? t - 1 : 0), s = 1; s < t; s++)
      i[s - 1] = arguments[s];
    if (e !== x.ActiveSpeakersChanged && e !== x.TranscriptionReceived) {
      const r = zd(i).filter((o) => o !== void 0);
      (e === x.TrackSubscribed || e === x.TrackUnsubscribed) && this.log.trace("subscribe trace: ".concat(e), Object.assign(Object.assign({}, this.logContext), {
        event: e,
        args: r
      })), this.log.debug("room event ".concat(e), Object.assign(Object.assign({}, this.logContext), {
        event: e,
        args: r
      }));
    }
    return super.emit(e, ...i);
  }
}
Bi.cleanupRegistry = typeof FinalizationRegistry != "undefined" && new FinalizationRegistry((n) => {
  n();
});
function zd(n) {
  return n.map((e) => {
    if (e)
      return Array.isArray(e) ? zd(e) : typeof e == "object" ? "logContext" in e ? e.logContext : void 0 : e;
  });
}
var Eo;
(function(n) {
  n[n.TooShort = 0] = "TooShort", n[n.HeaderOverrun = 1] = "HeaderOverrun", n[n.MissingExtWords = 2] = "MissingExtWords", n[n.UnsupportedVersion = 3] = "UnsupportedVersion", n[n.InvalidHandle = 4] = "InvalidHandle", n[n.MalformedExt = 5] = "MalformedExt";
})(Eo || (Eo = {}));
var Ro;
(function(n) {
  n[n.TooSmallForHeader = 0] = "TooSmallForHeader", n[n.TooSmallForPayload = 1] = "TooSmallForPayload";
})(Ro || (Ro = {}));
var Qn;
(function(n) {
  n[n.UserTimestamp = 2] = "UserTimestamp", n[n.E2ee = 1] = "E2ee";
})(Qn || (Qn = {}));
Qn.UserTimestamp;
Qn.E2ee;
var Io;
(function(n) {
  n[n.Reserved = 0] = "Reserved", n[n.TooLarge = 1] = "TooLarge";
})(Io || (Io = {}));
var Po;
(function(n) {
  n[n.Start = 0] = "Start", n[n.Inter = 1] = "Inter", n[n.Final = 2] = "Final", n[n.Single = 3] = "Single";
})(Po || (Po = {}));
var xo;
(function(n) {
  n[n.MtuTooShort = 0] = "MtuTooShort";
})(xo || (xo = {}));
St(at.DataTracks);
var Mo;
(function(n) {
  n[n.Interrupted = 0] = "Interrupted", n[n.UnknownFrame = 1] = "UnknownFrame", n[n.BufferFull = 2] = "BufferFull", n[n.Incomplete = 3] = "Incomplete";
})(Mo || (Mo = {}));
var Ao;
(function(n) {
  n[n.NotAllowed = 0] = "NotAllowed", n[n.DuplicateName = 1] = "DuplicateName", n[n.Timeout = 2] = "Timeout", n[n.LimitReached = 3] = "LimitReached", n[n.Disconnected = 4] = "Disconnected", n[n.Cancelled = 5] = "Cancelled";
})(Ao || (Ao = {}));
var Oo;
(function(n) {
  n[n.TrackUnpublished = 0] = "TrackUnpublished", n[n.Dropped = 1] = "Dropped";
})(Oo || (Oo = {}));
var Do;
(function(n) {
  n[n.Packetizer = 0] = "Packetizer", n[n.Encryption = 1] = "Encryption";
})(Do || (Do = {}));
St(at.DataTracks);
var ft;
(function(n) {
  n[n.IDLE = 0] = "IDLE", n[n.RUNNING = 1] = "RUNNING", n[n.SKIPPED = 2] = "SKIPPED", n[n.SUCCESS = 3] = "SUCCESS", n[n.FAILED = 4] = "FAILED";
})(ft || (ft = {}));
class ei extends Pt.EventEmitter {
  constructor(e, t) {
    let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    super(), this.status = ft.IDLE, this.logs = [], this.options = {}, this.url = e, this.token = t, this.name = this.constructor.name, this.room = new Bi(i.roomOptions), this.connectOptions = i.connectOptions, this.options = i;
  }
  run(e) {
    return m(this, void 0, void 0, function* () {
      if (this.status !== ft.IDLE)
        throw Error("check is running already");
      this.setStatus(ft.RUNNING);
      try {
        yield this.perform();
      } catch (t) {
        t instanceof Error && (this.options.errorsAsWarnings ? this.appendWarning(t.message) : this.appendError(t.message));
      }
      return yield this.disconnect(), yield new Promise((t) => setTimeout(t, 500)), this.status !== ft.SKIPPED && this.setStatus(this.isSuccess() ? ft.SUCCESS : ft.FAILED), e && e(), this.getInfo();
    });
  }
  isSuccess() {
    return !this.logs.some((e) => e.level === "error");
  }
  connect(e) {
    return m(this, void 0, void 0, function* () {
      return this.room.state === fe.Connected ? this.room : (e || (e = this.url), yield this.room.connect(e, this.token, this.connectOptions), this.room);
    });
  }
  disconnect() {
    return m(this, void 0, void 0, function* () {
      this.room && this.room.state !== fe.Disconnected && (yield this.room.disconnect(), yield new Promise((e) => setTimeout(e, 500)));
    });
  }
  skip() {
    this.setStatus(ft.SKIPPED);
  }
  switchProtocol(e) {
    return m(this, void 0, void 0, function* () {
      let t = !1, i = !1;
      if (this.room.on(x.Reconnecting, () => {
        t = !0;
      }), this.room.once(x.Reconnected, () => {
        i = !0;
      }), this.room.simulateScenario("force-".concat(e)), yield new Promise((r) => setTimeout(r, 1e3)), !t)
        return;
      const s = Date.now() + 1e4;
      for (; Date.now() < s; ) {
        if (i)
          return;
        yield ze(100);
      }
      throw new Error("Could not reconnect using ".concat(e, " protocol after 10 seconds"));
    });
  }
  appendMessage(e) {
    this.logs.push({
      level: "info",
      message: e
    }), this.emit("update", this.getInfo());
  }
  appendWarning(e) {
    this.logs.push({
      level: "warning",
      message: e
    }), this.emit("update", this.getInfo());
  }
  appendError(e) {
    this.logs.push({
      level: "error",
      message: e
    }), this.emit("update", this.getInfo());
  }
  setStatus(e) {
    this.status = e, this.emit("update", this.getInfo());
  }
  get engine() {
    var e;
    return (e = this.room) === null || e === void 0 ? void 0 : e.engine;
  }
  getInfo() {
    return {
      logs: this.logs,
      name: this.name,
      status: this.status,
      description: this.description
    };
  }
}
class Nm extends ei {
  get description() {
    return "Cloud regions";
  }
  perform() {
    return m(this, void 0, void 0, function* () {
      const e = new ye(this.url, this.token);
      if (!e.isCloud()) {
        this.skip();
        return;
      }
      const t = [], i = /* @__PURE__ */ new Set();
      for (let r = 0; r < 3; r++) {
        const o = yield e.getNextBestRegionUrl();
        if (!o)
          break;
        if (i.has(o))
          continue;
        i.add(o);
        const a = yield this.checkCloudRegion(o);
        this.appendMessage("".concat(a.region, " RTT: ").concat(a.rtt, "ms, duration: ").concat(a.duration, "ms")), t.push(a);
      }
      t.sort((r, o) => (r.duration - o.duration) * 0.5 + (r.rtt - o.rtt) * 0.5);
      const s = t[0];
      this.bestStats = s, this.appendMessage("best Cloud region: ".concat(s.region));
    });
  }
  getInfo() {
    const e = super.getInfo();
    return e.data = this.bestStats, e;
  }
  checkCloudRegion(e) {
    return m(this, void 0, void 0, function* () {
      var t, i;
      yield this.connect(e), this.options.protocol === "tcp" && (yield this.switchProtocol("tcp"));
      const s = (t = this.room.serverInfo) === null || t === void 0 ? void 0 : t.region;
      if (!s)
        throw new Error("Region not found");
      const r = yield this.room.localParticipant.streamText({
        topic: "test"
      }), o = 1e3, c = 1e6 / o, d = "A".repeat(o), l = Date.now();
      for (let b = 0; b < c; b++)
        yield r.write(d);
      yield r.close();
      const u = Date.now(), h = yield (i = this.room.engine.pcManager) === null || i === void 0 ? void 0 : i.publisher.getStats(), p = {
        region: s,
        rtt: 1e4,
        duration: u - l
      };
      return h == null || h.forEach((b) => {
        b.type === "candidate-pair" && b.nominated && (p.rtt = b.currentRoundTripTime * 1e3);
      }), yield this.disconnect(), p;
    });
  }
}
const Ds = 1e4;
class Um extends ei {
  get description() {
    return "Connection via UDP vs TCP";
  }
  perform() {
    return m(this, void 0, void 0, function* () {
      const e = yield this.checkConnectionProtocol("udp"), t = yield this.checkConnectionProtocol("tcp");
      this.bestStats = e, e.qualityLimitationDurations.bandwidth - t.qualityLimitationDurations.bandwidth > 0.5 || (e.packetsLost - t.packetsLost) / e.packetsSent > 0.01 ? (this.appendMessage("best connection quality via tcp"), this.bestStats = t) : this.appendMessage("best connection quality via udp");
      const i = this.bestStats;
      this.appendMessage("upstream bitrate: ".concat((i.bitrateTotal / i.count / 1e3 / 1e3).toFixed(2), " mbps")), this.appendMessage("RTT: ".concat((i.rttTotal / i.count * 1e3).toFixed(2), " ms")), this.appendMessage("jitter: ".concat((i.jitterTotal / i.count * 1e3).toFixed(2), " ms")), i.packetsLost > 0 && this.appendWarning("packets lost: ".concat((i.packetsLost / i.packetsSent * 100).toFixed(2), "%")), i.qualityLimitationDurations.bandwidth > 1 && this.appendWarning("bandwidth limited ".concat((i.qualityLimitationDurations.bandwidth / (Ds / 1e3) * 100).toFixed(2), "%")), i.qualityLimitationDurations.cpu > 0 && this.appendWarning("cpu limited ".concat((i.qualityLimitationDurations.cpu / (Ds / 1e3) * 100).toFixed(2), "%"));
    });
  }
  getInfo() {
    const e = super.getInfo();
    return e.data = this.bestStats, e;
  }
  checkConnectionProtocol(e) {
    return m(this, void 0, void 0, function* () {
      yield this.connect(), e === "tcp" ? yield this.switchProtocol("tcp") : yield this.switchProtocol("udp");
      const t = document.createElement("canvas");
      t.width = 1280, t.height = 720;
      const i = t.getContext("2d");
      if (!i)
        throw new Error("Could not get canvas context");
      let s = 0;
      const r = () => {
        s = (s + 1) % 360, i.fillStyle = "hsl(".concat(s, ", 100%, 50%)"), i.fillRect(0, 0, t.width, t.height), requestAnimationFrame(r);
      };
      r();
      const a = t.captureStream(30).getVideoTracks()[0], d = (yield this.room.localParticipant.publishTrack(a, {
        simulcast: !1,
        degradationPreference: "maintain-resolution",
        videoEncoding: {
          maxBitrate: 2e6
        }
      })).track, l = {
        protocol: e,
        packetsLost: 0,
        packetsSent: 0,
        qualityLimitationDurations: {},
        rttTotal: 0,
        jitterTotal: 0,
        bitrateTotal: 0,
        count: 0
      }, u = setInterval(() => m(this, void 0, void 0, function* () {
        const h = yield d.getRTCStatsReport();
        h == null || h.forEach((p) => {
          p.type === "outbound-rtp" ? (l.packetsSent = p.packetsSent, l.qualityLimitationDurations = p.qualityLimitationDurations, l.bitrateTotal += p.targetBitrate, l.count++) : p.type === "remote-inbound-rtp" && (l.packetsLost = p.packetsLost, l.rttTotal += p.roundTripTime, l.jitterTotal += p.jitter);
        });
      }), 1e3);
      return yield new Promise((h) => setTimeout(h, Ds)), clearInterval(u), a.stop(), t.remove(), yield this.disconnect(), l;
    });
  }
}
class Fm extends ei {
  get description() {
    return "Can publish audio";
  }
  perform() {
    return m(this, void 0, void 0, function* () {
      var e;
      const t = yield this.connect(), i = yield xm();
      if (yield Id(i, 1e3))
        throw new Error("unable to detect audio from microphone");
      this.appendMessage("detected audio from microphone"), t.localParticipant.publishTrack(i), yield new Promise((a) => setTimeout(a, 3e3));
      const r = yield (e = i.sender) === null || e === void 0 ? void 0 : e.getStats();
      if (!r)
        throw new Error("Could not get RTCStats");
      let o = 0;
      if (r.forEach((a) => {
        a.type === "outbound-rtp" && (a.kind === "audio" || !a.kind && a.mediaType === "audio") && (o = a.packetsSent);
      }), o === 0)
        throw new Error("Could not determine packets are sent");
      this.appendMessage("published ".concat(o, " audio packets"));
    });
  }
}
class Vm extends ei {
  get description() {
    return "Can publish video";
  }
  perform() {
    return m(this, void 0, void 0, function* () {
      var e;
      const t = yield this.connect(), i = yield Pm();
      yield this.checkForVideo(i.mediaStreamTrack), t.localParticipant.publishTrack(i), yield new Promise((o) => setTimeout(o, 5e3));
      const s = yield (e = i.sender) === null || e === void 0 ? void 0 : e.getStats();
      if (!s)
        throw new Error("Could not get RTCStats");
      let r = 0;
      if (s.forEach((o) => {
        o.type === "outbound-rtp" && (o.kind === "video" || !o.kind && o.mediaType === "video") && (r += o.packetsSent);
      }), r === 0)
        throw new Error("Could not determine packets are sent");
      this.appendMessage("published ".concat(r, " video packets"));
    });
  }
  checkForVideo(e) {
    return m(this, void 0, void 0, function* () {
      const t = new MediaStream();
      t.addTrack(e.clone());
      const i = document.createElement("video");
      i.srcObject = t, i.muted = !0, i.autoplay = !0, i.playsInline = !0, i.setAttribute("playsinline", "true"), document.body.appendChild(i), yield new Promise((s) => {
        i.onplay = () => {
          setTimeout(() => {
            var r, o, a, c;
            const d = document.createElement("canvas"), l = e.getSettings(), u = (o = (r = l.width) !== null && r !== void 0 ? r : i.videoWidth) !== null && o !== void 0 ? o : 1280, h = (c = (a = l.height) !== null && a !== void 0 ? a : i.videoHeight) !== null && c !== void 0 ? c : 720;
            d.width = u, d.height = h;
            const p = d.getContext("2d");
            p.drawImage(i, 0, 0);
            const v = p.getImageData(0, 0, d.width, d.height).data;
            let C = !0;
            for (let T = 0; T < v.length; T += 4)
              if (v[T] !== 0 || v[T + 1] !== 0 || v[T + 2] !== 0) {
                C = !1;
                break;
              }
            C ? this.appendError("camera appears to be producing only black frames") : this.appendMessage("received video frames"), s();
          }, 1e3);
        }, i.play();
      }), t.getTracks().forEach((s) => s.stop()), i.remove();
    });
  }
}
class Bm extends ei {
  get description() {
    return "Resuming connection after interruption";
  }
  perform() {
    return m(this, void 0, void 0, function* () {
      var e;
      const t = yield this.connect();
      let i = !1, s = !1, r;
      const o = new Promise((d) => {
        setTimeout(d, 5e3), r = d;
      }), a = () => {
        i = !0;
      };
      t.on(x.SignalReconnecting, a).on(x.Reconnecting, a).on(x.Reconnected, () => {
        s = !0, r(!0);
      }), (e = t.engine.client.ws) === null || e === void 0 || e.close();
      const c = t.engine.client.onClose;
      if (c && c(""), yield o, i) {
        if (!s || t.state !== fe.Connected)
          throw this.appendWarning("reconnection is only possible in Redis-based configurations"), new Error("Not able to reconnect");
      } else throw new Error("Did not attempt to reconnect");
    });
  }
}
class jm extends ei {
  get description() {
    return "Can connect via TURN";
  }
  perform() {
    return m(this, void 0, void 0, function* () {
      var e, t, i;
      Vi(new URL(this.url)) && (this.appendMessage("Using region specific url"), this.url = (e = yield new ye(this.url, this.token).getNextBestRegionUrl()) !== null && e !== void 0 ? e : this.url);
      const s = new Kr(), r = yield s.join(this.url, this.token, {
        autoSubscribe: !0,
        maxRetries: 0,
        e2eeEnabled: !1,
        websocketTimeout: 15e3
      }, void 0, !0);
      let o = !1, a = !1, c = !1;
      for (let d of r.iceServers)
        for (let l of d.urls)
          l.startsWith("turn:") ? (a = !0, c = !0) : l.startsWith("turns:") && (a = !0, c = !0, o = !0), l.startsWith("stun:") && (c = !0);
      c ? a && !o && this.appendWarning("TURN is configured server side, but TURN/TLS is unavailable.") : this.appendWarning("No STUN servers configured on server side."), yield s.close(), !((i = (t = this.connectOptions) === null || t === void 0 ? void 0 : t.rtcConfig) === null || i === void 0) && i.iceServers || a ? yield this.room.connect(this.url, this.token, {
        rtcConfig: {
          iceTransportPolicy: "relay"
        }
      }) : (this.appendWarning("No TURN servers configured."), this.skip(), yield new Promise((d) => setTimeout(d, 0)));
    });
  }
}
class qm extends ei {
  get description() {
    return "Establishing WebRTC connection";
  }
  perform() {
    return m(this, void 0, void 0, function* () {
      let e = !1, t = !1;
      this.room.on(x.SignalConnected, () => {
        var i;
        const s = this.room.engine.client.onTrickle;
        this.room.engine.client.onTrickle = (r, o) => {
          if (r.candidate) {
            const a = new RTCIceCandidate(r);
            let c = "".concat(a.protocol, " ").concat(a.address, ":").concat(a.port, " ").concat(a.type);
            a.address && (Hm(a.address) ? c += " (private)" : a.protocol === "tcp" && a.tcpType === "passive" ? (e = !0, c += " (passive)") : a.protocol === "udp" && (t = !0)), this.appendMessage(c);
          }
          s && s(r, o);
        }, !((i = this.room.engine.pcManager) === null || i === void 0) && i.subscriber && (this.room.engine.pcManager.subscriber.onIceCandidateError = (r) => {
          r instanceof RTCPeerConnectionIceErrorEvent && this.appendWarning("error with ICE candidate: ".concat(r.errorCode, " ").concat(r.errorText, " ").concat(r.url));
        });
      });
      try {
        yield this.connect(), se.info("now the room is connected");
      } catch (i) {
        throw this.appendWarning("ports need to be open on firewall in order to connect."), i;
      }
      e || this.appendWarning("Server is not configured for ICE/TCP"), t || this.appendWarning("No public IPv4 UDP candidates were found. Your server is likely not configured correctly");
    });
  }
}
function Hm(n) {
  const e = n.split(".");
  if (e.length === 4) {
    if (e[0] === "10")
      return !0;
    if (e[0] === "192" && e[1] === "168")
      return !0;
    if (e[0] === "172") {
      const t = parseInt(e[1], 10);
      if (t >= 16 && t <= 31)
        return !0;
    }
  }
  return !1;
}
class Wm extends ei {
  get description() {
    return "Connecting to signal connection via WebSocket";
  }
  perform() {
    return m(this, void 0, void 0, function* () {
      var e, t, i;
      (this.url.startsWith("ws:") || this.url.startsWith("http:")) && this.appendWarning("Server is insecure, clients may block connections to it");
      let s = new Kr(), r;
      try {
        r = yield s.join(this.url, this.token, {
          autoSubscribe: !0,
          maxRetries: 0,
          e2eeEnabled: !1,
          websocketTimeout: 15e3
        }, void 0, !0);
      } catch (o) {
        if (Vi(new URL(this.url))) {
          this.appendMessage("Initial connection failed with error ".concat(o.message, ". Retrying with region fallback"));
          const c = yield new ye(this.url, this.token).getNextBestRegionUrl();
          c && (r = yield s.join(c, this.token, {
            autoSubscribe: !0,
            maxRetries: 0,
            e2eeEnabled: !1,
            websocketTimeout: 15e3
          }, void 0, !0), this.appendMessage("Fallback to region worked. To avoid initial connections failing, ensure you're calling room.prepareConnection() ahead of time"));
        }
      }
      r ? (this.appendMessage("Connected to server, version ".concat(r.serverVersion, ".")), ((e = r.serverInfo) === null || e === void 0 ? void 0 : e.edition) === Rc.Cloud && (!((t = r.serverInfo) === null || t === void 0) && t.region) && this.appendMessage("LiveKit Cloud: ".concat((i = r.serverInfo) === null || i === void 0 ? void 0 : i.region))) : this.appendError("Websocket connection could not be established"), yield s.close();
    });
  }
}
class wv extends Pt.EventEmitter {
  constructor(e, t) {
    let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    super(), this.options = {}, this.checkResults = /* @__PURE__ */ new Map(), this.url = e, this.token = t, this.options = i;
  }
  getNextCheckId() {
    const e = this.checkResults.size;
    return this.checkResults.set(e, {
      logs: [],
      status: ft.IDLE,
      name: "",
      description: ""
    }), e;
  }
  updateCheck(e, t) {
    this.checkResults.set(e, t), this.emit("checkUpdate", e, t);
  }
  isSuccess() {
    return Array.from(this.checkResults.values()).every((e) => e.status !== ft.FAILED);
  }
  getResults() {
    return Array.from(this.checkResults.values());
  }
  createAndRunCheck(e) {
    return m(this, void 0, void 0, function* () {
      const t = this.getNextCheckId(), i = new e(this.url, this.token, this.options), s = (o) => {
        this.updateCheck(t, o);
      };
      i.on("update", s);
      const r = yield i.run();
      return i.off("update", s), r;
    });
  }
  checkWebsocket() {
    return m(this, void 0, void 0, function* () {
      return this.createAndRunCheck(Wm);
    });
  }
  checkWebRTC() {
    return m(this, void 0, void 0, function* () {
      return this.createAndRunCheck(qm);
    });
  }
  checkTURN() {
    return m(this, void 0, void 0, function* () {
      return this.createAndRunCheck(jm);
    });
  }
  checkReconnect() {
    return m(this, void 0, void 0, function* () {
      return this.createAndRunCheck(Bm);
    });
  }
  checkPublishAudio() {
    return m(this, void 0, void 0, function* () {
      return this.createAndRunCheck(Fm);
    });
  }
  checkPublishVideo() {
    return m(this, void 0, void 0, function* () {
      return this.createAndRunCheck(Vm);
    });
  }
  checkConnectionProtocol() {
    return m(this, void 0, void 0, function* () {
      const e = yield this.createAndRunCheck(Um);
      if (e.data && "protocol" in e.data) {
        const t = e.data;
        this.options.protocol = t.protocol;
      }
      return e;
    });
  }
  checkCloudRegion() {
    return m(this, void 0, void 0, function* () {
      return this.createAndRunCheck(Nm);
    });
  }
}
function he(n, e, t) {
  return (e = zm(e)) in n ? Object.defineProperty(n, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : n[e] = t, n;
}
function $m(n, e) {
  if (typeof n != "object" || !n) return n;
  var t = n[Symbol.toPrimitive];
  if (t !== void 0) {
    var i = t.call(n, e);
    if (typeof i != "object") return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(n);
}
function zm(n) {
  var e = $m(n, "string");
  return typeof e == "symbol" ? e : e + "";
}
new TextEncoder();
new TextDecoder();
class et extends Error {
  constructor(e, t) {
    var i;
    super(e, t), he(this, "code", "ERR_JOSE_GENERIC"), this.name = this.constructor.name, (i = Error.captureStackTrace) === null || i === void 0 || i.call(Error, this, this.constructor);
  }
}
he(et, "code", "ERR_JOSE_GENERIC");
class Km extends et {
  constructor(e, t) {
    let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "unspecified", s = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "unspecified";
    super(e, {
      cause: {
        claim: i,
        reason: s,
        payload: t
      }
    }), he(this, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED"), he(this, "claim", void 0), he(this, "reason", void 0), he(this, "payload", void 0), this.claim = i, this.reason = s, this.payload = t;
  }
}
he(Km, "code", "ERR_JWT_CLAIM_VALIDATION_FAILED");
class Gm extends et {
  constructor(e, t) {
    let i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "unspecified", s = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "unspecified";
    super(e, {
      cause: {
        claim: i,
        reason: s,
        payload: t
      }
    }), he(this, "code", "ERR_JWT_EXPIRED"), he(this, "claim", void 0), he(this, "reason", void 0), he(this, "payload", void 0), this.claim = i, this.reason = s, this.payload = t;
  }
}
he(Gm, "code", "ERR_JWT_EXPIRED");
class Jm extends et {
  constructor() {
    super(...arguments), he(this, "code", "ERR_JOSE_ALG_NOT_ALLOWED");
  }
}
he(Jm, "code", "ERR_JOSE_ALG_NOT_ALLOWED");
class Ym extends et {
  constructor() {
    super(...arguments), he(this, "code", "ERR_JOSE_NOT_SUPPORTED");
  }
}
he(Ym, "code", "ERR_JOSE_NOT_SUPPORTED");
class Qm extends et {
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "decryption operation failed", t = arguments.length > 1 ? arguments[1] : void 0;
    super(e, t), he(this, "code", "ERR_JWE_DECRYPTION_FAILED");
  }
}
he(Qm, "code", "ERR_JWE_DECRYPTION_FAILED");
class Xm extends et {
  constructor() {
    super(...arguments), he(this, "code", "ERR_JWE_INVALID");
  }
}
he(Xm, "code", "ERR_JWE_INVALID");
class Zm extends et {
  constructor() {
    super(...arguments), he(this, "code", "ERR_JWS_INVALID");
  }
}
he(Zm, "code", "ERR_JWS_INVALID");
class ef extends et {
  constructor() {
    super(...arguments), he(this, "code", "ERR_JWT_INVALID");
  }
}
he(ef, "code", "ERR_JWT_INVALID");
class tf extends et {
  constructor() {
    super(...arguments), he(this, "code", "ERR_JWK_INVALID");
  }
}
he(tf, "code", "ERR_JWK_INVALID");
class nf extends et {
  constructor() {
    super(...arguments), he(this, "code", "ERR_JWKS_INVALID");
  }
}
he(nf, "code", "ERR_JWKS_INVALID");
class sf extends et {
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "no applicable key found in the JSON Web Key Set", t = arguments.length > 1 ? arguments[1] : void 0;
    super(e, t), he(this, "code", "ERR_JWKS_NO_MATCHING_KEY");
  }
}
he(sf, "code", "ERR_JWKS_NO_MATCHING_KEY");
class rf extends et {
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "multiple matching keys found in the JSON Web Key Set", t = arguments.length > 1 ? arguments[1] : void 0;
    super(e, t), he(this, Symbol.asyncIterator, void 0), he(this, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS");
  }
}
he(rf, "code", "ERR_JWKS_MULTIPLE_MATCHING_KEYS");
class af extends et {
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "request timed out", t = arguments.length > 1 ? arguments[1] : void 0;
    super(e, t), he(this, "code", "ERR_JWKS_TIMEOUT");
  }
}
he(af, "code", "ERR_JWKS_TIMEOUT");
class of extends et {
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "signature verification failed", t = arguments.length > 1 ? arguments[1] : void 0;
    super(e, t), he(this, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
  }
}
he(of, "code", "ERR_JWS_SIGNATURE_VERIFICATION_FAILED");
const cf = {
  CLIENT_INITIATED: 1
};
class fn {
  constructor() {
    this.events = /* @__PURE__ */ new Map();
  }
  /**
   * Subscribe to an event
   * @param event Event name
   * @param callback Callback function
   * @returns Unsubscribe function
   */
  on(e, t) {
    return this.events.has(e) || this.events.set(e, /* @__PURE__ */ new Set()), this.events.get(e).add(t), () => {
      this.off(e, t);
    };
  }
  /**
   * Unsubscribe from an event
   * @param event Event name
   * @param callback Callback function to remove
   */
  off(e, t) {
    const i = this.events.get(e);
    i && (i.delete(t), i.size === 0 && this.events.delete(e));
  }
  /**
   * Emit an event to all subscribers
   * @param event Event name
   * @param args Arguments to pass to callbacks
   */
  emit(e, ...t) {
    const i = this.events.get(e);
    i && i.forEach((s) => {
      try {
        s(...t);
      } catch (r) {
        console.error(`Error in event handler for "${e}":`, r);
      }
    });
  }
  /**
   * Remove all event listeners
   */
  removeAllListeners() {
    this.events.clear();
  }
  /**
   * Get the number of listeners for an event
   * @param event Event name
   * @returns Number of listeners
   */
  listenerCount(e) {
    var t, i;
    return (i = (t = this.events.get(e)) == null ? void 0 : t.size) != null ? i : 0;
  }
}
class df extends fn {
  constructor(e) {
    super(), this.room = null, this.listeners = [], this._wsSession = null, this._isAudioEnabled = !1, this._isAudioMuted = !1, this._audioLevel = 0, e && this.setRoom(e);
  }
  setWebSocketSession(e) {
    this._wsSession = e;
  }
  syncWsAudioState(e) {
    this._isAudioEnabled = e, this._isAudioMuted = !e, this.emit("audioStateChange", {
      isAudioMuted: this._isAudioMuted,
      isAudioEnabled: this._isAudioEnabled
    });
  }
  get isAudioEnabled() {
    return this._isAudioEnabled;
  }
  get isAudioMuted() {
    return this._isAudioMuted;
  }
  get audioLevel() {
    return this._audioLevel;
  }
  /**
   * Set the LiveKit room instance
   */
  setRoom(e) {
    this.room && this.cleanupListeners(), this.room = e, e && (this.setupListeners(), e.state !== "disconnected" && this.updateState());
  }
  /**
   * Setup event listeners for room
   */
  setupListeners() {
    if (!this.room)
      return;
    const e = this.room.localParticipant, t = (o) => {
      o.source === "microphone" && (this._isAudioMuted = !0, this._isAudioEnabled = !1, this.emit("audioStateChange", { isAudioMuted: !0, isAudioEnabled: !1 }));
    }, i = (o) => {
      o.source === "microphone" && (this._isAudioMuted = !1, this._isAudioEnabled = !0, this.emit("audioStateChange", { isAudioMuted: !1, isAudioEnabled: !0 }));
    }, s = (o) => {
      o.source === "microphone" && (this._isAudioEnabled = !0, this._isAudioMuted = !1, this.emit("audioStateChange", { isAudioMuted: !1, isAudioEnabled: !0 }));
    }, r = (o) => {
      o.source === "microphone" && (this._isAudioEnabled = !1, this._isAudioMuted = !0, this.emit("audioStateChange", { isAudioMuted: !0, isAudioEnabled: !1 }));
    };
    this.listeners = [
      ["trackMuted", t],
      ["trackUnmuted", i],
      ["localTrackPublished", s],
      ["localTrackUnpublished", r]
    ];
    for (const [o, a] of this.listeners)
      e.on(o, a);
  }
  /**
   * Clean up event listeners
   */
  cleanupListeners() {
    if (!this.room)
      return;
    const e = this.room.localParticipant;
    for (const [t, i] of this.listeners)
      e.off(t, i);
    this.listeners = [];
  }
  /**
   * Force-sync the stored audio state with the underlying LiveKit room.
   * Useful right after a connection completes so the UI can reflect
   * the current microphone permission without waiting for a toggle event.
   */
  syncStateFromRoom(e = {}) {
    var a;
    const { emit: t = !1 } = e;
    if (!this.room || this.room.state === "disconnected") {
      const c = this._isAudioEnabled !== !1 || this._isAudioMuted !== !0 || this._audioLevel !== 0;
      this._isAudioEnabled = !1, this._isAudioMuted = !0, this._audioLevel = 0, t && c && this.emit("audioStateChange", {
        isAudioMuted: this._isAudioMuted,
        isAudioEnabled: this._isAudioEnabled,
        audioLevel: this._audioLevel
      });
      return;
    }
    const i = this.room.localParticipant, s = (a = i == null ? void 0 : i.isMicrophoneEnabled) != null ? a : !1, r = !s, o = this._isAudioEnabled !== s || this._isAudioMuted !== r;
    this._isAudioEnabled = s, this._isAudioMuted = r, t && o && this.emit("audioStateChange", {
      isAudioMuted: this._isAudioMuted,
      isAudioEnabled: this._isAudioEnabled,
      audioLevel: this._audioLevel
    });
  }
  /**
   * Update audio state from room
   */
  updateState() {
    this.syncStateFromRoom();
  }
  /**
   * Enable audio
   */
  async enableAudio() {
    if (this._wsSession) {
      this._wsSession.enableMic(!0), this._isAudioEnabled = !0, this._isAudioMuted = !1, this.emit("audioStateChange", { isAudioMuted: !1, isAudioEnabled: !0, audioLevel: this._audioLevel });
      return;
    }
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      await this.room.localParticipant.setMicrophoneEnabled(!0), this._isAudioEnabled = !0, this._isAudioMuted = !1, this.emit("audioStateChange", {
        isAudioMuted: !1,
        isAudioEnabled: !0,
        audioLevel: this._audioLevel
      });
    } catch (e) {
      throw e;
    }
  }
  /**
   * Disable audio and completely release microphone
   */
  async disableAudio() {
    var e;
    if (this._wsSession) {
      this._wsSession.enableMic(!1), this._isAudioEnabled = !1, this._isAudioMuted = !0, this.emit("audioStateChange", { isAudioMuted: !0, isAudioEnabled: !1, audioLevel: 0 });
      return;
    }
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      const t = (e = Array.from(this.room.localParticipant.audioTrackPublications.values()).find((i) => i.source === "microphone" && i.track)) == null ? void 0 : e.track;
      await this.room.localParticipant.setMicrophoneEnabled(!1), t && t.stop(), this._isAudioEnabled = !1, this._isAudioMuted = !0, this.emit("audioStateChange", {
        isAudioMuted: !0,
        isAudioEnabled: !1,
        audioLevel: 0
      });
    } catch (t) {
      throw t;
    }
  }
  /**
   * Mute audio
   */
  async muteAudio() {
    await this.disableAudio();
  }
  /**
   * Unmute audio
   */
  async unmuteAudio() {
    await this.enableAudio();
  }
  /**
   * Toggle audio
   */
  async toggleAudio() {
    this._isAudioMuted ? await this.unmuteAudio() : await this.muteAudio();
  }
  /**
   * Set audio device
   */
  async setAudioDevice(e) {
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      await this.room.localParticipant.setMicrophoneEnabled(!0, { deviceId: e });
    } catch (t) {
      throw t;
    }
  }
  /**
   * Get available audio devices
   */
  async getAudioDevices() {
    try {
      return (await navigator.mediaDevices.enumerateDevices()).filter((i) => i.kind === "audioinput");
    } catch (e) {
      throw e;
    }
  }
  /**
   * Start audio level monitoring
   */
  startAudioLevelMonitoring() {
    this.room;
  }
  /**
   * Stop audio level monitoring
   */
  stopAudioLevelMonitoring() {
    this._audioLevel = 0;
  }
  /**
   * Reset state on disconnect
   */
  reset() {
    this._isAudioEnabled = !1, this._isAudioMuted = !0, this._audioLevel = 0, this.emit("audioStateChange", {
      isAudioMuted: !0,
      isAudioEnabled: !1,
      audioLevel: 0
    });
  }
}
function lf(n, e, t = typeof location != "undefined" ? location.protocol : void 0) {
  return /^ws:\/\//i.test(n) && (typeof e == "string" && /^https:\/\//i.test(e) || t === "https:") ? n.replace(/^ws:\/\//i, "wss://") : n;
}
const uf = () => {
  var o, a, c;
  const n = typeof window != "undefined", e = (d) => {
    try {
      return typeof process != "undefined" && process.env ? process.env[d] : void 0;
    } catch {
      return;
    }
  }, t = e("NEXT_PUBLIC_ENVIRONMENT");
  if (t === "PRODUCTION")
    return "production";
  if (t === "PREVIEW" || t === "STAGING")
    return "development";
  const i = e("NODE_ENV"), s = e("REACT_APP_ENV");
  return i === "production" || s === "production" ? "production" : i === "development" || s === "development" || e("VITE_DEV_SERVER_URL") !== void 0 || n && (((o = window.location) == null ? void 0 : o.hostname) === "localhost" || ((a = window.location) == null ? void 0 : a.hostname) === "127.0.0.1" || (c = window.location) != null && c.port && ["3000", "3001", "5173", "8080"].includes(window.location.port)) ? "development" : "production";
}, hf = uf(), pf = hf === "development";
function bi() {
  if (pf)
    return !0;
  try {
    if (typeof window != "undefined" && window.__CONVAI_DEBUG__)
      return !0;
  } catch {
  }
  return !1;
}
const yi = {
  log: (...n) => console.log("[Convai]", ...n),
  warn: (...n) => console.warn("[Convai]", ...n),
  error: (...n) => console.error("[Convai]", ...n),
  info: (...n) => console.info("[Convai]", ...n),
  debug: (...n) => console.debug("[Convai]", ...n),
  trace: (...n) => console.trace("[Convai]", ...n)
}, Si = () => {
}, Pi = {
  log: (...n) => bi() ? yi.log(...n) : Si(),
  warn: (...n) => bi() ? yi.warn(...n) : Si(),
  error: (...n) => bi() ? yi.error(...n) : Si(),
  info: (...n) => bi() ? yi.info(...n) : Si(),
  debug: (...n) => bi() ? yi.debug(...n) : Si(),
  trace: (...n) => bi() ? yi.trace(...n) : Si()
};
function Tt(n) {
  return n === "webcam" || n === "camera";
}
function mf(n, e, t) {
  return !t && Tt(n) && Tt(e);
}
class ff extends fn {
  constructor(e) {
    super(), this.room = null, this.listeners = [], this._isVideoEnabled = !1, this._isVideoHidden = !1, this._activeVisionSource = null, this.pendingVisionSourceTracks = /* @__PURE__ */ new WeakMap(), this.webSocketVisionMessageSender = null, this.webSocketVisionMode = "off", e && this.setRoom(e);
  }
  get isVideoEnabled() {
    return this._isVideoEnabled;
  }
  get isVideoHidden() {
    return this._isVideoHidden;
  }
  get activeVisionSource() {
    return this.getLiveVisionSource();
  }
  get hasActiveVisionSource() {
    return this.activeVisionSource !== null;
  }
  get visionSourceState() {
    return this.makeVisionSourceState();
  }
  /**
   * Set the LiveKit room instance
   */
  setRoom(e) {
    this.room && this.cleanupListeners(), this.room = e, e && (this.setupListeners(), this.updateState());
  }
  setWebSocketVisionMessageSender(e) {
    this.webSocketVisionMessageSender = e, this.webSocketVisionMode = e ? "enabled" : "off";
  }
  setWebSocketVisionDisabled() {
    var t;
    this.webSocketVisionMessageSender = null, this.webSocketVisionMode = "disabled";
    const e = this._activeVisionSource;
    (t = e == null ? void 0 : e.cleanup) == null || t.call(e), e != null && e.stopTrackOnUnpublish && e.track.readyState !== "ended" && e.track.stop(), this._activeVisionSource = null, this._isVideoEnabled = !1;
  }
  /**
   * Setup event listeners for room
   */
  setupListeners() {
    if (!this.room)
      return;
    const e = this.room.localParticipant, t = (o) => {
      this.isWebcamPublication(o) && (this._isVideoHidden = !0, this.emitVideoStateChange("track_muted", { isVideoHidden: !0 }));
    }, i = (o) => {
      this.isWebcamPublication(o) && (this._isVideoHidden = !1, this.emitVideoStateChange("track_unmuted", { isVideoHidden: !1 }));
    }, s = (o) => {
      if (this.isWebcamPublication(o)) {
        if (this._isVideoEnabled = !0, !this._activeVisionSource) {
          const a = this.createPublicationHandle(o, "webcam", "webcam", !1);
          a && this.setActiveVisionSource(a);
        }
        this.emitVideoStateChange("track_published", { isVideoEnabled: !0 });
      }
    }, r = (o) => {
      if (this.isCameraLikeSource(o == null ? void 0 : o.source)) {
        const a = this.isWebcamPublication(o);
        this.clearActiveVisionSourceForPublication(o, a ? "track_unpublished" : "vision_source_unpublished"), this.updateState(), this.emitVideoStateChange(a ? "track_unpublished" : "vision_source_unpublished", {
          isVideoEnabled: this._isVideoEnabled
        });
      }
    };
    this.listeners = [
      ["trackMuted", t],
      ["trackUnmuted", i],
      ["localTrackPublished", s],
      ["localTrackUnpublished", r]
    ];
    for (const [o, a] of this.listeners)
      e.on(o, a);
  }
  /**
   * Clean up event listeners
   */
  cleanupListeners() {
    if (!this.room)
      return;
    const e = this.room.localParticipant;
    for (const [t, i] of this.listeners)
      e.off(t, i);
    this.listeners = [];
  }
  /**
   * Update video state from room
   */
  updateState() {
    var i, s;
    if (!this.room || this.room.state === "disconnected") {
      this._isVideoEnabled = !1, this._isVideoHidden = !1, (s = (i = this._activeVisionSource) == null ? void 0 : i.cleanup) == null || s.call(i), this._activeVisionSource = null;
      return;
    }
    let e = this.getLiveVisionSource();
    const t = this.room.localParticipant;
    if (!e && t.isCameraEnabled) {
      const r = this.createPublicationHandle(t.getTrackPublication(E.Source.Camera), "webcam", "webcam", !1);
      r && (this.setActiveVisionSource(r), e = r);
    }
    this._isVideoEnabled = Tt(e == null ? void 0 : e.source) || !e && t.isCameraEnabled, this._isVideoHidden = !1;
  }
  /**
   * Enable video
   */
  async enableVideo() {
    if (this.isWebSocketVisionTransport()) {
      this.assertWebSocketVisionEnabled();
      const t = (await navigator.mediaDevices.getUserMedia({
        video: !0,
        audio: !1
      })).getVideoTracks()[0];
      if (!t)
        throw new Error("getUserMedia() produced no video track");
      try {
        await this.publishVideoTrack(t, {
          name: "webcam",
          source: "webcam",
          stopTrackOnUnpublish: !0
        });
      } catch (i) {
        throw t.stop(), i;
      }
      return;
    }
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      await this.replaceActiveVisionSource({ source: "webcam" });
      const e = await this.room.localParticipant.setCameraEnabled(!0);
      this._isVideoEnabled = !0;
      const t = this.createPublicationHandle(e || this.room.localParticipant.getTrackPublication(E.Source.Camera), "webcam", "webcam", !1);
      t && this.setActiveVisionSource(t), this.emitVideoStateChange("webcam_enabled", { isVideoEnabled: !0 });
    } catch (e) {
      throw e;
    }
  }
  /**
   * Disable video
   */
  async disableVideo() {
    var e;
    if (this.isWebSocketVisionTransport()) {
      const t = this._activeVisionSource;
      t && await this.unpublishVisionSource(t), this._isVideoEnabled = !1, this.emitVideoStateChange("webcam_disabled", { isVideoEnabled: !1 });
      return;
    }
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      await this.room.localParticipant.setCameraEnabled(!1), this._isVideoEnabled = !1;
      const t = this._activeVisionSource;
      t && (Tt(t.source) ? ((e = t.cleanup) == null || e.call(t), this._activeVisionSource = null) : await this.unpublishVisionSource(t)), this.emitVideoStateChange("webcam_disabled", { isVideoEnabled: !1 });
    } catch (t) {
      throw t;
    }
  }
  /**
   * Hide video
   */
  async hideVideo() {
    await this.disableVideo();
  }
  /**
   * Show video
   */
  async showVideo() {
    await this.enableVideo();
  }
  /**
   * Toggle video
   */
  async toggleVideo() {
    this._isVideoEnabled ? await this.disableVideo() : await this.enableVideo();
  }
  /**
   * Set video device
   */
  async setVideoDevice(e) {
    if (this.isWebSocketVisionTransport()) {
      this.assertWebSocketVisionEnabled();
      const i = (await navigator.mediaDevices.getUserMedia({
        video: { deviceId: { exact: e } },
        audio: !1
      })).getVideoTracks()[0];
      if (!i)
        throw new Error("getUserMedia() produced no video track");
      try {
        await this.publishVideoTrack(i, {
          name: "webcam",
          source: "webcam",
          stopTrackOnUnpublish: !0
        });
      } catch (s) {
        throw i.stop(), s;
      }
      return;
    }
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      await this.replaceActiveVisionSource({ source: "webcam" });
      const t = await this.room.localParticipant.setCameraEnabled(!0, {
        deviceId: e
      }), i = this.createPublicationHandle(t || this.room.localParticipant.getTrackPublication(E.Source.Camera), "webcam", "webcam", !1);
      i && this.setActiveVisionSource(i), this._isVideoEnabled = !0, this.emitVideoStateChange("webcam_device_selected", {
        isVideoEnabled: !0
      });
    } catch (t) {
      throw Pi.error("Failed to set video device:", t), t;
    }
  }
  /**
   * Get available video devices
   */
  async getVideoDevices() {
    try {
      return (await navigator.mediaDevices.enumerateDevices()).filter((i) => i.kind === "videoinput");
    } catch (e) {
      throw Pi.error("Failed to get video devices:", e), e;
    }
  }
  /**
   * Set video quality
   */
  async setVideoQuality(e) {
    if (this.isWebSocketVisionTransport()) {
      this.assertWebSocketVisionEnabled();
      return;
    }
    if (!this.room)
      throw new Error("Room not initialized");
  }
  async publishCanvas(e, t = {}) {
    var o, a, c, d;
    if (typeof e.captureStream != "function")
      throw new Error("Canvas captureStream() is not supported in this browser");
    const r = e.captureStream((o = t.fps) != null ? o : 1).getVideoTracks()[0];
    if (!r)
      throw new Error("Canvas captureStream() produced no video track");
    try {
      return await this.publishVideoTrack(r, {
        name: (a = t.name) != null ? a : "canvas-pov",
        source: (c = t.source) != null ? c : "canvas",
        fps: t.fps,
        stopTrackOnUnpublish: (d = t.stopTrackOnUnpublish) != null ? d : !0
      });
    } catch (l) {
      throw r.readyState !== "ended" && r.stop(), l;
    }
  }
  async publishVideoTrack(e, t = {}) {
    var d, l, u;
    if (this.isWebSocketVisionTransport())
      return this.assertWebSocketVisionEnabled(), this.publishWebSocketVideoTrack(e, t);
    if (!this.room)
      throw new Error("Room not initialized");
    const i = (d = t.source) != null ? d : "custom", s = (l = t.name) != null ? l : i, r = s.toLowerCase().includes(i.toLowerCase()) ? s : `${i}:${s}`, o = (u = t.stopTrackOnUnpublish) != null ? u : !1;
    await this.replaceActiveVisionSource({ source: i, track: e }), this.pendingVisionSourceTracks.set(e, i);
    let a;
    try {
      a = await this.room.localParticipant.publishTrack(e, {
        name: r,
        source: this.toLiveKitSource(i)
      });
    } catch (h) {
      throw this.pendingVisionSourceTracks.delete(e), h;
    }
    const c = {
      track: e,
      publication: a,
      transport: "livekit",
      sourceName: s,
      source: i,
      stopTrackOnUnpublish: o,
      unpublish: async () => this.unpublishVisionSource(c)
    };
    return this.addTrackEndedListener(c), this.setActiveVisionSource(c), this._isVideoEnabled = Tt(i), this.emitVideoStateChange("vision_source_published", {
      isVideoEnabled: this._isVideoEnabled
    }), c;
  }
  async unpublishVisionSource(e) {
    var i, s, r, o, a;
    const t = this.resolveVisionSource(e);
    if (t) {
      if (t.transport === "websocket") {
        const c = ((i = this._activeVisionSource) == null ? void 0 : i.track) === t.track;
        (s = t.cleanup) == null || s.call(t), t.stopTrackOnUnpublish && t.track.readyState !== "ended" && t.track.stop(), c && (this._activeVisionSource = null, Tt(t.source) && (this._isVideoEnabled = !1), this.sendWebSocketVisionSourceState(!1, t.source), this.emitVideoStateChange("vision_source_unpublished", {
          isVideoEnabled: this._isVideoEnabled
        }));
        return;
      }
      if (!this.room)
        throw new Error("Room not initialized");
      await this.room.localParticipant.unpublishTrack(t.track, t.stopTrackOnUnpublish), t.stopTrackOnUnpublish && t.track.readyState !== "ended" && t.track.stop(), ((r = this._activeVisionSource) == null ? void 0 : r.track) === t.track && ((a = (o = this._activeVisionSource).cleanup) == null || a.call(o), this._activeVisionSource = null), this.updateState(), this.emitVideoStateChange("vision_source_unpublished", {
        isVideoEnabled: this._isVideoEnabled
      });
    }
  }
  async publishWebSocketVideoTrack(e, t = {}) {
    var P, R, g, f, k;
    const i = (P = t.source) != null ? P : "custom", s = (R = t.name) != null ? R : i, r = (g = t.stopTrackOnUnpublish) != null ? g : !1, o = this.normalizeWebSocketFps((f = t.fps) != null ? f : 1), a = this._activeVisionSource;
    (a == null ? void 0 : a.track) === e ? ((k = a.cleanup) == null || k.call(a), this._activeVisionSource = null) : await this.replaceActiveVisionSource({ source: i, track: e });
    const c = new MediaStream([e]), d = document.createElement("video");
    d.muted = !0, d.playsInline = !0, d.srcObject = c;
    const l = document.createElement("canvas"), u = l.getContext("2d");
    if (!u)
      throw new Error("Unable to create canvas context for WebSocket vision");
    let h = null, p = !1, b = !1, v;
    const C = () => {
      var A, O;
      if (p)
        return;
      if (e.readyState !== "live") {
        this.clearEndedVisionSource(v);
        return;
      }
      if (!this.webSocketVisionMessageSender)
        return;
      const w = d.videoWidth || ((A = e.getSettings) == null ? void 0 : A.call(e).width) || 0, D = d.videoHeight || ((O = e.getSettings) == null ? void 0 : O.call(e).height) || 0;
      if (!(!w || !D))
        try {
          l.width !== w && (l.width = w), l.height !== D && (l.height = D), u.drawImage(d, 0, 0, w, D), this.webSocketVisionMessageSender("vision-frame", {
            image: l.toDataURL("image/jpeg", 0.82),
            source_label: this.toBackendVisionSourceLabel(i),
            capture_pts_ns: String(Math.round(performance.now() * 1e6))
          });
        } catch (N) {
          b || (b = !0, Pi.warn("Unable to capture WebSocket vision frame:", N));
        }
    };
    v = {
      track: e,
      transport: "websocket",
      sourceName: s,
      source: i,
      stopTrackOnUnpublish: r,
      unpublish: async () => this.unpublishVisionSource(v),
      cleanup: () => {
        p = !0, h !== null && (window.clearInterval(h), h = null), d.pause(), d.srcObject = null;
      }
    }, this.addTrackEndedListener(v), this.setActiveVisionSource(v), this._isVideoEnabled = Tt(i), this.emitVideoStateChange("vision_source_published", {
      isVideoEnabled: this._isVideoEnabled
    }), this.sendWebSocketVisionSourceState(!0, i);
    try {
      await d.play();
    } catch (w) {
      Pi.warn("WebSocket vision video playback did not start immediately:", w);
    }
    return C(), p || (h = window.setInterval(C, Math.round(1e3 / o))), v;
  }
  resolveVisionSource(e) {
    var t;
    return e ? "track" in e ? e : ((t = this._activeVisionSource) == null ? void 0 : t.track) === e ? this._activeVisionSource : {
      track: e,
      sourceName: e.label || "custom",
      source: "custom",
      transport: this.isWebSocketVisionTransport() ? "websocket" : "livekit",
      stopTrackOnUnpublish: !1,
      unpublish: async () => this.unpublishVisionSource(e)
    } : this._activeVisionSource;
  }
  isWebSocketVisionTransport() {
    return this.webSocketVisionMode !== "off";
  }
  assertWebSocketVisionEnabled() {
    if (this.webSocketVisionMode !== "enabled" || !this.webSocketVisionMessageSender)
      throw new Error("WebSocket vision input is disabled for this session");
  }
  normalizeWebSocketFps(e) {
    return !Number.isFinite(e) || e <= 0 ? 1 : Math.max(0.2, Math.min(10, e));
  }
  sendWebSocketVisionSourceState(e, t) {
    this.webSocketVisionMessageSender && this.webSocketVisionMessageSender("vision-source-state", {
      active: e,
      source_label: this.toBackendVisionSourceLabel(t)
    });
  }
  toBackendVisionSourceLabel(e) {
    return e === "webcam" || e === "camera" ? "webcam" : e === "canvas" ? "canvas" : e === "screen" || e === "screen_share" ? "screen" : "custom";
  }
  toLiveKitSource(e) {
    return e === "screen" || e === "screen_share" ? E.Source.ScreenShare : e === "unknown" ? E.Source.Unknown : E.Source.Camera;
  }
  getLiveVisionSource() {
    const e = this._activeVisionSource;
    return e && e.track.readyState === "live" ? e : null;
  }
  makeVisionSourceState(e) {
    var s, r, o, a;
    const t = this.getLiveVisionSource(), i = e != null ? e : this.webSocketVisionMode === "disabled" ? "websocket_vision_disabled" : void 0;
    return {
      active: !!t,
      source: (s = t == null ? void 0 : t.source) != null ? s : null,
      sourceName: (r = t == null ? void 0 : t.sourceName) != null ? r : null,
      trackState: (o = t == null ? void 0 : t.track.readyState) != null ? o : null,
      transport: (a = t == null ? void 0 : t.transport) != null ? a : this.isWebSocketVisionTransport() ? "websocket" : void 0,
      ...i ? { reason: i } : {}
    };
  }
  emitVideoStateChange(e, t = {}) {
    this.emit("videoStateChange", {
      isVideoEnabled: this._isVideoEnabled,
      isVideoHidden: this._isVideoHidden,
      activeVisionSource: this.activeVisionSource,
      hasActiveVisionSource: this.hasActiveVisionSource,
      visionSourceState: this.makeVisionSourceState(e),
      ...t
    });
  }
  setActiveVisionSource(e) {
    var t, i, s;
    ((t = this._activeVisionSource) == null ? void 0 : t.track) !== e.track && ((s = (i = this._activeVisionSource) == null ? void 0 : i.cleanup) == null || s.call(i)), this._activeVisionSource = e;
  }
  async replaceActiveVisionSource(e) {
    const t = this._activeVisionSource;
    t && (e.track && t.track === e.track || mf(t.source, e.source, e.track !== void 0) || await t.unpublish());
  }
  createPublicationHandle(e, t, i, s) {
    const r = this.mediaTrackFromPublication(e);
    if (!r)
      return null;
    let o;
    return o = {
      track: r,
      publication: e,
      transport: "livekit",
      sourceName: i,
      source: t,
      stopTrackOnUnpublish: s,
      unpublish: async () => {
        if (Tt(t)) {
          await this.disableVideo();
          return;
        }
        await this.unpublishVisionSource(o);
      }
    }, this.addTrackEndedListener(o), o;
  }
  addTrackEndedListener(e) {
    var s, r;
    const t = e.cleanup, i = () => this.clearEndedVisionSource(e);
    (r = (s = e.track).addEventListener) == null || r.call(s, "ended", i, { once: !0 }), e.cleanup = () => {
      var o, a;
      (a = (o = e.track).removeEventListener) == null || a.call(o, "ended", i), t == null || t();
    };
  }
  clearEndedVisionSource(e) {
    var t, i;
    if (((t = this._activeVisionSource) == null ? void 0 : t.track) === e.track) {
      if ((i = e.cleanup) == null || i.call(e), this._activeVisionSource = null, e.transport === "websocket") {
        this.sendWebSocketVisionSourceState(!1, e.source), Tt(e.source) && (this._isVideoEnabled = !1), this.emitVideoStateChange("track_ended");
        return;
      }
      this.updateState(), this.emitVideoStateChange("track_ended");
    }
  }
  clearActiveVisionSourceForPublication(e, t) {
    var s;
    const i = this._activeVisionSource;
    i && (i.publication !== e && i.track !== this.mediaTrackFromPublication(e) || ((s = i.cleanup) == null || s.call(i), this._activeVisionSource = null, this.emitVideoStateChange(t)));
  }
  mediaTrackFromPublication(e) {
    var s;
    const t = e == null ? void 0 : e.track, i = (s = t == null ? void 0 : t.mediaStreamTrack) != null ? s : t;
    return i && typeof i.readyState == "string" ? i : null;
  }
  semanticSourceForPublication(e) {
    var i;
    const t = this.mediaTrackFromPublication(e);
    if (t)
      return ((i = this._activeVisionSource) == null ? void 0 : i.track) === t ? this._activeVisionSource.source : this.pendingVisionSourceTracks.get(t);
  }
  isWebcamPublication(e) {
    const t = this.semanticSourceForPublication(e);
    return t !== void 0 ? Tt(t) : this.isCameraLikeSource(e == null ? void 0 : e.source);
  }
  isCameraLikeSource(e) {
    return e === "camera" || e === E.Source.Camera;
  }
  /**
   * Reset state on disconnect
   */
  reset() {
    var t;
    this._isVideoEnabled = !1, this._isVideoHidden = !1, this.webSocketVisionMessageSender = null, this.webSocketVisionMode = "off";
    const e = this._activeVisionSource;
    (t = e == null ? void 0 : e.cleanup) == null || t.call(e), e != null && e.stopTrackOnUnpublish && e.track.readyState !== "ended" && e.track.stop(), this._activeVisionSource = null, this.emit("videoStateChange", {
      isVideoEnabled: !1,
      isVideoHidden: !1,
      activeVisionSource: null,
      hasActiveVisionSource: !1,
      visionSourceState: this.makeVisionSourceState("reset")
    });
  }
}
class gf extends fn {
  constructor(e) {
    super(), this.room = null, this._isScreenShareEnabled = !1, this._isScreenShareActive = !1, this.listeners = [], e && this.setRoom(e);
  }
  get isScreenShareEnabled() {
    return this._isScreenShareEnabled;
  }
  get isScreenShareActive() {
    return this._isScreenShareActive;
  }
  /**
   * Set the LiveKit room instance
   */
  setRoom(e) {
    this.room && this.cleanupListeners(), this.room = e, e && (this.setupListeners(), e.state !== "disconnected" && this.updateState());
  }
  /**
   * Follow the local screen-share track.
   *
   * The local participant emits `localTrackPublished` / `localTrackUnpublished`
   * (livekit-client's `ParticipantEvent.LocalTrack*`). `trackPublished` /
   * `trackUnpublished` are `RemoteParticipant` events and never fire here, which
   * is how a share ended from the browser's own "Stop sharing" bar — LiveKit
   * unpublishes the ended track — used to leave `isScreenShareActive` true.
   */
  setupListeners() {
    if (!this.room)
      return;
    const e = this.room.localParticipant, t = (s, r = s) => {
      this._isScreenShareActive = s, this._isScreenShareEnabled = r, this.emit("screenShareStateChange", { isScreenShareEnabled: r, isScreenShareActive: s });
    }, i = (s) => (s == null ? void 0 : s.source) === "screen_share";
    this.listeners = [
      ["localTrackPublished", (s) => {
        i(s) && t(!0);
      }],
      ["localTrackUnpublished", (s) => {
        i(s) && t(!1);
      }],
      // A muted share is still published (enabled), just not showing.
      ["trackMuted", (s) => {
        i(s) && t(!1, this._isScreenShareEnabled);
      }],
      ["trackUnmuted", (s) => {
        i(s) && t(!0, this._isScreenShareEnabled);
      }]
    ];
    for (const [s, r] of this.listeners)
      e.on(s, r);
  }
  /**
   * Detach from the current room, so a reconnect's new room is the only one
   * driving state.
   */
  cleanupListeners() {
    if (!this.room)
      return;
    const e = this.room.localParticipant;
    for (const [t, i] of this.listeners)
      e.off(t, i);
    this.listeners = [];
  }
  /**
   * Update screen share state from room
   */
  updateState() {
    if (!this.room || this.room.state === "disconnected") {
      this._isScreenShareEnabled = !1, this._isScreenShareActive = !1;
      return;
    }
    const e = this.room.localParticipant;
    this._isScreenShareEnabled = e.isScreenShareEnabled, this._isScreenShareActive = e.isScreenShareEnabled;
  }
  /**
   * Enable screen share
   */
  async enableScreenShare() {
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      await this.room.localParticipant.setScreenShareEnabled(!0, {
        // @ts-ignore - selfBrowserSurface is a valid Chrome option but may not be in types
        selfBrowserSurface: "include",
        surfaceSwitching: "include",
        systemAudio: "include"
      }), this._isScreenShareEnabled = !0, this._isScreenShareActive = !0, this.emit("screenShareStateChange", { isScreenShareEnabled: !0, isScreenShareActive: !0 });
    } catch (e) {
      throw e;
    }
  }
  /**
   * Disable screen share
   */
  async disableScreenShare() {
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      await this.room.localParticipant.setScreenShareEnabled(!1), this._isScreenShareEnabled = !1, this._isScreenShareActive = !1, this.emit("screenShareStateChange", { isScreenShareEnabled: !1, isScreenShareActive: !1 });
    } catch (e) {
      throw e;
    }
  }
  /**
   * Toggle screen share
   */
  async toggleScreenShare() {
    this._isScreenShareEnabled ? await this.disableScreenShare() : await this.enableScreenShare();
  }
  /**
   * Enable screen share with audio
   */
  async enableScreenShareWithAudio() {
    if (!this.room)
      throw new Error("Room not initialized");
    try {
      const e = await this.room.localParticipant.createScreenTracks({
        audio: !0,
        // @ts-ignore - selfBrowserSurface is a valid Chrome option but may not be in types
        selfBrowserSurface: "include",
        surfaceSwitching: "include",
        systemAudio: "include"
      });
      await Promise.all(e.map((t) => this.room.localParticipant.publishTrack(t))), this._isScreenShareEnabled = !0, this._isScreenShareActive = !0, this.emit("screenShareStateChange", { isScreenShareEnabled: !0, isScreenShareActive: !0 });
    } catch (e) {
      throw Pi.error("Failed to enable screen share with audio:", e), e;
    }
  }
  /**
   * Get screen share tracks
   */
  async getScreenShareTracks() {
    if (!this.room)
      return [];
    try {
      const e = this.room.localParticipant, t = [];
      return e.trackPublications.forEach((i) => {
        i.source === "screen_share" && i.track && t.push(i.track);
      }), t;
    } catch (e) {
      throw e;
    }
  }
  /**
   * Reset state on disconnect
   */
  reset() {
    this._isScreenShareEnabled = !1, this._isScreenShareActive = !1, this.emit("screenShareStateChange", {
      isScreenShareEnabled: !1,
      isScreenShareActive: !1
    });
  }
}
const vf = 128, bf = 128;
function yf(n) {
  for (let e = 0; e < n.length; e += 1) {
    const t = n.charCodeAt(e);
    if (t >= 55296 && t <= 56319) {
      const i = n.charCodeAt(e + 1);
      if (!(i >= 56320 && i <= 57343))
        return !1;
      e += 1;
      continue;
    }
    if (t >= 56320 && t <= 57343)
      return !1;
  }
  return !0;
}
function Kd(n, e) {
  return typeof n == "string" && n.trim().length > 0 && yf(n) && n.length <= e && new TextEncoder().encode(n).byteLength <= e;
}
function Ni(n) {
  return Kd(n, vf);
}
function yr(n) {
  return Kd(n, bf);
}
function Jt(n) {
  if (typeof n != "object" || n === null || Array.isArray(n))
    return !1;
  const e = Object.getPrototypeOf(n);
  return e === Object.prototype || e === null;
}
function Gd(n) {
  if (Jt(n)) {
    if (n.type === "model-output")
      return Jt(n.data) ? { ...n.data, type: "model-output" } : n;
    if (n.type === "server-message" && Jt(n.data) && n.data.type === "model-output")
      return n.data;
  }
}
function Ls(n) {
  return n == null || typeof n == "string";
}
function ki(n) {
  return typeof n == "string" && n.trim().length > 0;
}
function pn(n, e = /* @__PURE__ */ new Set()) {
  if (n === null || typeof n == "string" || typeof n == "boolean")
    return !0;
  if (typeof n == "number")
    return Number.isFinite(n);
  if (typeof n != "object" || e.has(n))
    return !1;
  e.add(n);
  const t = Array.isArray(n) ? n.every((i) => pn(i, e)) : Jt(n) && Object.values(n).every((i) => pn(i, e));
  return e.delete(n), t;
}
function Lo(n) {
  return Jt(n) && pn(n);
}
function Sf(n) {
  if (!Jt(n) || typeof n.type != "string")
    return null;
  switch (n.type) {
    case "message":
      return n.role !== "assistant" || n.channel !== "final" && n.channel !== "commentary" || typeof n.content != "string" ? null : n;
    case "emotion":
      return !ki(n.name) || n.scale !== 1 && n.scale !== 2 && n.scale !== 3 ? null : n;
    case "semantic_action":
      return !ki(n.id) || !ki(n.name) || !Ls(n.target) ? null : n;
    case "tool_call":
      return !ki(n.id) || !ki(n.name) || !Ls(n.target) || !Lo(n.arguments) ? null : n;
    case "extension":
      return !ki(n.schema) || !Number.isInteger(n.version) || n.version < 1 || !Lo(n.payload) || !Ls(n.fallback) ? null : n;
    default:
      return null;
  }
}
function kf(n) {
  const e = Jt(n) && Object.prototype.hasOwnProperty.call(n, "logical_turn_id");
  if (!Jt(n) || n.type !== "model-output" || n.version !== 2 || !yr(n.output_id) || e && !Ni(n.logical_turn_id) || ![
    "text",
    "convai-combined-json",
    "semantic-actions-json",
    "client-tool-calls-json"
  ].includes(n.format) || typeof n.raw != "string" || n.final !== !0 || !Array.isArray(n.items))
    return null;
  const t = n.items.map(Sf);
  if (t.some((s) => s === null))
    return null;
  const i = /* @__PURE__ */ new Set();
  for (const s of t)
    if (!(s.type !== "semantic_action" && s.type !== "tool_call")) {
      if (i.has(s.id))
        return null;
      i.add(s.id);
    }
  return {
    type: "model-output",
    version: 2,
    output_id: n.output_id,
    ...e && {
      logical_turn_id: n.logical_turn_id
    },
    format: n.format,
    raw: n.raw,
    items: t,
    final: !0
  };
}
function Jd(n, e) {
  if (n !== "server-message" || typeof e != "object" || e === null || Array.isArray(e) || typeof e.type != "string")
    return { type: n, data: e };
  const { type: t, ...i } = e;
  return { type: t, data: "data" in i ? i.data : i };
}
function Tf(n, e) {
  const t = n;
  if (!(n instanceof Float32Array) && t.values instanceof Float32Array)
    return { ...t, values: t.values.map((r) => r * e) };
  const i = new Float32Array(n.length);
  for (let r = 0; r < n.length; r++)
    i[r] = n[r] * e;
  const s = n.__blendshapeNames;
  return s && Object.defineProperty(i, "__blendshapeNames", { value: s, enumerable: !1 }), i;
}
class ht {
  /**
   * Create a new BlendshapeQueue
   * @param mapper - Optional function to map/transform blendshape data as it's added
   */
  constructor(e, t = () => Date.now()) {
    this.queue = [], this.pendingTimelineFrames = /* @__PURE__ */ new Map(), this.activeTimelineAliases = /* @__PURE__ */ new Set(), this.retiredTimelineAliases = /* @__PURE__ */ new Set(), this.retiredOwnerlessTimelineAliases = /* @__PURE__ */ new Set(), this.conversationActive = !1, this.botSpeaking = !1, this.conversationEnded = !1, this.turnStats = null, this.framesConsumed = 0, this.interrupted = !1, this.interruptedAtFrame = 0, this.needsNormalization = !1, this._awaitingBotSpeak = !1, this.playbackFps = 60, this.ownerReplacementStoppedSpeaking = !1, this.missingExpectedFramesSinceMs = null, this.mapper = e, this.now = t;
  }
  /**
   * Add a chunk of blendshapes to the queue
   * @param blendshapes - Array of blendshape frames (each frame is an array of numbers)
   * @param metadata - Optional timeline metadata for ahead-delivered chunks
   */
  addChunk(e, t = {}) {
    if (e.length === 0)
      return;
    const i = this.framesConsumed + this.queue.length + this.pendingTimelineFrames.size, s = this.conversationEnded && this.turnStats !== null && i < this.turnStats.total_blendshapes, r = this.conversationActive || this.botSpeaking || s, o = this.timelineAliases(t);
    if (o.length > 0) {
      if (this.isRetiredTimelineOwner(t))
        return;
      if (this.hasActiveTimelineOwner())
        if (this.matchesActiveTimelineChunkOwner(t))
          this.mergeActiveTimelineAliases(o);
        else {
          const c = this.botSpeaking;
          this.rememberRetiredTimelineAliases(this.activeTimelineAliases, o), this.adoptTimelineOwner(o), c && (this.ownerReplacementStoppedSpeaking = !0, this.needsNormalization = !0);
        }
      else {
        if (!r)
          return;
        this.adoptTimelineOwner(o, this.botSpeaking);
      }
    } else if (!r)
      return;
    const a = Number.isInteger(t.startFrameIndex);
    if (a && Number.isFinite(t.fps) && t.fps > 0 && (this.playbackFps = t.fps), this.missingExpectedFramesSinceMs = null, a) {
      this.addTimelineChunk(e, t.startFrameIndex);
      return;
    }
    for (let c = 0; c < e.length; c++)
      this.queue.push(this.mapFrame(e[c]));
  }
  mapFrame(e) {
    return this.mapper ? this.mapper(e) : new Float32Array(e);
  }
  addTimelineChunk(e, t) {
    const i = this.framesConsumed, s = this.framesConsumed + this.queue.length;
    for (let r = 0; r < e.length; r++) {
      const o = t + r;
      o < i || o < s || this.pendingTimelineFrames.has(o) || this.pendingTimelineFrames.set(o, this.mapFrame(e[r]));
    }
    this.flushContiguousTimelineFrames();
  }
  flushContiguousTimelineFrames() {
    let e = this.framesConsumed + this.queue.length;
    for (; this.pendingTimelineFrames.has(e); ) {
      const t = this.pendingTimelineFrames.get(e);
      if (!t)
        break;
      this.pendingTimelineFrames.delete(e), this.queue.push(t), e += 1;
    }
  }
  timelineAliases(e = {}) {
    const t = [];
    return e.responseId && t.push(`r:${e.responseId}`), Number.isInteger(e.neurosyncTurnId) && (t.push(`t:${e.neurosyncTurnId}`), Number.isInteger(e.epoch) && t.push(`t:${e.neurosyncTurnId}|e:${e.epoch}`)), Array.from(new Set(t));
  }
  hasActiveTimelineOwner() {
    return this.activeTimelineAliases.size > 0;
  }
  responseAlias(e = {}) {
    return e.responseId ? `r:${e.responseId}` : void 0;
  }
  turnEpochAlias(e = {}) {
    return Number.isInteger(e.neurosyncTurnId) && Number.isInteger(e.epoch) ? `t:${e.neurosyncTurnId}|e:${e.epoch}` : void 0;
  }
  turnAlias(e = {}) {
    return Number.isInteger(e.neurosyncTurnId) ? `t:${e.neurosyncTurnId}` : void 0;
  }
  activeHasResponseAlias() {
    return Array.from(this.activeTimelineAliases).some((e) => e.startsWith("r:"));
  }
  activeHasTurnEpochAlias() {
    return Array.from(this.activeTimelineAliases).some((e) => e.includes("|e:"));
  }
  matchesActiveTimelineOwner(e = {}) {
    const t = this.timelineAliases(e);
    if (t.length === 0 || !this.hasActiveTimelineOwner())
      return !1;
    const i = this.responseAlias(e);
    if (i && this.activeHasResponseAlias())
      return this.activeTimelineAliases.has(i);
    const s = this.turnEpochAlias(e);
    return s && this.activeHasTurnEpochAlias() ? this.activeTimelineAliases.has(s) : t.some((r) => this.activeTimelineAliases.has(r));
  }
  matchesActiveTimelineChunkOwner(e = {}) {
    if (!this.hasActiveTimelineOwner())
      return !1;
    const t = this.responseAlias(e);
    if (this.activeHasResponseAlias() && t)
      return this.activeTimelineAliases.has(t);
    const s = this.turnEpochAlias(e), r = this.activeHasTurnEpochAlias();
    if (s || r)
      return s !== void 0 && this.activeTimelineAliases.has(s);
    const o = this.turnAlias(e);
    return o !== void 0 && this.activeTimelineAliases.has(o);
  }
  mergeActiveTimelineAliases(e) {
    e.forEach((t) => this.activeTimelineAliases.add(t));
  }
  isRetiredTimelineOwner(e = {}) {
    if (this.timelineAliases(e).length === 0)
      return !1;
    const i = this.responseAlias(e);
    if (i) {
      if (this.retiredTimelineAliases.has(i))
        return !0;
      if (this.activeTimelineAliases.has(i))
        return !1;
    }
    const s = this.turnEpochAlias(e);
    if (s !== void 0 && this.retiredTimelineAliases.has(s) || i === void 0 && s !== void 0 && this.retiredOwnerlessTimelineAliases.has(s))
      return !0;
    const r = this.turnAlias(e);
    return r !== void 0 && (this.retiredTimelineAliases.has(r) || i === void 0 && this.retiredOwnerlessTimelineAliases.has(r));
  }
  rememberRetiredTimelineAliases(e, t = []) {
    this.rememberBoundedAliases(this.retiredTimelineAliases, e, t);
  }
  rememberRetiredOwnerlessTimelineAliases(e, t = []) {
    this.rememberBoundedAliases(this.retiredOwnerlessTimelineAliases, e, t);
  }
  rememberBoundedAliases(e, t, i = []) {
    const s = new Set(i), r = Array.from(t).filter((o) => !s.has(o));
    if (r.length !== 0)
      for (r.forEach((o) => e.add(o)); e.size > ht.MAX_RETIRED_TIMELINE_ALIASES; ) {
        const o = e.values().next().value;
        if (!o)
          break;
        e.delete(o);
      }
  }
  adoptTimelineOwner(e, t = !1) {
    const i = t && this.botSpeaking;
    this.activeTimelineAliases = new Set(e), this.queue = [], this.pendingTimelineFrames.clear(), this.framesConsumed = 0, this.turnStats = null, this.missingExpectedFramesSinceMs = null, this.conversationActive = !0, this.conversationEnded = !1, this.interrupted = !1, this.botSpeaking = i, this._awaitingBotSpeak = !i, this.playbackFps = ht.TARGET_FPS, i || (this.ownerReplacementStoppedSpeaking = !1);
  }
  clearTimelineOwner() {
    this.activeTimelineAliases.clear();
  }
  /**
   * True when a lifecycle event belongs to an owner that has already been
   * interrupted/cancelled or does not match the active indexed timeline.
   * Ownerless events are treated as current for backward compatibility.
   */
  isStaleOwner(e = {}) {
    return this.timelineAliases(e).length === 0 ? !1 : this.isRetiredOwner(e) ? !0 : this.hasActiveTimelineOwner() && !this.matchesActiveTimelineOwner(e);
  }
  /**
   * True when an owner was explicitly interrupted/cancelled/completed.
   * Chunk messages use this narrower predicate so a newer owner can still
   * reach addChunk() and atomically replace the active owner there.
   */
  isRetiredOwner(e = {}) {
    return this.isRetiredTimelineOwner(e);
  }
  /**
   * Drop buffered ahead-delivered frames for a server-cancelled owner.
   * Returns true when the active owner was flushed.
   */
  cancelOwner(e = {}) {
    const t = this.timelineAliases(e);
    if (t.length === 0)
      return !1;
    const i = this.matchesActiveTimelineOwner(e), s = Array.from(this.activeTimelineAliases);
    return i && this.responseAlias(e) !== void 0 && this.turnAlias(e) === void 0 ? (this.rememberRetiredTimelineAliases(t), this.rememberRetiredOwnerlessTimelineAliases(s, t)) : this.rememberRetiredTimelineAliases(i ? [...t, ...s] : t, i ? [] : s), i ? (this.queue = [], this.pendingTimelineFrames.clear(), this.framesConsumed = 0, this.missingExpectedFramesSinceMs = null, this.botSpeaking = !1, this.conversationActive = !1, this.conversationEnded = !0, this.needsNormalization = !0, this.clearTimelineOwner(), !0) : !1;
  }
  hasBufferedFrames() {
    return this.queue.length > 0 || this.pendingTimelineFrames.size > 0;
  }
  /**
   * Set or update the mapper function
   * @param mapper - Function to map/transform blendshape data
   */
  setMapper(e) {
    this.mapper = e;
  }
  /**
   * Clear the mapper function (passthrough mode)
   */
  clearMapper() {
    this.mapper = void 0;
  }
  /**
   * Check if a mapper is configured
   */
  hasMapper() {
    return this.mapper !== void 0;
  }
  /**
   * Get all frames currently in the queue
   * @returns Array of blendshape frames as Float32Arrays
   */
  getFrames() {
    return this.queue;
  }
  /**
   * Get a specific frame by index
   * @param index - Frame index
   * @returns The frame at the given index, or null if out of bounds
   */
  getFrame(e) {
    return e < 0 || e >= this.queue.length ? null : this.queue[e];
  }
  /**
   * Get a frame with fade-in/fade-out alpha multiplier applied
   * First 10 frames: fade in from 0 to 1 (starts with bot-started-speaking)
   * Last 10 frames: fade out from 1 to 0 (normal end or interruption)
   * @param index - Frame index within the current queue
   * @returns The frame with alpha applied, or null if out of bounds
   */
  getFrameWithAlpha(e) {
    const t = this.getFrame(e);
    if (!t)
      return null;
    let i = 1;
    const s = this.framesConsumed + e;
    if (s < 10 && (i = s / 10), this.interrupted) {
      const r = this.queue.length, o = e;
      if (o >= r - 10) {
        const a = r - o;
        i = Math.min(i, a / 10);
      }
    } else if (this.turnStats) {
      const o = this.turnStats.total_blendshapes - s;
      o <= 10 && (i = Math.min(i, o / 10));
    }
    return i < 1 ? Tf(t, i) : t;
  }
  /**
   * Remove frames from the beginning of the queue (consume frames)
   * @param count - Number of frames to remove
   */
  consumeFrames(e) {
    if (e <= 0)
      return;
    const t = Math.min(e, this.queue.length);
    this.queue.splice(0, t), this.framesConsumed += t, this.flushContiguousTimelineFrames();
  }
  /**
   * Get the number of frames currently in the queue
   */
  get length() {
    return this.queue.length;
  }
  /**
   * Check if queue has frames
   */
  hasFrames() {
    return this.queue.length > 0;
  }
  /**
   * Check if conversation is active
   */
  isConversationActive() {
    return this.conversationActive;
  }
  /**
   * Check if conversation has ended and is ready for reset
   *
   * Returns true when:
   * 1. Server sent blendshape-turn-stats (conversationEnded = true)
   * AND
   * 2. All expected frames consumed OR queue is empty (playback complete)
   *
   * This combines the logic previously needed in consumers for definitive
   * end-of-conversation detection.
   */
  isConversationEnded() {
    if (!this.conversationEnded || this.botSpeaking)
      return !1;
    const e = this.isAllFramesConsumed(), t = this.hasUnconsumedExpectedFrames(), i = !this.hasFrames();
    if (!i || !t)
      this.missingExpectedFramesSinceMs = null;
    else if (this.hasActiveTimelineOwner()) {
      if (this.missingExpectedFramesSinceMs === null)
        return this.missingExpectedFramesSinceMs = this.now(), !1;
      if (this.now() - this.missingExpectedFramesSinceMs < ht.MISSING_INDEXED_FRAME_GRACE_MS)
        return !1;
    }
    return e || i;
  }
  /**
   * Check if the server end signal is safe to expose to playback consumers.
   *
   * Ahead-delivery can deliver blendshape-turn-stats before bot-started-speaking.
   * Keep those early stats internally for expected-frame accounting, but do not
   * expose a public drain signal until audio playback has actually started.
   * This does NOT check if all frames have been consumed - use isConversationEnded() for that.
   */
  hasReceivedEndSignal() {
    return this.conversationEnded && !this._awaitingBotSpeak;
  }
  /**
   * Mark conversation start (called when user sends a message)
   * Clears any remaining frames from previous conversation and activates the queue
   */
  startConversation() {
    if (this.hasActiveTimelineOwner() && (this.hasBufferedFrames() || this.hasUnconsumedExpectedFrames())) {
      this.conversationActive = !this.conversationEnded, this.botSpeaking = !1, this.interrupted = !1, this._awaitingBotSpeak = !0, this.ownerReplacementStoppedSpeaking = !1;
      return;
    }
    this.queue = [], this.pendingTimelineFrames.clear(), this.rememberRetiredTimelineAliases(this.activeTimelineAliases), this.clearTimelineOwner(), this.conversationActive = !0, this.botSpeaking = !1, this.conversationEnded = !1, this.framesConsumed = 0, this.turnStats = null, this.interrupted = !1, this.interruptedAtFrame = 0, this._awaitingBotSpeak = !0, this.playbackFps = ht.TARGET_FPS, this.ownerReplacementStoppedSpeaking = !1, this.missingExpectedFramesSinceMs = null;
  }
  /**
   * Mark bot as started speaking (called when bot-started-speaking event received)
   * This signals that the lipsync player can start consuming frames
   */
  startBotSpeaking() {
    const e = this.conversationEnded && this._awaitingBotSpeak && this.hasActiveTimelineOwner() && this.hasBufferedFrames();
    return this.conversationEnded && !e ? !1 : (this.botSpeaking = !0, this._awaitingBotSpeak = !1, !0);
  }
  /**
   * Mark bot as stopped speaking (called when bot-stopped-speaking event received)
   */
  stopBotSpeaking() {
    this.botSpeaking = !1;
  }
  /**
   * Check if bot is currently speaking
   * Lipsync player should only play frames when this is true
   */
  isBotSpeaking() {
    return this.botSpeaking;
  }
  /**
   * Consume the signal that a newer ahead-delivered owner replaced an active
   * speaking owner before the old bot-stopped-speaking event arrived.
   */
  consumeOwnerReplacementStoppedSpeaking() {
    const e = this.ownerReplacementStoppedSpeaking;
    return this.ownerReplacementStoppedSpeaking = !1, e;
  }
  /**
   * Mark conversation end with turn stats
   * Called when blendshape-turn-stats received
   * Stops accepting new frames and marks conversation as ended
   */
  endConversation(e, t = {}) {
    const i = this.timelineAliases(t);
    if (i.length > 0) {
      if (this.isRetiredTimelineOwner(t) || this.hasActiveTimelineOwner() && !this.matchesActiveTimelineOwner(t))
        return;
      (this.hasActiveTimelineOwner() || !this._awaitingBotSpeak) && this.mergeActiveTimelineAliases(i);
    }
    const s = i.length > 0 && this.hasActiveTimelineOwner() && this.matchesActiveTimelineOwner(t);
    this._awaitingBotSpeak && !s || (this.conversationActive = !1, this.conversationEnded = !0, this.missingExpectedFramesSinceMs = null, e && (this.turnStats = e));
  }
  /**
   * Handle interruption - mark for fade out
   * Keeps last 10 frames in queue and fades them out
   */
  interrupt() {
    this.rememberRetiredTimelineAliases(this.activeTimelineAliases), this.clearTimelineOwner(), this.interrupted = !0, this.interruptedAtFrame = this.framesConsumed + this.queue.length, this.conversationActive = !1, this.botSpeaking = !1, this.conversationEnded = !0, this.needsNormalization = !0, this.ownerReplacementStoppedSpeaking = !1, this.pendingTimelineFrames.clear(), this.missingExpectedFramesSinceMs = null, this.queue = [];
  }
  /**
   * Consume the normalization signal (one-shot).
   * Returns true if the lipsync player should begin lerping morphs back to 0.
   * startConversation() intentionally does NOT clear this so the signal survives
   * the immediate queue reset that follows an interruption.
   */
  consumeNormalizationSignal() {
    const e = this.needsNormalization;
    return this.needsNormalization = !1, e;
  }
  /**
   * Get turn stats
   */
  getTurnStats() {
    return this.turnStats;
  }
  /**
   * Get number of frames consumed
   */
  getFramesConsumed() {
    return this.framesConsumed;
  }
  /**
   * Get playback FPS from chunk metadata, falling back to 60fps.
   */
  getPlaybackFps() {
    return this.playbackFps || ht.TARGET_FPS;
  }
  /**
   * Calculate time left in milliseconds based on turn stats
   * Returns null if stats not available
   */
  getTimeLeftMs() {
    if (!this.turnStats)
      return null;
    const { total_audio_duration_ms: e, total_blendshapes: t } = this.turnStats, i = e / t, r = (t - this.framesConsumed) * i;
    return Math.max(0, r);
  }
  /**
   * Check if all frames have been consumed based on turn stats
   */
  isAllFramesConsumed() {
    return this.turnStats ? this.framesConsumed >= this.turnStats.total_blendshapes : !1;
  }
  hasUnconsumedExpectedFrames() {
    return this.turnStats ? this.framesConsumed + this.queue.length + this.pendingTimelineFrames.size < this.turnStats.total_blendshapes : !1;
  }
  /**
   * Reset queue for new conversation
   * Should be called after all frames have been consumed
   */
  reset() {
    this.queue = [], this.pendingTimelineFrames.clear(), this.rememberRetiredTimelineAliases(this.activeTimelineAliases), this.clearTimelineOwner(), this.conversationActive = !1, this.botSpeaking = !1, this.conversationEnded = !1, this.turnStats = null, this.framesConsumed = 0, this.needsNormalization = !1, this._awaitingBotSpeak = !1, this.playbackFps = ht.TARGET_FPS, this.ownerReplacementStoppedSpeaking = !1, this.missingExpectedFramesSinceMs = null;
  }
  /**
   * Get frame at specified time
   * @param elapsedTime - Elapsed time in seconds
   * @returns Frame data
   */
  getFrameAtTime(e) {
    if (this.queue.length === 0)
      return null;
    const t = Math.floor(e * this.getPlaybackFps()), i = Math.min(t, this.queue.length - 1);
    return {
      frame: this.queue[i],
      frameIndex: i
    };
  }
  /**
   * Get debug info about the queue state
   */
  getDebugInfo() {
    return {
      frameCount: this.queue.length,
      conversationActive: this.conversationActive,
      botSpeaking: this.botSpeaking,
      conversationEnded: this.conversationEnded,
      interrupted: this.interrupted,
      awaitingBotSpeak: this._awaitingBotSpeak,
      framesConsumed: this.framesConsumed,
      turnStats: this.turnStats,
      timeLeftMs: this.getTimeLeftMs(),
      pendingTimelineFrames: this.pendingTimelineFrames.size,
      playbackFps: this.getPlaybackFps()
    };
  }
}
ht.TARGET_FPS = 60;
ht.MAX_RETIRED_TIMELINE_ALIASES = 48;
ht.MISSING_INDEXED_FRAME_GRACE_MS = 24 / ht.TARGET_FPS * 1e3;
function Sr(n) {
  return Array.isArray(n) ? `[${n.map(Sr).join(",")}]` : n && typeof n == "object" ? `{${Object.entries(n).sort(([t], [i]) => t.localeCompare(i)).map(([t, i]) => `${JSON.stringify(t)}:${Sr(i)}`).join(",")}}` : JSON.stringify(n);
}
const Cf = 400, No = 4 * 1024 * 1024;
class _f extends fn {
  constructor(e) {
    super(), this.room = null, this.chatMessages = [], this.activeBotLlmMessageId = null, this.userTranscription = "", this.logRtviMessages = !0, this.isBotResponding = !1, this.isSpeaking = !1, this.isListening = !1, this.totalBlendshapesReceived = 0, this._currentEmotion = null, this.modelOutputVersion = 1, this.seenModelOutputPayloads = /* @__PURE__ */ new Set(), this.seenModelOutputPayloadCharacters = 0, this.seenBotOutputSegments = /* @__PURE__ */ new Set(), this._boundHandleDataReceived = (t, i) => this.handleDataReceived(t, i, "livekit"), this.blendshapeQueue = new ht(), e && this.setRoom(e);
  }
  /**
   * Get the blendshape queue instance
   */
  getBlendshapeQueue() {
    return this.blendshapeQueue;
  }
  /**
   * Enable or disable console logging for decoded incoming RTVI messages.
   */
  setRtviMessageLogging(e) {
    this.logRtviMessages = e;
  }
  /** Select the server-negotiated canonical output version for this session. */
  setModelOutputVersion(e) {
    this.modelOutputVersion = e, this._clearModelOutputReplayLedger();
  }
  /**
   * Get current chat messages
   */
  getChatMessages() {
    return this.chatMessages;
  }
  /**
   * Get current user transcription
   */
  getUserTranscription() {
    return this.userTranscription;
  }
  /**
   * Get bot responding state
   */
  getIsBotResponding() {
    return this.isBotResponding;
  }
  /**
   * Get speaking state
   */
  getIsSpeaking() {
    return this.isSpeaking;
  }
  /**
   * Get current bot emotion (updated from bot-emotion messages)
   */
  getEmotion() {
    return this._currentEmotion;
  }
  /**
   * Get whether the user is currently speaking (bot is in "listening" state).
   * True from user-started-speaking until user-stopped-speaking.
   */
  getIsListening() {
    return this.isListening;
  }
  /**
   * Local interruption path used by the client before the server cancel/terminal
   * arrives. Keep MessageHandler state and BlendshapeQueue state in sync so the
   * next bot-started-speaking can activate cleanly.
   */
  interruptLipsyncPlayback() {
    const e = this.isSpeaking;
    this.isSpeaking = !1, this.blendshapeQueue.interrupt(), e && this.emit("speakingChange", !1);
  }
  /**
   * Finalize local response state after the client intentionally aborts a
   * transport before the server can deliver its terminal response frame.
   */
  finalizeInterruptedResponse(e = !1) {
    const t = this.finalizeStreamingBotMessages(e);
    this.isBotResponding = !1, this.emit("botRespondingChange", !1), t.length > 0 && this.emit("messagesChange", this.chatMessages, void 0, t);
  }
  finalizeStreamingBotMessages(e = this.modelOutputVersion === 2) {
    const t = [];
    if (e)
      for (let i = 0; i < this.chatMessages.length; i++) {
        const s = this.chatMessages[i];
        if ((s.type === "bot-llm-text" || s.type === "bot-output") && s.isStreaming) {
          const r = {
            ...s,
            isStreaming: !1
          };
          this.chatMessages[i] = r, t.push(r);
        }
      }
    else {
      let i = this.activeBotLlmMessageId ? this.chatMessages.findIndex((r) => r.id === this.activeBotLlmMessageId) : -1;
      i === -1 && (i = this.chatMessages.length - 1);
      const s = this.chatMessages[i];
      if (s && (s.type === "bot-llm-text" || s.type === "bot-output") && s.isStreaming) {
        const r = { ...s, isStreaming: !1 };
        this.chatMessages[i] = r, t.push(r);
      }
    }
    return t;
  }
  /**
   * Set the LiveKit room instance
   */
  setRoom(e) {
    this.room && this.cleanupListeners(), this.room = e, this.setupListeners();
  }
  /**
   * Setup message listeners
   */
  setupListeners() {
    this.room && this.room.on(x.DataReceived, this._boundHandleDataReceived);
  }
  /**
   * Clean up message listeners
   */
  cleanupListeners() {
    this.room && this.room.off(x.DataReceived, this._boundHandleDataReceived);
  }
  /**
   * Handle incoming data message
   */
  handleDataReceived(e, t, i = "livekit", s) {
    var a, c, d, l, u, h, p, b, v, C, T, P, R, g, f, k, w, D, A, O, N, L, B, Q, ae, re, K, xe;
    let r = "", o = !1;
    try {
      r = new TextDecoder().decode(e);
      const $ = JSON.parse(r);
      if (o = !0, i !== "sse" && this.listenerCount("rawMessage") > 0) {
        const Ke = i === "livekit" ? { transport: i, participant: t, byteLength: e.byteLength, message: JSON.parse(r) } : { transport: i, byteLength: e.byteLength, message: JSON.parse(r) };
        this.emit("rawMessage", Ke);
      }
      const $e = Gd($);
      if ($e !== void 0) {
        this._handleModelOutput($e);
        return;
      }
      const _e = (/* @__PURE__ */ new Date()).toISOString(), je = `${$.type}-${Date.now()}-${Math.random()}`, ot = {
        ...((a = $.data) == null ? void 0 : a.membership_id) && {
          membershipId: $.data.membership_id
        },
        ...((c = $.data) == null ? void 0 : c.character_id) && {
          characterId: $.data.character_id
        }
      }, ce = (Ke) => !!Ke && Ke.membershipId === ot.membershipId;
      switch ($.type) {
        // Submitted text is appended locally by sendUserTextMessage. Ignore
        // server echoes so each user message appears exactly once.
        case "user_text_message":
        case "user-llm-text":
        case "text-input":
        case "user-input":
        case "text-message":
        case "chat-message":
        case "input-text":
        case "message":
          break;
        // Bot Ready - Bot is ready, connection should be true
        case "bot-ready":
          this.emit("botReady", (u = (d = $.data) == null ? void 0 : d.about) != null ? u : (l = $.data) != null && l.membership_id ? $.data : void 0);
          break;
        // Bot LLM Started - Begin streaming response
        case "bot-llm-started":
          if (this.isBotResponding = !0, this.emit("botRespondingChange", !0), this.seenBotOutputSegments.clear(), (this.modelOutputVersion === 2 || i === "sse") && this.chatMessages.some((F) => F.type === "bot-llm-text" && F.isStreaming && F.content === "" && F.outputId === void 0 && F.logicalTurnId === void 0))
            break;
          const xt = {
            id: je,
            type: "bot-llm-text",
            content: "",
            timestamp: _e,
            isStreaming: !0,
            ...ot
          };
          this.activeBotLlmMessageId = je, this.chatMessages.push(xt), this.emit("messagesChange", this.chatMessages);
          break;
        // Bot Output - Aggregated output stream (sentence/word-level, replaces bot-transcript)
        // Payload: { text, spoken, aggregated_by, segment_id, spoken_status,
        // spoken_progress }. The same segment_id is re-sent with the FULL
        // segment text on every TTS progress tick (spoken_status
        // "in-progress" → "completed"), so appending per event repeats the
        // sentence once per tick.
        case "bot-output":
          if ((h = $.data) != null && h.text) {
            const F = $.data.text, pe = $.data.segment_id;
            if (this.emit("botOutput", {
              text: F,
              spoken: (p = $.data.spoken) != null ? p : !1,
              aggregatedBy: (b = $.data.aggregated_by) != null ? b : "sentence",
              segmentId: pe,
              spokenStatus: $.data.spoken_status
            }), pe !== void 0) {
              if (this.seenBotOutputSegments.has(pe))
                break;
              this.seenBotOutputSegments.add(pe);
            }
            const ge = this.activeBotLlmMessageId ? this.chatMessages.find((Ge) => Ge.id === this.activeBotLlmMessageId) : void 0, de = this.chatMessages[this.chatMessages.length - 1];
            if ((ge == null ? void 0 : ge.type) === "bot-llm-text" || (de == null ? void 0 : de.type) === "bot-llm-text" || (de == null ? void 0 : de.type) === "bot-output" && de.content.includes(F))
              break;
            (de == null ? void 0 : de.type) === "bot-output" && de.isStreaming && ce(de) ? this.chatMessages[this.chatMessages.length - 1] = {
              ...de,
              content: de.content + F
            } : this.chatMessages.push({
              id: `bot-output-${Date.now()}-${Math.random()}`,
              type: "bot-output",
              content: F,
              timestamp: (/* @__PURE__ */ new Date()).toISOString(),
              isStreaming: !0,
              ...ot
            }), this.emit("messagesChange", this.chatMessages);
          }
          break;
        // Bot LLM Text Messages - Streaming chunks
        case "bot-llm-text":
          if ((v = $.data) != null && v.text) {
            const F = $.data.text, pe = i === "sse", ge = (this.modelOutputVersion === 2 || pe) && yr($.data.output_id) ? $.data.output_id : void 0, de = (this.modelOutputVersion === 2 || pe) && Ni($.data.logical_turn_id) ? $.data.logical_turn_id : void 0;
            let Ge = -1;
            if (ge !== void 0) {
              for (let ve = this.chatMessages.length - 1; ve >= 0; ve--) {
                const me = this.chatMessages[ve];
                if (me.type === "bot-llm-text" && me.isStreaming && me.outputId === ge && ce(me)) {
                  Ge = ve;
                  break;
                }
              }
              if (Ge === -1)
                for (let ve = this.chatMessages.length - 1; ve >= 0; ve--) {
                  const me = this.chatMessages[ve];
                  if (me.type === "bot-llm-text" && me.isStreaming && me.content === "" && me.outputId === void 0 && me.logicalTurnId === void 0 && ce(me)) {
                    Ge = ve;
                    break;
                  }
                }
            } else if (de !== void 0) {
              for (let ve = this.chatMessages.length - 1; ve >= 0; ve--) {
                const me = this.chatMessages[ve];
                if (me.type === "bot-llm-text" && me.isStreaming && me.outputId === void 0 && me.logicalTurnId === de && ce(me)) {
                  Ge = ve;
                  break;
                }
              }
              if (Ge === -1) {
                const ve = this.chatMessages.length - 1, me = this.chatMessages[ve];
                (me == null ? void 0 : me.type) === "bot-llm-text" && me.isStreaming && me.content === "" && me.outputId === void 0 && me.logicalTurnId === void 0 && ce(me) && (Ge = ve);
              }
            } else if (this.activeBotLlmMessageId && (Ge = this.chatMessages.findIndex((ve) => ve.id === this.activeBotLlmMessageId && ve.type === "bot-llm-text" && ve.isStreaming && !ve.outputId && !ve.logicalTurnId && ce(ve))), Ge === -1) {
              const ve = this.chatMessages.length - 1, me = this.chatMessages[ve];
              me && me.type === "bot-llm-text" && me.isStreaming && !me.outputId && !me.logicalTurnId && ce(me) && (Ge = ve);
            }
            let Ft;
            if (Ge !== -1) {
              const ve = this.chatMessages[Ge];
              Ft = {
                ...ve,
                content: ve.content + F,
                ...ge !== void 0 && ve.outputId === void 0 ? { outputId: ge } : {},
                ...de !== void 0 && ve.logicalTurnId === void 0 ? { logicalTurnId: de } : {}
              }, this.chatMessages[Ge] = Ft;
            } else
              Ft = {
                id: `${$.type}-${Date.now()}-${Math.random()}`,
                type: "bot-llm-text",
                content: F,
                timestamp: (/* @__PURE__ */ new Date()).toISOString(),
                isStreaming: !0,
                ...ge ? { outputId: ge } : {},
                ...de ? { logicalTurnId: de } : {},
                ...ot
              }, this.activeBotLlmMessageId = Ft.id, this.chatMessages.push(Ft);
            this.emit("messagesChange", this.chatMessages, Ft);
          }
          break;
        // Parallel diagnostics-only provider output. This must never affect
        // normal chat, speech, TTS, or response lifecycle state.
        case "bot-llm-text-raw":
          this._handleBotLlmTextRaw($.data);
          break;
        // Bot LLM Stopped - Complete streaming response
        case "bot-llm-stopped": {
          const F = this.finalizeStreamingBotMessages();
          this.isBotResponding = !1, this.emit("botRespondingChange", !1), this.emit("messagesChange", this.chatMessages, void 0, F);
          break;
        }
        // Text-only Interactions API terminal marker. This is deliberately a
        // separate event: a completed REST turn must not be represented as a
        // synthetic bot-llm-stopped message.
        case "bot-turn-completed": {
          this._handleTurnCompleted((C = $.data) != null ? C : {}, i, s);
          break;
        }
        case "llm-no-response":
          this._handleNoResponse(_e, i, s);
          break;
        // User Transcription Messages
        case "user-transcription":
          if ((T = $.data) != null && T.text) {
            const F = $.data.text;
            if ((P = $.data) != null && P.final) {
              const pe = this.transcriptionLogicalTurnId($.data.logical_turn_id), ge = this.chatMessages[this.chatMessages.length - 1];
              if ((ge == null ? void 0 : ge.type) === "user-llm-text" && ge.content.trim() === String(F).trim()) {
                this.userTranscription = "", this.emit("userTranscriptionChange", "");
                break;
              }
              if (ge && ge.type === "user-transcription" && ge.isStreaming === !0) {
                const de = ge.content.trim() + " " + F.trim();
                this.chatMessages[this.chatMessages.length - 1] = {
                  ...ge,
                  ...pe === void 0 ? {} : { logicalTurnId: pe },
                  content: de,
                  timestamp: _e
                };
              } else {
                const de = {
                  id: je,
                  type: "user-transcription",
                  content: F,
                  timestamp: _e,
                  isStreaming: !0,
                  ...pe === void 0 ? {} : { logicalTurnId: pe }
                };
                this.chatMessages.push(de);
              }
              this.emit("messagesChange", this.chatMessages), this.userTranscription = "", this.emit("userTranscriptionChange", "");
            } else
              this.userTranscription = F, this.emit("userTranscriptionChange", F);
          }
          break;
        // Bot Emotion Messages — LiveKit path: arrives as an RTVI message frame (messageData.data)
        case "bot-emotion":
          if ((R = $.data) != null && R.emotion) {
            this._currentEmotion = {
              emotion: $.data.emotion,
              scale: $.data.scale
            }, this.logRtviMessages && console.log("[SDK bot-emotion]", $.data), this.emit("emotionChange", this._currentEmotion);
            const F = {
              id: je,
              type: "bot-emotion",
              content: `${$.data.emotion} (scale: ${$.data.scale || 1})`,
              timestamp: _e
            };
            this.chatMessages.push(F), this.emit("messagesChange", this.chatMessages);
          }
          break;
        // Bot TTS Text - Words as spoken by TTS (word-by-word for socket-based TTS)
        case "bot-tts-text":
          (g = $.data) != null && g.text && this.emit("botTtsText", { text: $.data.text });
          break;
        // Bot TTS lifecycle (more granular than bot-started/stopped-speaking)
        case "bot-tts-started":
          this.emit("botTtsStarted");
          break;
        case "bot-tts-stopped":
          this.emit("botTtsStopped");
          break;
        case "audio-data": {
          const F = $.data;
          typeof (F == null ? void 0 : F.audio) == "string" && typeof F.sample_rate == "number" && typeof F.channels == "number" && this.emit("audioData", {
            audio: F.audio,
            sample_rate: F.sample_rate,
            channels: F.channels,
            includes_wav_header: F.includes_wav_header === !0
          }, s);
          break;
        }
        // Server-side muting indicators
        case "user-mute-started":
          this.emit("userMuteStarted");
          break;
        case "user-mute-stopped":
          this.emit("userMuteStopped");
          break;
        case "user-started-speaking":
          this.isListening = !0, this.emit("listeningChange", !0);
          break;
        case "user-stopped-speaking":
          this.isListening = !1, this.emit("listeningChange", !1);
          break;
        // Bot Started Speaking (priority over listening: state becomes speaking)
        case "bot-started-speaking": {
          const F = this.lifecycleOwner($.data);
          if (this.blendshapeQueue.isStaleOwner(F))
            break;
          this.blendshapeQueue.startBotSpeaking() && (this.isSpeaking = !0, this.totalBlendshapesReceived = 0, this.emit("speakingChange", !0));
          break;
        }
        // Bot Stopped Speaking
        case "bot-stopped-speaking":
          if (this.blendshapeQueue.isStaleOwner(this.lifecycleOwner($.data)))
            break;
          this.isSpeaking && (this.isSpeaking = !1, this.blendshapeQueue.stopBotSpeaking(), this.emit("speakingChange", !1));
          break;
        // Action Response Messages (LiveKit/WebRTC path)
        case "action-response":
          this._handleActionResponse((k = (f = $.data) == null ? void 0 : f.actions) != null ? k : [], je, _e);
          break;
        case "metrics":
          $.data && this.emit("metrics", $.data);
          break;
        // Per-turn usage/cost breakdown. Informational only: the server streams
        // it once the client opts in with usage-toggle, and it never affects
        // server-side usage tracking or billing.
        case "usage-update":
          $.data && this.emit("usageUpdate", $.data);
          break;
        // Behavior Tree Response Messages
        case "behavior-tree-response":
          if ((w = $.data) != null && w.narrative_section_id) {
            const F = {
              id: je,
              type: "behavior-tree",
              content: `Narrative Section: ${$.data.narrative_section_id}`,
              timestamp: _e
            };
            this.chatMessages.push(F), this.emit("messagesChange", this.chatMessages);
          }
          break;
        // Server Message - Contains various data types like blendshapes
        case "server-message":
          if ($.data) {
            const F = $.data;
            switch (F.type) {
              // How production delivers usage: wrapped in a server-message,
              // the record's fields beside `type`. Strip the envelope's type.
              case "usage-update": {
                const { type: pe, ...ge } = F;
                this.emit("usageUpdate", ge);
                break;
              }
              case "bot-llm-text-raw":
                this._handleBotLlmTextRaw((D = F.data) != null ? D : F);
                break;
              case "final-user-transcription":
                if (F.text) {
                  const pe = F.text, ge = this.transcriptionLogicalTurnId(F.logical_turn_id), de = this.chatMessages[this.chatMessages.length - 1];
                  if ((de == null ? void 0 : de.type) === "user-llm-text" && de.content.trim() === String(pe).trim()) {
                    this.userTranscription = "", this.emit("userTranscriptionChange", "");
                    break;
                  }
                  de && de.type === "user-transcription" && de.isStreaming === !0 ? this.chatMessages[this.chatMessages.length - 1] = {
                    ...de,
                    ...ge === void 0 ? {} : { logicalTurnId: ge },
                    content: pe,
                    timestamp: _e,
                    isStreaming: !1
                  } : this.chatMessages.push({
                    id: `${F.type}-${Date.now()}-${Math.random()}`,
                    type: "user-transcription",
                    content: pe,
                    timestamp: _e,
                    isStreaming: !1,
                    ...ge === void 0 ? {} : { logicalTurnId: ge }
                  }), this.emit("messagesChange", this.chatMessages), this.userTranscription = "", this.emit("userTranscriptionChange", "");
                }
                break;
              // WebSocket path: arrives inside a bot-text data message as serverData (not messageData.data)
              case "bot-emotion":
                F.emotion && (this._currentEmotion = {
                  emotion: F.emotion,
                  scale: F.scale
                }, this.logRtviMessages && console.log("[SDK bot-emotion (ws)]", F), this.emit("emotionChange", this._currentEmotion));
                break;
              case "blendshape-turn-stats":
                if (this.blendshapeQueue.isStaleOwner(this.lifecycleOwner(F)))
                  break;
                this.blendshapeQueue.endConversation(F.stats, this.lifecycleOwner(F)), this.emit("blendshapeStatsReceived", F);
                break;
              case "chunked-neurosync-blendshapes":
                if (F.blendshapes) {
                  const pe = this.lifecycleOwner(F);
                  if (this.blendshapeQueue.isRetiredOwner(pe))
                    break;
                  !this.blendshapeQueue.isConversationActive() && !this.isSpeaking && this.blendshapeQueue.startConversation(), this.blendshapeQueue.addChunk(F.blendshapes, pe), this.blendshapeQueue.consumeOwnerReplacementStoppedSpeaking() && this.isSpeaking && (this.isSpeaking = !1, this.emit("speakingChange", !1)), this.totalBlendshapesReceived += F.blendshapes.length, this.emit("blendshapes", F);
                }
                break;
              case "neurosync-blendshapes-cancel": {
                this.blendshapeQueue.cancelOwner(this.lifecycleOwner(F)) && this.isSpeaking && (this.isSpeaking = !1, this.emit("speakingChange", !1)), this.emit("blendshapeCancel", F);
                break;
              }
              case "user-idle-warning": {
                const pe = (O = (A = F.remaining_seconds) != null ? A : F.remainingSeconds) != null ? O : null;
                this.emit("idleWarning", { remainingSeconds: pe }), this.chatMessages.push({
                  id: `user-idle-warning-${Date.now()}-${Math.random()}`,
                  type: "idle-warning",
                  content: pe !== null ? String(pe) : "",
                  timestamp: _e
                }), this.emit("messagesChange", this.chatMessages);
                break;
              }
              case "llm-no-response":
                this._handleNoResponse(_e, i, s);
                break;
              case "bot-turn-completed":
                this._handleTurnCompleted(Jd("server-message", F).data, i, s);
                break;
              // Action Response (WebSocket/RTVI path — wrapped in server-message)
              case "action-response":
                this._handleActionResponse((N = F.actions) != null ? N : [], je, _e);
                break;
              // Server acknowledgment — arrives wrapped in server-message envelope
              case "server-response": {
                this._handleServerResponse(F, i === "sse" ? s : void 0);
                break;
              }
              /**
               * Lifecycle of one roster member. Emitted when a member is added
               * at runtime, becomes ready, or fails after /connect already
               * returned 200. `bot-ready` stays the readiness authority --
               * a `character-status` of "ready" must not enable interaction on
               * its own -- but this is the only way a background dispatch
               * failure is ever reported.
               */
              case "character-status": {
                const pe = {
                  status: (L = F.status) != null ? L : "starting",
                  membershipId: (B = F.membership_id) != null ? B : "",
                  characterId: (Q = F.character_id) != null ? Q : "",
                  characterSessionId: (ae = F.character_session_id) != null ? ae : null,
                  participantIdentity: (re = F.participant_identity) != null ? re : F.membership_id ? `character:${F.membership_id}` : "",
                  roomSessionId: (K = F.room_session_id) != null ? K : null,
                  rosterEpoch: typeof F.roster_epoch == "number" ? F.roster_epoch : null,
                  failureCode: (xe = F.failure_code) != null ? xe : null
                };
                pe.membershipId && this.emit("characterStatus", pe);
                break;
              }
              // interaction-created: session IDs for analytics/tracking
              case "interaction-created": {
                const pe = {
                  interactionId: F.interaction_id,
                  characterSessionId: F.character_session_id
                };
                this.emit("interactionCreated", pe);
                break;
              }
            }
          }
          break;
        // SSE carries the acknowledgement in data; legacy realtime may flatten it.
        case "server-response": {
          this._handleServerResponse($, i === "sse" ? s : void 0);
          break;
        }
        // Silently ignore other message types
        case "moderation-response":
        case "trigger-message":
        case "update-template-keys":
        case "update-dynamic-info":
        case "interrupt-bot":
          break;
      }
    } catch {
    }
  }
  _handleTurnCompleted(e, t, i) {
    const s = this.finalizeStreamingBotMessages(t === "sse");
    s.length > 0 && this.emit("messagesChange", this.chatMessages, void 0, s), this.isBotResponding = !1, this.emit("botRespondingChange", !1), this.emit("botTurnCompleted", e, t === "sse" ? i : void 0);
  }
  _handleNoResponse(e, t, i) {
    const s = t === "sse" ? this.finalizeStreamingBotMessages(!0) : [];
    t === "sse" && (this.isBotResponding = !1, this.emit("botRespondingChange", !1)), t === "sse" ? this.emit("llmNoResponse", i) : this.emit("llmNoResponse"), this.chatMessages.push({
      id: `llm-no-response-${Date.now()}-${Math.random()}`,
      type: "llm-no-response",
      content: "",
      timestamp: e
    }), t === "sse" ? this.emit("messagesChange", this.chatMessages, void 0, s) : this.emit("messagesChange", this.chatMessages);
  }
  _handleServerResponse(e, t) {
    var o, a, c, d;
    const i = e.data, s = i !== null && typeof i == "object" && !Array.isArray(i) && (typeof i.event_type == "string" || e.event_type === void 0) ? i : e;
    if (s.event_type === "client-ready")
      return;
    const r = {
      event_type: (o = s.event_type) != null ? o : "unknown",
      status: (a = s.status) != null ? a : "error",
      message: (c = s.message) != null ? c : null,
      extras: (d = s.extras) != null ? d : null
    };
    t ? this.emit("serverResponse", r, t) : this.emit("serverResponse", r);
  }
  _handleActionResponse(e, t, i) {
    if (this.modelOutputVersion === 2)
      return;
    this.emit("actionResponse", { actions: e });
    const s = e.length === 0 ? "No action" : e.map((o) => o.target ? `${o.name} → ${o.target}` : o.name).join(", "), r = {
      id: t,
      type: "action",
      content: s,
      timestamp: i
    };
    this.chatMessages.push(r), this.emit("messagesChange", this.chatMessages);
  }
  _handleModelOutput(e) {
    if (this.modelOutputVersion !== 2)
      return;
    const t = kf(e);
    if (!t) {
      this.emit("modelOutputProtocolError", {
        code: "invalid_model_output",
        message: "Core sent a malformed or unsupported model-output envelope"
      });
      return;
    }
    const i = Sr(t);
    if (!this.seenModelOutputPayloads.has(i)) {
      if (i.length > No) {
        this.emit("modelOutputProtocolError", {
          code: "invalid_model_output",
          message: "Core sent an oversized model-output envelope"
        });
        return;
      }
      for (this.seenModelOutputPayloads.add(i), this.seenModelOutputPayloadCharacters += i.length; this.seenModelOutputPayloads.size > Cf || this.seenModelOutputPayloadCharacters > No; ) {
        const s = this.seenModelOutputPayloads.values().next().value;
        if (!s)
          break;
        this.seenModelOutputPayloads.delete(s), this.seenModelOutputPayloadCharacters -= s.length;
      }
      this.emit("modelOutput", t);
    }
  }
  _clearModelOutputReplayLedger() {
    this.seenModelOutputPayloads.clear(), this.seenModelOutputPayloadCharacters = 0;
  }
  _handleBotLlmTextRaw(e) {
    if (this.modelOutputVersion !== 2 || !e || typeof e != "object")
      return;
    const t = e;
    typeof t.text != "string" || !Ni(t.logical_turn_id) || this.emit("botLlmTextRaw", {
      text: t.text,
      logical_turn_id: t.logical_turn_id,
      ...yr(t.output_id) ? { output_id: t.output_id } : {}
    });
  }
  lifecycleOwner(e) {
    var t;
    return e ? {
      responseId: e.response_id,
      neurosyncTurnId: (t = e.neurosync_turn_id) != null ? t : e.turn_id,
      epoch: e.epoch,
      fps: this.numberOrUndefined(e.fps),
      startFrameIndex: this.numberOrUndefined(e.start_frame_index)
    } : {};
  }
  numberOrUndefined(e) {
    return typeof e == "number" && Number.isFinite(e) ? e : void 0;
  }
  transcriptionLogicalTurnId(e) {
    return this.modelOutputVersion === 2 && Ni(e) ? e : void 0;
  }
  /**
   * Public entry point for WebSocket transport to inject messages into the same pipeline.
   */
  handleDataReceivedPublic(e, t = "websocket", i) {
    this.handleDataReceived(e, null, t, i);
  }
  /** Append a submitted text message without waiting for a server echo. */
  addUserTextMessage(e) {
    const t = e.trim();
    t && (this.chatMessages.push({
      id: `user-llm-text-${Date.now()}-${Math.random()}`,
      type: "user-llm-text",
      content: t,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), this.emit("messagesChange", this.chatMessages));
  }
  /**
   * Insert a message into the transcript locally. Nothing is transmitted and
   * no LLM turn is billed -- this is for client-side lines (a greeting, a
   * system notice, a replayed history entry) that must appear in the chat.
   *
   * Subscribers see it through the same `messagesChange` as a live message,
   * so React and the widgets pick it up with no special casing.
   */
  appendLocalMessage(e) {
    const t = {
      id: `local-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`,
      type: e.sender === "user" ? "user-llm-text" : "bot-llm-text",
      content: e.content,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      ...e.membershipId && { membershipId: e.membershipId },
      ...e.characterId && { characterId: e.characterId }
    };
    return this.chatMessages.push(t), this.emit("messagesChange", this.chatMessages), t;
  }
  /**
   * Reset message state
   */
  reset() {
    const e = {
      messages: this.chatMessages.length > 0,
      transcription: this.userTranscription !== "",
      responding: this.isBotResponding,
      speaking: this.isSpeaking,
      listening: this.isListening,
      emotion: this._currentEmotion !== null
    };
    this.chatMessages = [], this.activeBotLlmMessageId = null, this.userTranscription = "", this.isBotResponding = !1, this.isSpeaking = !1, this.isListening = !1, this.totalBlendshapesReceived = 0, this._currentEmotion = null, this.seenBotOutputSegments.clear(), this._clearModelOutputReplayLedger(), this.blendshapeQueue.reset(), e.messages && this.emit("messagesChange", this.chatMessages), e.transcription && this.emit("userTranscriptionChange", ""), e.responding && this.emit("botRespondingChange", !1), e.speaking && this.emit("speakingChange", !1), e.listening && this.emit("listeningChange", !1), e.emotion && this.emit("emotionChange", null);
  }
}
const wf = [
  "dispatch_queued",
  "dispatch_accepted",
  "dispatch_failed"
];
function Ef(n) {
  return typeof n == "string" && wf.includes(n) ? n : "dispatch_queued";
}
function Ns(n) {
  var e, t, i, s, r, o;
  return n != null && n.membership_id ? {
    membershipId: n.membership_id,
    characterId: (e = n.character_id) != null ? e : "",
    sessionId: (t = n.session_id) != null ? t : null,
    characterSessionId: (i = n.character_session_id) != null ? i : null,
    // Identity is derivable and always `character:{membership_id}`. Falling
    // back to it is safe; falling back to a positional name or a LiveKit SID
    // would not be, so those are never used.
    participantIdentity: n.participant_identity || `character:${n.membership_id}`,
    isInitial: n.is_initial === !0,
    provisioningStatus: Ef(n.provisioning_status),
    displayName: (s = n.display_name) != null ? s : null,
    description: (r = n.description) != null ? r : null,
    failureCode: (o = n.failure_code) != null ? o : null,
    isReady: !1
  } : null;
}
class Rf {
  constructor() {
    this._characters = [], this._activeMembershipId = null, this._roomSessionId = null, this._roomName = null, this._requestTraceId = null, this._routeEpoch = 0, this._rosterEpoch = 0, this._partialDispatch = !1;
  }
  /** Character instances in roster order. Empty in single-character mode. */
  get characters() {
    return this._characters;
  }
  /** Membership currently receiving user turns, or null. */
  get activeMembershipId() {
    return this._activeMembershipId;
  }
  get roomSessionId() {
    return this._roomSessionId;
  }
  get routeEpoch() {
    return this._routeEpoch;
  }
  get rosterEpoch() {
    return this._rosterEpoch;
  }
  /** True once a multi-character connect response has been applied. */
  get isMultiCharacter() {
    return this._characters.length > 0;
  }
  /** The server-owned snapshot, or null for a single-character session. */
  get roomSession() {
    return this._roomSessionId ? {
      roomSessionId: this._roomSessionId,
      roomName: this._roomName,
      requestTraceId: this._requestTraceId,
      activeMembershipId: this._activeMembershipId,
      routeEpoch: this._routeEpoch,
      rosterEpoch: this._rosterEpoch,
      partialDispatch: this._partialDispatch,
      characters: this._characters
    } : null;
  }
  find(e) {
    return this._characters.find((t) => t.membershipId === e);
  }
  /** Members that have sent their own `bot-ready`. */
  get readyCharacters() {
    return this._characters.filter((e) => e.isReady);
  }
  /**
   * Mark a member ready from its own `bot-ready`, filling in any detail the
   * connect response did not yet have.
   *
   * Returns whether anything changed, so the caller only pushes state when it
   * did. A single-character `bot-ready` also carries these fields, so nothing
   * is tracked until a roster is actually seeded.
   */
  applyBotReady(e) {
    var o, a, c;
    if (!e || !this.isMultiCharacter)
      return !1;
    const t = Ns(e);
    if (!t)
      return !1;
    const i = this._characters.findIndex((d) => d.membershipId === t.membershipId);
    if (i === -1)
      return this._characters = [...this._characters, { ...t, isReady: !0 }], !0;
    const s = this._characters[i], r = {
      ...s,
      characterSessionId: (o = t.characterSessionId) != null ? o : s.characterSessionId,
      sessionId: (a = t.sessionId) != null ? a : s.sessionId,
      displayName: (c = t.displayName) != null ? c : s.displayName,
      participantIdentity: t.participantIdentity || s.participantIdentity,
      isReady: !0
    };
    return s.isReady && r.characterSessionId === s.characterSessionId && r.sessionId === s.sessionId && r.participantIdentity === s.participantIdentity ? !1 : (this._characters = [
      ...this._characters.slice(0, i),
      r,
      ...this._characters.slice(i + 1)
    ], !0);
  }
  /**
   * Apply a `character-status` transition. Readiness recorded here is
   * bookkeeping for replacement selection; `bot-ready` remains what gates
   * interaction.
   */
  applyCharacterStatus(e) {
    var r;
    const t = this._characters.findIndex((o) => o.membershipId === e.membershipId);
    if (t === -1)
      return !1;
    const i = this._characters[t], s = {
      ...i,
      ...e.status === "failed" ? {
        provisioningStatus: "dispatch_failed",
        failureCode: (r = e.failureCode) != null ? r : i.failureCode,
        isReady: !1
      } : {}
    };
    return s.provisioningStatus === i.provisioningStatus && s.failureCode === i.failureCode && s.isReady === i.isReady ? !1 : (this._characters = [
      ...this._characters.slice(0, t),
      s,
      ...this._characters.slice(t + 1)
    ], e.status === "failed" && (this._partialDispatch = !0), !0);
  }
  /**
   * Pick a member to take over routing when the active one is removed.
   *
   * The runtime refuses a replacement that has not sent `bot-ready`
   * (`replacement_target_unavailable`), so ready survivors come first. Falling
   * back to any survivor at least produces a nameable rejection rather than
   * `replacement_target_required`.
   */
  pickReplacement(e) {
    var s, r, o;
    const t = new Set(e), i = this._characters.filter((a) => !t.has(a.membershipId));
    return (o = (s = i.find((a) => a.isReady)) == null ? void 0 : s.membershipId) != null ? o : (r = i[0]) == null ? void 0 : r.membershipId;
  }
  /** Payload that switches the active member. */
  buildInteractionTarget(e, t) {
    return {
      room_session_id: this._roomSessionId,
      target_membership_id: e,
      expected_route_epoch: this._routeEpoch,
      command_id: t
    };
  }
  /** Payload that adds and removes members. */
  buildRosterUpdate(e, t) {
    var s, r;
    const i = ((s = e.add) != null ? s : []).map((o) => ({
      character_id: o.characterId.trim(),
      ...o.characterSessionId ? { character_session_id: o.characterSessionId } : {}
    }));
    return {
      room_session_id: this._roomSessionId,
      expected_roster_epoch: this._rosterEpoch,
      command_id: t,
      ...i.length > 0 && { add: i },
      ...((r = e.remove) == null ? void 0 : r.length) && { remove_membership_ids: e.remove },
      ...e.replacementTarget && {
        replacement_target_membership_id: e.replacementTarget
      }
    };
  }
  /**
   * Adopt the server's authoritative epochs and active member from any
   * response, errors included.
   *
   * A `stale_route_epoch` rejection carries the real epoch, and adopting it is
   * precisely what makes the single retry meaningful rather than a repeat of
   * the same losing bet.
   */
  adoptEpochs(e) {
    var t;
    e && (typeof e.route_epoch == "number" && (this._routeEpoch = e.route_epoch), typeof e.roster_epoch == "number" && (this._rosterEpoch = e.roster_epoch), e.active_membership_id !== void 0 && (this._activeMembershipId = (t = e.active_membership_id) != null ? t : null));
  }
  /**
   * Apply a successful `interaction-target` ack. Returns the change even when
   * the target did not move, so a caller awaiting the promise always learns the
   * authoritative state.
   */
  applyInteractionTarget(e) {
    const t = (e == null ? void 0 : e.previous_membership_id) !== void 0 ? e.previous_membership_id : this._activeMembershipId;
    return this.adoptEpochs(e), {
      previous: t != null ? t : null,
      active: this._activeMembershipId,
      routeEpoch: this._routeEpoch
    };
  }
  /** Apply a successful `character-roster-update` ack, mutating the roster. */
  applyRosterUpdate(e) {
    var o, a;
    const t = (Array.isArray(e == null ? void 0 : e.added) ? e.added : []).map((c) => Ns(c)).filter((c) => c !== null), i = new Set(Array.isArray(e == null ? void 0 : e.removed_membership_ids) ? e.removed_membership_ids : []), s = [...i].map((c) => {
      var d;
      return (d = this.find(c)) != null ? d : {
        membershipId: c,
        characterId: "",
        sessionId: null,
        characterSessionId: null,
        participantIdentity: `character:${c}`,
        isInitial: !1,
        provisioningStatus: "dispatch_failed",
        displayName: null,
        description: null,
        failureCode: null,
        isReady: !1
      };
    }), r = new Set(t.map((c) => c.membershipId));
    return this._characters = [
      ...this._characters.filter((c) => !i.has(c.membershipId) && !r.has(c.membershipId)),
      ...t
    ], this.adoptEpochs(e), this._activeMembershipId && !this.find(this._activeMembershipId) && (this._activeMembershipId = (a = (o = this._characters[0]) == null ? void 0 : o.membershipId) != null ? a : null), {
      added: t,
      removed: s,
      characters: this._characters,
      rosterEpoch: this._rosterEpoch,
      routeEpoch: this._routeEpoch,
      activeMembershipId: this._activeMembershipId
    };
  }
  reset() {
    this._characters = [], this._activeMembershipId = null, this._roomSessionId = null, this._roomName = null, this._requestTraceId = null, this._routeEpoch = 0, this._rosterEpoch = 0, this._partialDispatch = !1;
  }
  /**
   * Seed the roster from a `/connect` response, for either a create or a join.
   *
   * Returns false for a response with no `characters` array — that is an
   * ordinary single-character session, and the roster stays empty so
   * `isMultiCharacter` keeps distinguishing the two.
   */
  applyConnectResponse(e) {
    var s, r, o, a, c, d, l;
    const t = e == null ? void 0 : e.characters;
    if (!Array.isArray(t) || t.length === 0)
      return !1;
    const i = t.map((u) => Ns(u)).filter((u) => u !== null);
    return i.length === 0 ? !1 : (this._characters = i, this._roomSessionId = kn(e.room_session_id), this._roomName = kn(e.room_name), this._requestTraceId = kn(e.request_trace_id), this._activeMembershipId = (c = (a = (r = kn(e.active_membership_id)) != null ? r : (s = i.find((u) => u.isInitial)) == null ? void 0 : s.membershipId) != null ? a : (o = i[0]) == null ? void 0 : o.membershipId) != null ? c : null, this._routeEpoch = (d = Uo(e.route_epoch)) != null ? d : 0, this._rosterEpoch = (l = Uo(e.roster_epoch)) != null ? l : 0, this._partialDispatch = e.partial_dispatch === !0 || i.some((u) => u.provisioningStatus === "dispatch_failed"), !0);
  }
}
function kn(n) {
  return typeof n == "string" && n ? n : null;
}
function Uo(n) {
  return typeof n == "number" && Number.isFinite(n) ? n : null;
}
const Yd = "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", Qd = "(?:0|[1-9]\\d*)\\.(?:0|[1-9]\\d*)(?:\\.(?:0|[1-9]\\d*))?", If = new RegExp(`^${Yd}$`), Pf = new RegExp(`^(?:draft|latest|${Qd})$`), xf = new RegExp(`^(${Yd})(?:-(draft|latest|${Qd}))?$`);
function kr(n) {
  return typeof n == "string" && Pf.test(n);
}
function Xd(n) {
  var s;
  const e = xf.exec(n.trim());
  if (!e)
    return null;
  const t = e[1].toLowerCase(), i = (s = e[2]) != null ? s : null;
  return {
    characterId: t,
    version: i,
    reference: i ? `${t}-${i}` : t
  };
}
function Us(n, e) {
  const t = Xd(n);
  if (e != null && e !== "") {
    if (!kr(e))
      throw new Error(`characterVersion must be "draft", "latest", or a major.minor[.patch] tag; received ${JSON.stringify(e)}`);
    if (!t)
      throw new Error("characterVersion requires characterId to be a character UUID");
    if (t.version && t.version !== e)
      throw new Error(`characterId already selects version "${t.version}" but characterVersion is "${e}"`);
    return {
      characterId: t.characterId,
      version: e,
      reference: `${t.characterId}-${e}`
    };
  }
  return t || { characterId: n, version: null, reference: n };
}
function Mf(n) {
  return If.test(n);
}
const Fo = 50, Af = /^[A-Za-z0-9_-]{1,128}$/;
function Un(n) {
  return Array.isArray(n.characters) && n.characters.length > 0;
}
function Xn(n, e) {
  if (n !== void 0 && !Af.test(n))
    throw new Error(`${e} must be 1-128 characters of letters, digits, hyphen or underscore`);
}
function Ui(n) {
  return typeof n == "string" && n.trim().length > 0;
}
function Of(n) {
  var i;
  const e = (i = n.characters) != null ? i : [];
  if (n.characterId)
    throw new Error("Pass either characterId or characters, not both");
  if (e.length === 0)
    throw new Error("characters must contain at least one entry");
  if (e.length > Fo)
    throw new Error(`characters accepts at most ${Fo} entries; your plan may allow fewer`);
  const t = /* @__PURE__ */ new Set();
  if (e.forEach((s, r) => {
    if (!s || !Ui(s.characterId))
      throw new Error(`characters[${r}] requires a characterId`);
    if (!Mf(s.characterId.trim()))
      throw new Error(`characters[${r}].characterId must be a bare character UUID; version selectors are not supported inside a roster`);
    if (s.characterSessionId !== void 0) {
      if (!Ui(s.characterSessionId))
        throw new Error(`characters[${r}].characterSessionId must be nonblank when supplied`);
      if (t.has(s.characterSessionId))
        throw new Error(`characters[${r}].characterSessionId is repeated; resume ids must be unique within the roster`);
      t.add(s.characterSessionId);
    }
  }), n.characterSessionId)
    throw new Error("characterSessionId is not valid with characters; use characters[].characterSessionId");
  if (!Ui(n.endUserId))
    throw new Error("characters requires a nonblank endUserId");
  if (n.transport && n.transport !== "livekit")
    throw new Error("Multi-character rooms require the LiveKit transport");
  if (n.interactionApiUrl)
    throw new Error("Multi-character rooms require the LiveKit transport; interactionApiUrl selects SSE");
  if (n.characterVersion)
    throw new Error("characterVersion applies to a single character; roster entries take bare UUIDs");
  if (Xn(n.sharedSessionKey, "sharedSessionKey"), Xn(n.connectAttemptId, "connectAttemptId"), n.maxNumParticipants !== void 0 && (!Number.isInteger(n.maxNumParticipants) || n.maxNumParticipants < 1))
    throw new Error("maxNumParticipants must be a positive integer");
}
function Df(n) {
  var i, s, r, o;
  if (!(((i = n.capabilities) == null ? void 0 : i.actionProtocolVersion) === 2 || ((s = n.capabilities) == null ? void 0 : s.modelOutputVersion) === 2)) {
    if ((o = (r = n.actionConfig) == null ? void 0 : r.tools) != null && o.length)
      throw new Error("actionConfig.tools requires capabilities.actionProtocolVersion: 2");
    return;
  }
  const t = [];
  if (Un(n) && t.push("characters"), n.sharedSessionKey && t.push("sharedSessionKey"), n.maxNumParticipants !== void 0 && n.maxNumParticipants !== 1 && t.push("maxNumParticipants greater than 1"), t.length !== 0)
    throw new Error(`Negotiated v2 output protocols require a single-character room: remove ${t.join(", ")}, or drop capabilities to version 1. ` + (t.includes("characters") ? "Multi-character rooms cannot use action protocol v2, and therefore cannot use client tools. " : "") + "The runtime rejects this combination with unsupported_action_protocol_topology.");
}
function Lf(n) {
  if (Number(Ui(n == null ? void 0 : n.roomSessionId)) + Number(Ui(n == null ? void 0 : n.sharedSessionKey)) !== 1)
    throw new Error("joinRoom requires exactly one of roomSessionId or sharedSessionKey");
  if (!Ui(n.endUserId))
    throw new Error("joinRoom requires a nonblank endUserId");
  const t = n;
  if (t.characters || t.characterId || t.characterSessionId)
    throw new Error("joinRoom must not carry character topology; the room's roster is server-owned");
  Xn(n.sharedSessionKey, "sharedSessionKey"), Xn(n.connectAttemptId, "connectAttemptId");
}
function Nf(n) {
  var t;
  return {
    // Both carry server defaults that already match, but a roster room is
    // rejected outright without them, so they are stated rather than assumed.
    mode: "create",
    spawn_agent: !0,
    characters: ((t = n.characters) != null ? t : []).map((i) => ({
      character_id: i.characterId.trim(),
      ...i.characterSessionId ? { character_session_id: i.characterSessionId } : {}
    })),
    ...n.sharedSessionKey ? { shared_session_key: n.sharedSessionKey } : {},
    ...n.connectAttemptId ? { connect_attempt_id: n.connectAttemptId } : {},
    ...n.maxNumParticipants !== void 0 ? { max_num_participants: n.maxNumParticipants } : {}
  };
}
function Uf(n) {
  return {
    mode: "join",
    transport: "livekit",
    ...n.roomSessionId ? { room_session_id: n.roomSessionId } : { shared_session_key: n.sharedSessionKey },
    end_user_id: n.endUserId,
    ...n.endUserMetadata ? { end_user_metadata: n.endUserMetadata } : {},
    ...n.connectAttemptId ? { connect_attempt_id: n.connectAttemptId } : {}
  };
}
class Zd extends Error {
  constructor(e, t, i, s, r) {
    super(e), this.name = "ConvaiRoomError", this.status = t, this.code = i, this.requestTraceId = s, this.detail = r;
  }
  /**
   * True when retrying the identical payload can plausibly succeed.
   *
   * Only the two "still working on it" conflicts qualify. A fingerprint
   * mismatch means the topology genuinely differs, and a capacity or
   * entitlement rejection will not change on its own — retrying those just
   * burns the room's provisioning window.
   */
  get isRetryable() {
    return this.status !== 409 ? !1 : this.code === "ROSTER_PROVISIONING_IN_PROGRESS" || this.code === "CONNECT_ATTEMPT_IN_PROGRESS";
  }
}
const Ff = ["code", "error_code", "detail_code"];
function el(n) {
  if (typeof n == "string")
    return Vo(n) ? n : null;
  if (typeof n != "object" || n === null)
    return null;
  const e = n;
  for (const i of Ff) {
    const s = e[i];
    if (typeof s == "string" && s)
      return s;
  }
  const t = e.detail;
  return typeof t == "string" ? Vo(t) ? t : null : typeof t == "object" && t !== null ? el(t) : null;
}
function Vo(n) {
  return /^[A-Z][A-Z0-9_]{2,}$/.test(n.trim());
}
function tl(n) {
  if (typeof n != "object" || n === null)
    return null;
  const e = n, t = e.request_trace_id;
  if (typeof t == "string" && t)
    return t;
  const i = e.detail;
  return typeof i == "object" && i !== null ? tl(i) : null;
}
function il(n, e) {
  if (typeof n == "string" && n.trim())
    return n.trim();
  if (typeof n == "object" && n !== null) {
    const t = n;
    for (const i of ["message", "detail", "error"]) {
      const s = t[i];
      if (typeof s == "string" && s.trim())
        return s.trim();
      if (typeof s == "object" && s !== null) {
        const r = il(s, e);
        if (!r.startsWith("Room request failed"))
          return r;
      }
    }
  }
  return `Room request failed with HTTP ${e}`;
}
function nl(n) {
  if (typeof n != "object" || n === null)
    return [];
  const e = n, t = e.character_ids;
  return Array.isArray(t) ? t.filter((i) => typeof i == "string") : nl(e.detail);
}
function Bo(n, e) {
  const t = el(e);
  let i = il(e, n);
  if (t && i === `Room request failed with HTTP ${n}`) {
    const s = nl(e);
    i = `${t} (HTTP ${n})${s.length ? `: ${s.join(", ")}` : ""}`;
  }
  return new Zd(i, n, t, tl(e), e);
}
const Vf = "1.9.4";
class jo {
  /**
   * Create a new MemoryManager instance
   *
   * @param apiKeyOrAuthToken - Convai API key or auth token (required)
   * @param characterId - Character UUID (required)
   * @param endUserId - End user identifier (required)
   * @param baseUrl - Base URL for Convai API (default: https://api.convai.com)
   * @param useAuthToken - If true, treats first parameter as auth token instead of API key (default: false)
   */
  constructor(e, t, i, s = "https://api.convai.com", r = !1) {
    if (!e)
      throw new Error("API key or auth token is required");
    if (!t)
      throw new Error("Character ID is required");
    if (!i)
      throw new Error("End user ID is required");
    r ? (this.apiKey = null, this.authToken = e) : (this.apiKey = e, this.authToken = null), this.characterId = t, this.endUserId = i, this.baseUrl = s.replace(/\/$/, "");
  }
  /**
   * Make an authenticated request to the Convai Memory API
   */
  async makeRequest(e, t) {
    const i = `${this.baseUrl}${e}`;
    try {
      const s = {
        "Content-Type": "application/json"
      };
      this.authToken ? s["API-AUTH-TOKEN"] = this.authToken : this.apiKey && (s["CONVAI-API-KEY"] = this.apiKey);
      const r = await fetch(i, {
        method: "POST",
        headers: s,
        body: JSON.stringify(t)
      }), o = await r.json();
      if (!r.ok) {
        const a = o;
        throw new Error(a.ERROR || `HTTP error! status: ${r.status}`);
      }
      return o;
    } catch (s) {
      throw s instanceof Error ? s : new Error("Unknown error occurred");
    }
  }
  /**
   * Add one or more memory strings
   *
   * @param memories - Array of memory strings to add (required, non-empty)
   * @returns Promise resolving to the add response with memory IDs
   *
   * @example
   * ```typescript
   * const result = await memoryManager.addMemories([
   *   "User prefers outdoor activities",
   *   "User is allergic to peanuts"
   * ]);
   *
   * result.memories.forEach(memory => {
   *   console.log(`Added memory ${memory.id}: ${memory.memory}`);
   * });
   * ```
   */
  async addMemories(e) {
    if (!e || e.length === 0)
      throw new Error("Memories array is required and must not be empty");
    const t = {
      character_id: this.characterId,
      end_user_id: this.endUserId,
      memories: e
    };
    return this.makeRequest("/memory/add", t);
  }
  /**
   * List memories with pagination
   *
   * @param options - Pagination options
   * @param options.page - Page number (default: 1, clamped to 1-1000)
   * @param options.pageSize - Number of memories per page (default: 50, clamped to 1-100)
   * @returns Promise resolving to paginated list of memories
   *
   * @example
   * ```typescript
   * // Get first page
   * const firstPage = await memoryManager.listMemories({ page: 1, pageSize: 50 });
   *
   * console.log(`Total memories: ${firstPage.total_count}`);
   * console.log(`Has more: ${firstPage.has_more}`);
   *
   * firstPage.memories.forEach(memory => {
   *   console.log(`${memory.id}: ${memory.memory}`);
   * });
   *
   * // Get next page if available
   * if (firstPage.has_more) {
   *   const nextPage = await memoryManager.listMemories({ page: 2, pageSize: 50 });
   * }
   * ```
   */
  async listMemories(e = {}) {
    const t = {
      character_id: this.characterId,
      end_user_id: this.endUserId,
      page: e.page,
      page_size: e.pageSize
    };
    return this.makeRequest("/memory/list", t);
  }
  /**
   * Fetch a single memory by ID
   *
   * @param memoryId - Memory UUID to fetch
   * @returns Promise resolving to the memory details
   *
   * @example
   * ```typescript
   * const memory = await memoryManager.getMemory('f4cbdb08-7062-4f3e-8eb2-9f5c80dfe64c');
   *
   * console.log(`Memory: ${memory.memory}`);
   * console.log(`Created: ${memory.created_at}`);
   * console.log(`Updated: ${memory.updated_at}`);
   * ```
   */
  async getMemory(e) {
    if (!e)
      throw new Error("Memory ID is required");
    const t = {
      character_id: this.characterId,
      end_user_id: this.endUserId,
      memory_id: e
    };
    return this.makeRequest("/memory/get", t);
  }
  /**
   * Delete a single memory by ID
   *
   * @param memoryId - Memory UUID to delete
   * @returns Promise resolving to the deletion confirmation
   *
   * @example
   * ```typescript
   * const result = await memoryManager.deleteMemory('f4cbdb08-7062-4f3e-8eb2-9f5c80dfe64c');
   *
   * if (result.deleted) {
   *   console.log('Memory deleted successfully');
   * }
   * ```
   */
  async deleteMemory(e) {
    if (!e)
      throw new Error("Memory ID is required");
    const t = {
      character_id: this.characterId,
      end_user_id: this.endUserId,
      memory_id: e
    };
    return this.makeRequest("/memory/delete", t);
  }
  /**
   * Delete all memories for the (character_id, end_user_id) pair
   *
   * This operation is asynchronous on the server side.
   * Check listMemories() after a short delay if confirmation is needed.
   *
   * @returns Promise resolving to the deletion status message
   *
   * @example
   * ```typescript
   * const result = await memoryManager.deleteAllMemories();
   * console.log(result.message); // "Memory deletion in progress..."
   *
   * // Optional: Wait and verify
   * await new Promise(resolve => setTimeout(resolve, 2000));
   * const remaining = await memoryManager.listMemories();
   * console.log(`Remaining memories: ${remaining.total_count}`);
   * ```
   */
  async deleteAllMemories() {
    const e = {
      character_id: this.characterId,
      end_user_id: this.endUserId
    };
    return this.makeRequest("/memory/delete-all", e);
  }
  /**
   * Update the end user ID for this memory manager instance
   * Useful when switching users in the same session
   *
   * @param endUserId - New end user identifier
   */
  setEndUserId(e) {
    if (!e)
      throw new Error("End user ID is required");
    this.endUserId = e;
  }
  /**
   * Get the current end user ID
   */
  getEndUserId() {
    return this.endUserId;
  }
  /**
   * Update the character ID for this memory manager instance
   * Useful when switching characters in the same session
   *
   * @param characterId - New character UUID
   */
  setCharacterId(e) {
    if (!e)
      throw new Error("Character ID is required");
    this.characterId = e;
  }
  /**
   * Get the current character ID
   */
  getCharacterId() {
    return this.characterId;
  }
}
const Bf = "https://api2.convai.com";
class jf extends Error {
  constructor(e, t, i) {
    super(e), this.name = "CharacterApiError", this.status = t, this.detail = i;
  }
}
class qf {
  constructor(e) {
    var a, c;
    const { characterId: t, apiKey: i, personalAccessToken: s, baseUrl: r, workspaceId: o } = e;
    if (!t)
      throw new Error("Character ID is required");
    if (!i && !s)
      throw new Error("Either apiKey or personalAccessToken is required");
    this.characterId = (c = (a = Xd(t)) == null ? void 0 : a.characterId) != null ? c : t, this.apiKey = i != null ? i : null, this.personalAccessToken = s != null ? s : null, this.baseUrl = (r || Bf).replace(/\/$/, ""), this.workspaceId = o != null ? o : null;
  }
  /** List released tags plus the current latest and draft revisions. */
  async list() {
    return this.request("GET", "/character/versions/list");
  }
  /**
   * Resolve a reference to the configuration snapshot the runtime would run.
   * Omit `version` to resolve the effective latest, or pass `draft`,
   * `latest`, or a tag.
   */
  async resolve(e, t = {}) {
    const i = e ? `${this.characterId}-${this.assertSelector(e)}` : this.characterId;
    return this.request("GET", "/character/versions/resolve", {
      query: {
        character_id: i,
        ...t.includeRuntimeSettings ? { include_runtime_settings: "true" } : {}
      }
    });
  }
  /**
   * Give a character that predates versioning an editable draft. Safe to call
   * repeatedly — `created` is false when a draft already existed.
   */
  async bootstrap() {
    return this.request("POST", "/character/versions/bootstrap");
  }
  async diff(e, t, i = {}) {
    return this.request("GET", "/character/versions/diff", {
      query: {
        from: this.assertSelector(e),
        to: this.assertSelector(t),
        ...i.view ? { view: i.view } : {}
      }
    });
  }
  /**
   * Release the current draft as an immutable tagged version.
   * @param version - New tag, `major.minor` or `major.minor.patch`
   */
  async create(e, t = {}) {
    return this.request("POST", "/character/versions/create", {
      body: {
        version: this.assertTag(e),
        ...t.makeLatest !== void 0 ? { make_latest: t.makeLatest } : {}
      }
    });
  }
  /** Point `latest` at an already released tag — the way to roll back. */
  async promote(e) {
    return this.request("POST", "/character/versions/promote", {
      body: { version: this.assertTag(e) }
    });
  }
  /**
   * Discard every saved draft change and restore the draft from its released
   * parent. Pass the draft revision you last saw so a concurrent edit is
   * refused instead of silently thrown away.
   */
  async discardDraft(e) {
    if (!e)
      throw new Error("expectedDraftRevisionId is required");
    return this.request("POST", "/character/versions/discard-draft", {
      body: { expected_draft_revision_id: e }
    });
  }
  /** Undo one semantic change in the draft, identified by a semantic diff's `change_id`. */
  async revert(e) {
    const { from: t, changeId: i, expectedDraftRevisionId: s } = e;
    if (!i || !s)
      throw new Error("changeId and expectedDraftRevisionId are required");
    return this.request("POST", "/character/versions/revert", {
      body: {
        from: this.assertSelector(t),
        change_id: i,
        expected_draft_revision_id: s
      }
    });
  }
  /** Mark a tag deprecated, or restore it with `deprecated: false`. Deprecated tags stay connectable. */
  async deprecate(e, t = !0) {
    return this.request("POST", "/character/versions/deprecate", {
      body: { version: this.assertTag(e), deprecated: t }
    });
  }
  /**
   * Replace the draft with the contents of a released tag, to branch new work
   * from an older version. `expectedDraftRevisionId` guards against clobbering
   * a draft someone else just changed.
   */
  async fork(e, t) {
    return this.request("POST", "/character/versions/fork", {
      body: {
        version: this.assertTag(e),
        ...t ? { expected_draft_revision_id: t } : {}
      }
    });
  }
  assertSelector(e) {
    if (!kr(e))
      throw new Error(`Expected "draft", "latest", or a major.minor[.patch] tag; received ${JSON.stringify(e)}`);
    return e;
  }
  assertTag(e) {
    if (!kr(e) || e === "draft" || e === "latest")
      throw new Error(`Expected a major.minor[.patch] version tag; received ${JSON.stringify(e)}`);
    return e;
  }
  async request(e, t, i = {}) {
    const s = new URLSearchParams({
      character_id: this.characterId,
      ...this.workspaceId ? { workspace_id: this.workspaceId } : {},
      ...i.query
    }), r = `${this.baseUrl}${t}?${s.toString()}`, o = { Accept: "application/json" };
    this.personalAccessToken ? o.Authorization = `Bearer ${this.personalAccessToken}` : this.apiKey && (o["CONVAI-API-KEY"] = this.apiKey), i.body !== void 0 && (o["Content-Type"] = "application/json");
    const a = await fetch(r, {
      method: e,
      headers: o,
      ...i.body !== void 0 ? { body: JSON.stringify(i.body) } : {}
    }), c = await a.text();
    let d = null;
    if (c)
      try {
        d = JSON.parse(c);
      } catch {
        d = c;
      }
    if (!a.ok)
      throw new jf(Hf(a.status, d), a.status, d);
    return d;
  }
}
function Hf(n, e) {
  const t = e != null ? e : null, i = t == null ? void 0 : t.detail;
  if (typeof i == "string")
    return i;
  if (typeof (t == null ? void 0 : t.message) == "string")
    return t.message;
  if (Array.isArray(i)) {
    const s = i.map((r) => {
      var o;
      return [(o = r.loc) == null ? void 0 : o.join("."), r.msg].filter(Boolean).join(": ");
    }).filter(Boolean);
    if (s.length)
      return s.join("; ");
  }
  return typeof e == "string" && e ? `HTTP ${n}: ${e}` : `HTTP ${n}`;
}
class Wf {
  constructor(e, t, i, s) {
    this.onStateUpdate = e, this.onBotReadyChange = t, this.onMessageHandlerReset = i, this.onDisconnectEvent = s;
  }
  /**
   * Handle room disconnection
   * @param reason - LiveKit disconnect reason (optional, defaults to UNKNOWN_REASON if not provided)
   */
  handleDisconnected(e) {
    const t = e != null ? e : 0;
    this.onStateUpdate({
      isConnected: !1,
      isConnecting: !1,
      isSpeaking: !1,
      isThinking: !1,
      isListening: !1,
      endUserId: null,
      endUserMetadata: null,
      metrics: [],
      disconnectReason: t
    }), this.onBotReadyChange(!1), this.onMessageHandlerReset(), this.onDisconnectEvent(t);
  }
  /**
   * Handle connection state changes from LiveKit
   * @param state - The new connection state
   */
  handleConnectionStateChanged(e) {
    e === fe.Disconnected ? (this.onStateUpdate({
      isConnected: !1,
      isConnecting: !1
    }), this.onBotReadyChange(!1), this.onMessageHandlerReset()) : e === fe.Connected ? this.onStateUpdate({
      isConnected: !0,
      isConnecting: !1
    }) : e === fe.Connecting && (this.onStateUpdate({
      isConnecting: !0,
      isConnected: !1
    }), this.onBotReadyChange(!1));
  }
  /**
   * Reset all connection state to default values
   * Called when disconnecting or cleaning up the client
   */
  resetConnectionState() {
    this.onStateUpdate({
      isConnected: !1,
      isConnecting: !1,
      isSpeaking: !1,
      isThinking: !1,
      isListening: !1,
      endUserId: null,
      endUserMetadata: null,
      metrics: [],
      disconnectReason: null
    }), this.onBotReadyChange(!1), this.onMessageHandlerReset();
  }
}
function sl(n) {
  if (!n)
    return;
  const e = {
    ...n.actionProtocolVersion !== void 0 && {
      action_protocol_version: n.actionProtocolVersion
    },
    ...n.modelOutputVersion !== void 0 && {
      model_output_version: n.modelOutputVersion
    }
  };
  return Object.keys(e).length > 0 ? e : void 0;
}
function $f(n) {
  return n.map((e) => ({
    name: e.name,
    description: e.description,
    input_schema: e.inputSchema
  }));
}
function zf(n, e) {
  if (e != null && e !== 1 && e !== 2)
    throw new Error(`Core selected unsupported action protocol version: ${String(e)}`);
  if (n === 2 && e !== 2)
    throw new Error("Core did not select requested action protocol version 2");
  if (e === 2 && n !== 2)
    throw new Error("Core selected action protocol version 2 without an explicit client opt-in");
}
function Kf(n, e) {
  if (e != null && e !== 1 && e !== 2)
    throw new Error(`Core selected unsupported model output version: ${String(e)}`);
  if (n === 2 && e !== 2)
    throw new Error("Core did not select requested model output version 2");
  if (e === 2 && n !== 2)
    throw new Error("Core selected model output version 2 without an explicit client opt-in");
  return e === 2 ? 2 : 1;
}
function Gf(n) {
  var t, i, s, r, o, a;
  const e = n.enableLipsync === !0 && ((t = n.blendshapeConfig) == null ? void 0 : t.deliver_chunks_ahead) !== !1;
  return {
    blendshape_provider: n.enableLipsync ? "neurosync" : "not_provided",
    blendshape_config: {
      enable_chunking: !0,
      chunk_size: 10,
      format: ((i = n.blendshapeConfig) == null ? void 0 : i.format) || "mha",
      frames_buffer_duration: (r = (s = n.blendshapeConfig) == null ? void 0 : s.frames_buffer_duration) != null ? r : 0.1,
      // In the legacy paced path, output_fps is a delivery cadence and the SDK
      // player keeps its 60fps visual timeline. Only ahead-delivery treats
      // output_fps as a client-visible timeline override because chunks carry
      // fps metadata.
      output_fps: e ? (a = (o = n.blendshapeConfig) == null ? void 0 : o.output_fps) != null ? a : 60 : 90,
      ...e ? { deliver_chunks_ahead: !0 } : {}
    }
  };
}
function Zn(n) {
  var t, i, s, r;
  if (n.enableEmotion !== !0)
    return;
  const e = n.emotionConfig;
  return (e == null ? void 0 : e.provider) === "nrclex" ? {
    provider: e.provider,
    min_word_threshold: (t = e.min_word_threshold) != null ? t : 3,
    low_intensity_threshold: (i = e.low_intensity_threshold) != null ? i : 0.33,
    high_intensity_threshold: (s = e.high_intensity_threshold) != null ? s : 0.66
  } : { provider: (r = e == null ? void 0 : e.provider) != null ? r : "llm" };
}
function es(n) {
  const e = n.actionConfig;
  if (e)
    return {
      actions: e.actions,
      objects: e.objects,
      characters: e.characters,
      ...e.current_attention_object && {
        current_attention_object: e.current_attention_object
      },
      ...e.tools && { tools: $f(e.tools) }
    };
}
function Jf(n) {
  return n.run_llm !== void 0 ? n.run_llm === "true" : n.respond_mode === "must_respond";
}
function qo(n) {
  return n === "must_respond";
}
function Ho(n) {
  var e, t;
  return ((e = n.visionInputConfig) == null ? void 0 : e.enabled) === !1 ? n.visionInputConfig : n.enableVideo ? {
    ...(t = n.visionInputConfig) != null ? t : {},
    enabled: !0
  } : n.visionInputConfig;
}
function Yf(n) {
  return {
    ...n.enabled !== void 0 && { enabled: n.enabled },
    ...n.sampleIntervalSecs !== void 0 && {
      sample_interval_secs: n.sampleIntervalSecs
    },
    ...n.framesPerTurn !== void 0 && {
      frames_per_turn: n.framesPerTurn
    },
    ...n.bufferFrames !== void 0 && {
      buffer_frames: n.bufferFrames
    },
    ...n.samplingWindows !== void 0 && {
      sampling_windows: n.samplingWindows.map((e) => ({
        count: e.count,
        interval_ms: e.intervalMs
      }))
    },
    ...n.stalenessSeconds !== void 0 && {
      staleness_seconds: n.stalenessSeconds
    },
    ...n.maxResolution !== void 0 && {
      max_resolution: n.maxResolution
    },
    ...n.replacePreviousVisionContext !== void 0 && {
      replace_previous_vision_context: n.replacePreviousVisionContext
    }
  };
}
class mn {
  constructor(e) {
    this.options = e, this.connected = !1, this.abortController = null, this.currentReader = null, this.queue = Promise.resolve(), this.pendingBotLlmText = "", this.pendingBotLlmTextMetadata = {}, this.botLlmTextFlushTimer = null, this.pendingMessages = [], this.interruptGeneration = 0, this.activeRespondModes = e.respondModes && {
      ...e.respondModes
    };
  }
  get isConnected() {
    return this.connected;
  }
  connect() {
    this.connected = !0;
  }
  sendMessage(e, t, i) {
    this.sendMessages([{ type: e, data: t, ...i !== void 0 ? { id: i } : {} }]);
  }
  sendMessages(e) {
    var o;
    if (e.length === 0)
      return;
    const t = this.interruptGeneration, i = this.options.takeStateOfMind(), s = (o = this.options.ttsEnabled) != null ? o : !1;
    let r = e;
    this.queue = this.queue.then(() => {
      if (!this.connected || t !== this.interruptGeneration)
        return;
      const a = this.pendingMessages;
      this.pendingMessages = [];
      const c = e.filter((l) => l.type === "update-dynamic-info"), d = e.filter((l) => l.type !== "update-dynamic-info");
      return r = [...c, ...a, ...d], this.sendInteraction(r, i, s).catch((l) => {
        throw Wo(l, r, !!this.options.credentialProvider);
      });
    }).catch((a) => {
      al(a) || this.options.onError(a, Tr(r));
    }).finally(() => {
      var a, c;
      return (c = (a = this.options).onResponseFinished) == null ? void 0 : c.call(a);
    });
  }
  /** Update request-scoped dynamic context without opening a control-only request. */
  updateDynamicInfo(e) {
    this.options.dynamicInfo = e;
  }
  getDynamicInfo() {
    return this.options.dynamicInfo;
  }
  setTtsEnabled(e) {
    this.options.ttsEnabled = e;
  }
  /** Carry a silent control update into the next stateless interaction request. */
  queueMessage(e, t) {
    this.pendingMessages.push({ type: e, data: t });
  }
  async disconnect() {
    var e;
    this.connected = !1, (e = this.abortController) == null || e.abort(), this.cancelCurrentReader(), this.discardQueuedRequestState(), this.options.takeStateOfMind(), await this.queue, this.clearPendingBotLlmText(), this.abortController = null, this.pendingMessages = [];
  }
  interrupt() {
    var e;
    this.interruptGeneration += 1, this.discardQueuedRequestState(), (e = this.abortController) == null || e.abort(new DOMException("SSE interaction interrupted", "AbortError")), this.cancelCurrentReader(), this.flushBotLlmText();
  }
  cancelCurrentReader() {
    var e;
    (e = this.currentReader) == null || e.cancel().catch(() => {
    });
  }
  discardQueuedRequestState() {
    this.pendingMessages = [];
  }
  async sendInteraction(e, t, i) {
    var r;
    const s = new AbortController();
    this.abortController = s;
    try {
      let o = this.options.authToken ? { "API-AUTH-TOKEN": this.options.authToken } : { Authorization: `Bearer ${this.options.authorization}` }, a;
      if (this.options.credentialProvider) {
        const l = this.options.credentialProvider, u = await Yi(() => l(s.signal), s.signal);
        if (s.signal.aborted || !this.connected)
          return;
        if (!((r = u.authToken) != null && r.startsWith("wpg_")))
          throw new Error("A fresh Workspace preview grant is required for each interaction");
        o = { "API-AUTH-TOKEN": u.authToken }, a = Xf();
      }
      const c = this.options.getCharacterSessionId(), d = await Yi(() => {
        var l;
        return fetch(this.options.interactionApiUrl, {
          method: "POST",
          headers: {
            ...o,
            Accept: "text/event-stream",
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            character_id: this.options.characterId,
            tts_enabled: i,
            ...a ? { connect_attempt_id: a } : {},
            ...t ? { state_of_mind: t } : {},
            ...c && c !== "-1" ? { character_session_id: c } : {},
            ...this.options.endUserId ? { end_user_id: this.options.endUserId } : {},
            ...this.options.endUserMetadata ? { end_user_metadata: this.options.endUserMetadata } : {},
            ...Zn(this.options) && {
              emotion_config: Zn(this.options)
            },
            ...es(this.options) && {
              action_config: es(this.options)
            },
            ...this.options.capabilities && {
              capabilities: sl(this.options.capabilities)
            },
            ...this.options.dynamicInfo && {
              dynamic_info: {
                text: this.options.dynamicInfo,
                ...this.options.keepInContext !== void 0 && {
                  keep_in_context: this.options.keepInContext
                }
              }
            },
            ...this.options.narrativeTemplateKeys && Object.keys(this.options.narrativeTemplateKeys).length > 0 && {
              narrative_template_keys: this.options.narrativeTemplateKeys
            },
            ...this.options.sceneDescription && {
              scene_description: this.options.sceneDescription
            },
            ...this.activeRespondModes && {
              respond_modes: Qf(this.activeRespondModes)
            },
            ...this.options.debug !== void 0 ? { debug: this.options.debug } : {},
            ...this.options.useResponseLifecycleContract !== void 0 ? {
              use_response_lifecycle_contract: this.options.useResponseLifecycleContract
            } : {},
            ...this.options.invocationMetadata && {
              invocation_metadata: {
                source: (l = this.options.invocationMetadata.source) != null ? l : "web_sdk",
                ...this.options.invocationMetadata.clientVersion && {
                  client_version: this.options.invocationMetadata.clientVersion
                },
                ...this.options.invocationMetadata.extraMetadata && {
                  extra_metadata: this.options.invocationMetadata.extraMetadata
                }
              }
            },
            messages: e.map(({ type: u, data: h, id: p }) => ({
              label: "rtvi-ai",
              type: u,
              ...p !== void 0 ? { id: p } : {},
              data: h
            }))
          }),
          signal: s.signal
        });
      }, s.signal, Fs);
      if (s.signal.aborted || !this.connected) {
        Fs(d);
        return;
      }
      try {
        if (!d.ok) {
          const l = await Yi(() => d.text(), s.signal);
          throw new Error(`Interaction API HTTP ${d.status}${l ? `: ${l}` : ""}`);
        }
        if (!d.body)
          throw new Error("Interaction API returned no SSE body");
        await this.readEvents(d.body, s.signal, e);
      } finally {
        s.signal.aborted && Fs(d);
      }
    } catch (o) {
      throw Zf(o) && s.signal.aborted ? new rl(o) : o;
    } finally {
      s.signal.aborted || !this.connected ? this.clearPendingBotLlmText() : this.flushBotLlmText(), this.abortController === s && (this.abortController = null);
    }
  }
  async readEvents(e, t, i) {
    const s = e.getReader();
    this.currentReader = s;
    try {
      await this.consumeReader(s, t, i);
    } finally {
      const r = s.cancel().catch(() => {
      });
      try {
        t.aborted || await Yi(() => r, t);
      } finally {
        this.currentReader === s && (this.currentReader = null), s.releaseLock();
      }
    }
  }
  async consumeReader(e, t, i) {
    var P;
    const s = new TextDecoder();
    let r = "", o = "message", a = [];
    const c = Tr(i), d = new Set(c.logicalTurnIds), l = d.size > 0, u = new Set(i.map((R, g) => g)), h = new Set(i.flatMap((R, g) => this.messageStartsTurn(R) ? [g] : []));
    let p = !1, b = !1, v = !1, C = !1;
    const T = () => {
      var A, O, N;
      if (t.aborted) {
        o = "message", a = [];
        return;
      }
      if (a.length === 0) {
        o = "message";
        return;
      }
      const R = a.join(`
`);
      let g = R;
      try {
        g = JSON.parse(R);
      } catch {
      }
      if ((O = (A = this.options).onRawMessage) == null || O.call(A, {
        transport: "sse",
        byteLength: new TextEncoder().encode(R).byteLength,
        message: structuredClone({ type: o, data: g }),
        request: structuredClone(c)
      }), t.aborted)
        return;
      if (o === "bot-llm-text" && typeof g == "object" && g !== null && typeof g.text == "string") {
        b = !0;
        const L = g;
        this.queueBotLlmText(L.text, {
          logical_turn_id: L.logical_turn_id,
          output_id: L.output_id
        }), o = "message", a = [];
        return;
      }
      this.flushBotLlmText();
      const f = Jd(o, g);
      ng(f.type, f.data) && (b = !0);
      const k = f.type === "bot-turn-completed" || f.type === "llm-no-response";
      let w = !1;
      if (k && typeof f.data == "object" && f.data !== null && !Array.isArray(f.data)) {
        const L = f.data;
        "logical_turn_id" in L ? Ni(L.logical_turn_id) && (!l || d.has(L.logical_turn_id)) && (p = !0, w = !0, d.delete(L.logical_turn_id)) : (p = !0, w = !0, d.clear());
      }
      if (k && !w) {
        o = "message", a = [];
        return;
      }
      const D = eg(f.type, f.data, i, u);
      if (D !== void 0) {
        const L = wt(f.data);
        ((L == null ? void 0 : L.status) === "success" || (L == null ? void 0 : L.status) === "error") && u.delete(D);
        const B = i[D], Q = wt(L == null ? void 0 : L.extras);
        (L == null ? void 0 : L.status) !== "error" && ((Q == null ? void 0 : Q.actual_run_llm) === "true" || (Q == null ? void 0 : Q.llm_triggered) === !0) && h.add(D);
        const ae = tg(f.data, B);
        if (ae) {
          this.applyRespondModeUpdates([ae]);
          for (let re = D + 1; re < i.length; re += 1)
            u.has(re) && (this.messageStartsTurn(i[re]) ? h.add(re) : h.delete(re));
        }
        ((N = wt(f.data)) == null ? void 0 : N.status) === "error" && h.delete(D) && B.type === "user_text_message" && B.id && d.delete(B.id);
      }
      if (o === "session" || o === "done") {
        o === "done" && (C = !0);
        const L = g == null ? void 0 : g.character_session_id;
        typeof L == "string" && this.options.onCharacterSessionId(L);
      } else
        f.type === "error" && (v = !0, this.options.onError(Wo(f.data, i, !!this.options.credentialProvider), c)), this.options.onMessage(new TextEncoder().encode(JSON.stringify({ type: o, data: g })), c);
      o = "message", a = [];
    };
    for (; !t.aborted; ) {
      const { done: R, value: g } = await Yi(() => e.read(), t);
      if (t.aborted)
        return;
      r += s.decode(g, { stream: !R });
      const f = r.split(/\r?\n/);
      r = (P = f.pop()) != null ? P : "";
      for (const k of f) {
        if (t.aborted)
          return;
        if (C)
          break;
        k ? k.startsWith("event:") ? o = k.slice(6).trim() : k.startsWith("data:") && a.push(k.slice(5).trimStart()) : T();
      }
      if (R || C) {
        if (R && r && (r.startsWith("event:") ? o = r.slice(6).trim() : r.startsWith("data:") && a.push(r.slice(5).trimStart())), T(), this.flushBotLlmText(), !t.aborted && !v && (h.size > 0 || b) && (!p || d.size > 0))
          throw Object.assign(new Error("SSE response ended before the turn completed"), {
            code: "SSE_RESPONSE_INCOMPLETE"
          });
        return;
      }
    }
  }
  messageStartsTurn(e) {
    var i, s, r, o;
    if (e.type === "user_text_message")
      return !0;
    const t = wt(e.data);
    switch (e.type) {
      case "context-update":
        return (t == null ? void 0 : t.run_llm) !== void 0 ? t.run_llm === "true" : Vs(t, (i = this.activeRespondModes) == null ? void 0 : i.contextUpdate) === "must_respond";
      case "vision-trigger":
        return Vs(t, (s = this.activeRespondModes) == null ? void 0 : s.vision) === "must_respond";
      case "trigger-message":
        return ((r = this.activeRespondModes) == null ? void 0 : r.trigger) === "must_respond";
      case "update-scene-metadata":
        return Vs(t, (o = this.activeRespondModes) == null ? void 0 : o.sceneMetadata) === "must_respond";
      default:
        return !1;
    }
  }
  applyRespondModeUpdates(e) {
    var t;
    for (const { modality: i, mode: s } of e)
      switch ((t = this.activeRespondModes) != null || (this.activeRespondModes = {}), i) {
        case "vision":
          this.activeRespondModes.vision = s;
          break;
        case "context_update":
          this.activeRespondModes.contextUpdate = s;
          break;
        case "trigger":
          this.activeRespondModes.trigger = s;
          break;
        case "scene_metadata":
          this.activeRespondModes.sceneMetadata = s;
          break;
      }
  }
  queueBotLlmText(e, t = {}) {
    const i = Object.fromEntries(Object.entries(t).filter(([, s]) => s !== void 0));
    this.pendingBotLlmText && mn.botLlmTextCorrelationChanged(this.pendingBotLlmTextMetadata, i) && this.flushBotLlmText(), this.pendingBotLlmText += e, this.pendingBotLlmTextMetadata = {
      ...this.pendingBotLlmTextMetadata,
      ...i
    }, this.botLlmTextFlushTimer === null && (this.botLlmTextFlushTimer = setTimeout(() => {
      this.botLlmTextFlushTimer = null, this.flushBotLlmText();
    }, mn.BOT_LLM_TEXT_FLUSH_MS));
  }
  flushBotLlmText() {
    if (this.botLlmTextFlushTimer !== null && (clearTimeout(this.botLlmTextFlushTimer), this.botLlmTextFlushTimer = null), !this.pendingBotLlmText)
      return;
    const e = this.pendingBotLlmText, t = this.pendingBotLlmTextMetadata;
    this.pendingBotLlmText = "", this.pendingBotLlmTextMetadata = {}, this.options.onMessage(new TextEncoder().encode(JSON.stringify({ type: "bot-llm-text", data: { text: e, ...t } })));
  }
  static botLlmTextCorrelationChanged(e, t) {
    return e.output_id !== void 0 || t.output_id !== void 0 ? e.output_id !== t.output_id : e.logical_turn_id !== void 0 || t.logical_turn_id !== void 0 ? e.logical_turn_id !== t.logical_turn_id : !1;
  }
  clearPendingBotLlmText() {
    this.botLlmTextFlushTimer !== null && (clearTimeout(this.botLlmTextFlushTimer), this.botLlmTextFlushTimer = null), this.pendingBotLlmText = "", this.pendingBotLlmTextMetadata = {};
  }
}
mn.BOT_LLM_TEXT_FLUSH_MS = 16;
function Qf(n) {
  return {
    ...n.text !== void 0 && { text: n.text },
    ...n.audio !== void 0 && { audio: n.audio },
    ...n.vision !== void 0 && { vision: n.vision },
    ...n.contextUpdate !== void 0 && {
      context_update: n.contextUpdate
    },
    ...n.trigger !== void 0 && { trigger: n.trigger },
    ...n.sceneMetadata !== void 0 && {
      scene_metadata: n.sceneMetadata
    }
  };
}
function Yi(n, e, t) {
  return new Promise((i, s) => {
    let r = !1;
    const o = () => {
      r = !0, e.removeEventListener("abort", o), s(new DOMException("SSE operation cancelled", "AbortError"));
    };
    if (e.aborted) {
      o();
      return;
    }
    e.addEventListener("abort", o, { once: !0 }), Promise.resolve().then(() => {
      if (e.aborted)
        throw new DOMException("SSE operation cancelled", "AbortError");
      return n();
    }).then((a) => {
      e.removeEventListener("abort", o), r ? t == null || t(a) : i(a);
    }, (a) => {
      e.removeEventListener("abort", o), s(a);
    });
  });
}
function Fs(n) {
  var e;
  (e = n.body) == null || e.cancel().catch(() => {
  });
}
function Xf() {
  return typeof crypto != "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `workspace_sse_${Date.now()}_${Math.random().toString(36).slice(2)}`;
}
function Zf(n) {
  return typeof n == "object" && n !== null && "name" in n && n.name === "AbortError";
}
class rl extends Error {
  constructor(e) {
    super("SSE interaction request cancelled"), this.name = "AbortError", this.cause = e;
  }
}
function al(n) {
  return n instanceof rl;
}
function Tr(n) {
  return {
    transport: "sse",
    logicalTurnIds: n.filter((e) => e.type === "user_text_message" && e.id).map((e) => e.id),
    messageTypes: n.map((e) => e.type)
  };
}
function wt(n) {
  return typeof n == "object" && n !== null && !Array.isArray(n) ? n : null;
}
function Cr(n) {
  return n === "must_respond" || n === "auto" || n === "silent" ? n : null;
}
function Vs(n, e) {
  var t;
  return n && "respond_mode" in n ? (t = Cr(n.respond_mode)) != null ? t : void 0 : e;
}
function eg(n, e, t, i) {
  if (n !== "server-response")
    return;
  const s = wt(e);
  if (typeof (s == null ? void 0 : s.event_type) != "string" || s.status !== "success" && s.status !== "error" && s.status !== "pending" && s.status !== "processing")
    return;
  const r = wt(s.extras), o = s.event_type === "respond-mode-update" && r !== null && "update_id" in r;
  if (!(o && typeof (r == null ? void 0 : r.update_id) != "string"))
    return [...i].find((a) => {
      var d;
      const c = t[a];
      return c.type === s.event_type && (!o || ((d = wt(c.data)) == null ? void 0 : d.update_id) === (r == null ? void 0 : r.update_id));
    });
}
function tg(n, e) {
  var o, a;
  const t = wt(n);
  if (e.type !== "respond-mode-update" || (t == null ? void 0 : t.status) !== "success")
    return null;
  const i = wt(t.extras), s = (o = Cr(i == null ? void 0 : i.actual_respond_mode)) != null ? o : Cr(i == null ? void 0 : i.mode);
  if (!s)
    return null;
  const r = ig((a = wt(e.data)) == null ? void 0 : a.modality);
  return r ? { modality: r, mode: s } : null;
}
function ig(n) {
  return n === "vision" || n === "context_update" || n === "trigger" || n === "scene_metadata" ? n : null;
}
function ng(n, e) {
  return n === "bot-llm-started" || n === "bot-llm-text" || n === "bot-llm-text-raw" || n === "bot-llm-stopped" || n === "bot-transcription" || n === "action-response" || n === "bot-output" || n === "bot-tts-text" || n === "bot-tts-started" || n === "bot-tts-stopped" || n === "bot-started-speaking" || n === "bot-stopped-speaking" || Gd({ type: n, data: e }) !== void 0;
}
function Wo(n, e, t = !1) {
  if (al(n))
    return n;
  const i = Tr(e);
  if (n instanceof Error) {
    const s = n instanceof DOMException ? new DOMException(n.message, n.name) : new Error(n.message);
    n instanceof DOMException || Object.setPrototypeOf(s, Object.getPrototypeOf(n));
    const r = Object.getOwnPropertyDescriptors(n);
    for (const o of Object.keys(i))
      delete r[o];
    Object.defineProperties(s, r);
    for (const [o, a] of Object.entries(i))
      Object.defineProperty(s, o, {
        value: a,
        writable: !0,
        configurable: !0,
        enumerable: !0
      });
    return s;
  }
  return Array.isArray(n) ? Object.assign([...n], i) : n !== null && typeof n == "object" ? { ...n, ...i } : t ? { error: n, ...i } : n;
}
kh("warn");
let Bs = null;
const $o = /* @__PURE__ */ new Set([
  "joy",
  "trust",
  "fear",
  "surprise",
  "sadness",
  "disgust",
  "anger",
  "anticipation"
]);
function js(n) {
  if (n == null)
    return n;
  const e = n.trim().toLowerCase();
  return e === "neutral" || e === "" ? null : e;
}
class Ti extends Error {
  constructor(e, t) {
    super(e), this.name = t.reason === "aborted" ? "AbortError" : t.reason === "timeout" ? "TimeoutError" : "ActionResultAckError", this.reason = t.reason, this.toolCallId = t.toolCallId, this.errorCode = t.errorCode, this.response = t.response, this.cause = t.cause;
  }
}
class Qi extends Error {
}
class sg extends Kc {
  nextRetryDelayInMs() {
    return null;
  }
}
class Ve extends fn {
  /**
   * Match an update-emotion ack to a value this client sent. The ack carries
   * no request id, its state_of_mind is the state still in effect rather than
   * the value it judged, and acks can arrive out of order (measured: "happy"'s
   * rejection before "joy"'s success). So an applied ack settles the value it
   * names, and a rejected one settles the oldest pending value that is not an
   * accepted state of mind. Returns the rejected value, when it can be named.
   */
  _settleStateOfMindAck(e) {
    var s, r;
    const t = this._pendingStateOfMindAcks;
    if (((s = e.extras) == null ? void 0 : s.applied) === !0) {
      let o = t.indexOf((r = e.extras.state_of_mind) != null ? r : null);
      o === -1 && (o = t.findIndex((a) => a === null || $o.has(a))), o !== -1 && t.splice(o, 1);
      return;
    }
    const i = t.findIndex((o) => o !== null && !$o.has(o));
    return i === -1 ? void 0 : t.splice(i, 1)[0];
  }
  /**
   * Register the WebSocket transport factory. Called automatically as a side-effect
   * when you import `@convai/web-sdk/vanilla/websocket` (or the react equivalent).
   * Only needed when using `transport: "websocket"` in ConvaiConfig.
   */
  static registerWebSocketTransport(e) {
    Bs = e;
  }
  constructor(e) {
    if (super(), this._connectionType = null, this._apiKey = null, this._authToken = null, this._characterId = null, this._characterVersion = null, this._characterReference = null, this._characterVersionManager = null, this._characterVersionManagerKey = null, this._characterSessionId = "-1", this._roster = new Rf(), this._characterMuted = !1, this._characterMutedByMembership = /* @__PURE__ */ new Map(), this._wsBotAudioTrack = null, this._pendingRosterCommands = /* @__PURE__ */ new Map(), this._rosterCommandSeq = 0, this._requestTraceId = null, this._isBotReady = !1, this._pendingTurnEnd = null, this._warnedVisionNotEnabled = !1, this._participantSid = "", this._storedConfig = null, this._stateOfMind = null, this._pendingStateOfMindAcks = [], this._endUserId = null, this._endUserMetadata = null, this._wsSession = null, this._activeTransport = null, this._sseSession = null, this._logRtviMessages = !0, this._isDisconnecting = !1, this._isPublishedChatSession = !1, this._clientReadyRetryTimer = null, this._clientReadyTimeoutTimer = null, this._clientReadyMsgId = null, this._pendingActionResultAcks = /* @__PURE__ */ new Map(), this._conversationSessionId = 0, this._conversationStartTime = 0, this._memoryManager = null, e && (this._storedConfig = e, this._logRtviMessages = e.logRtviMessages !== !1, e.characterId && !Un(e)))
      try {
        const t = Us(e.characterId, e.characterVersion);
        this._characterId = t.characterId, this._characterVersion = t.version, this._characterReference = t.reference;
      } catch {
      }
    this._room = new Bi({
      reconnectPolicy: new sg()
    }), this._state = {
      isConnected: !1,
      isConnecting: !1,
      isListening: !1,
      isThinking: !1,
      isSpeaking: !1,
      agentState: "disconnected",
      emotion: null,
      endUserId: null,
      endUserMetadata: null,
      metrics: [],
      characters: [],
      activeMembershipId: null,
      disconnectReason: null
    }, this._audioSettings = {
      echoCancellation: !0,
      noiseSuppression: !0,
      autoGainControl: !0,
      sampleRate: 48e3,
      channelCount: 1
    }, this._audioManager = new df(this._room), this._videoManager = new ff(this._room), this._screenShareManager = new gf(this._room), this._messageHandler = new _f(this._room), this._messageHandler.setRtviMessageLogging(this._logRtviMessages), this._connectionStateHandler = new Wf(this.updateState.bind(this), (t) => this._isBotReady = t, () => {
      this._messageHandler.reset(), this._endUserId = null, this._endUserMetadata = null;
    }, (t) => this.emit("disconnect", t)), this.setupEventListeners(), this.setupMessageHandlerEvents();
  }
  // Getters
  get state() {
    return { ...this._state };
  }
  get connectionType() {
    return this._connectionType;
  }
  get isPublishedChatSession() {
    return this._isPublishedChatSession;
  }
  get apiKey() {
    return this._apiKey;
  }
  get authToken() {
    return this._authToken;
  }
  get characterId() {
    return this._characterId;
  }
  get characterVersion() {
    return this._characterVersion;
  }
  get characterReference() {
    return this._characterReference;
  }
  /**
   * Character version manager for the configured character. Built from the
   * live connection when there is one, otherwise from the stored config, so
   * versions can be listed and released before connecting. Null without an
   * API key (the Character REST platform does not accept realtime auth tokens).
   */
  get characterVersions() {
    var o, a, c, d, l, u, h, p;
    const e = (c = (a = this._apiKey) != null ? a : (o = this._storedConfig) == null ? void 0 : o.apiKey) != null ? c : null, t = (u = (l = this._characterId) != null ? l : (d = this._storedConfig) == null ? void 0 : d.characterId) != null ? u : null;
    if (!e || !t)
      return null;
    let i = t;
    try {
      i = Us(t).characterId;
    } catch {
    }
    const s = (p = (h = this._storedConfig) == null ? void 0 : h.characterApiUrl) != null ? p : void 0, r = `${e}\0${i}\0${s != null ? s : ""}`;
    return this._characterVersionManagerKey !== r && (this._characterVersionManager = new qf({
      apiKey: e,
      characterId: i,
      baseUrl: s
    }), this._characterVersionManagerKey = r), this._characterVersionManager;
  }
  get room() {
    return this._room;
  }
  get chatMessages() {
    return this._messageHandler.getChatMessages();
  }
  get userTranscription() {
    return this._messageHandler.getUserTranscription();
  }
  get characterSessionId() {
    return this._characterSessionId;
  }
  on(e, t) {
    return super.on(e, t);
  }
  /**
   * Server-owned snapshot of a multi-character room, or null for a
   * single-character session. Carries the room id, epochs and roster.
   */
  get roomSession() {
    return this._roster.roomSession;
  }
  /**
   * Character instances in a multi-character room, in roster order. Empty for a
   * single-character session, so `length` distinguishes the two.
   */
  get characters() {
    return this._roster.characters;
  }
  /** Membership currently receiving user turns, or null. */
  get activeMembershipId() {
    return this._roster.activeMembershipId;
  }
  /**
   * Start or stop the server streaming per-turn usage/cost breakdowns as
   * `usageUpdate` events. Informational only; server-side usage tracking and
   * billing are unaffected either way.
   */
  toggleUsageUpdates(e) {
    var t;
    this.isTransportReady() && (e && !((t = this._storedConfig) != null && t.debug) && console.warn("[ConvaiClient] toggleUsageUpdates(true) needs a session connected with `debug: true`; without it the server sends no usageUpdate events."), this.publishMessage("usage-toggle", { enabled: e }));
  }
  /** Insert a transcript line locally. Nothing is sent; nothing is billed. */
  appendMessage(e) {
    var t;
    if (!((t = e == null ? void 0 : e.content) != null && t.trim()))
      throw new Error("appendMessage requires non-empty content");
    return this._messageHandler.appendLocalMessage(e);
  }
  /** Trace id of the /connect that produced this session; quote it to backend support. */
  get requestTraceId() {
    return this._requestTraceId;
  }
  get isBotReady() {
    return this._isBotReady;
  }
  get audioControls() {
    return this._audioManager;
  }
  /**
   * Configured origin for the widget's character name/avatar lookup, or null
   * when unset. See {@link ConvaiConfig.characterInfoUrl}.
   */
  get characterInfoUrl() {
    var e, t;
    return (t = (e = this._storedConfig) == null ? void 0 : e.characterInfoUrl) != null ? t : null;
  }
  /**
   * Silence the character's voice, or bring it back. See
   * {@link IConvaiClient.setCharacterMuted}.
   */
  setCharacterMuted(e, t) {
    const i = t == null ? void 0 : t.membershipId;
    i ? this._characterMutedByMembership.set(i, e) : (this._characterMuted = e, this._characterMutedByMembership.clear()), this._applyCharacterMute();
  }
  /**
   * Whether the character's voice is currently silenced. See
   * {@link IConvaiClient.isCharacterMuted}.
   */
  isCharacterMuted(e) {
    var t;
    return e === void 0 ? this._characterMuted : (t = this._characterMutedByMembership.get(e)) != null ? t : this._characterMuted;
  }
  /**
   * Push the desired state onto every track that can carry the character's
   * voice right now.
   *
   * `MediaStreamTrack.enabled` is the lever, not LiveKit's
   * `RemoteTrack.setMuted` (marked `@internal`, and it reports the publisher as
   * muted) and not the `<audio>` elements (core holds no DOM, and a headless
   * consumer has no elements to find). A disabled receiving track yields
   * silence while the stream keeps flowing, which is what a speaker mute is:
   * nothing is renegotiated and no turn is interrupted.
   */
  _applyCharacterMute() {
    var e, t;
    this._wsBotAudioTrack && (this._wsBotAudioTrack.enabled = !this._characterMuted), (t = (e = this._wsSession) == null ? void 0 : e.setBotAudioMuted) == null || t.call(e, this._characterMuted), this._room.state === fe.Connected && this._room.remoteParticipants.forEach((i) => {
      const s = i.identity;
      let r;
      if (this._roster.isMultiCharacter) {
        if (!s.startsWith("character:"))
          return;
        const a = s.slice(10);
        if (!this._roster.find(a))
          return;
        r = a;
      }
      const o = this.isCharacterMuted(r);
      i.audioTrackPublications.forEach((a) => {
        var d;
        const c = (d = a.track) == null ? void 0 : d.mediaStreamTrack;
        c && (c.enabled = !o);
      });
    });
  }
  get videoControls() {
    return this._videoManager;
  }
  get screenShareControls() {
    return this._screenShareManager;
  }
  get blendshapeQueue() {
    return this._messageHandler.getBlendshapeQueue();
  }
  get conversationSessionId() {
    return this._conversationSessionId;
  }
  get memoryManager() {
    return this._memoryManager;
  }
  /**
   * Setup event listeners for room and managers
   */
  setupEventListeners() {
    this._room.on(x.TrackSubscribed, (e, t, i) => {
      if (e.kind !== "audio")
        return;
      const s = i.identity;
      if (this._applyCharacterMute(), !this._roster.isMultiCharacter) {
        this.emit("characterAudioTrack", {
          membershipId: null,
          characterId: this._characterId,
          participantIdentity: s,
          track: e.mediaStreamTrack
        });
        return;
      }
      const r = s.startsWith("character:") ? s.slice(10) : null, o = r ? this._roster.find(r) : void 0;
      if (!o) {
        this._logRtviMessages && console.warn(`[ConvaiClient] dropped audio track from unattributed participant "${s}"`);
        return;
      }
      this.emit("characterAudioTrack", {
        membershipId: o.membershipId,
        characterId: o.characterId,
        participantIdentity: s,
        track: e.mediaStreamTrack
      });
    }), this._room.on(x.Disconnected, (e) => {
      this._connectionStateHandler.handleDisconnected(e);
    }), this._room.on(x.ConnectionStateChanged, this._connectionStateHandler.handleConnectionStateChanged.bind(this._connectionStateHandler)), this._messageHandler.on("botReady", (e) => {
      if (this._roster.applyBotReady(e)) {
        this.updateState({
          characters: this._roster.characters,
          activeMembershipId: this._roster.activeMembershipId
        });
        const t = e == null ? void 0 : e.membership_id;
        t && this.emit("characterReady", this._roster.find(t));
      }
      this._isBotReady || (this._isBotReady = !0, this._stopClientReadyHandshake(), this.updateState({ isConnected: !0 }), this.emit("botReady"));
    }), this._messageHandler.on("messagesChange", (e, t, i) => {
      if (i != null && i.length)
        for (const s of i)
          this.emit("message", s);
      else
        this.emit("message", t != null ? t : e[e.length - 1]);
      this.emit("messagesChange", e);
    }), this._messageHandler.on("userTranscriptionChange", (e) => {
      this.emit("userTranscriptionChange", e);
    }), this._messageHandler.on("speakingChange", (e) => {
      if (this.updateState({ isSpeaking: e }), this.emit("speakingChange", e), e) {
        this._pendingTurnEnd && clearTimeout(this._pendingTurnEnd), this._pendingTurnEnd = null;
        return;
      }
      if (this._conversationSessionId > 0) {
        const t = Date.now(), i = this._conversationSessionId, s = parseFloat(((t - this._conversationStartTime) / 1e3).toFixed(2));
        this._pendingTurnEnd && clearTimeout(this._pendingTurnEnd), this._pendingTurnEnd = setTimeout(() => {
          this._pendingTurnEnd = null, this.emit("turnEnd", { sessionId: i, duration: s, timestamp: t });
        }, Ve.TURN_END_SETTLE_MS);
      }
    }), this._messageHandler.on("botRespondingChange", (e) => {
      this.updateState({ isThinking: e });
    }), this._messageHandler.on("emotionChange", (e) => {
      this.updateState({ emotion: e }), this.emit("emotionChange", e);
    }), this._messageHandler.on("listeningChange", (e) => {
      const t = this._state.isListening;
      this.updateState({ isListening: e }), !t && e && ((this.blendshapeQueue.isConversationActive() || this._state.isSpeaking || this.blendshapeQueue.hasBufferedFrames()) && this._messageHandler.interruptLipsyncPlayback(), this._conversationSessionId++, this._conversationStartTime = Date.now(), this.emit("conversationStart", {
        sessionId: this._conversationSessionId,
        userMessage: "[voice]",
        timestamp: this._conversationStartTime
      }));
    }), this._messageHandler.on("metrics", (e) => {
      const t = [
        ...this._state.metrics,
        {
          id: `metrics-${Date.now()}-${Math.random()}`,
          data: e,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        }
      ];
      this.updateState({ metrics: t }), this.emit("metrics", e);
    }), this._messageHandler.on("blendshapes", (e) => {
      this.emit("blendshapes", e);
    }), this._messageHandler.on("blendshapeStatsReceived", (e) => {
      this.emit("blendshapeStatsReceived", e);
    }), this._messageHandler.on("blendshapeCancel", (e) => {
      this.emit("blendshapeCancel", e);
    }), this._messageHandler.on("idleWarning", (e) => {
      this.emit("idleWarning", e);
    }), this._messageHandler.on("llmNoResponse", (e) => {
      e ? this.emit("llmNoResponse", e) : this.emit("llmNoResponse");
    }), this._messageHandler.on("rawMessage", (e) => {
      this.emit("rawMessage", e);
    }), this._messageHandler.on("botTurnCompleted", (e, t) => {
      this.emit("botTurnCompleted", e, t);
    }), this._messageHandler.on("botOutput", (e) => {
      this.emit("botOutput", e);
    }), this._messageHandler.on("botTtsText", (e) => {
      this.emit("botTtsText", e);
    }), this._messageHandler.on("botTtsStarted", () => {
      this.emit("botTtsStarted");
    }), this._messageHandler.on("botTtsStopped", () => {
      this.emit("botTtsStopped");
    }), this._messageHandler.on("audioData", (e, t) => {
      this.emit("audioData", e, t);
    }), this._messageHandler.on("userMuteStarted", () => {
      this.emit("userMuteStarted");
    }), this._messageHandler.on("userMuteStopped", () => {
      this.emit("userMuteStopped");
    }), this._messageHandler.on("actionResponse", (e) => {
      this.emit("actionResponse", e);
    }), this._messageHandler.on("usageUpdate", (e) => {
      this.emit("usageUpdate", e);
    }), this._messageHandler.on("characterStatus", (e) => {
      this._roster.applyCharacterStatus(e) && this.updateState({
        characters: this._roster.characters,
        activeMembershipId: this._roster.activeMembershipId
      }), this.emit("characterStatus", e);
    }), this._messageHandler.on("modelOutput", (e) => {
      this.emit("modelOutput", e);
    }), this._messageHandler.on("botLlmTextRaw", (e) => {
      this.emit("botLlmTextRaw", e);
    }), this._messageHandler.on("modelOutputProtocolError", (e) => {
      this.emit("modelOutputProtocolError", e);
    }), this._messageHandler.on("serverResponse", (e, t) => {
      var s, r, o, a;
      this._handleRosterServerResponse(e);
      const i = e.event_type === "update-emotion" ? this._settleStateOfMindAck(e) : void 0;
      e.event_type === "update-emotion" && ((s = e.extras) == null ? void 0 : s.applied) === !1 && console.warn(`[ConvaiClient] the server ignored ${i !== void 0 ? `state of mind ${JSON.stringify(i)}` : "a state of mind"}. Use one of: joy, trust, fear, surprise, sadness, disgust, anger, anticipation.`), !this._warnedVisionNotEnabled && (((r = e.extras) == null ? void 0 : r.downgrade_reason) === "vision_not_enabled" || ((a = (o = e.extras) == null ? void 0 : o.vision_buffer) == null ? void 0 : a.status) === "vision_not_enabled") && (this._warnedVisionNotEnabled = !0, console.warn("[ConvaiClient] vision is not enabled for this session, so published frames are not seen. It needs enableVideo: true, the unified vision context feature on the account, and a vision-capable non-realtime model on the character.")), t ? this.emit("serverResponse", e, t) : this.emit("serverResponse", e);
    }), this._messageHandler.on("interactionCreated", (e) => {
      this.emit("interactionCreated", e);
    });
  }
  /**
   * Setup MessageHandler to respond to conversation start events
   * This ensures the BlendshapeQueue starts accepting frames when user sends a message,
   * rather than waiting for bot-started-speaking (which would cause early frames to be dropped)
   */
  setupMessageHandlerEvents() {
    this.on("conversationStart", (e) => {
      this._messageHandler.getBlendshapeQueue().startConversation();
    });
  }
  /**
   * Update state and emit changes
   */
  updateState(e) {
    const t = { ...this._state };
    this._state = { ...this._state, ...e }, this._state.isConnected ? this._state.isSpeaking ? this._state.agentState = "speaking" : this._state.isListening ? this._state.agentState = "listening" : this._state.isThinking ? this._state.agentState = "thinking" : this._state.agentState = "connected" : this._state.agentState = "disconnected", JSON.stringify(t) !== JSON.stringify(this._state) && this.emit("stateChange", this._state);
  }
  /**
   * Send a data message via the active transport.
   * For LiveKit: publishes via the data channel.
   * For WebSocket: sends via PipecatClient.sendClientMessage (wrapped in {t,d} envelope).
   */
  publishMessage(e, t, i) {
    var r, o, a;
    const s = i === void 0 ? { type: e, data: t } : { type: e, id: i, data: t };
    if (this._activeTransport === "sse" && ((r = this._sseSession) != null && r.isConnected)) {
      this._sseSession.sendMessage(e, t, i);
      return;
    }
    if (this._activeTransport === "websocket" && ((o = this._wsSession) != null && o.isConnected))
      this._wsSession.sendMessage(e, t);
    else if ((a = this._room) != null && a.localParticipant && this._room.state !== "disconnected") {
      const c = new TextEncoder().encode(JSON.stringify(s));
      this._room.localParticipant.publishData(c, { reliable: !0 });
    }
  }
  /**
   * Publish exactly one message while retaining the transport's local completion
   * signal. Server acceptance is still proved separately by `serverResponse`.
   */
  async publishMessageAndWaitForLocalPublication(e, t, i) {
    var r, o;
    const s = i === void 0 ? { type: e, data: t } : { type: e, id: i, data: t };
    if (this._activeTransport === "websocket") {
      if (!((r = this._wsSession) != null && r.isConnected))
        throw new Error("The action-result WebSocket transport is no longer available");
      this._wsSession.sendMessage(e, t);
      return;
    }
    if (this._activeTransport === "livekit" && ((o = this._room) != null && o.localParticipant) && this._room.state !== "disconnected") {
      const a = new TextEncoder().encode(JSON.stringify(s));
      await this._room.localParticipant.publishData(a, {
        reliable: !0
      });
      return;
    }
    throw new Error("The action-result transport is no longer available");
  }
  /**
   * Returns true when a message can be sent on the active transport.
   */
  isTransportReady() {
    var e, t, i, s, r;
    return this._activeTransport === "sse" ? (t = (e = this._sseSession) == null ? void 0 : e.isConnected) != null ? t : !1 : this._activeTransport === "websocket" ? (s = (i = this._wsSession) == null ? void 0 : i.isConnected) != null ? s : !1 : !!((r = this._room) != null && r.localParticipant) && this._room.state !== "disconnected";
  }
  /**
   * Connect to a Convai character
   */
  async connect(e) {
    var s, r, o, a, c, d, l, u, h, p, b, v, C, T;
    this._warnedVisionNotEnabled = !1, this._pendingStateOfMindAcks = [];
    const t = e || this._storedConfig;
    if (!t)
      throw new Error("No configuration provided. Pass config to connect() or store it in the client");
    this._storedConfig = { ...t }, this._isPublishedChatSession = !1, t.characterSessionId && t.characterSessionId !== "-1" && (this._characterSessionId = t.characterSessionId);
    const i = this.applyConfigDefaults(t);
    this._messageHandler.setModelOutputVersion(1), this.updateState({ isConnecting: !0 }), this._requestTraceId = null;
    try {
      this._apiKey = (s = i.apiKey) != null ? s : null, this._authToken = (r = i.authToken) != null ? r : null, this._characterId = i.characterId, this._characterVersion = (o = i.characterVersion) != null ? o : null, this._characterReference = i.characterReference;
      const P = i.enableVideo ? "video" : "audio";
      this._connectionType = P;
      const R = (a = i.transport) != null ? a : i.interactionApiUrl ? "sse" : "livekit";
      if (R === "sse" && !i.interactionApiUrl)
        throw new Error("interactionApiUrl is required when using the SSE transport");
      if (R === "sse" && i.enableVideo)
        throw new Error("The SSE transport supports text interactions only");
      this._activeTransport = R;
      const g = Ho(i), f = i.stateOfMind !== void 0 ? (c = js(i.stateOfMind)) != null ? c : null : this._stateOfMind;
      if (this._stateOfMind = f, R === "sse") {
        this._sseSession = new mn({
          interactionApiUrl: i.interactionApiUrl,
          authorization: (d = i.apiKey) != null ? d : "",
          ...i.authToken && { authToken: i.authToken },
          credentialProvider: i.interactionCredentialProvider,
          characterId: i.characterReference,
          getCharacterSessionId: () => this._characterSessionId,
          takeStateOfMind: () => {
            var Q;
            const B = this._stateOfMind;
            return this._stateOfMind = null, ((Q = this._storedConfig) == null ? void 0 : Q.stateOfMind) !== void 0 && (this._storedConfig = { ...this._storedConfig, stateOfMind: null }), B;
          },
          onCharacterSessionId: (B) => {
            this._characterSessionId = B, this.emit("characterSessionId", B), this._storedConfig = {
              ...this._storedConfig,
              characterSessionId: B
            };
          },
          endUserId: i.endUserId,
          endUserMetadata: i.endUserMetadata,
          enableEmotion: i.enableEmotion,
          emotionConfig: i.emotionConfig,
          actionConfig: i.actionConfig,
          capabilities: i.capabilities,
          dynamicInfo: i.dynamicInfo,
          keepInContext: i.keepInContext,
          narrativeTemplateKeys: i.narrativeTemplateKeys,
          sceneDescription: i.sceneDescription,
          respondModes: i.respondModes,
          useResponseLifecycleContract: i.useResponseLifecycleContract,
          invocationMetadata: i.invocationMetadata,
          ttsEnabled: i.ttsEnabled,
          debug: i.debug,
          onRawMessage: (B) => this.emit("rawMessage", B),
          onMessage: (B, Q) => this._messageHandler.handleDataReceivedPublic(B, "sse", Q),
          onError: (B, Q) => this.emit("error", B, Q),
          // EOF/rejection is a local transport boundary, not a synthetic Core
          // completion. Close every row before the next stateless request.
          onResponseFinished: () => this._messageHandler.finalizeInterruptedResponse(!0)
        }), this._sseSession.connect(), this._connectionType = "audio", this._isBotReady = !0, this.updateState({
          isConnected: !0,
          isConnecting: !1,
          endUserId: (l = i.endUserId) != null ? l : null,
          endUserMetadata: (u = i.endUserMetadata) != null ? u : null
        }), this.emit("connect"), this.emit("botReady");
        return;
      }
      const k = (h = i.characterSessionId) != null ? h : this._characterSessionId, w = Un(i), D = sl(i.capabilities), A = {
        ...w ? Nf(i) : { character_id: i.characterReference },
        ...f ? { state_of_mind: f } : {},
        ...i.endUserId && {
          end_user_id: i.endUserId
        },
        ...i.endUserMetadata != null && {
          end_user_metadata: i.endUserMetadata
        },
        transport: R,
        ...D && {
          capabilities: D
        },
        connection_type: P,
        ...Gf(i),
        ...Zn(i) && {
          emotion_config: Zn(i)
        },
        default_tts_enabled: i.ttsEnabled !== void 0 ? i.ttsEnabled : !0,
        default_stt_enabled: !0,
        ...g && {
          vision_input_config: Yf(g)
        },
        ...i.visionPromptMode !== void 0 && {
          vision_prompt_mode: i.visionPromptMode
        },
        ...i.respondModes && {
          respond_modes: this.serializeRespondModes(i.respondModes)
        },
        ...D && { capabilities: D },
        ...i.sceneDescription && {
          scene_description: i.sceneDescription
        },
        // A roster room owns its members' sessions; the singular resume id is
        // a compatibility mirror and must not go back on the wire.
        ...!w && k && k !== "-1" && {
          character_session_id: k
        },
        ...es(i) && {
          action_config: es(i)
        },
        ...i.dynamicInfo && {
          dynamic_info: {
            text: i.dynamicInfo,
            ...i.keepInContext !== void 0 && {
              keep_in_context: i.keepInContext
            }
          }
        },
        ...i.narrativeTemplateKeys && Object.keys(i.narrativeTemplateKeys).length > 0 && {
          narrative_template_keys: i.narrativeTemplateKeys
        },
        ...i.debug !== void 0 && {
          debug: i.debug
        },
        ...i.preserveLinksInOutput !== void 0 && {
          preserve_links_in_output: i.preserveLinksInOutput
        },
        ...i.useResponseLifecycleContract !== void 0 && {
          use_response_lifecycle_contract: i.useResponseLifecycleContract
        },
        invocation_metadata: {
          source: (b = (p = i.invocationMetadata) == null ? void 0 : p.source) != null ? b : "web_sdk",
          client_version: (C = (v = i.invocationMetadata) == null ? void 0 : v.clientVersion) != null ? C : Vf,
          ...((T = i.invocationMetadata) == null ? void 0 : T.extraMetadata) && {
            extra_metadata: i.invocationMetadata.extraMetadata
          }
        }
      }, O = {
        "Content-Type": "application/json"
      };
      i.authToken ? O["API-AUTH-TOKEN"] = i.authToken : i.apiKey && (O["X-API-Key"] = i.apiKey);
      const N = async () => {
        var Q, ae;
        const B = await fetch(`${i.url}/connect`, {
          method: "POST",
          headers: O,
          body: JSON.stringify(A)
        });
        if (!B.ok) {
          const re = await B.text();
          let K = `HTTP ${B.status}`;
          try {
            const xe = JSON.parse(re), Ie = (ae = (Q = xe.message) != null ? Q : xe.error) != null ? ae : xe.detail;
            typeof Ie == "string" ? K = Ie : Array.isArray(Ie) ? K = Ie.map(($) => {
              var $e;
              return [($e = $.loc) == null ? void 0 : $e.join("."), $.msg].filter(Boolean).join(": ");
            }).join("; ") || K : Ie != null ? K = JSON.stringify(Ie) : re && (K = `${K}: ${re}`);
          } catch {
            re && (K = `${K}: ${re}`);
          }
          if (w) {
            let xe = re;
            try {
              xe = JSON.parse(re);
            } catch {
            }
            throw Bo(B.status, xe);
          }
          throw new Error(K);
        }
        return await B.json();
      }, L = w ? await this._withProvisioningRetry(i, N) : await N();
      return await this.consumeConnectionData(L, i);
    } catch (P) {
      throw await this.cleanupWebSocketSessionAfterConnectFailure(), this.updateState({
        isConnected: !1,
        isConnecting: !1
      }), this.emit("error", P), P;
    }
  }
  /**
   * Complete a connection from an already-fetched /connect response body.
   *
   * `connect()` fetches /connect and then calls this internally. Call it
   * directly when the response was obtained elsewhere — a server-side session
   * manager, or the embed's connect-proxy flow, where the API key must never
   * reach the browser.
   *
   * @example
   * // Server (customer's backend): holds the API key, calls Convai's
   * // /connect, and relays the response body verbatim.
   * // Browser: never sees the API key, only the relayed response.
   * const data = await fetch('/api/convai-connect', {
   *   method: 'POST',
   *   headers: { 'Content-Type': 'application/json' },
   *   body: JSON.stringify({ characterId: 'your-character-id' }),
   * }).then(r => r.json())
   * await client.connectWithConnectionData(data)
   */
  async connectWithConnectionData(e, t) {
    this._isPublishedChatSession = !1;
    const i = t || this._storedConfig;
    if (!i)
      throw new Error("No configuration provided. Pass config to connectWithConnectionData() or store it in the client");
    this._storedConfig = { ...i }, i.characterSessionId && i.characterSessionId !== "-1" && (this._characterSessionId = i.characterSessionId);
    const s = this.applyConfigDefaults(i, {
      requireCredential: !1
    });
    this.updateState({ isConnecting: !0 });
    try {
      return await this.consumeConnectionData(e, s);
    } catch (r) {
      throw await this.cleanupWebSocketSessionAfterConnectFailure(), this.updateState({
        isConnected: !1,
        isConnecting: !1
      }), this.emit("error", r), r;
    }
  }
  /** Correlate roster acks back to the promise that issued the command. */
  _handleRosterServerResponse(e) {
    var a, c, d;
    const t = e.event_type;
    if (t !== "interaction-target" && t !== "character-roster-update")
      return;
    const i = (a = e.extras) != null ? a : null, s = i == null ? void 0 : i.command_id, r = s ? this._pendingRosterCommands.get(s) : void 0;
    if (e.status === "error") {
      this._roster.adoptEpochs(i), this._pushRosterState(), r && s && (this._pendingRosterCommands.delete(s), clearTimeout(r.timer), r.reject(Object.assign(new Error((c = e.message) != null ? c : `${t} was rejected`), { code: (d = i == null ? void 0 : i.code) != null ? d : null, extras: i })));
      return;
    }
    let o;
    t === "interaction-target" ? (o = this._roster.applyInteractionTarget(i), this._pushRosterState(), this.emit("activeCharacterChange", o)) : (o = this._roster.applyRosterUpdate(i), this._pushRosterState(), this.emit("rosterChange", o)), r && s && (this._pendingRosterCommands.delete(s), clearTimeout(r.timer), r.resolve(o));
  }
  /**
   * Settle every in-flight roster command.
   *
   * Without this a caller who disconnects mid-command keeps a live 10s timer
   * and gets a rejection long after the session ended -- an unhandled rejection
   * if they stopped awaiting when they tore the client down. The roster is
   * reset alongside, so the command could not be applied meaningfully anyway.
   */
  _failPendingRosterCommands(e) {
    for (const [, t] of this._pendingRosterCommands)
      clearTimeout(t.timer), t.reject(new Error(e));
    this._pendingRosterCommands.clear();
  }
  _pushRosterState() {
    this.updateState({
      characters: this._roster.characters,
      activeMembershipId: this._roster.activeMembershipId
    });
  }
  /** Publish a roster command and settle when its ack arrives. */
  _sendRosterCommand(e, t) {
    if (!this._roster.isMultiCharacter)
      return Promise.reject(new Error(`Cannot send ${e}: this session was not created with a characters array`));
    if (!this.isTransportReady())
      return Promise.reject(new Error(`Cannot send ${e}: not connected`));
    const i = `${e}-${++this._rosterCommandSeq}-${Date.now()}`;
    return new Promise((s, r) => {
      const o = setTimeout(() => {
        this._pendingRosterCommands.delete(i), r(new Error(`${e} was not acknowledged within ${Ve.ROSTER_COMMAND_TIMEOUT_MS}ms. The outcome is unknown -- acks can be suppressed as duplicates. Reconcile from the next authoritative room state before sending a conflicting command.`));
      }, Ve.ROSTER_COMMAND_TIMEOUT_MS);
      this._pendingRosterCommands.set(i, { resolve: s, reject: r, timer: o }), this.publishMessage(e, t(i), i);
    });
  }
  /**
   * Route subsequent user turns to a different character instance.
   *
   * Pass null to close every gate, so no member consumes the user until a
   * target is set again.
   */
  async setInteractionTarget(e) {
    if (!this._roster.isMultiCharacter)
      throw new Error("Cannot send interaction-target: this session was not created with a characters array");
    if (e !== null) {
      if (!e)
        throw new Error("setInteractionTarget requires a membershipId, or null to close all gates");
      const i = this._roster.find(e);
      if (this._roster.isMultiCharacter && !i)
        throw new Error(`Unknown membershipId "${e}". Address instances by membershipId, not characterId.`);
      if (i && !i.isReady)
        throw new Error(`Membership "${e}" has not sent bot-ready yet; the runtime refuses an unready target`);
    }
    const t = () => this._sendRosterCommand("interaction-target", (i) => this._roster.buildInteractionTarget(e, i));
    try {
      return await t();
    } catch (i) {
      if ((i == null ? void 0 : i.code) !== "stale_route_epoch")
        throw i;
      return await t();
    }
  }
  /** Add or remove character instances on a live room, without reconnecting. */
  async updateCharacterRoster(e) {
    var o, a;
    if (!this._roster.isMultiCharacter)
      throw new Error("Cannot send character-roster-update: this session was not created with a characters array");
    const t = (o = e == null ? void 0 : e.add) != null ? o : [], i = (a = e == null ? void 0 : e.remove) != null ? a : [];
    if (t.length === 0 && i.length === 0)
      throw new Error("updateCharacterRoster requires at least one add or remove");
    if (t.some((c) => {
      var d;
      return !((d = c == null ? void 0 : c.characterId) != null && d.trim());
    }))
      throw new Error("Every entry in add requires a characterId");
    if (i.length && i.length >= this._roster.characters.length && t.length === 0)
      throw new Error("A roster room cannot be emptied; add a replacement or keep one member");
    const s = this._roster.activeMembershipId, r = !e.replacementTarget && s && i.includes(s) ? { ...e, replacementTarget: this._roster.pickReplacement(i) } : e;
    return await this._sendRosterCommand("character-roster-update", (c) => this._roster.buildRosterUpdate(r, c));
  }
  /**
   * Run a room request, retrying only the conflicts that mean "still working".
   *
   * The runtime answers a create that collides with an in-flight identical
   * create with 409 `ROSTER_PROVISIONING_IN_PROGRESS`, and the documented
   * recovery is to retry the same key with bounded backoff. Left to callers,
   * every integration reimplements that, usually without a cap. The payload is
   * replayed verbatim -- changing it would turn the retry into a fingerprint
   * mismatch.
   */
  async _withProvisioningRetry(e, t) {
    var a, c;
    const i = e.rosterProvisioningRetry;
    if (i === !1)
      return t();
    const s = Math.max(1, (a = i == null ? void 0 : i.attempts) != null ? a : Ve.ROSTER_RETRY_ATTEMPTS), r = Math.max(0, (c = i == null ? void 0 : i.initialDelayMs) != null ? c : Ve.ROSTER_RETRY_INITIAL_MS);
    let o;
    for (let d = 0; d < s; d++)
      try {
        return await t();
      } catch (l) {
        if (o = l, !(l instanceof Zd && l.isRetryable) || d === s - 1)
          throw l;
        const p = r * 2 ** d * (0.8 + Math.random() * 0.4);
        await new Promise((b) => setTimeout(b, p));
      }
    throw o;
  }
  /**
   * Join a multi-character room that already exists.
   *
   * A join supplies a locator and the joining human, and nothing else: the
   * roster is server-owned, so resending topology is rejected. It never spawns,
   * removes or repairs a character -- only room creation does that.
   *
   * Capacity counts distinct speakers derived from `endUserId`, and defaults to
   * one, so raise `maxNumParticipants` at creation before expecting a second
   * human to get in.
   *
   * @example
   * ```ts
   * const client = new ConvaiClient({ apiKey: 'YOUR_API_KEY' })
   * await client.joinRoom({
   *   roomSessionId: 'the-room-session-id',
   *   endUserId: 'player-99',
   * })
   * ```
   */
  async joinRoom(e) {
    var s, r, o;
    Lf(e), this._isPublishedChatSession = !1;
    const t = (s = this._storedConfig) != null ? s : {}, i = (r = t.url) != null ? r : "https://realtime-api.convai.com";
    if (!t.apiKey && !t.authToken)
      throw new Error("Either apiKey or authToken is required to join a room");
    this._logRtviMessages = t.logRtviMessages !== !1, this._messageHandler.setRtviMessageLogging(this._logRtviMessages), this.updateState({ isConnecting: !0 });
    try {
      const a = await this._withProvisioningRetry(t, async () => {
        const h = await fetch(`${i}/connect`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...t.apiKey ? { "X-API-Key": t.apiKey } : { "API-AUTH-TOKEN": t.authToken }
          },
          body: JSON.stringify(Uf(e))
        });
        if (!h.ok) {
          const p = await h.text();
          let b = p;
          try {
            b = JSON.parse(p);
          } catch {
          }
          throw Bo(h.status, b);
        }
        return await h.json();
      }), c = a.characters, d = (o = c == null ? void 0 : c[0]) == null ? void 0 : o.character_id, l = {
        ...t,
        characters: void 0,
        characterId: d != null ? d : t.characterId,
        endUserId: e.endUserId,
        ...e.endUserMetadata ? { endUserMetadata: e.endUserMetadata } : {}
      };
      this._storedConfig = l;
      const u = this.applyConfigDefaults(l, {
        requireCredential: !1
      });
      return await this.consumeConnectionData(a, u);
    } catch (a) {
      throw await this.cleanupWebSocketSessionAfterConnectFailure(), this.updateState({ isConnected: !1, isConnecting: !1 }), this.emit("error", a), a;
    }
  }
  /**
   * Add default URL, apply RTVI-logging config, and validate that either an
   * API key or auth token plus a character ID are present.
   * Shared by connect() and connectWithConnectionData() so both derive
   * `configWithDefaults` identically.
   *
   * `connect()` performs its own /connect fetch and always needs a credential
   * to do so, so it uses the default `requireCredential: true`.
   * `connectWithConnectionData()` consumes a response obtained elsewhere (e.g.
   * a proxy that holds the credential server-side) and passes
   * `requireCredential: false` — a character ID is still required either way.
   */
  applyConfigDefaults(e, t = {}) {
    var h;
    const { requireCredential: i = !0 } = t, s = {
      url: "https://realtime-api.convai.com",
      ...e
    };
    this._logRtviMessages = s.logRtviMessages !== !1, this._messageHandler.setRtviMessageLogging(this._logRtviMessages);
    const r = !!s.apiKey, o = !!s.authToken, a = !!s.interactionCredentialProvider, c = s.endUserId !== void 0 && s.endUserId !== null;
    if (a && (r || o || c || s.endUserMetadata !== void 0 || ((h = s.transport) != null ? h : s.interactionApiUrl ? "sse" : "livekit") !== "sse"))
      throw new Error("interactionCredentialProvider requires SSE without static credentials or end-user overrides");
    const d = i && !r && !o && !a;
    Df(s);
    const l = Un(s);
    if (d || !l && !s.characterId)
      throw new Error("Either apiKey or authToken is required, and characterId is required");
    if (l) {
      Of(s);
      const p = s.characters[0].characterId.trim();
      return {
        ...s,
        // Singular readouts mirror characters[0], exactly as the wire's own
        // top-level session_id/character_session_id aliases do.
        characterId: p,
        characterVersion: null,
        characterReference: p
      };
    }
    const u = Us(s.characterId, s.characterVersion);
    return {
      ...s,
      characterId: u.characterId,
      characterVersion: u.version,
      characterReference: u.reference
    };
  }
  /**
   * Consume a /connect response and bring up the transport.
   * `connect()` calls this after its own fetch; external callers use it
   * when the response came from a proxy.
   */
  async consumeConnectionData(e, t) {
    var c, d, l, u, h, p, b, v, C, T;
    this._apiKey = (c = t.apiKey) != null ? c : null, this._authToken = (d = t.authToken) != null ? d : null, this._characterId = t.characterId, this._characterVersion = (l = t.characterVersion) != null ? l : null, this._characterReference = t.characterReference;
    const i = t.enableVideo ? "video" : "audio";
    this._connectionType = i;
    const s = (u = t.transport) != null ? u : "livekit";
    this._activeTransport = s;
    const r = Ho(t);
    e.character_session_id && (this._characterSessionId = e.character_session_id, this.emit("characterSessionId", e.character_session_id), this._storedConfig = {
      ...this._storedConfig,
      characterSessionId: e.character_session_id
    });
    const o = (h = e.capabilities) != null ? h : {}, a = t.capabilities;
    if (zf(a == null ? void 0 : a.actionProtocolVersion, o.action_protocol_version), this._messageHandler.setModelOutputVersion(Kf(a == null ? void 0 : a.modelOutputVersion, o.model_output_version)), this._requestTraceId = (p = e.request_trace_id) != null ? p : null, this._roster.applyConnectResponse(e) && this.updateState({
      characters: this._roster.characters,
      activeMembershipId: this._roster.activeMembershipId
    }), e.end_user_id && (this._endUserId = e.end_user_id), e.end_user_metadata && (this._endUserMetadata = e.end_user_metadata), s === "websocket") {
      const P = e.room_url, R = P && lf(P, t.url);
      if (!R)
        throw new Error("No WebSocket URL returned from /connect endpoint (expected room_url)");
      if (!Bs)
        throw new Error("[ConvaiClient] WebSocket transport is not registered. Add `import '@convai/web-sdk/vanilla/websocket'` before calling connect().");
      this._wsSession = Bs((k) => this._messageHandler.handleDataReceivedPublic(k), !0), (v = (b = this._wsSession).setBotAudioMuted) == null || v.call(b, this._characterMuted);
      const g = t.enableVideo === !0 && (r == null ? void 0 : r.enabled) !== !1;
      g ? this._videoManager.setWebSocketVisionMessageSender((k, w) => {
        var D;
        this._activeTransport !== "websocket" || !((D = this._wsSession) != null && D.isConnected) || this._wsSession.sendMessage(k, w);
      }) : this._videoManager.setWebSocketVisionDisabled();
      const f = this._wsSession;
      f.on("botAudioTrack", (k) => {
        this._wsBotAudioTrack = k, this._applyCharacterMute(), this.emit("botAudioTrack", k);
      }), f.on("disconnected", () => {
        this._wsSession !== f || this._isDisconnecting || (this._connectionStateHandler.handleDisconnected(), this.clearAllManagers());
      }), this._audioManager.setWebSocketSession(this._wsSession), await new Promise((k, w) => {
        let D = !1;
        const A = () => {
          f.off("connected", N), f.off("error", L), f.off("disconnected", B);
        }, O = (Q) => {
          D || (D = !0, A(), Q());
        }, N = () => {
          O(k);
        }, L = (Q) => {
          O(() => {
            w(Q instanceof Error ? Q : new Error(String(Q)));
          });
        }, B = () => {
          O(() => {
            w(new Error("WebSocket disconnected before connect completed"));
          });
        };
        f.on("connected", N), f.on("error", L), f.on("disconnected", B), f.connectWithUrl(R).catch((Q) => {
          O(() => {
            w(Q instanceof Error ? Q : new Error(String(Q)));
          });
        });
      }), t.startWithAudioOn === !1 ? (this._wsSession.enableMic(!1), this._audioManager.syncWsAudioState(!1)) : this._audioManager.syncWsAudioState(!0), g && t.enableVideo && t.startWithVideoOn && await this._videoManager.enableVideo();
    } else
      this._videoManager.setWebSocketVisionMessageSender(null), await this._room.connect(e.room_url, e.token, {
        rtcConfig: {
          // Defaults to "relay" (TURN-only) for reliable NAT traversal
          // against Convai's hosted LiveKit. Set iceTransportPolicy: "all"
          // when pointing at a LiveKit without TURN (e.g. local dev).
          iceTransportPolicy: (C = t.iceTransportPolicy) != null ? C : "relay"
        }
      }), t.startWithAudioOn && await this._room.localParticipant.setMicrophoneEnabled(!0, {
        echoCancellation: this._audioSettings.echoCancellation,
        noiseSuppression: this._audioSettings.noiseSuppression,
        autoGainControl: this._audioSettings.autoGainControl,
        sampleRate: this._audioSettings.sampleRate,
        channelCount: this._audioSettings.channelCount
      }), t.enableVideo && t.startWithVideoOn && await this._room.localParticipant.setCameraEnabled(!0), this._audioManager.syncStateFromRoom({ emit: !0 }), this._participantSid = this._room.localParticipant.sid;
    (T = t.blendshapeConfig) != null && T.customMapper && this.blendshapeQueue.setMapper(t.blendshapeConfig.customMapper), this.updateState({
      isConnected: !0,
      isConnecting: !1,
      endUserId: this._endUserId,
      endUserMetadata: this._endUserMetadata
    }), this._endUserId && (this._apiKey ? this._memoryManager = new jo(
      this._apiKey,
      this._characterId,
      this._endUserId,
      void 0,
      // Use default base URL
      !1
    ) : this._authToken && (this._memoryManager = new jo(
      this._authToken,
      this._characterId,
      this._endUserId,
      void 0,
      // Use default base URL
      !0
    ))), this.emit("connect"), this._startClientReadyHandshake();
  }
  async cleanupWebSocketSessionAfterConnectFailure() {
    if (!(this._activeTransport !== "websocket" || !this._wsSession)) {
      this._isDisconnecting = !0;
      try {
        await this._wsSession.disconnect();
      } catch {
      } finally {
        this._isDisconnecting = !1;
      }
      this.clearAllManagers();
    }
  }
  /**
   * Connect to a published text-chat revision without publisher credentials.
   *
   * The launch grant is single-use and is never retained for reconnect. This
   * path is LiveKit data-only: it does not enable microphone, camera, TTS,
   * video, or lipsync.
   */
  async connectWithPublicationGrant(e, t = {}) {
    var c, d, l, u, h, p, b, v, C;
    if (typeof e != "string" || e.length < 32 || e.length > 512)
      throw new Error("A valid publication launch token is required");
    if (this._state.isConnected || this._state.isConnecting)
      throw new Error("Disconnect the current session before connecting again");
    const i = () => {
      var T;
      if ((T = t.signal) != null && T.aborted)
        throw new DOMException("The operation was aborted", "AbortError");
    };
    i();
    let s = null;
    const r = () => {
      s != null || (s = this.disconnect().catch(() => {
      }));
    }, o = ((c = t.url) != null ? c : "https://realtime-api.convai.com").replace(/\/+$/, ""), a = (d = t.connectAttemptId) != null ? d : typeof crypto != "undefined" && "randomUUID" in crypto ? `published_${crypto.randomUUID().replace(/-/g, "")}` : `published_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    if (!/^[a-zA-Z0-9_-]{1,128}$/.test(a))
      throw new Error("A valid published chat connect attempt id is required");
    this._storedConfig = null, this._isPublishedChatSession = !0, this._requestTraceId = null, this._apiKey = null, this._authToken = null, this._characterId = null, this._characterSessionId = "-1", this._endUserId = null, this._endUserMetadata = null, this._requestTraceId = null, this._memoryManager = null, this._connectionType = "text", this._activeTransport = "livekit", this._messageHandler.setModelOutputVersion(1), this.updateState({ isConnecting: !0 });
    try {
      (l = t.signal) == null || l.addEventListener("abort", r, {
        once: !0
      });
      const T = () => fetch(`${o}/published-chat/connect`, {
        method: "POST",
        // A published launch token is bearer-like. Never include any ambient
        // cookies when the host happens to be same-origin with Core.
        credentials: "omit",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          launch_token: e,
          connect_attempt_id: a
        }),
        signal: t.signal
      }), P = async (f, k) => {
        var D, A, O, N;
        if (!f.ok) {
          if (k && f.status >= 500)
            throw new Qi();
          const L = await f.text();
          let B = `HTTP ${f.status}`;
          try {
            const Q = JSON.parse(L);
            this._requestTraceId = (A = (D = Q.request_trace_id) != null ? D : Q.requestTraceId) != null ? A : null;
            const ae = (N = (O = Q.message) != null ? O : Q.error) != null ? N : Q.detail;
            B = typeof ae == "string" ? ae : ae == null ? B : JSON.stringify(ae);
          } catch {
            L && (B = `${B}: ${L}`);
          }
          throw new Error(B);
        }
        let w;
        try {
          w = await f.json();
        } catch {
          throw k ? new Qi() : new Error("Published chat returned an invalid connection response");
        }
        if (i(), typeof w != "object" || w === null || typeof w.room_url != "string" || typeof w.token != "string" || typeof w.character_session_id != "string")
          throw k ? new Qi() : new Error("Published chat returned an invalid connection response");
        return w;
      }, R = async (f) => {
        let k;
        try {
          k = await T();
        } catch (w) {
          throw i(), f ? new Qi() : w;
        }
        return P(k, f);
      };
      let g;
      try {
        g = await R(!0);
      } catch (f) {
        if (i(), !(f instanceof Qi))
          throw f;
        g = await R(!1);
      }
      i(), this._requestTraceId = (u = g.request_trace_id) != null ? u : null, this._characterSessionId = g.character_session_id, this._endUserId = (h = g.end_user_id) != null ? h : null, this._endUserMetadata = (p = g.end_user_metadata) != null ? p : null, await this._room.connect(g.room_url, g.token, {
        rtcConfig: {
          // Hosted Core has TURN, so relay is the safe default. On-prem
          // deployments without TURN may explicitly allow host/srflx paths.
          iceTransportPolicy: (b = t.iceTransportPolicy) != null ? b : "relay"
        }
      }), i(), this._audioManager.syncStateFromRoom({ emit: !0 }), this._participantSid = this._room.localParticipant.sid, this.updateState({
        isConnected: !0,
        isConnecting: !1,
        endUserId: this._endUserId,
        endUserMetadata: this._endUserMetadata
      }), this.emit("connect"), this._startClientReadyHandshake();
    } catch (T) {
      throw (v = t.signal) != null && v.aborted && (s != null || (s = this.disconnect().catch(() => {
      })), await s), this.updateState({ isConnected: !1, isConnecting: !1 }), this.emit("error", T), T;
    } finally {
      (C = t.signal) == null || C.removeEventListener("abort", r);
    }
  }
  /**
   * RTVI client-ready handshake. Server-side gates bot-ready emission on
   * receipt of client-ready (and re-emits bot-ready on every client-ready),
   * so we can retry until we hear bot-ready back. Closes the race where the
   * bot publishes bot-ready before the client data-channel is subscribed.
   */
  _startClientReadyHandshake() {
    if (this._activeTransport !== "livekit")
      return;
    this._stopClientReadyHandshake(), this._clientReadyMsgId = typeof crypto != "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `client-ready-${Date.now()}-${Math.random()}`;
    const e = () => {
      if (!this._isBotReady && !(!this._room || this._room.state !== "connected")) {
        try {
          const t = {
            id: this._clientReadyMsgId,
            label: "rtvi-ai",
            type: "client-ready",
            data: {
              version: "1.0.0",
              about: { library: "convai-web-sdk" }
            }
          }, i = new TextEncoder().encode(JSON.stringify(t));
          this._room.localParticipant.publishData(i, { reliable: !0 });
        } catch {
        }
        this._clientReadyRetryTimer = setTimeout(e, Ve.CLIENT_READY_RETRY_MS);
      }
    };
    e(), this._clientReadyTimeoutTimer = setTimeout(() => {
      if (this._isBotReady)
        return;
      this._stopClientReadyHandshake();
      const t = new Error(`bot-ready not received within ${Ve.CLIENT_READY_TIMEOUT_MS}ms`);
      this.emit("error", t);
    }, Ve.CLIENT_READY_TIMEOUT_MS);
  }
  _stopClientReadyHandshake() {
    this._clientReadyRetryTimer && (clearTimeout(this._clientReadyRetryTimer), this._clientReadyRetryTimer = null), this._clientReadyTimeoutTimer && (clearTimeout(this._clientReadyTimeoutTimer), this._clientReadyTimeoutTimer = null);
  }
  /**
   * Disconnect from the current character session
   */
  async disconnect() {
    if (this._stopClientReadyHandshake(), this._failPendingRosterCommands("Disconnected before the roster command was acknowledged; its outcome is unknown"), this._activeTransport === "sse" && this._sseSession)
      await this._sseSession.disconnect(), this._connectionStateHandler.resetConnectionState(), this.clearAllManagers();
    else if (this._activeTransport === "websocket" && this._wsSession) {
      this._isDisconnecting = !0;
      try {
        await this._wsSession.disconnect();
      } catch {
      } finally {
        this._isDisconnecting = !1;
      }
      this._wsSession = null, this._connectionStateHandler.handleDisconnected(cf.CLIENT_INITIATED), this.clearAllManagers();
    } else if (this._room && this._room.state !== "disconnected")
      try {
        await this._room.disconnect(), this._connectionStateHandler.resetConnectionState(), this.clearAllManagers();
      } catch {
        this._connectionStateHandler.resetConnectionState(), this.clearAllManagers();
      }
    else (this._state.isConnected || this._state.isConnecting) && (this._connectionStateHandler.resetConnectionState(), this.clearAllManagers());
  }
  /**
   * Clear all manager states
   */
  clearAllManagers() {
    this._connectionType = null, this._activeTransport = null, this._wsSession = null, this._wsBotAudioTrack = null, this._failPendingRosterCommands("Disconnected before the roster command was acknowledged; its outcome is unknown"), this._roster.reset(), this._sseSession = null, this._apiKey = null, this._authToken = null, this._characterId = null, this._characterVersion = null, this._characterReference = null, this._endUserId = null, this._endUserMetadata = null, this._memoryManager = null, this._audioManager.setWebSocketSession(null), this._audioManager.reset(), this._videoManager.setWebSocketVisionMessageSender(null), this._videoManager.reset(), this._screenShareManager.reset();
  }
  /**
   * Reconnect - disconnect and connect again using stored config
   */
  async reconnect() {
    if (!this._storedConfig)
      throw new Error("No stored config available for reconnection");
    await this.connect(this._storedConfig);
  }
  /**
   * Reset the session ID to start a new conversation
   */
  resetSession() {
    var e;
    if (this._roster.isMultiCharacter)
      throw new Error("resetSession() is not supported in a multi-character room; character sessions are server-owned");
    if (this._characterSessionId = "-1", ((e = this._storedConfig) == null ? void 0 : e.characterSessionId) !== void 0) {
      const { characterSessionId: t, ...i } = this._storedConfig;
      this._storedConfig = i;
    }
    this.emit("characterSessionId", "-1"), this._messageHandler.reset(), this.updateState({ metrics: [], disconnectReason: null });
  }
  /**
   * Send a text message to the character
   */
  sendUserTextMessage(e, t = {}) {
    var s, r, o, a, c, d, l, u;
    if (!this.isTransportReady() || !e || !e.trim())
      return;
    const i = t == null ? void 0 : t.logicalTurnId;
    if (i !== void 0 && !Ni(i))
      throw new Error("logicalTurnId must be non-empty and at most 128 UTF-8 bytes");
    try {
      (this.blendshapeQueue.isConversationActive() || this._state.isSpeaking || this.blendshapeQueue.hasBufferedFrames()) && this._messageHandler.interruptLipsyncPlayback(), this._conversationSessionId++, this._conversationStartTime = Date.now(), this.emit("conversationStart", {
        sessionId: this._conversationSessionId,
        userMessage: e.trim(),
        timestamp: this._conversationStartTime
      });
      const h = {
        text: e.trim(),
        participant_sid: this._participantSid || ((s = this._room.localParticipant) == null ? void 0 : s.sid)
      }, p = (r = js(t.stateOfMind)) != null ? r : null;
      if ((p || this._activeTransport === "sse" && t.stateOfMind === null) && (this._stateOfMind = p), this._activeTransport === "sse") {
        const b = (o = t.dynamicInfo) == null ? void 0 : o.trim();
        b && ((a = this._sseSession) == null || a.updateDynamicInfo(b));
        const v = [], C = (d = (c = this._sseSession) == null ? void 0 : c.getDynamicInfo()) == null ? void 0 : d.trim();
        C && v.push({
          type: "update-dynamic-info",
          data: { dynamic_info: { text: C } }
        }), p && v.push({ type: "update-emotion", data: { state_of_mind: p } }), v.push({
          type: "user_text_message",
          data: h,
          ...i !== void 0 ? { id: i } : {}
        }), (l = this._sseSession) == null || l.sendMessages(v);
      } else
        p && (this._pendingStateOfMindAcks.push(p), this.publishMessage("update-emotion", {
          state_of_mind: p,
          participant_sid: this._participantSid || ((u = this._room.localParticipant) == null ? void 0 : u.sid)
        })), this.publishMessage("user_text_message", h, i);
      this._messageHandler.addUserTextMessage(e);
    } catch (h) {
      throw h;
    }
  }
  /**
   * Return a correlated terminal result for a client-executed tool call.
   */
  sendActionResult(e) {
    const t = this.buildActionResultPayload(e);
    this.publishMessage("action-result", t);
  }
  /**
   * Publish one correlated terminal result and wait for Core's exact
   * `server-response` acknowledgement. This method performs one publication;
   * callers own any idempotent retry policy.
   */
  async sendActionResultAndWait(e, t = {}) {
    var a, c;
    const i = (a = t.timeoutMs) != null ? a : Ve.ACTION_RESULT_ACK_TIMEOUT_MS;
    if (!Number.isFinite(i) || i <= 0)
      throw new Error("Action result acknowledgement timeout must be greater than zero");
    if ((c = t.signal) != null && c.aborted)
      throw new Ti("Action result acknowledgement was aborted", {
        reason: "aborted",
        toolCallId: e.id
      });
    const s = this.buildActionResultPayload(e), r = s.id;
    if (this._pendingActionResultAcks.has(r))
      throw new Ti(`An action result acknowledgement is already pending for ${r}`, {
        reason: "duplicate_in_flight",
        toolCallId: r
      });
    const o = Symbol(r);
    return this._pendingActionResultAcks.set(r, o), new Promise((d, l) => {
      var R;
      let u = !1, h = null, p = null;
      const b = () => {
        var g;
        h !== null && (clearTimeout(h), h = null), p && (p(), p = null), (g = t.signal) == null || g.removeEventListener("abort", T), this._pendingActionResultAcks.get(r) === o && this._pendingActionResultAcks.delete(r);
      }, v = (g) => {
        u || (u = !0, b(), d(g));
      }, C = (g) => {
        u || (u = !0, b(), l(g));
      }, T = () => {
        C(new Ti("Action result acknowledgement was aborted", {
          reason: "aborted",
          toolCallId: r
        }));
      }, P = (g) => {
        var A;
        if (!g || typeof g != "object")
          return;
        const f = g;
        if (f.event_type !== "action-result")
          return;
        const k = f.extras;
        if (!k || k.tool_call_id !== r)
          return;
        const w = typeof f.message == "string" ? f.message : null;
        if (f.status === "success") {
          v({
            toolCallId: r,
            status: "success",
            message: w,
            idempotent: k.idempotent === !0
          });
          return;
        }
        if (f.status !== "error")
          return;
        const D = typeof k.error_code == "string" ? k.error_code : void 0;
        C(new Ti((A = w != null ? w : D) != null ? A : "Core rejected the action result", {
          reason: "server_error",
          toolCallId: r,
          ...D ? { errorCode: D } : {},
          response: f
        }));
      };
      p = this.on("serverResponse", P), (R = t.signal) == null || R.addEventListener("abort", T, { once: !0 }), h = setTimeout(() => {
        C(new Ti(`Timed out waiting for action result acknowledgement for ${r}`, {
          reason: "timeout",
          toolCallId: r
        }));
      }, i), this.publishMessageAndWaitForLocalPublication("action-result", s).catch((g) => {
        const f = g instanceof Error ? `: ${g.message}` : "";
        C(new Ti(`Failed to publish action result ${r}${f}`, {
          reason: "publication_error",
          toolCallId: r,
          cause: g
        }));
      });
    });
  }
  buildActionResultPayload(e) {
    var i;
    if (!this.isTransportReady())
      throw new Error("Cannot send an action result before the session is ready");
    if (!e.id.trim())
      throw new Error("Action result id is required");
    if (e.status !== "completed" && e.status !== "error" && e.status !== "cancelled")
      throw new Error("Unsupported action result status");
    if (e.status === "completed" && e.error !== void 0)
      throw new Error("Completed action results cannot include error");
    if (e.output !== void 0 && !pn(e.output))
      throw new Error("Action result output must contain only finite JSON values");
    if (e.error !== void 0 && !pn(e.error))
      throw new Error("Action result error must contain only finite JSON values");
    const t = (i = e.characterSessionId) != null ? i : this._characterSessionId;
    return {
      id: e.id,
      status: e.status,
      ...e.output !== void 0 && { output: e.output },
      ...e.error !== void 0 && { error: e.error },
      ...t && t !== "-1" && {
        character_session_id: t
      }
    };
  }
  /**
   * Send a trigger message to invoke specific character actions
   */
  sendTriggerMessage(e, t) {
    var i;
    this.isTransportReady() && ((this.blendshapeQueue.isConversationActive() || this._state.isSpeaking || this.blendshapeQueue.hasBufferedFrames()) && this._messageHandler.interruptLipsyncPlayback(), this._conversationSessionId++, this._conversationStartTime = Date.now(), this.emit("conversationStart", {
      sessionId: this._conversationSessionId,
      userMessage: `[trigger:${e != null ? e : ""}]`,
      timestamp: this._conversationStartTime
    }), this.publishMessage("trigger-message", {
      ...e && { trigger_name: e },
      ...t && { trigger_message: t },
      participant_sid: this._participantSid || ((i = this._room.localParticipant) == null ? void 0 : i.sid)
    }));
  }
  /**
   * If the bot is currently speaking or a conversation is active, send an
   * interrupt to the server and end the blendshape conversation so the queue
   * is clean before a new response starts arriving.
   */
  endCurrentConversationIfActive() {
    var i;
    const e = this.blendshapeQueue.isConversationActive() || this.blendshapeQueue.hasBufferedFrames(), t = this._state.isSpeaking;
    !e && !t || (this.isTransportReady() && this.publishMessage("interrupt-bot", {
      participant_sid: this._participantSid || ((i = this._room.localParticipant) == null ? void 0 : i.sid)
    }), this._messageHandler.interruptLipsyncPlayback());
  }
  startTrackedConversation(e) {
    (this.blendshapeQueue.isConversationActive() || this._state.isSpeaking || this.blendshapeQueue.hasBufferedFrames()) && this._messageHandler.interruptLipsyncPlayback(), this._conversationSessionId++, this._conversationStartTime = Date.now(), this.emit("conversationStart", {
      sessionId: this._conversationSessionId,
      userMessage: e,
      timestamp: this._conversationStartTime
    });
  }
  /**
   * Send an interrupt message to stop the bot's current response
   */
  sendInterruptMessage() {
    var e, t;
    if (this.isTransportReady())
      try {
        this._activeTransport === "sse" && ((e = this._sseSession) != null && e.isConnected) ? (this._sseSession.interrupt(), this._messageHandler.finalizeInterruptedResponse(!0)) : this.publishMessage("interrupt-bot", {
          participant_sid: this._participantSid || ((t = this._room.localParticipant) == null ? void 0 : t.sid)
        }), (this.blendshapeQueue.isConversationActive() || this._state.isSpeaking || this.blendshapeQueue.hasBufferedFrames()) && this._messageHandler.interruptLipsyncPlayback();
      } catch (i) {
        throw i;
      }
  }
  /**
   * Replace the Narrative Design template keys on the live session.
   * Same key map as the `narrativeTemplateKeys` config option; full replace,
   * not a merge. Requires Narrative Design enabled on the character.
   */
  updateTemplateKeys(e) {
    var t;
    Object.keys(e).length !== 0 && (this._storedConfig && (this._storedConfig = { ...this._storedConfig, narrativeTemplateKeys: { ...e } }), this.isTransportReady() && this.publishMessage("update-template-keys", {
      template_keys: e,
      participant_sid: this._participantSid || ((t = this._room.localParticipant) == null ? void 0 : t.sid)
    }));
  }
  /**
   * Update dynamic information about the current context
   */
  updateDynamicInfo(e) {
    var i;
    if (!this.isTransportReady() || !(e != null && e.trim()))
      return;
    const t = e.trim();
    if (this._storedConfig && (this._storedConfig = { ...this._storedConfig, dynamicInfo: t }), this._activeTransport === "sse" && this._sseSession) {
      this._sseSession.updateDynamicInfo(t);
      return;
    }
    this.publishMessage("update-dynamic-info", {
      dynamic_info: { text: t },
      participant_sid: this._participantSid || ((i = this._room.localParticipant) == null ? void 0 : i.sid)
    });
  }
  /**
   * Update the bot's temporary runtime context in a unified way.
   * Provides flexible control over ephemeral context management.
   *
   * @param options - Context update configuration
   *
   * @example
   * ```typescript
   * // Append to existing context
   * client.updateContext({
   *   text: "User completed dragon quest",
   *   mode: "append",
   *   run_llm: "false"
   * });
   *
   * // Replace entire context
   * client.updateContext({
   *   text: "New game state: level 5",
   *   mode: "replace",
   *   run_llm: "auto"
   * });
   *
   * // Clear context
   * client.updateContext({ mode: "reset" });
   * ```
   */
  updateContext(e) {
    var r, o, a;
    if (!this.isTransportReady())
      return;
    const t = !!((r = e.text) != null && r.trim()), i = e.current_attention_object !== void 0;
    if (e.mode !== "reset" && !t && !i) {
      console.warn("[ConvaiClient] updateContext: text or current_attention_object is required unless mode is 'reset'");
      return;
    }
    if (Jf(e) && this.startTrackedConversation(`[context-update:${(o = e.mode) != null ? o : "append"}]`), this._activeTransport === "sse" && this._sseSession) {
      const c = {
        ...t && { text: e.text.trim() },
        ...e.mode && { mode: e.mode },
        ...e.run_llm && { run_llm: e.run_llm },
        ...e.respond_mode && { respond_mode: e.respond_mode },
        ...i && { current_attention_object: e.current_attention_object }
      };
      e.run_llm === "false" ? this._sseSession.queueMessage("context-update", c) : this._sseSession.sendMessage("context-update", c);
      return;
    }
    this.publishMessage("context-update", {
      ...t && { text: e.text.trim() },
      ...e.mode && { mode: e.mode },
      ...e.run_llm && { run_llm: e.run_llm },
      ...e.respond_mode && { respond_mode: e.respond_mode },
      ...i && { current_attention_object: e.current_attention_object },
      participant_sid: this._participantSid || ((a = this._room.localParticipant) == null ? void 0 : a.sid)
    });
  }
  visionStatus(e = {}) {
    var i, s;
    if (!this.isTransportReady())
      return null;
    const t = (i = e.updateId) != null ? i : this.createUpdateId("vision-status");
    return this.publishMessage("vision-status", {
      update_id: t,
      participant_sid: this._participantSid || ((s = this._room.localParticipant) == null ? void 0 : s.sid)
    }), t;
  }
  visionTrigger(e = {}) {
    var s, r;
    if (!this.isTransportReady())
      return null;
    const t = (s = e.updateId) != null ? s : this.createUpdateId("vision-trigger"), i = e.respondMode;
    return qo(i) && this.startTrackedConversation(`[vision-trigger:${i}]`), this.publishMessage("vision-trigger", {
      update_id: t,
      ...e.text && { text: e.text },
      ...i && { respond_mode: i },
      ...e.frameIndices && { frame_indices: e.frameIndices },
      ...e.frameIds && { frame_ids: e.frameIds },
      participant_sid: this._participantSid || ((r = this._room.localParticipant) == null ? void 0 : r.sid)
    }), t;
  }
  respondModeUpdate(e) {
    var i, s;
    if (!this.isTransportReady())
      return null;
    this.rememberRespondMode(e.modality, e.mode);
    const t = (i = e.updateId) != null ? i : this.createUpdateId("respond-mode");
    return this.publishMessage("respond-mode-update", {
      update_id: t,
      modality: e.modality,
      mode: e.mode,
      participant_sid: this._participantSid || ((s = this._room.localParticipant) == null ? void 0 : s.sid)
    }), t;
  }
  /**
   * Set or clear the character's temporary state of mind.
   * This is silent: it affects the next response and does not trigger one.
   */
  updateEmotion(e) {
    var i, s;
    const t = (i = js(e)) != null ? i : null;
    this._stateOfMind = t, this._storedConfig && (this._storedConfig = { ...this._storedConfig, stateOfMind: t }), this.isTransportReady() && this._activeTransport !== "sse" && (this._pendingStateOfMindAcks.push(t), this.publishMessage("update-emotion", {
      state_of_mind: t,
      participant_sid: this._participantSid || ((s = this._room.localParticipant) == null ? void 0 : s.sid)
    }));
  }
  /**
   * Send descriptive scene updates. Use when environment description changes
   * and the bot should know what is visible or nearby. Does not modify action_config.
   */
  updateSceneMetadata(e, t = {}) {
    this.isTransportReady() && (qo(t.respondMode) && this.startTrackedConversation(`[scene-metadata:${t.respondMode}]`), this.publishMessage("update-scene-metadata", {
      scene_metadata: e,
      ...t.respondMode && { respond_mode: t.respondMode }
    }));
  }
  /**
   * Mirror a runtime respond-mode change into the stored config, so
   * reconnect() — which replays _storedConfig — does not revert it. text and
   * audio are typed `"must_respond"` only in the config, so other values for
   * them stay runtime-only rather than widening that type.
   */
  rememberRespondMode(e, t) {
    if (!this._storedConfig)
      return;
    const i = {
      text: "text",
      audio: "audio",
      vision: "vision",
      context_update: "contextUpdate",
      trigger: "trigger",
      scene_metadata: "sceneMetadata"
    }[e];
    (i === "text" || i === "audio") && t !== "must_respond" || (this._storedConfig = {
      ...this._storedConfig,
      respondModes: { ...this._storedConfig.respondModes, [i]: t }
    });
  }
  createUpdateId(e) {
    return typeof crypto != "undefined" && "randomUUID" in crypto ? `${e}:${crypto.randomUUID()}` : `${e}:${Date.now()}:${Math.random().toString(36).slice(2)}`;
  }
  serializeRespondModes(e) {
    return {
      ...e.text !== void 0 && { text: e.text },
      ...e.audio !== void 0 && { audio: e.audio },
      ...e.vision !== void 0 && { vision: e.vision },
      ...e.contextUpdate !== void 0 && {
        context_update: e.contextUpdate
      },
      ...e.trigger !== void 0 && { trigger: e.trigger },
      ...e.sceneMetadata !== void 0 && {
        scene_metadata: e.sceneMetadata
      }
    };
  }
  /**
   * Upload a file to the character via the LiveKit byte stream transport.
   * Only works when connected with the LiveKit transport.
   *
   * @throws if not connected or if the LiveKit room is unavailable
   */
  async uploadFile(e, t = {}) {
    var r;
    if (!((r = this._room) != null && r.localParticipant))
      throw new Error("[ConvaiClient] uploadFile: not connected to a LiveKit room");
    const { topic: i = "file-upload", onProgress: s } = t;
    await this._room.localParticipant.sendFile(e, {
      topic: i,
      mimeType: e.type,
      ...s && {
        onProgress: (o) => s(Math.ceil(o * 100))
      }
    });
  }
  /**
   * Toggle text-to-speech on or off
   */
  toggleTts(e) {
    if (this.isTransportReady()) {
      if (this._storedConfig && (this._storedConfig = { ...this._storedConfig, ttsEnabled: e }), this._activeTransport === "sse" && this._sseSession) {
        this._sseSession.setTtsEnabled(e);
        return;
      }
      this.publishMessage("tts-toggle", { enabled: e });
    }
  }
  /**
   * Toggle speech-to-text on or off
   */
  toggleStt(e) {
    this.isTransportReady() && this.publishMessage("stt-toggle", { muted: !e });
  }
  /**
   * Reset the server-side idle timer.
   * Call this on any user activity (clicks, UI interactions, etc.) to prevent
   * the session from being disconnected due to inactivity.
   */
  resetIdleTimer() {
    var e;
    this._activeTransport !== "sse" && this.isTransportReady() && this.publishMessage("reset-idle-timer", {
      participant_sid: this._participantSid || ((e = this._room.localParticipant) == null ? void 0 : e.sid)
    });
  }
}
Ve.TURN_END_SETTLE_MS = 150;
Ve.CLIENT_READY_RETRY_MS = 500;
Ve.CLIENT_READY_TIMEOUT_MS = 45e3;
Ve.ACTION_RESULT_ACK_TIMEOUT_MS = 1e4;
Ve.ROSTER_COMMAND_TIMEOUT_MS = 1e4;
Ve.ROSTER_RETRY_ATTEMPTS = 4;
Ve.ROSTER_RETRY_INITIAL_MS = 500;
const rg = "https://api.convai.com", ag = "Convi";
function og(n) {
  var s, r, o, a, c;
  const e = n != null ? n : {}, t = (d) => typeof d == "string" && d.length > 0 ? d : null, i = e.model_details;
  return {
    name: (s = t(e.character_name)) != null ? s : ag,
    image: (c = (a = t((r = i == null ? void 0 : i.METAHUMAN) == null ? void 0 : r.avatar_image_square)) != null ? a : t((o = i == null ? void 0 : i.METAHUMAN) == null ? void 0 : o.avatar_image)) != null ? c : t(i == null ? void 0 : i.modelPlaceholder)
  };
}
async function cg(n) {
  const { characterId: e, apiKey: t, authToken: i, baseUrl: s, signal: r } = n, o = {
    "Content-Type": "application/json"
  };
  i ? o["API-AUTH-TOKEN"] = i : t && (o["CONVAI-API-KEY"] = t);
  const a = (s || rg).replace(/\/+$/, ""), c = await fetch(`${a}/character/get`, {
    method: "POST",
    headers: o,
    body: JSON.stringify({ charID: e }),
    signal: r
  });
  if (!c.ok)
    throw new Error(`Failed to fetch character info: ${c.status}`);
  return og(await c.json());
}
const dg = /\.(png|jpe?g|gif|webp|avif)$/i, lg = /\.(mp4|webm|mov|ogg)$/i;
function qs(n) {
  let e;
  try {
    e = new URL(n).pathname;
  } catch {
    return null;
  }
  return dg.test(e) ? "image" : lg.test(e) ? "video" : null;
}
const ol = ["http", "https", "ftp", "ftps", "mailto", "tel", "sms"], ug = ["http", "https", "ftp", "ftps"], hg = ol.join("|"), pg = ug.join("|");
function cl(n, e = 44) {
  if (n.length <= e)
    return n;
  let t, i;
  try {
    ({ host: t, pathname: i } = new URL(n));
  } catch {
    return `${n.slice(0, e - 1)}…`;
  }
  const s = i.split("/").filter(Boolean).pop();
  if (!s)
    return t.length <= e ? t : `${t.slice(0, e - 1)}…`;
  const r = `${t}/…/${s}`;
  return r.length <= e ? r : s.length <= e ? s : `…${s.slice(-(e - 1))}`;
}
function mg(n) {
  var t;
  const e = (t = /^([a-z][a-z0-9+.-]*):/i.exec(n)) == null ? void 0 : t[1];
  return e !== void 0 && ol.includes(e.toLowerCase());
}
const zo = new RegExp([
  // The target allows one level of balanced parens, so `javascript:alert(1)`
  // and `…/a_(b).pdf` are consumed whole. Without it the inner `)` ended the
  // match and the outer one was left stranded in the text.
  '(!?)\\[([^\\]]*)\\]\\(\\s*((?:[^\\s()]|\\([^()]*\\))+)(?:\\s+"[^"]*")?\\s*\\)',
  `<((?:${hg}):[^\\s<>]+)>`,
  `(?<!\\]\\()((?:${pg}):\\/\\/[^\\s<>"'\`]+|(?:mailto|tel|sms):[^\\s<>"'\`]+)`,
  "(\\*\\*|__)(.*?)\\6",
  "\\*([^*]+)\\*",
  "_([^_]+)_"
].join("|"), "gi"), fg = `.,;:!?'"`;
function gg(n) {
  var t, i;
  let e = n;
  for (; e.length > 0; ) {
    const s = e[e.length - 1];
    if (fg.includes(s)) {
      e = e.slice(0, -1);
      continue;
    }
    if (s === ")") {
      const r = ((t = e.match(/\(/g)) != null ? t : []).length;
      if (((i = e.match(/\)/g)) != null ? i : []).length > r) {
        e = e.slice(0, -1);
        continue;
      }
    }
    break;
  }
  return [e, n.slice(e.length)];
}
function vg(n) {
  const e = [], t = (r) => {
    if (!r)
      return;
    const o = e[e.length - 1];
    (o == null ? void 0 : o.kind) === "text" ? o.text += r : e.push({ kind: "text", text: r });
  };
  let i = 0;
  zo.lastIndex = 0;
  let s;
  for (; (s = zo.exec(n)) !== null; ) {
    t(n.slice(i, s.index));
    const [, r, o, a, c, d, , l, u, h] = s;
    if (a !== void 0)
      mg(a) ? r ? e.push({ kind: "image", src: a, alt: o }) : e.push({ kind: "link", href: a, label: o, media: qs(a) }) : e.push({ kind: "blocked", href: a, label: r ? o || a : o });
    else if (c !== void 0)
      e.push({ kind: "link", href: c, label: c, media: qs(c) });
    else if (d !== void 0) {
      const [p, b] = gg(d);
      p && e.push({ kind: "link", href: p, label: p, media: qs(p) }), t(b);
    } else l !== void 0 ? e.push({ kind: "strong", text: l }) : u !== void 0 ? e.push({ kind: "em", text: u }) : h !== void 0 && e.push({ kind: "em", text: h });
    i = s.index + s[0].length;
  }
  return t(n.slice(i)), e;
}
const bg = /\.(png|jpe?g|gif|webp|avif)$/i, yg = /\.(mp4|webm|mov|ogg)$/i, Sg = /\.(pdf|docx?|xlsx?|csv|pptx?|txt|md|zip)$/i;
function kg(n) {
  var i, s;
  const e = (s = (i = /^([a-z][a-z0-9+.-]*):/i.exec(n)) == null ? void 0 : i[1]) == null ? void 0 : s.toLowerCase();
  if (e === "mailto")
    return "email";
  if (e === "tel")
    return "phone";
  if (e === "sms")
    return "sms";
  if (e === "ftp" || e === "ftps")
    return "ftp";
  let t;
  try {
    t = new URL(n).pathname;
  } catch {
    return "web";
  }
  return bg.test(t) ? "image" : yg.test(t) ? "video" : Sg.test(t) ? "document" : "web";
}
function Hs(n) {
  try {
    const { host: e, pathname: t } = new URL(n), i = t.split("/").filter(Boolean).pop();
    return i ? `${e} · ${i}` : e;
  } catch {
    return cl(n);
  }
}
function _r(n) {
  var e;
  try {
    return (e = new URL(n).pathname.split("/").filter(Boolean).pop()) != null ? e : n;
  } catch {
    return n;
  }
}
function Tg(n) {
  var t;
  const e = (t = /\.([a-z0-9]{1,5})$/i.exec(_r(n))) == null ? void 0 : t[1];
  return e ? e.toUpperCase() : "FILE";
}
function Fn(n) {
  return n.replace(/^[a-z][a-z0-9+.-]*:/i, "").split("?")[0];
}
function Ko(n, e, t) {
  switch (n) {
    case "email":
      return `Send an email to ${Fn(e)}`;
    case "phone":
      return `Call ${Fn(e)}`;
    case "sms":
      return `Send a text to ${Fn(e)}`;
    case "ftp":
      return "FTP link — most browsers no longer open these";
    default:
      return t === e ? void 0 : e;
  }
}
function Cg(n, e = typeof location == "undefined" ? "https:" : location.protocol) {
  return e === "https:" && /^http:/i.test(n);
}
const _g = 8e3, wg = 200;
function Eg(n) {
  return !!n && (!!n.title || !!n.image);
}
function wr(n) {
  if (n)
    try {
      const e = new URL(n);
      return e.protocol === "http:" || e.protocol === "https:" ? e.href : void 0;
    } catch {
      return;
    }
}
function Rg(n, e) {
  if (n.siteName)
    return n.siteName;
  try {
    return new URL(e).hostname.replace(/^www\./, "");
  } catch {
    return e;
  }
}
function Ig(n, e) {
  const t = wr(n.favicon);
  if (t)
    return t;
  try {
    return `${new URL(e).origin}/favicon.ico`;
  } catch {
    return;
  }
}
const Xi = /* @__PURE__ */ new Map();
function Pg(n, e) {
  const t = Xi.get(e);
  if (t)
    return t;
  const i = new AbortController(), s = setTimeout(() => i.abort(), _g), r = Promise.resolve().then(() => n(e, i.signal)).then((o) => o ? { ...o, image: wr(o.image), favicon: wr(o.favicon) } : null).catch(() => null).finally(() => clearTimeout(s));
  if (Xi.size >= wg) {
    const o = Xi.keys().next().value;
    o !== void 0 && Xi.delete(o);
  }
  return Xi.set(e, r), r;
}
class Go {
  constructor(e, t) {
    var i;
    this.audioElements = /* @__PURE__ */ new Map(), this.livekitTracks = /* @__PURE__ */ new Map(), this._wsAudioElement = null, this.room = e, this.rendererId = `renderer-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`, this.boundHandleTrackSubscribed = this.handleTrackSubscribed.bind(this), this.boundHandleTrackUnsubscribed = this.handleTrackUnsubscribed.bind(this), this.boundHandleParticipantDisconnected = this.handleParticipantDisconnected.bind(this), this.container = document.createElement("div"), this.container.id = `convai-audio-renderer-${this.rendererId}`, this.container.style.display = "none", ((i = t == null ? void 0 : t.container) != null ? i : document.body).appendChild(this.container), this.setupEventListeners(), this.attachExistingTracks();
  }
  /**
   * Setup event listeners for room events
   */
  setupEventListeners() {
    this.room.on(x.TrackSubscribed, this.boundHandleTrackSubscribed), this.room.on(x.TrackUnsubscribed, this.boundHandleTrackUnsubscribed), this.room.on(x.ParticipantDisconnected, this.boundHandleParticipantDisconnected);
  }
  /**
   * Attach audio elements for existing tracks (if any)
   */
  attachExistingTracks() {
    this.room.remoteParticipants.forEach((e) => {
      e.audioTrackPublications.forEach((t) => {
        t.track && t.isSubscribed && this.attachAudioTrack(t, e);
      });
    });
  }
  /**
   * Handle track subscribed event
   */
  handleTrackSubscribed(e, t, i) {
    e.kind === "audio" && this.attachAudioTrack(t, i);
  }
  /**
   * Handle track unsubscribed event
   */
  handleTrackUnsubscribed(e, t, i) {
    e.kind === "audio" && this.detachAudioTrack(t.trackSid);
  }
  /**
   * Handle participant disconnected event
   */
  handleParticipantDisconnected(e) {
    e.audioTrackPublications.forEach((t) => {
      this.detachAudioTrack(t.trackSid);
    });
  }
  /**
   * Attach an audio track to an audio element
   */
  attachAudioTrack(e, t) {
    const i = e.track;
    if (!i || i.kind !== "audio")
      return;
    const s = e.trackSid;
    if (!this.audioElements.has(s))
      try {
        const r = document.createElement("audio");
        r.id = `audio-${s}`, r.dataset.participantIdentity = t.identity, t.identity.startsWith("character:") && (r.dataset.membershipId = t.identity.slice(10)), r.autoplay = !0, i.attach(r), this.container.appendChild(r), this.audioElements.set(s, r), this.livekitTracks.set(s, i);
      } catch (r) {
        Pi.error("Failed to attach audio track:", r);
      }
  }
  /**
   * Detach an audio track and remove its element
   */
  detachAudioTrack(e) {
    const t = this.audioElements.get(e);
    if (t) {
      const i = this.livekitTracks.get(e);
      i && (i.detach(t), this.livekitTracks.delete(e)), t.pause(), t.srcObject = null, t.remove();
    }
    this.audioElements.delete(e);
  }
  /**
   * Attach a MediaStreamTrack from WebSocket transport for bot audio playback.
   */
  attachWebSocketTrack(e) {
    this.detachWebSocketTrack();
    const t = document.createElement("audio");
    t.autoplay = !0, t.srcObject = new MediaStream([e]), this.container.appendChild(t), this._wsAudioElement = t;
  }
  detachWebSocketTrack() {
    this._wsAudioElement && (this._wsAudioElement.pause(), this._wsAudioElement.srcObject = null, this._wsAudioElement.remove(), this._wsAudioElement = null);
  }
  /**
   * Cleanup and destroy the audio renderer
   */
  destroy() {
    this.detachWebSocketTrack(), this.audioElements.forEach((e, t) => {
      this.detachAudioTrack(t);
    }), this.audioElements.clear(), this.container && this.container.parentElement && this.container.remove(), this.room.off(x.TrackSubscribed, this.boundHandleTrackSubscribed), this.room.off(x.TrackUnsubscribed, this.boundHandleTrackUnsubscribed), this.room.off(x.ParticipantDisconnected, this.boundHandleParticipantDisconnected);
  }
}
function xg(n) {
  if (!n)
    return;
  const { connectAttemptId: e, ...t } = n;
  return t;
}
const q = {
  colors: {
    convai: {
      light: "#1EB453",
      dark: "#084c3a"
    },
    neutral: {
      100: "#f5f5f5",
      200: "#e5e5e5",
      300: "#d4d4d4",
      400: "#a3a3a3",
      700: "#404040"
    },
    glass: {
      medium: "rgba(255, 255, 255, 0.15)",
      backdrop: "rgba(255, 255, 255, 0.8)"
    },
    error: {
      500: "#ef4444"
    },
    text: {
      primary: "#1f2937",
      secondary: "#6b7280"
    }
  },
  typography: {
    fontFamily: {
      primary: '"Noto Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      body: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    },
    fontSize: {
      sm: "14px",
      base: "16px"
    },
    fontWeight: {
      semibold: 600
    }
  },
  spacing: {
    xs: "4px"
  },
  borderRadius: {
    md: "8px",
    lg: "12px",
    xl: "16px",
    full: "9999px"
  },
  shadows: {
    xl: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
    glass: "0 8px 32px rgba(0, 0, 0, 0.1)"
  },
  glass: {
    backdrop: "blur(20px)",
    border: "1px solid rgba(255, 255, 255, 0.2)"
  },
  transitions: {
    fast: "0.15s ease-in-out"
  },
  zIndex: {
    modal: 1040
  }
}, Mg = () => `
  @keyframes convai-pulse {
    0%, 100% {
      opacity: 1;
    }
    50% {
      opacity: 0.5;
    }
  }

  @keyframes convai-spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }

  @keyframes convai-bounce {
    0%, 100% {
      transform: translateY(0);
    }
    50% {
      transform: translateY(-10px);
    }
  }

  @keyframes convai-slide-up {
    from {
      transform: translateY(20px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }

  @keyframes convai-slide-down {
    from {
      transform: translateY(-20px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }

  @keyframes convai-fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @keyframes convai-scale-in {
    from {
      transform: scale(0.8);
      opacity: 0;
    }
    to {
      transform: scale(1);
      opacity: 1;
    }
  }

  .convai-widget * {
    box-sizing: border-box;
  }

  .convai-widget {
    font-family: var(--convai-font, ${q.typography.fontFamily.primary});
    color: var(--convai-panel-fg, ${q.colors.text.primary});
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  .convai-widget button {
    font-family: inherit;
    cursor: pointer;
    border: none;
    outline: none;
    background: none;
    padding: 0;
    margin: 0;
  }

  .convai-widget input {
    font-family: inherit;
    border: none;
    outline: none;
    background: none;
  }

  .convai-widget::-webkit-scrollbar {
    width: 6px;
  }

  .convai-widget::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.05);
    border-radius: 3px;
  }

  .convai-widget::-webkit-scrollbar-thumb {
    background: rgba(0, 0, 0, 0.2);
    border-radius: 3px;
  }

  .convai-widget::-webkit-scrollbar-thumb:hover {
    background: rgba(0, 0, 0, 0.3);
  }
`, Jo = "convai-widget-styles", Yo = "convai-widget-keyframes", Ws = /* @__PURE__ */ new WeakSet(), $s = /* @__PURE__ */ new WeakSet(), ta = (n) => n instanceof ShadowRoot ? n : n.head, dl = (n, e) => ta(n).querySelector(`#${e}`) !== null, Ag = `
  @keyframes popIn {
    from { opacity: 0; transform: scale(0.95) translateY(-10px); }
    to { opacity: 1; transform: scale(1) translateY(0); }
  }

  /* Link-preview skeleton: one sweep across the placeholder while the media
   * decodes. Lives here rather than in getGlobalStyles() because that string is
   * pinned byte-for-byte by the inline-style parity fixture, and this is an
   * addition no existing element uses. */
  @keyframes convai-preview-shimmer {
    from { background-position: 200% 0; }
    to { background-position: -200% 0; }
  }

  /* Image lightbox entrance. Additive, like the shimmer above. */
  @keyframes convai-lightbox-in {
    from { opacity: 0; transform: scale(.98); }
    to { opacity: 1; transform: scale(1); }
  }

  /* Connecting overlay: logo spin + label pulse. Values match the React
   * widget's framer-motion transitions (ConvaiWidget.tsx:681-737) exactly --
   * a full turn every 2s linear, and opacity 0.5 -> 1 -> 0.5 every 2s
   * ease-in-out. React does not honour prefers-reduced-motion; vanilla does,
   * via the media query below, since a full-turn infinite spin plus a
   * pulsing label is exactly what that setting exists for. */
  @keyframes convaiConnectingSpin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }

  @keyframes convaiConnectingPulse {
    0%, 100% { opacity: 0.5; }
    50% { opacity: 1; }
  }

  /* Voice mode's avatar: two counter-rotating liquid-gradient layers behind
   * the character image. Matches the React overlay's framer-motion values
   * (VoiceModeOverlay.tsx) — 20s clockwise for the conic layer, 15s
   * anticlockwise for the radial one, both linear and infinite — and the
   * gentle scale breathing it applies while the character is speaking. */
  @keyframes convaiVoiceSpin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }

  @keyframes convaiVoiceSpinReverse {
    from { transform: rotate(360deg); }
    to { transform: rotate(0deg); }
  }

  @keyframes convaiVoiceBreathe {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
  }

  @media (prefers-reduced-motion: reduce) {
    .convai-connecting-spin {
      animation: none !important;
    }
    .convai-connecting-pulse {
      animation: none !important;
    }
    .convai-voice-gradient,
    .convai-voice-avatar {
      animation: none !important;
    }
    [data-convai-skeleton] {
      animation: none !important;
    }
    [part~="lightbox-backdrop"] {
      animation: none !important;
    }
  }
`, Og = (n = document) => {
  if (Ws.has(n)) return;
  if (dl(n, Jo)) {
    Ws.add(n);
    return;
  }
  const e = document.createElement("style");
  e.id = Jo, e.textContent = Mg(), ta(n).appendChild(e), Ws.add(n);
}, Vn = (n = document) => {
  if ($s.has(n)) return;
  if (dl(n, Yo)) {
    $s.add(n);
    return;
  }
  const e = document.createElement("style");
  e.id = Yo, e.textContent = Ag, ta(n).appendChild(e), $s.add(n);
}, ll = {
  xs: "12px",
  sm: "16px",
  md: "20px",
  lg: "24px",
  xl: "32px",
  "2xl": "40px"
}, Dg = {
  idle: "#1EB453",
  connecting: "#f59e0b",
  connected: "#1EB453",
  disconnected: "#ef4444",
  typing: "#8b5cf6",
  listening: "#3b82f6",
  processing: "#6366f1"
};
function ct(n, e, t, i) {
  const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"), r = ll[n];
  return s.setAttribute("width", r), s.setAttribute("height", r), s.setAttribute("viewBox", e), s.setAttribute("fill", "none"), s.setAttribute("stroke", "currentColor"), s.setAttribute("stroke-width", "2"), s.setAttribute("stroke-linecap", "round"), s.setAttribute("stroke-linejoin", "round"), i && (s.className.baseVal = i), t.forEach((o) => {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "path");
    a.setAttribute("d", o), s.appendChild(a);
  }), s;
}
function Zi(n, e, t, i) {
  const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"), r = ll[n];
  return s.setAttribute("width", r), s.setAttribute("height", r), s.setAttribute("viewBox", e), s.setAttribute("fill", "currentColor"), i && (s.className.baseVal = i), t.forEach((o) => {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "path");
    a.setAttribute("d", o.d), o.fill && a.setAttribute("fill", o.fill), o.transform && a.setAttribute("transform", o.transform), o.stroke && a.setAttribute("stroke", o.stroke), o.strokeWidth && a.setAttribute("stroke-width", o.strokeWidth), o.strokeLinecap && a.setAttribute("stroke-linecap", o.strokeLinecap), o.strokeMiterlimit && a.setAttribute("stroke-miterlimit", o.strokeMiterlimit), s.appendChild(a);
  }), s;
}
const Ce = {
  // Convai Logo - exact copy from React example
  ConvaiLogo: (n = "md", e = "idle", t) => Zi(
    n,
    "0 0 384 384",
    [
      // First strip - Main body (always original green)
      {
        d: "M0 0 C0.69959839 -0.0065712 1.39919678 -0.0131424 2.11999512 -0.01991272 C4.43522251 -0.03962096 6.75038501 -0.05130455 9.06567383 -0.0612793 C9.85831446 -0.06535482 10.65095509 -0.06943035 11.46761513 -0.07362938 C15.66541914 -0.0944825 19.86319057 -0.10878583 24.06103516 -0.11816406 C28.38410215 -0.12920936 32.70665171 -0.16358924 37.02953625 -0.20333576 C40.36427221 -0.22956171 43.69888619 -0.23786131 47.0337162 -0.24144554 C48.62643224 -0.24629839 50.21914331 -0.2578751 51.81175804 -0.27648354 C69.26930263 -0.46773456 69.26930263 -0.46773456 75.58610535 5.6245575 C80.21645647 10.85588298 81.33540199 14.49016989 81.35986328 21.4206543 C81.36497421 22.14311844 81.37008514 22.86558258 81.37535095 23.60993958 C81.38923214 25.99435754 81.38829113 28.37848592 81.38598633 30.76293945 C81.38987448 32.42436836 81.39420939 34.08579627 81.39897156 35.7472229 C81.40643089 39.22905703 81.40614488 42.71078976 81.40087891 46.19262695 C81.39508893 50.64694813 81.41200506 55.10085286 81.43522358 59.55510521 C81.44998192 62.98670871 81.4508297 66.41821245 81.44771385 69.84984207 C81.44822615 71.49163258 81.45344672 73.1334288 81.46352577 74.77518845 C81.47591195 77.07525124 81.46908575 79.37450987 81.45751953 81.67456055 C81.45814896 82.981539 81.45877838 84.28851746 81.45942688 85.63510132 C80.84254452 91.47371365 78.52732357 95.26249723 74.08520508 98.98950195 C73.40458008 99.57344727 72.72395508 100.15739258 72.02270508 100.7590332 C68.47350615 103.35653161 65.36290965 103.30519544 61.10424805 103.31884766 C59.87221649 103.32588211 58.64018494 103.33291656 57.37081909 103.34016418 C56.7124493 103.34198008 56.05407951 103.34379597 55.37575912 103.34566689 C53.30624131 103.35285669 51.23695729 103.36854441 49.16751099 103.38700867 C43.28366424 103.43934056 37.3999433 103.4873775 31.51586914 103.50292969 C27.91355676 103.5130737 24.3118307 103.54256243 20.70975113 103.5842495 C19.34402042 103.59647838 17.97820656 103.60169572 16.61242294 103.59945107 C8.73090231 103.58969075 1.87263728 103.81383569 -4.91479492 108.17700195 C-7.72384754 111.13052013 -9.15477197 114.52324306 -10.91479492 118.17700195 C-11.28512344 118.93435638 -11.65545197 119.69171082 -12.03700256 120.47201538 C-16.07726993 130.41632989 -15.43823163 140.76281367 -15.37008476 151.32646561 C-15.34801891 154.90096301 -15.35197296 158.47462262 -15.36256409 162.04916382 C-15.38412577 170.92003422 -15.36687668 179.79071265 -15.34106445 188.66156006 C-15.31962039 196.17710783 -15.31776573 203.69211414 -15.34398079 211.20765305 C-15.34831203 214.71647808 -15.32375642 218.22434564 -15.29844666 221.73306274 C-15.30371999 223.89748554 -15.31044419 226.06190545 -15.31884766 228.22631836 C-15.30393784 229.19074356 -15.28902802 230.15516876 -15.27366638 231.14881897 C-15.34508206 238.01141921 -16.9480351 243.5040945 -20.91479492 249.17700195 C-26.0538927 253.49142781 -30.93587496 255.28530317 -37.61843872 255.3309021 C-38.56028519 255.33950256 -39.50213165 255.34810303 -40.47251892 255.35696411 C-41.49906082 255.36122406 -42.52560272 255.36548401 -43.58325195 255.36987305 C-44.66992661 255.37805054 -45.75660126 255.38622803 -46.87620544 255.39465332 C-50.47500054 255.41947905 -54.07375621 255.43601739 -57.67260742 255.45043945 C-58.90313717 255.45576313 -60.13366692 255.46108681 -61.40148544 255.46657181 C-67.24488135 255.49053877 -73.08826109 255.5097802 -78.93169224 255.52259386 C-84.98841103 255.53614167 -91.04475988 255.56242227 -97.10131836 255.60913086 C-103.60933706 255.65850314 -110.11701183 255.68322666 -116.62520981 255.69032669 C-119.10105009 255.69703038 -121.57688297 255.71222923 -124.05261612 255.7362175 C-127.52547148 255.76794397 -130.99700762 255.7678936 -134.4699707 255.76049805 C-135.48436722 255.77690338 -136.49876373 255.79330872 -137.54389954 255.81021118 C-144.58516525 255.74911945 -150.0594436 254.18666177 -155.91479492 250.17700195 C-160.11922437 245.7740819 -162.02935988 241.44006577 -162.06869507 235.39033508 C-162.08159576 233.91218575 -162.08159576 233.91218575 -162.09475708 232.4041748 C-162.09901703 231.32414185 -162.10327698 230.24410889 -162.10766602 229.13134766 C-162.11584351 227.99283859 -162.124021 226.85432953 -162.13244629 225.68132019 C-162.15730395 221.90514656 -162.17381777 218.12901055 -162.18823242 214.3527832 C-162.1935561 213.06367727 -162.19887978 211.77457134 -162.20436478 210.4464016 C-162.22559522 205.02735272 -162.24472449 199.60831609 -162.25598717 194.18923664 C-162.27221051 186.43543753 -162.30535181 178.68214076 -162.36238801 170.92853099 C-162.40584504 164.81123062 -162.42174109 158.6941264 -162.42811966 152.57668114 C-162.43483541 149.9791729 -162.45006568 147.38167207 -162.47401047 144.78426552 C-162.50563862 141.14566586 -162.50570126 137.50833002 -162.49829102 133.86962891 C-162.51469635 132.7997171 -162.53110168 131.7298053 -162.54800415 130.62747192 C-162.49171427 123.86379339 -161.30224231 119.40867493 -156.91479492 114.17700195 C-150.70048633 108.27340879 -145.09496666 107.88810653 -136.89892578 107.9375 C-135.89334625 107.93548584 -134.88776672 107.93347168 -133.85171509 107.93139648 C-131.67026481 107.92785441 -129.48880427 107.92861384 -127.30735588 107.93317223 C-123.84643147 107.93877446 -120.38584111 107.92958995 -116.92494202 107.91596985 C-107.08536336 107.87889048 -97.24589659 107.86026615 -87.40625 107.87158203 C-81.38322548 107.87745814 -75.36066903 107.85904709 -69.33773994 107.82569313 C-67.05060701 107.81777476 -64.76342257 107.81896733 -62.47630119 107.82971764 C-43.45245929 108.09017669 -43.45245929 108.09017669 -26.78979492 99.73950195 C-23.10917107 94.70931602 -22.66695746 89.8832171 -22.67529297 83.76977539 C-22.67327881 83.05344437 -22.67126465 82.33711334 -22.66918945 81.59907532 C-22.66565984 80.05224746 -22.66639133 78.50540513 -22.67096519 76.95858002 C-22.67659236 74.50202502 -22.66734352 72.0459363 -22.65376282 69.5894165 C-22.61678347 62.60801088 -22.59805845 55.62676468 -22.609375 48.64526367 C-22.61525918 44.36517663 -22.59680667 40.08574677 -22.5634861 35.80579376 C-22.55558359 34.18408293 -22.55673851 32.56229947 -22.5675106 30.94060516 C-22.62477994 21.92945939 -22.61028477 13.70058716 -16.91479492 6.17700195 C-11.68775031 1.25109893 -7.03157131 0.05467437 0 0 Z",
        fill: "#1EB453",
        transform: "translate(275.914794921875,92.822998046875)"
      },
      // Second strip - Accent (dynamic colors based on state)
      {
        d: "M0 0 C0.70949799 -0.0065712 1.41899597 -0.0131424 2.1499939 -0.01991272 C4.49224974 -0.03958252 6.83444162 -0.05129463 9.17675781 -0.0612793 C9.97951393 -0.06535482 10.78227005 -0.06943035 11.60935211 -0.07362938 C15.85903157 -0.09446397 20.10867901 -0.10877652 24.35839844 -0.11816406 C28.73412049 -0.12921848 33.10933265 -0.16361435 37.48487473 -0.20333576 C40.86164252 -0.22955602 44.23828982 -0.2378607 47.61515045 -0.24144554 C49.22740367 -0.24629814 50.83965199 -0.25787412 52.45180511 -0.27648354 C61.87754315 -0.37851798 69.22600258 -0.40722527 76.90332031 5.81762695 C77.34933594 6.3487207 77.79535156 6.87981445 78.25488281 7.42700195 C78.94710937 8.20817383 78.94710937 8.20817383 79.65332031 9.00512695 C84.02596265 16.74776753 83.1900497 25.91727112 83.18066406 34.5168457 C83.18455855 36.00842913 83.18889475 37.50001147 83.19364929 38.99159241 C83.20108066 42.10738735 83.20084254 45.22306892 83.19555664 48.33886719 C83.189763 52.31076588 83.20670518 56.28219809 83.22990131 60.25401974 C83.24470727 63.33145309 83.24550113 66.40877581 83.24239159 69.48623848 C83.24290125 70.94971198 83.24807164 72.41319226 83.25820351 73.87663078 C83.37438765 93.0006229 83.37438765 93.0006229 77.12988281 100.05200195 C76.68128906 100.58567383 76.23269531 101.1193457 75.77050781 101.66918945 C70.71771348 105.69889733 65.71373184 106.5516213 59.38745117 106.56176758 C58.67430252 106.56714035 57.96115387 106.57251312 57.22639465 106.57804871 C55.69051241 106.58777157 54.15457559 106.5907876 52.6186657 106.58769226 C50.18403577 106.58318589 47.75012185 106.59729184 45.31556702 106.61608887 C39.27289347 106.65895188 33.23023785 106.67011114 27.18743896 106.68231201 C22.07081894 106.69385979 16.95452773 106.71746947 11.83804512 106.75700378 C9.4460817 106.7705322 7.05456878 106.76641182 4.6625824 106.76159668 C3.1893558 106.77094038 1.71613413 106.78110998 0.24291992 106.79223633 C-1.03724503 106.79429077 -2.31740997 106.79634521 -3.6363678 106.79846191 C-7.41637293 107.20919275 -9.82064532 108.34953123 -13.12011719 110.17700195 C-13.78011719 110.17700195 -14.44011719 110.17700195 -15.12011719 110.17700195 C-17.52280099 115.83889015 -17.41598579 121.16057712 -17.42871094 127.20043945 C-17.45386958 129.37752548 -17.47926763 131.55460875 -17.50488281 133.73168945 C-17.53360338 137.14379163 -17.55763834 140.55584604 -17.57641602 143.96801758 C-17.59814672 147.27490607 -17.63758849 150.58124339 -17.67871094 153.88793945 C-17.67882675 154.89964203 -17.67894257 155.9113446 -17.67906189 156.95370483 C-17.7841159 164.52274898 -19.03497091 169.98795471 -23.24511719 176.42700195 C-29.45623238 182.36806866 -36.31490332 183.78705333 -44.68652344 183.6730957 C-46.00401833 183.67527855 -46.00401833 183.67527855 -47.34812927 183.67750549 C-49.19102319 183.67585714 -51.03393241 183.66441631 -52.87670898 183.64355469 C-55.67914918 183.61453786 -58.47969965 183.62298099 -61.28222656 183.63598633 C-63.08366794 183.62974909 -64.88510341 183.62135826 -66.68652344 183.6105957 C-67.51382462 183.61353134 -68.34112579 183.61646698 -69.1934967 183.61949158 C-75.59165864 183.51691869 -81.40132888 182.53204156 -86.39746094 178.2043457 C-86.9453125 177.51469727 -87.49316406 176.82504883 -88.05761719 176.11450195 C-88.62351562 175.42227539 -89.18941406 174.73004883 -89.77246094 174.0168457 C-91.95579877 171.03611492 -92.25725067 169.22772898 -92.31298828 165.57885742 C-92.32905121 164.62381317 -92.34511414 163.66876892 -92.36166382 162.68478394 C-92.40618833 158.30003565 -92.44720831 153.91543939 -92.47021484 149.53051758 C-92.48674024 147.22214655 -92.51398466 144.91382596 -92.55224609 142.60571289 C-92.60721123 139.27243575 -92.62892302 135.94035974 -92.64355469 132.60668945 C-92.66622406 131.58243866 -92.68889343 130.55818787 -92.71224976 129.50289917 C-92.69275809 122.84191599 -91.55490715 118.27254494 -87.12011719 113.17700195 C-82.85713484 109.85187572 -79.42315905 108.06794719 -74.01928711 108.01928711 C-73.19800827 108.00902496 -72.37672943 107.99876282 -71.53056335 107.9881897 C-70.64617081 107.98088837 -69.76177826 107.97358704 -68.85058594 107.96606445 C-66.97362414 107.93799282 -65.09667113 107.90932834 -63.21972656 107.88012695 C-60.26391881 107.83890024 -57.30827464 107.80200782 -54.35229492 107.77563477 C-51.49721474 107.74795955 -48.64287792 107.70208605 -45.78808594 107.65356445 C-44.47060616 107.64868515 -44.47060616 107.64868515 -43.12651062 107.64370728 C-38.07403193 107.54295109 -34.47561603 107.02250373 -30.12011719 104.17700195 C-28.38692337 101.61731491 -28.38692337 101.61731491 -27.30761719 98.67700195 C-26.90929687 97.71793945 -26.51097656 96.75887695 -26.10058594 95.77075195 C-24.41267145 91.30551203 -23.99587525 87.9866657 -23.99414062 83.20214844 C-23.99227249 82.49600906 -23.99040436 81.78986969 -23.98847961 81.06233215 C-23.9844771 79.52854718 -23.98240091 77.99475626 -23.98201752 76.46096611 C-23.97859338 73.18930997 -23.95721325 69.91785101 -23.93678665 66.64626408 C-23.89884548 60.55842138 -23.86749302 54.47078699 -23.86962891 48.3828125 C-23.87042015 44.14504806 -23.84687404 39.90800348 -23.80774689 35.67042732 C-23.79734392 34.06268623 -23.79572049 32.45486145 -23.80339813 30.84710503 C-23.84202858 21.8556044 -23.77030332 13.69524181 -18.12011719 6.17700195 C-12.50415323 0.77468343 -7.52615394 0.05781024 0 0 Z",
        fill: Dg[e],
        transform: "translate(92.1201171875,53.822998046875)"
      },
      // Additional detail paths
      {
        d: "M0 0 C0.66 0.33 1.32 0.66 2 1 C0.90033225 2.29549899 -0.20491801 3.58626071 -1.3125 4.875 C-1.92738281 5.59429687 -2.54226563 6.31359375 -3.17578125 7.0546875 C-5 9 -5 9 -8 11 C-6.60366572 6.55711819 -4.39598172 4.13475236 -1 1 C-0.67 0.67 -0.34 0.34 0 0 Z",
        fill: "currentColor",
        transform: "translate(264,95)"
      },
      {
        d: "M0 0 C0.66 0.33 1.32 0.66 2 1 C-0.64 3.64 -3.28 6.28 -6 9 C-6 6 -6 6 -3.5625 3.375 C-2.716875 2.59125 -1.87125 1.8075 -1 1 C-0.67 0.67 -0.34 0.34 0 0 Z",
        fill: "currentColor",
        transform: "translate(79,56)"
      }
    ],
    t
  ),
  // ChevronDown - from Feather Icons (react-icons/fi)
  ChevronDown: (n = "md", e) => ct(n, "0 0 24 24", ["M6 9l6 6 6-6"], e),
  // Close - IoClose from react-icons/io5
  Close: (n = "md", e) => ct(n, "0 0 24 24", ["M18 6L6 18M6 6l12 12"], e),
  // Send - FiSend from react-icons/fi
  Send: (n = "md", e) => ct(n, "0 0 24 24", ["M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"], e),
  // Microphone - FiMic from react-icons/fi
  Mic: (n = "md", e) => ct(
    n,
    "0 0 24 24",
    [
      "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z",
      "M19 10v2a7 7 0 0 1-14 0v-2",
      "M12 19v4M8 23h8"
    ],
    e
  ),
  // Waveform - PiWaveform from react-icons/pi (Phosphor). The previous
  // version was a hand-drawn 6-bar stroke icon on a 24x24 grid; the real
  // PiWaveform is a single filled path with 5 bars on Phosphor's 256x256
  // grid. Source: node_modules/react-icons/pi/index.js, PiWaveform.
  Waveform: (n = "md", e) => Zi(
    n,
    "0 0 256 256",
    [
      {
        d: "M56,96v64a8,8,0,0,1-16,0V96a8,8,0,0,1,16,0ZM88,24a8,8,0,0,0-8,8V224a8,8,0,0,0,16,0V32A8,8,0,0,0,88,24Zm40,32a8,8,0,0,0-8,8V192a8,8,0,0,0,16,0V64A8,8,0,0,0,128,56Zm40,32a8,8,0,0,0-8,8v64a8,8,0,0,0,16,0V96A8,8,0,0,0,168,88Zm40-16a8,8,0,0,0-8,8v96a8,8,0,0,0,16,0V80A8,8,0,0,0,208,72Z"
      }
    ],
    e
  ),
  // Phone Off - FiPhoneOff from react-icons/fi
  PhoneOff: (n = "md", e) => ct(
    n,
    "0 0 24 24",
    [
      "M10.68 13.31a16 16 0 0 0 3.41 2.6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7 2 2 0 0 1 1.72 2v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.42 19.42 0 0 1-3.33-2.67m-2.67-3.34a19.79 19.79 0 0 1-3.07-8.63A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91",
      "M23 1L1 23"
    ],
    e
  ),
  // Video Camera - IoVideocam from react-icons/io5
  Video: (n = "md", e) => ct(
    n,
    "0 0 24 24",
    ["M23 7l-7 5 7 5V7zM16 5H2C.9 5 0 5.9 0 7v10c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2z"],
    e
  ),
  // Video Camera Off - IoVideocamOff from react-icons/io5
  VideoOff: (n = "md", e) => ct(
    n,
    "0 0 24 24",
    [
      "M1 1l22 22M16 16v1a2 2 0 01-2 2H3a2 2 0 01-2-2V7a2 2 0 012-2h2m5.66 0H14a2 2 0 012 2v3.34l1 1L23 7v10"
    ],
    e
  ),
  // Volume Mute - IoVolumeMute from react-icons/io5 (Ionicons). The previous
  // version was a hand-drawn Feather-style "volume-x" glyph on a 24x24 grid;
  // the real IoVolumeMute lives on Ionicons' 512x512 grid and mixes two
  // filled paths with one stroked diagonal slash. Source:
  // node_modules/react-icons/io5/index.js, IoVolumeMute.
  VolumeMute: (n = "md", e) => Zi(
    n,
    "0 0 512 512",
    [
      {
        d: "M416 432 64 80",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "32",
        strokeLinecap: "round",
        strokeMiterlimit: "10"
      },
      {
        d: "M243.33 98.86a23.89 23.89 0 0 0-25.55 1.82l-.66.51-28.52 23.35a8 8 0 0 0-.59 11.85l54.33 54.33a8 8 0 0 0 13.66-5.66v-64.49a24.51 24.51 0 0 0-12.67-21.71zm8 236.43L96.69 180.69A16 16 0 0 0 85.38 176H56a24 24 0 0 0-24 24v112a24 24 0 0 0 24 24h69.76l92 75.31a23.9 23.9 0 0 0 25.87 1.69A24.51 24.51 0 0 0 256 391.45v-44.86a16 16 0 0 0-4.67-11.3zM352 256c0-24.56-5.81-47.87-17.75-71.27a16 16 0 1 0-28.5 14.55C315.34 218.06 320 236.62 320 256q0 4-.31 8.13a8 8 0 0 0 2.32 6.25l14.36 14.36a8 8 0 0 0 13.55-4.31A146 146 0 0 0 352 256zm64 0c0-51.18-13.08-83.89-34.18-120.06a16 16 0 0 0-27.64 16.12C373.07 184.44 384 211.83 384 256c0 23.83-3.29 42.88-9.37 60.65a8 8 0 0 0 1.9 8.26L389 337.4a8 8 0 0 0 13.13-2.79C411 311.76 416 287.26 416 256z"
      },
      {
        d: "M480 256c0-74.25-20.19-121.11-50.51-168.61a16 16 0 1 0-27 17.22C429.82 147.38 448 189.5 448 256c0 46.19-8.43 80.27-22.43 110.53a8 8 0 0 0 1.59 9l11.92 11.92a8 8 0 0 0 12.92-2.16C471.6 344.9 480 305 480 256z"
      }
    ],
    e
  ),
  // Volume High - IoVolumeHigh from react-icons/io5 (Ionicons). Same
  // grid/source mismatch as VolumeMute above: the previous version was a
  // hand-drawn 24x24 Feather-style "volume-2" glyph. The real IoVolumeHigh
  // is three filled paths on a 512x512 grid, no stroke. Source:
  // node_modules/react-icons/io5/index.js, IoVolumeHigh.
  VolumeHigh: (n = "md", e) => Zi(
    n,
    "0 0 512 512",
    [
      {
        d: "M232 416a23.88 23.88 0 0 1-14.2-4.68 8.27 8.27 0 0 1-.66-.51L125.76 336H56a24 24 0 0 1-24-24V200a24 24 0 0 1 24-24h69.75l91.37-74.81a8.27 8.27 0 0 1 .66-.51A24 24 0 0 1 256 120v272a24 24 0 0 1-24 24zm-106.18-80zm-.27-159.86zM320 336a16 16 0 0 1-14.29-23.19c9.49-18.87 14.3-38 14.3-56.81 0-19.38-4.66-37.94-14.25-56.73a16 16 0 0 1 28.5-14.54C346.19 208.12 352 231.44 352 256c0 23.86-6 47.81-17.7 71.19A16 16 0 0 1 320 336z"
      },
      {
        d: "M368 384a16 16 0 0 1-13.86-24C373.05 327.09 384 299.51 384 256c0-44.17-10.93-71.56-29.82-103.94a16 16 0 0 1 27.64-16.12C402.92 172.11 416 204.81 416 256c0 50.43-13.06 83.29-34.13 120a16 16 0 0 1-13.87 8z"
      },
      {
        d: "M416 432a16 16 0 0 1-13.39-24.74C429.85 365.47 448 323.76 448 256c0-66.5-18.18-108.62-45.49-151.39a16 16 0 1 1 27-17.22C459.81 134.89 480 181.74 480 256c0 64.75-14.66 113.63-50.6 168.74A16 16 0 0 1 416 432z"
      }
    ],
    e
  ),
  // More Vertical - FiMoreVertical from react-icons/fi
  MoreVertical: (n = "md", e) => {
    const t = ct(n, "0 0 24 24", [], e);
    for (let i of [12, 5, 19]) {
      const s = document.createElementNS("http://www.w3.org/2000/svg", "circle");
      s.setAttribute("cx", "12"), s.setAttribute("cy", i.toString()), s.setAttribute("r", "1"), s.setAttribute("fill", "currentColor"), t.appendChild(s);
    }
    return t;
  },
  // Screen Share - MdScreenShare from react-icons/md
  ScreenShare: (n = "md", e) => ct(
    n,
    "0 0 24 24",
    [
      "M20 18c1.1 0 1.99-.9 1.99-2L22 6c0-1.11-.9-2-2-2H4c-1.11 0-2 .89-2 2v10c0 1.1.89 2 2 2H0v2h24v-2h-4zM13 14.47v-2.19c-2.78 0-4.61.85-6 2.72.56-2.67 2.11-5.33 6-5.87V7l4 3.73-4 3.74z"
    ],
    e
  ),
  // Stop Screen Share - MdStopScreenShare from react-icons/md
  StopScreenShare: (n = "md", e) => ct(
    n,
    "0 0 24 24",
    [
      "M21.22 18.02l2 2H24v-2h-2.78zm-1.13-1.13l1.54 1.54c.15-.34.24-.72.24-1.12L21.88 7c0-1.11-.9-2-2-2H7.8l5.88 5.88L13 12 6.97 6.97 2.39 2.39 1.11 3.67l.8.8c-.01.01-.01.02-.01.02L2 17.33c0 1.11.89 2 1.99 2H0v2h18.13l2.71 2.71 1.27-1.27L2.39 2.39zM7 15.13c.96-1.29 2.13-2.08 3.67-2.46l3.46 3.46H7v-1z"
    ],
    e
  ),
  // Redo/Refresh - LiaRedoAltSolid from react-icons/lia
  Redo: (n = "md", e) => ct(
    n,
    "0 0 24 24",
    ["M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.2"],
    e
  ),
  // Drag Indicator - MdDragIndicator from react-icons/md
  DragIndicator: (n = "md", e) => {
    const t = Zi(
      n,
      "0 0 24 24",
      [
        { d: "M11 18c0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2 2 .9 2 2zm-2-8c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm6 4c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" }
      ],
      e
    );
    return t.removeAttribute("stroke"), t.removeAttribute("stroke-width"), t;
  },
  // User - FaUser from react-icons/fa
  User: (n = "md", e) => ct(
    n,
    "0 0 24 24",
    ["M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2", "M12 11a4 4 0 100-8 4 4 0 000 8z"],
    e
  )
};
class Lg {
  constructor(e) {
    this.isDestroyed = e, this.unsubscribes = [];
  }
  register(e, t) {
    if (this.isDestroyed()) return;
    const i = e((...s) => {
      this.isDestroyed() || t(...s);
    });
    if (typeof i == "function") {
      if (this.isDestroyed()) {
        i();
        return;
      }
      this.unsubscribes.push(i);
    }
  }
  unsubscribeAll() {
    for (const e of this.unsubscribes.splice(0))
      e();
  }
}
const Ng = 12e3, zs = 6, Ug = '<svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">', Fg = {
  document: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
  email: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
  phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8.1 9.7a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.8 2z"/>',
  sms: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  ftp: '<path d="M4 17V7l8 5 8-5v10"/><path d="M4 7h16"/>',
  zoom: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3M11 8v6M8 11h6"/>',
  close: '<path d="M18 6 6 18M6 6l12 12"/>',
  external: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14 21 3"/>'
};
function ts(n) {
  return `${Ug}${Fg[n]}</svg>`;
}
const Vg = /* @__PURE__ */ new Set([
  "opacity",
  "zIndex",
  "flex",
  "flexGrow",
  "flexShrink",
  "lineHeight",
  "fontWeight",
  "order",
  "WebkitLineClamp"
]);
function wi(n) {
  return Object.entries(n).map(([e, t]) => {
    const i = e.replace(/[A-Z]/g, (r) => `-${r.toLowerCase()}`), s = typeof t == "number" && !Vg.has(e) ? `${t}px` : String(t);
    return `${i}: ${s};`;
  }).join(" ");
}
const ni = 8, Tn = "#10b981", dt = (n) => `color-mix(in srgb, currentColor ${n}%, transparent)`, be = {
  link: {
    color: Tn,
    textDecoration: "underline",
    wordBreak: "break-all",
    borderRadius: 2
  },
  /** Applied on focus-visible by the renderer; kept here so both agree. */
  linkFocus: { outline: `2px solid ${dt(60)}`, outlineOffset: 2 },
  blocked: { opacity: 0.75, textDecoration: "underline dotted", cursor: "help" },
  card: {
    display: "block",
    position: "relative",
    marginTop: 6,
    maxWidth: 320,
    aspectRatio: "16 / 10",
    borderRadius: ni,
    overflow: "hidden",
    background: dt(6),
    boxShadow: `inset 0 0 0 1px ${dt(10)}`
  },
  cardButton: { cursor: "zoom-in" },
  zoom: {
    position: "absolute",
    right: 6,
    bottom: 6,
    width: 24,
    height: 24,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 6,
    background: "rgba(0,0,0,.55)",
    color: "#fff",
    fontSize: 14,
    pointerEvents: "none"
  },
  media: {
    display: "block",
    width: "100%",
    height: "100%",
    objectFit: "cover",
    borderRadius: ni,
    transition: "opacity .18s ease"
  },
  videoMedia: { objectFit: "contain" },
  skeleton: {
    position: "absolute",
    inset: 0,
    borderRadius: ni,
    background: dt(8),
    backgroundImage: `linear-gradient(90deg, transparent, ${dt(12)}, transparent)`,
    backgroundSize: "200% 100%",
    animation: "convai-preview-shimmer 1.4s ease-in-out infinite"
  },
  caption: {
    display: "block",
    marginTop: 4,
    fontSize: 11,
    opacity: 0.7,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  unavailable: {
    display: "block",
    marginTop: 6,
    fontSize: 11,
    opacity: 0.55,
    fontStyle: "italic",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  fileCard: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    marginTop: 6,
    maxWidth: 320,
    padding: "8px 10px",
    borderRadius: ni,
    background: dt(6),
    boxShadow: `inset 0 0 0 1px ${dt(10)}`,
    color: "inherit",
    textDecoration: "none"
  },
  fileIcon: {
    position: "relative",
    flex: "0 0 auto",
    width: 36,
    height: 44,
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "center",
    paddingBottom: 4,
    boxSizing: "border-box",
    borderRadius: 4,
    background: dt(10),
    color: Tn,
    fontSize: 9,
    fontWeight: 700,
    letterSpacing: ".04em"
  },
  fileBody: { minWidth: 0, display: "flex", flexDirection: "column", gap: 2 },
  fileName: {
    fontSize: 13,
    fontWeight: 600,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  fileMeta: {
    fontSize: 11,
    opacity: 0.7,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  contact: {
    display: "inline-flex",
    alignItems: "center",
    gap: 4,
    padding: "1px 8px 1px 6px",
    borderRadius: 999,
    background: dt(8),
    color: Tn,
    textDecoration: "none",
    fontSize: "0.95em",
    lineHeight: 1.6,
    verticalAlign: "baseline",
    maxWidth: "100%"
  },
  contactGlyph: { display: "inline-flex", fontSize: 13, opacity: 0.9 },
  badge: {
    display: "inline-block",
    marginLeft: 4,
    padding: "0 4px",
    borderRadius: 3,
    fontSize: 9,
    fontWeight: 700,
    letterSpacing: ".04em",
    verticalAlign: "middle",
    background: dt(10),
    opacity: 0.8
  },
  lightboxBackdrop: {
    position: "fixed",
    inset: 0,
    zIndex: 2147483e3,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "rgba(0,0,0,.82)",
    padding: 24,
    boxSizing: "border-box",
    animation: "convai-lightbox-in .16s ease-out"
  },
  lightbox: {
    position: "relative",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 10,
    maxWidth: "90vw",
    maxHeight: "90vh",
    color: "#fff"
  },
  lightboxImage: {
    display: "block",
    maxWidth: "90vw",
    maxHeight: "calc(90vh - 72px)",
    objectFit: "contain",
    borderRadius: ni,
    background: "#000"
  },
  lightboxCaption: {
    fontSize: 12,
    opacity: 0.8,
    maxWidth: "90vw",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  lightboxControls: {
    position: "absolute",
    top: -4,
    right: -4,
    transform: "translateY(-100%)",
    display: "flex",
    gap: 6
  },
  lightboxButton: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    padding: "6px 10px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,.25)",
    background: "rgba(0,0,0,.5)",
    color: "#fff",
    fontSize: 12,
    cursor: "pointer",
    textDecoration: "none"
  },
  lightboxFallback: {
    padding: "32px 40px",
    fontSize: 13,
    opacity: 0.8,
    border: "1px dashed rgba(255,255,255,.3)",
    borderRadius: ni
  },
  // Site card: Open Graph metadata under a plain web link. Same chrome as the
  // file card so the three card kinds read as one family.
  siteCard: {
    display: "block",
    marginTop: 6,
    maxWidth: 320,
    padding: "8px 10px",
    borderRadius: ni,
    background: dt(6),
    boxShadow: `inset 0 0 0 1px ${dt(10)}`,
    color: "inherit",
    textDecoration: "none"
  },
  siteHeader: { display: "flex", alignItems: "center", gap: 6, minWidth: 0 },
  siteFavicon: {
    width: 16,
    height: 16,
    flex: "0 0 auto",
    borderRadius: 3,
    objectFit: "contain"
  },
  siteName: {
    fontSize: 12,
    fontWeight: 700,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  siteTitle: {
    display: "block",
    marginTop: 2,
    fontSize: 13,
    fontWeight: 600,
    color: Tn,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis"
  },
  siteDescription: {
    display: "-webkit-box",
    WebkitBoxOrient: "vertical",
    WebkitLineClamp: 2,
    overflow: "hidden",
    marginTop: 2,
    fontSize: 12,
    opacity: 0.75,
    lineHeight: 1.35
  },
  siteImage: {
    display: "block",
    width: "100%",
    aspectRatio: "16 / 9",
    objectFit: "cover",
    marginTop: 8,
    borderRadius: 6
  }
};
let Ci = null;
const qt = (n, e, t) => {
  const i = document.createElement(n);
  return i.setAttribute("part", e), i.style.cssText = wi(t), i;
};
function Bg(n) {
  var b;
  Ci == null || Ci.close(), Vn(n.root);
  const e = n.root instanceof ShadowRoot ? n.root : n.root.body, t = qt("div", "lightbox-backdrop", be.lightboxBackdrop);
  t.setAttribute("role", "dialog"), t.setAttribute("aria-modal", "true"), t.setAttribute("aria-label", n.alt || "Image preview");
  const i = qt("div", "lightbox", be.lightbox), s = qt("img", "lightbox-image", be.lightboxImage);
  s.src = n.src, s.alt = n.alt;
  const r = qt("span", "lightbox-caption", be.lightboxCaption);
  r.textContent = n.caption;
  const o = qt("div", "lightbox-controls", be.lightboxControls), a = qt("a", "lightbox-open", be.lightboxButton);
  a.href = n.href, a.target = "_blank", a.rel = "noopener noreferrer", a.innerHTML = `${ts("external")}<span>Open original</span>`;
  const c = qt("button", "lightbox-close", be.lightboxButton);
  c.type = "button", c.setAttribute("aria-label", "Close image preview"), c.innerHTML = ts("close"), o.append(a, c), s.addEventListener("error", () => {
    const v = qt("div", "lightbox-fallback", be.lightboxFallback);
    v.textContent = "Image could not be loaded", s.replaceWith(v);
  });
  const d = document.body.style.overflow, l = (b = n.returnFocusTo) != null ? b : document.activeElement, u = () => n.root instanceof ShadowRoot ? n.root.activeElement : document.activeElement, h = (v) => {
    if (v.key === "Escape") {
      v.preventDefault(), p.close();
      return;
    }
    if (v.key === "Tab") {
      const C = u();
      v.shiftKey && C === a ? (v.preventDefault(), c.focus()) : !v.shiftKey && C === c && (v.preventDefault(), a.focus());
    }
  }, p = {
    close() {
      var v;
      Ci === p && (Ci = null, document.removeEventListener("keydown", h, !0), t.remove(), document.body.style.overflow = d, (v = l == null ? void 0 : l.focus) == null || v.call(l));
    }
  };
  return t.addEventListener("click", (v) => {
    v.target === t && p.close();
  }), c.addEventListener("click", () => p.close()), document.addEventListener("keydown", h, !0), i.append(o, s, r), t.appendChild(i), e.appendChild(t), document.body.style.overflow = "hidden", Ci = p, c.focus(), p;
}
const Ct = 24, Qo = {
  "bottom-right": `position: fixed; bottom: ${Ct}px; right: ${Ct}px;`,
  "bottom-left": `position: fixed; bottom: ${Ct}px; left: ${Ct}px;`,
  "top-right": `position: fixed; top: ${Ct}px; right: ${Ct}px;`,
  "top-left": `position: fixed; top: ${Ct}px; left: ${Ct}px;`,
  inline: "position: relative;"
}, jg = 400, qg = 600, Hg = `calc(100dvw - ${Ct * 2}px)`, Wg = `calc(100dvh - ${Ct * 2}px)`, $g = "mic-permission";
function zg(n) {
  const e = n == null ? void 0 : n.name;
  return e === "NotAllowedError" || e === "PermissionDeniedError";
}
function Kg(n) {
  const e = new Error(
    "Microphone access was denied. Continuing in text-only mode."
  );
  return e.name = "ConvaiMicPermissionError", e.code = $g, e.cause = n, e;
}
function _i(n, e, t) {
  var s;
  console.error(e, t);
  const i = zg(t) ? Kg(t) : t;
  (s = n.emit) == null || s.call(n, "error", i);
}
function Gg(n, e) {
  var ga;
  const t = (ga = e.styleTarget) != null ? ga : n.getRootNode() instanceof ShadowRoot ? n.getRootNode() : document, i = e.convaiClient || (() => {
    var _, V, j;
    if (!!!(e.apiKey || e.authToken) || !e.characterId)
      throw new Error(
        "Either convaiClient or (apiKey or authToken) and characterId must be provided"
      );
    return new Ve({
      apiKey: (e == null ? void 0 : e.apiKey) || void 0,
      authToken: (e == null ? void 0 : e.authToken) || void 0,
      characterId: e.characterId,
      enableVideo: (_ = e.enableVideo) != null ? _ : !1,
      startWithVideoOn: (V = e.startWithVideoOn) != null ? V : !1,
      enableLipsync: (j = e.enableLipsync) != null ? j : !1,
      enableEmotion: e.enableEmotion,
      blendshapeConfig: e.blendshapeConfig
    });
  })(), {
    showVideo: s = !0,
    showScreenShare: r = !0,
    defaultVoiceMode: o = !0,
    requestPublicationGrant: a,
    publishedChatConnectOptions: c,
    publishedChatDescriptor: d,
    onConnect: l,
    onDisconnect: u,
    onMessage: h
  } = e, p = e.placement && e.placement in Qo ? e.placement : "bottom-right";
  Og(t), Vn(t);
  let b = !1, v = !1, C = o && !a && i.connectionType !== "text", T = !1, P = !1, R = "", g = (d == null ? void 0 : d.display_name) || "Character", f = (d == null ? void 0 : d.image_url) || "", k = null, w = !1, D = !1, A = !1, O = !1;
  const N = new Lg(() => O);
  let L, B, Q, ae, re, K, xe, Ie, $, $e, _e, je, ot;
  const ce = {};
  let Ke = null, xt = null, F = null, pe = null, ge = null;
  const de = async () => {
    var _, V;
    if (d) return;
    const y = (_ = i.authToken) != null ? _ : i.apiKey;
    if (!(!y || !i.characterId))
      try {
        const j = await cg({
          characterId: i.characterId,
          apiKey: y,
          authToken: i.authToken,
          baseUrl: i.characterInfoUrl
        });
        g = j.name, f = (V = j.image) != null ? V : "", Mt();
      } catch (j) {
        console.error("Failed to fetch character info:", j);
      }
  }, Ge = () => {
    L = document.createElement("div"), L.className = "convai-widget", L.style.cssText = `
      ${Qo[p]}
      z-index: var(--convai-z-index, ${q.zIndex.modal});
      font-family: var(--convai-font, ${q.typography.fontFamily.primary});
    `, B = document.createElement("div"), B.setAttribute("part", "launcher"), B.style.cssText = `
      position: relative;
      width: var(--convai-launcher-size, 64px);
      height: var(--convai-launcher-size, 64px);
      max-width: ${Hg};
      max-height: ${Wg};
      background: var(--convai-panel-bg, ${q.colors.glass.backdrop});
      backdrop-filter: ${q.glass.backdrop};
      border: ${q.glass.border};
      border-radius: 50%;
      box-shadow: var(--convai-shadow, ${q.shadows.glass});
      transition: all 0.3s ease-in-out;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    `, Q = document.createElement("div"), Q.style.cssText = `
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: opacity 0.3s, transform 0.3s;
      opacity: 1;
      transform: scale(1);
    `;
    const y = Ce.ConvaiLogo("xl", "idle");
    y.style.color = `var(--convai-accent, ${q.colors.convai.light})`, Q.appendChild(y), ae = document.createElement("div"), ae.setAttribute("part", "panel"), ae.style.cssText = `
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      opacity: 0;
      transform: scale(0.8);
      transition: opacity 0.2s, transform 0.2s;
      pointer-events: none;
    `, je = Ft(), ae.appendChild(je), re = vl(), K = document.createElement("div"), K.style.cssText = `
      flex: 1;
      overflow-y: auto;
      padding: 16px;
      background: transparent;
      position: relative;
    `, $ = bl(), K.appendChild($), ot = me(), K.appendChild(ot), xe = yl(), ae.appendChild(re), ae.appendChild(K), ae.appendChild(xe), B.appendChild(Q), B.appendChild(ae), L.appendChild(B), $e = Sl(), L.appendChild($e), _e = Tl(), n.appendChild(_e), n.appendChild(L), B.addEventListener("click", oa);
  }, Ft = () => {
    const y = document.createElement("div");
    y.style.cssText = `
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
      padding: 16px;
      z-index: 10;
      pointer-events: auto;
      display: none;
      flex-direction: column;
      align-items: center;
      gap: 32px;
    `;
    const _ = document.createElement("div");
    _.style.cssText = `
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      isolation: isolate;
    `;
    const V = document.createElement("div");
    V.className = "convai-voice-avatar", ce.voiceModeAvatar = V, V.style.cssText = `
      position: relative;
      z-index: 10;
      border-radius: 50%;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
      background: white;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
    const j = document.createElement("div");
    j.className = "convai-voice-gradient", j.style.cssText = `
      position: absolute;
      width: 126px;
      height: 126px;
      border-radius: 50%;
      background: conic-gradient(
        from 0deg,
        ${q.colors.convai.light}00 0%,
        ${q.colors.convai.light}40 25%,
        ${q.colors.convai.dark}60 50%,
        ${q.colors.convai.light}40 75%,
        ${q.colors.convai.light}00 100%
      );
      opacity: 0.8;
      filter: blur(8px);
      z-index: -2;
      animation: convaiVoiceSpin 20s linear infinite;
    `;
    const M = document.createElement("div");
    M.className = "convai-voice-gradient", M.style.cssText = `
      position: absolute;
      width: 126px;
      height: 126px;
      border-radius: 50%;
      background:
        radial-gradient(ellipse 80% 100% at 30% 40%,
          ${q.colors.convai.light}50,
          ${q.colors.convai.light}30 40%,
          transparent 70%),
        radial-gradient(ellipse 80% 100% at 70% 60%,
          ${q.colors.convai.dark}50,
          ${q.colors.convai.dark}30 40%,
          transparent 70%);
      opacity: 0.9;
      filter: blur(6px);
      z-index: -1;
      animation: convaiVoiceSpinReverse 15s linear infinite;
    `;
    const z = document.createElement("div");
    z.style.cssText = `
      position: relative;
      border-radius: 50%;
      overflow: hidden;
      border: 3px solid rgba(255, 255, 255, 0.2);
      width: 120px;
      height: 120px;
      display: flex;
      align-items: center;
      justify-content: center;
    `, ce.voiceModeAvatarClip = z, V.append(j, M, z), _.appendChild(V), y.appendChild(_);
    const G = document.createElement("canvas");
    G.className = "convai-voice-wave", G.style.cssText = "width: 250px; height: 80px;", ce.voiceModeCanvas = G, y.appendChild(G);
    const te = document.createElement("div"), Se = document.createElement("div");
    Se.id = "voice-mode-title", ce.voiceModeTitle = Se, Se.style.cssText = `
      font-size: 16px;
      font-weight: 600;
      color: var(--convai-panel-fg, ${q.colors.text.primary});
      margin-bottom: 8px;
    `, Se.textContent = "Voice Mode";
    const ee = document.createElement("div");
    return ee.id = "voice-mode-subtitle", ce.voiceModeSubtitle = ee, ee.style.cssText = `
      font-size: 13px;
      color: ${q.colors.text.secondary};
    `, ee.textContent = "Tap microphone to talk", te.append(Se, ee), y.appendChild(te), y;
  }, ve = () => {
    var j;
    const y = ce.voiceModeAvatarClip;
    if (!y) return;
    const _ = f || `letter:${g}`;
    if (y.dataset.filledWith === _) return;
    if (y.dataset.filledWith = _, y.replaceChildren(), f) {
      const M = document.createElement("img");
      M.src = f, M.alt = g, M.style.cssText = "width: 120px; height: 120px; object-fit: cover; display: block;", y.appendChild(M);
      return;
    }
    const V = document.createElement("div");
    V.style.cssText = `
      width: 120px;
      height: 120px;
      background-color: ${q.colors.convai.light}20;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 48px;
      font-weight: 600;
      color: var(--convai-accent, ${q.colors.convai.light});
    `, V.textContent = ((j = g[0]) == null ? void 0 : j.toUpperCase()) || "C", y.appendChild(V);
  }, me = () => {
    const y = document.createElement("div");
    y.id = "convai-connecting-overlay", y.style.cssText = `
      position: absolute;
      inset: 0;
      z-index: 100;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 16px;
      background: rgba(255, 255, 255, 0.95);
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s;
    `, Vn(t);
    const _ = document.createElement("div");
    _.className = "convai-connecting-spin", _.style.cssText = `
      display: inline-flex;
      animation: convaiConnectingSpin 2s linear infinite;
    `;
    const V = Ce.ConvaiLogo("xl", "connecting");
    V.style.color = `var(--convai-accent, ${q.colors.convai.light})`, _.appendChild(V), y.appendChild(_);
    const j = document.createElement("div");
    return j.id = "convai-connecting-text", j.className = "convai-connecting-pulse", j.style.cssText = `
      font-size: 14px;
      font-weight: 500;
      color: ${q.colors.text.secondary};
      animation: convaiConnectingPulse 2s ease-in-out infinite;
    `, ce.connectingLabel = j, y.appendChild(j), y;
  }, na = () => {
    if (!ot) return;
    const y = ce.connectingLabel;
    y && (y.textContent = `Connecting to ${g}...`);
    const _ = (i.state.isConnected || i.state.isConnecting) && !i.isBotReady;
    ot.style.opacity = _ ? "1" : "0", ot.style.pointerEvents = _ ? "auto" : "none";
  };
  let pt = Array(40).fill(0), ji = 0, sa = 0, ra = !1;
  const ml = () => {
    const y = ce.voiceModeCanvas;
    if (!y || (sa ^= 1, sa)) return;
    let _ = 0;
    for (let ie = 0; ie < pt.length; ie++) _ += pt[ie];
    const V = _ / pt.length < 0.012;
    if (V && ra) return;
    ra = V;
    const j = Math.min(window.devicePixelRatio || 1, 2);
    y.width !== 250 * j && (y.width = 250 * j, y.height = 80 * j);
    const M = y.getContext("2d");
    if (!M) return;
    M.setTransform(j, 0, 0, j, 0, 0), M.clearRect(0, 0, 250, 80);
    const z = 40, G = 250, te = 40, Se = _ / pt.length, ee = [
      q.colors.convai.light,
      q.colors.convai.light,
      "#34d399"
    ];
    M.lineCap = "round", M.lineJoin = "round";
    for (let ie = 2; ie >= 0; ie--) {
      M.beginPath();
      for (let ke = 0; ke <= te; ke++) {
        const qe = ke / te * G, st = Math.floor(ke / te * (pt.length - 1)), X = pt[st] || 0, ne = (Date.now() / 500 + ke * 0.2 + ie * 1.5) % (Math.PI * 2), J = Se > 0.05 ? 2 + ie * 1.5 : 0, Y = J + X * (25 - J), le = z + Math.sin(ne) * Y;
        ke === 0 ? M.moveTo(qe, le) : M.lineTo(qe, le);
      }
      M.strokeStyle = ee[ie], M.globalAlpha = 0.18 * (0.3 + Se), M.lineWidth = 2.5 - ie * 0.4 + 8 * Se + 3, M.stroke(), M.globalAlpha = 0.95 - ie * 0.15, M.lineWidth = 2.5 - ie * 0.4, M.stroke();
    }
    M.globalAlpha = 1;
  }, aa = () => {
    if (!je) return;
    const y = i.state.isSpeaking, _ = i.state.isListening, V = !i.audioControls.isAudioMuted, j = ce.voiceModeAvatar;
    if (j) {
      const G = y ? "convaiVoiceBreathe 3s ease-in-out infinite" : "";
      j.style.animation !== G && (j.style.animation = G);
    }
    const M = ce.voiceModeTitle, z = ce.voiceModeSubtitle;
    if (M && (M.textContent = y ? `${g} Speaking...` : _ || V ? "Listening..." : "Voice Mode"), z && (z.textContent = _ || V || y ? "Audio active" : "Tap microphone to talk"), (_ || V) && xt && F) {
      xt.getByteTimeDomainData(F);
      let G = 0;
      for (let ee = 0; ee < F.length; ee++) {
        const ie = (F[ee] - 128) / 128;
        G += ie * ie;
      }
      const te = Math.sqrt(G / F.length), Se = Math.min(1, te * 3);
      for (let ee = 0; ee < pt.length; ee++) {
        const ie = ee / pt.length, ke = Date.now() / 300 + ie * Math.PI * 2, qe = Math.sin(ke) * 0.15 + 0.85;
        pt[ee] = Se * qe;
      }
    } else
      for (let G = 0; G < pt.length; G++) pt[G] = 0;
    ml(), pe = requestAnimationFrame(aa);
  }, fl = async () => {
    try {
      Ke || (Ke = new (window.AudioContext || window.webkitAudioContext)()), Ke.state === "suspended" && await Ke.resume();
      const y = await navigator.mediaDevices.getUserMedia({ audio: !0 });
      xt = Ke.createAnalyser(), xt.fftSize = 256, xt.smoothingTimeConstant = 0.7, ge = Ke.createMediaStreamSource(y), ge.connect(xt), F = new Uint8Array(xt.fftSize), aa();
    } catch (y) {
      _i(i, "Audio analysis setup failed:", y);
    }
  }, gl = () => {
    pe && cancelAnimationFrame(pe), ge && (ge.disconnect(), ge.mediaStream.getTracks().forEach((y) => y.stop()), ge = null);
  }, vl = () => {
    const y = document.createElement("div");
    y.setAttribute("part", "header"), y.style.cssText = `
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px;
      border-bottom: 1px solid ${q.colors.neutral[200]};
      background: var(--convai-panel-bg, white);
      position: relative;
    `;
    const _ = document.createElement("button"), V = Ce.ChevronDown("md");
    _.appendChild(V), _.style.cssText = `
      font-size: 20px;
      color: ${q.colors.text.secondary};
      cursor: pointer;
      padding: 4px;
      transition: ${q.transitions.fast};
      background: transparent;
      border: none;
    `, _.addEventListener("click", (G) => {
      G.stopPropagation(), gn();
    });
    const j = document.createElement("div");
    j.style.cssText = `
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: ${q.typography.fontSize.base};
      font-weight: ${q.typography.fontWeight.semibold};
      color: var(--convai-panel-fg, ${q.colors.text.primary});
    `, j.id = "convai-widget-title", ce.widgetTitle = j;
    const M = document.createElement("button"), z = Ce.MoreVertical("md");
    return M.appendChild(z), M.style.cssText = `
      font-size: 24px;
      color: ${q.colors.text.secondary};
      cursor: pointer;
      padding: 4px;
      transition: ${q.transitions.fast};
      background: transparent;
      border: none;
      margin-left: auto;
    `, M.addEventListener("click", (G) => {
      G.stopPropagation(), _l();
    }), y.appendChild(_), y.appendChild(j), y.appendChild(M), y;
  }, Mt = () => {
    const y = ce.widgetTitle;
    if (!y) return;
    if (y.innerHTML = "", f) {
      const M = document.createElement("img");
      M.src = f, M.alt = g, M.style.cssText = `
        width: 24px;
        height: 24px;
        border-radius: 50%;
        object-fit: cover;
        border: 1.5px solid ${fa().color};
        box-shadow: 0 0 6px ${fa().color}40;
        transition: all 0.3s ease;
      `, y.appendChild(M);
    }
    const _ = document.createElement("span");
    _.textContent = g, y.appendChild(_);
    const V = document.createElement("button");
    V.innerHTML = "";
    const j = T ? Ce.VolumeMute("sm") : Ce.VolumeHigh("sm");
    if (j.style.color = T ? "#919EABA6" : "#0E7360", V.appendChild(j), V.style.cssText = `
      cursor: pointer;
      background: transparent;
      border: none;
      box-shadow: none;
      width: auto;
      height: auto;
      padding: 0;
      display: inline-flex;
      align-items: center;
      margin-left: 8px;
      outline: none;
      transition: transform 0.1s ease-out;
    `, V.addEventListener("click", (M) => {
      M.stopPropagation(), Cl();
    }), V.addEventListener("mouseenter", () => {
      V.style.transform = "scale(1.1)";
    }), V.addEventListener("mouseleave", () => {
      V.style.transform = "scale(1)";
    }), y.appendChild(V), C) {
      const M = document.createElement("span");
      M.textContent = "VOICE", M.style.cssText = `
        font-size: 10px;
        color: var(--convai-accent, ${q.colors.convai.light});
        font-weight: 500;
        margin-left: 8px;
        padding: 2px 6px;
        border-radius: 4px;
        background-color: ${q.colors.convai.light}20;
      `, y.appendChild(M);
    }
    if (i.state.isSpeaking) {
      const M = document.createElement("span");
      M.textContent = "SPEAKING", M.style.cssText = `
        font-size: 10px;
        color: #10b981;
        font-weight: 600;
        margin-left: 8px;
        padding: 3px 8px;
        border-radius: 6px;
        background-color: #10b98120;
        border: 1px solid #10b98140;
        display: inline-flex;
        align-items: center;
        gap: 4px;
      `;
      const z = document.createElement("span");
      z.style.cssText = `
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background-color: #10b981;
        display: inline-block;
      `, M.insertBefore(z, M.firstChild), y.appendChild(M);
    }
    if (i.state.isListening && !i.state.isSpeaking) {
      const M = document.createElement("span");
      M.textContent = "LISTENING", M.style.cssText = `
        font-size: 10px;
        color: #3b82f6;
        font-weight: 600;
        margin-left: 8px;
        padding: 3px 8px;
        border-radius: 6px;
        background-color: #3b82f620;
        border: 1px solid #3b82f640;
        display: inline-flex;
        align-items: center;
        gap: 4px;
      `;
      const z = document.createElement("span");
      z.style.cssText = `
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background-color: #3b82f6;
        display: inline-block;
      `, M.insertBefore(z, M.firstChild), y.appendChild(M);
    }
    na(), ve();
  }, bl = () => {
    const y = document.createElement("div");
    return y.id = "convai-message-list", y.setAttribute("part", "messages"), y.style.cssText = `
      display: flex;
      flex-direction: column;
      gap: 12px;
      min-height: 100%;
    `, y;
  }, yl = () => {
    const y = document.createElement("div");
    y.style.cssText = `
      padding: 16px;
      border-top: 1px solid ${q.colors.neutral[200]};
      background: var(--convai-panel-bg, white);
      display: flex;
      gap: 8px;
      align-items: center;
      position: relative;
    `;
    const _ = document.createElement("button");
    _.id = "convai-voice-exit-btn", ce.voiceExitBtn = _;
    const V = Ce.PhoneOff("md");
    _.appendChild(V), _.style.cssText = `
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: ${q.colors.error[500]};
      color: white;
      display: none; /* Hidden by default */
      align-items: center;
      justify-content: center;
      cursor: pointer;
      margin: 0 auto;
      border: none;
    `, _.addEventListener("click", () => {
      i.sendInterruptMessage(), C = !1, qi();
    }), y.appendChild(_);
    const j = document.createElement("div");
    j.id = "convai-footer-standard", ce.footerStandard = j, j.style.cssText = `
      display: flex;
      gap: 8px;
      align-items: center;
      width: 100%;
    `;
    const M = document.createElement("div");
    M.style.cssText = `
      flex: 1;
      position: relative;
      display: flex;
      align-items: center;
    `, Ie = document.createElement("input"), Ie.setAttribute("part", "input"), Ie.type = "text", Ie.placeholder = "Conversation", Ie.style.cssText = `
      width: 100%;
      padding: 12px 44px 12px 16px;
      border-radius: ${q.borderRadius.full};
      border: 1px solid ${q.colors.neutral[300]};
      background: ${q.colors.glass.medium};
      color: var(--convai-panel-fg, ${q.colors.text.primary});
      font-size: ${q.typography.fontSize.sm};
      transition: ${q.transitions.fast};
      outline: none;
    `, Ie.addEventListener("input", (te) => {
      R = te.target.value, ti();
    }), Ie.addEventListener("keypress", (te) => {
      te.key === "Enter" && la();
    });
    const z = document.createElement("button");
    z.id = "convai-send-button", z.setAttribute("part", "send-button"), ce.sendButton = z;
    const G = Ce.Send("md");
    return z.appendChild(G), z.style.cssText = `
      position: absolute;
      right: 6px;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: transparent; /* Initial transparent for voice toggle */
      color: var(--convai-panel-fg, ${q.colors.text.primary});
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: ${q.transitions.fast};
      border: none;
    `, z.addEventListener("click", async () => {
      if (R.length > 0)
        la();
      else if (!a && i.connectionType !== "text") {
        i.sendInterruptMessage();
        try {
          await i.audioControls.unmuteAudio(), C = !0, await mi();
        } catch (te) {
          _i(i, "Failed to enable microphone:", te);
        }
      }
    }), M.appendChild(Ie), M.appendChild(z), j.appendChild(M), y.appendChild(j), y;
  }, Sl = () => {
    const y = document.createElement("div");
    y.setAttribute("data-settings-tray", "true"), y.style.cssText = `
      position: absolute;
      top: 60px;
      right: 16px;
      background: var(--convai-panel-bg, white);
      border-radius: ${q.borderRadius.xl};
      box-shadow: ${q.shadows.xl};
      padding: 0;
      display: none;
      flex-direction: row;
      align-items: center;
      gap: 0;
      z-index: 9999;
      min-width: auto;
      transform-origin: top right;
      animation: popIn 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      overflow: hidden;
    `, Vn(t);
    const _ = document.createElement("div");
    _.style.cssText = `
      display: flex;
      flex-direction: row;
      align-items: center;
      padding: 8px;
      gap: 4px;
    `;
    const V = (G, te, Se, ee = !1, ie = !1) => {
      const ke = document.createElement("div");
      ke.style.cssText = `
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        padding: 8px 12px;
        cursor: pointer;
        border-radius: ${q.borderRadius.md};
        background-color: ${ee ? "rgba(16, 185, 129, 0.15)" : ie ? "rgba(239, 68, 68, 0.1)" : "transparent"};
        color: ${ee ? "#10b981" : ie ? "#ef4444" : `var(--convai-panel-fg, ${q.colors.text.primary})`};
        transition: ${q.transitions.fast};
        min-width: 50px;
      `;
      const qe = document.createElement("div");
      qe.appendChild(G), ke.appendChild(qe);
      const st = document.createElement("span");
      return st.textContent = te, st.style.cssText = `
        font-size: 10px;
        font-weight: 500;
      `, ke.appendChild(st), ke.addEventListener("click", (X) => {
        X.stopPropagation(), Se();
      }), ke.addEventListener("mouseover", () => {
        ke.style.transform = "scale(1.02)", !ee && !ie && (ke.style.backgroundColor = q.colors.neutral[100]);
      }), ke.addEventListener("mouseout", () => {
        ke.style.transform = "scale(1)", ke.style.backgroundColor = ee ? "rgba(16, 185, 129, 0.15)" : ie ? "rgba(239, 68, 68, 0.1)" : "transparent";
      }), ke;
    }, j = Ce.Redo("md");
    j.style.width = "18px", j.style.height = "18px", (!i.isPublishedChatSession || a) && _.appendChild(V(j, "Reset", ua));
    const M = i.connectionType;
    if (M === "video" && s) {
      const G = P ? Ce.Video("md") : Ce.VideoOff("md");
      G.style.width = "18px", G.style.height = "18px";
      const te = V(
        G,
        "Video",
        pa,
        P
      );
      te.id = "convai-settings-video-btn", ce.settingsVideoBtn = te, _.appendChild(te);
    }
    if (M === "video" && r) {
      const G = i.screenShareControls.isScreenShareActive, te = G ? Ce.StopScreenShare("md") : Ce.ScreenShare("md");
      te.style.width = "18px", te.style.height = "18px";
      const Se = V(
        te,
        "Screen",
        ma,
        G
      );
      Se.id = "convai-settings-share-btn", ce.settingsShareBtn = Se, _.appendChild(Se);
    }
    const z = document.createElement("span");
    return z.innerHTML = "⏻", z.style.fontSize = "18px", (!i.isPublishedChatSession || a) && _.appendChild(
      V(z, "Disconnect", ha, !1, !0)
    ), y.appendChild(_), y;
  }, kl = () => {
    const y = $e.querySelector("div");
    if (!y) return;
    y.innerHTML = "";
    const _ = (z, G, te, Se = !1, ee = !1) => {
      const ie = document.createElement("div");
      ie.style.cssText = `
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        padding: 8px 12px;
        cursor: pointer;
        border-radius: ${q.borderRadius.md};
        background-color: ${Se ? "rgba(16, 185, 129, 0.15)" : ee ? "rgba(239, 68, 68, 0.1)" : "transparent"};
        color: ${Se ? "#10b981" : ee ? "#ef4444" : `var(--convai-panel-fg, ${q.colors.text.primary})`};
        transition: ${q.transitions.fast};
        min-width: 50px;
      `;
      const ke = document.createElement("div");
      ke.appendChild(z), ie.appendChild(ke);
      const qe = document.createElement("span");
      return qe.textContent = G, qe.style.cssText = `
        font-size: 10px;
        font-weight: 500;
      `, ie.appendChild(qe), ie.addEventListener("click", (st) => {
        st.stopPropagation(), te();
      }), ie.addEventListener("mouseover", () => {
        ie.style.transform = "scale(1.02)", !Se && !ee && (ie.style.backgroundColor = q.colors.neutral[100]);
      }), ie.addEventListener("mouseout", () => {
        ie.style.transform = "scale(1)", ie.style.backgroundColor = Se ? "rgba(16, 185, 129, 0.15)" : ee ? "rgba(239, 68, 68, 0.1)" : "transparent";
      }), ie;
    }, V = Ce.Redo("md");
    V.style.width = "18px", V.style.height = "18px", (!i.isPublishedChatSession || a) && y.appendChild(_(V, "Reset", ua));
    const j = i.connectionType;
    if (j === "video" && s) {
      const z = P ? Ce.Video("md") : Ce.VideoOff("md");
      z.style.width = "18px", z.style.height = "18px";
      const G = _(
        z,
        "Video",
        pa,
        P
      );
      G.id = "convai-settings-video-btn", ce.settingsVideoBtn = G, y.appendChild(G);
    }
    if (j === "video" && r) {
      const z = i.screenShareControls.isScreenShareActive, G = z ? Ce.StopScreenShare("md") : Ce.ScreenShare("md");
      G.style.width = "18px", G.style.height = "18px";
      const te = _(
        G,
        "Screen",
        ma,
        z
      );
      te.id = "convai-settings-share-btn", ce.settingsShareBtn = te, y.appendChild(te);
    }
    const M = document.createElement("span");
    M.innerHTML = "⏻", M.style.fontSize = "18px", (!i.isPublishedChatSession || a) && y.appendChild(
      _(M, "Disconnect", ha, !1, !0)
    );
  }, Tl = () => {
    const y = document.createElement("div");
    y.id = "floating-video-container", y.style.cssText = `
      position: fixed;
      left: 20px;
      top: 20px;
      z-index: 10000;
      width: 320px;
      border-radius: ${q.borderRadius.lg};
      overflow: hidden;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
      cursor: grab;
      display: none;
      transition: opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    `;
    const _ = document.createElement("div");
    _.style.cssText = `
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(20px);
      border: 1px solid ${q.colors.neutral[700]};
      border-radius: ${q.borderRadius.lg};
      overflow: hidden;
    `;
    const V = document.createElement("div");
    V.style.cssText = `
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 12px;
      background: rgba(0, 0, 0, 0.3);
      border-bottom: 1px solid ${q.colors.neutral[700]};
    `;
    const j = document.createElement("div");
    j.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
      color: ${q.colors.neutral[300]};
      font-size: 12px;
      font-weight: 500;
    `;
    const M = Ce.DragIndicator("sm");
    M.style.width = "16px", M.style.height = "16px", j.appendChild(M);
    const z = document.createElement("span");
    z.textContent = "Your Camera", j.appendChild(z);
    const G = document.createElement("button");
    G.innerHTML = "";
    const te = Ce.Close("md");
    te.style.width = "20px", te.style.height = "20px", G.appendChild(te), G.style.cssText = `
      background: transparent;
      border: none;
      color: ${q.colors.neutral[400]};
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 4px;
      transition: transform 0.1s ease-out;
    `, G.addEventListener("click", (Te) => {
      Te.stopPropagation(), i.videoControls.disableVideo();
    }), G.addEventListener("mouseenter", () => {
      G.style.transform = "scale(1.1)";
    }), G.addEventListener("mouseleave", () => {
      G.style.transform = "scale(1)";
    }), V.appendChild(j), V.appendChild(G);
    const Se = document.createElement("div");
    Se.style.cssText = `
      position: relative;
      width: 100%;
      padding-bottom: 75%;
      background: #000;
    `;
    const ee = document.createElement("div");
    ee.id = "floating-video-wrapper", ee.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    `;
    const ie = document.createElement("video");
    ie.id = "floating-video-element", ie.autoplay = !0, ie.playsInline = !0, ie.muted = !0, ie.style.cssText = `
      width: 100%;
      height: 100%;
      object-fit: cover;
      transform: scaleX(-1);
    `;
    const ke = document.createElement("div");
    ke.id = "camera-off-placeholder", ke.style.cssText = `
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: ${q.colors.neutral[400]};
      gap: 12px;
      background: #000;
    `;
    const qe = Ce.VideoOff("lg");
    qe.style.width = "48px", qe.style.height = "48px", ke.appendChild(qe);
    const st = document.createElement("span");
    st.textContent = "Camera is off", st.style.cssText = `
      font-size: 14px;
      text-align: center;
    `, ke.appendChild(st), ee.appendChild(ie), ee.appendChild(ke), Se.appendChild(ee), _.appendChild(V), _.appendChild(Se), y.appendChild(_);
    let X = !1, ne = 0, J = 0, Y = 20, le = 20;
    const Ue = (Te) => {
      if (Te.target.closest("button")) return;
      X = !0, ne = Te.clientX, J = Te.clientY;
      const fi = window.getComputedStyle(y);
      Y = parseInt(fi.left), le = parseInt(fi.top), y.style.cursor = "grabbing", Te.preventDefault();
    }, Ye = (Te) => {
      if (!X) return;
      const fi = Te.clientX - ne, bn = Te.clientY - J, ii = Y + fi, Hi = le + bn, Pl = window.innerWidth - 320, xl = window.innerHeight - 240, Ml = Math.max(0, Math.min(ii, Pl)), Al = Math.max(0, Math.min(Hi, xl));
      y.style.left = `${Ml}px`, y.style.top = `${Al}px`;
    }, Vt = () => {
      X && (X = !1, y.style.cursor = "grab");
    };
    return y.addEventListener("mousedown", Ue), document.addEventListener("mousemove", Ye), document.addEventListener("mouseup", Vt), y;
  }, us = async () => {
    if (!O && !(b || A))
      if (!i.state.isConnected && !i.state.isConnecting) {
        A = !0;
        try {
          if (a || i.isPublishedChatSession) {
            if (!a)
              throw new Error(
                "Published chat widgets require requestPublicationGrant to start a new session"
              );
            if (!i.connectWithPublicationGrant)
              throw new Error(
                "This Convai client does not support published chat connections"
              );
            const y = await a();
            if (O)
              return;
            await i.connectWithPublicationGrant(
              y,
              xg(c)
            );
          } else D && typeof i.reconnect == "function" ? await i.reconnect() : await i.connect();
          if (O) {
            await i.disconnect();
            return;
          }
          if (O) {
            await i.disconnect();
            return;
          }
          if (!A) return;
          vn(!0);
        } catch (y) {
          O || console.error("Failed to connect:", y);
        } finally {
          A = !1;
        }
      } else
        vn(!b);
  }, oa = () => {
    if (A) {
      gn();
      return;
    }
    us();
  }, gn = () => {
    A = !1, vn(!1);
  }, ca = () => !!a || !!i.isPublishedChatSession, da = () => i.state.isConnected && (!ca() || i.isBotReady), la = () => {
    R.trim() && da() && (i.sendUserTextMessage(R), R = "", Ie.value = "", ti());
  }, Cl = () => {
    T = !T, i.setCharacterMuted(T), Mt();
  }, ua = async () => {
    hs(!1);
    try {
      await i.disconnect(), i.resetSession(), T = !1, C = !1, w = !1, Mt(), await mi(), ti();
    } catch (y) {
      console.error("Failed to reset:", y);
    }
  }, ha = async () => {
    hs(!1), await i.disconnect(), T = !1, C = !1, w = !1, Mt(), qi(), ti();
  }, pa = async () => {
    if (i.connectionType === "video")
      try {
        P ? await i.videoControls.disableVideo() : await i.videoControls.enableVideo();
      } catch (y) {
        console.error("Failed to toggle video:", y);
      }
  }, ma = async () => {
    try {
      await i.screenShareControls.toggleScreenShare();
    } catch (y) {
      console.error("Failed to toggle screen share:", y);
    }
  }, _l = () => {
    v || kl(), hs(!v);
  }, vn = async (y) => {
    b = y, y ? (B.style.width = `${jg}px`, B.style.height = `${qg}px`, B.style.borderRadius = `var(--convai-radius, ${q.borderRadius.xl})`, B.style.cursor = "default", B.style.background = "var(--convai-panel-bg, rgba(252, 252, 253, 0.95))", B.style.backdropFilter = "blur(20px) saturate(180%)", Q.style.opacity = "0", Q.style.transform = "scale(0.8)", Q.style.pointerEvents = "none", ae.style.opacity = "1", ae.style.transform = "scale(1)", ae.style.pointerEvents = "auto", o && !a && i.connectionType !== "text" && !w && i.state.isConnected && setTimeout(async () => {
      try {
        await i.audioControls.unmuteAudio(), C = !0, w = !0, await mi();
      } catch (_) {
        _i(i, "Failed to enter voice mode on open:", _);
      }
    }, 100)) : (B.style.width = "var(--convai-launcher-size, 64px)", B.style.height = "var(--convai-launcher-size, 64px)", B.style.borderRadius = "50%", B.style.cursor = "pointer", B.style.background = `var(--convai-panel-bg, ${q.colors.glass.backdrop})`, B.style.backdropFilter = q.glass.backdrop, Q.style.opacity = "1", Q.style.transform = "scale(1)", Q.style.pointerEvents = "auto", ae.style.opacity = "0", ae.style.transform = "scale(0.8)", ae.style.pointerEvents = "none");
  }, hs = (y) => {
    v = y, $e.style.display = y ? "flex" : "none";
  }, ti = () => {
    const y = ce.sendButton;
    if (!y) return;
    y.innerHTML = "";
    const _ = ca(), V = da();
    Ie.disabled = _ && !V, R.length > 0 || a || i.connectionType === "text" ? (y.appendChild(Ce.Send("md")), y.style.background = `var(--convai-accent, ${q.colors.text.primary})`, y.style.color = "var(--convai-panel-bg, white)", y.style.border = "none", y.disabled = _ && (R.length === 0 || !V), _ ? (y.style.opacity = R.length > 0 && V ? "1" : "0.5", y.title = V ? R.length > 0 ? "Send" : "Type a message" : "Waiting for character") : y.title = "Send") : (y.appendChild(Ce.Waveform("md")), y.style.background = "transparent", y.style.color = `var(--convai-panel-fg, ${q.colors.text.primary})`, y.style.border = `1px solid ${q.colors.neutral[300]}`, y.style.opacity = "1", y.disabled = !1, y.title = "Voice Mode");
  }, wl = () => {
    if (!_e || !i.room || !i.room.localParticipant) return;
    const y = _e.querySelector(
      "#floating-video-element"
    ), _ = _e.querySelector(
      "#camera-off-placeholder"
    );
    if (!(!y || !_))
      if (P && !C) {
        const j = Array.from(
          i.room.localParticipant.videoTrackPublications.values()
        ).find((M) => M.kind === "video");
        j && j.track ? (j.track.attach(y), y.style.display = "block", _.style.display = "none") : (y.style.display = "none", _.style.display = "flex");
      } else
        y.style.display = "none", _.style.display = "flex";
  }, mi = async () => {
    const y = ce.footerStandard, _ = ce.voiceExitBtn;
    if (C)
      je && (je.style.display = "flex"), $ && ($.style.display = "none"), _e && (_e.style.display = "none"), y && (y.style.display = "none"), _ && (_.style.display = "flex"), xe && (xe.style.justifyContent = "center"), Mt(), ji = Date.now(), fl();
    else {
      if (!i.audioControls.isAudioMuted)
        try {
          await i.audioControls.muteAudio();
        } catch (V) {
          _i(i, "Failed to mute microphone:", V);
        }
      je && (je.style.display = "none"), P ? ($ && ($.style.display = "none"), _e && (_e.style.display = "block"), wl()) : ($ && ($.style.display = "flex"), _e && (_e.style.display = "none")), y && (y.style.display = "flex"), _ && (_.style.display = "none"), xe && (xe.style.justifyContent = "flex-start"), Mt(), gl();
    }
  }, qi = () => {
    mi().catch((y) => {
      _i(i, "Failed to apply voice mode:", y);
    });
  }, El = (y, _, { media: V = !0 } = {}) => {
    if (!y) return;
    const j = y.replace(/\\n/g, `
`).split(`
`), M = { cards: 0 }, z = (X, ne, ...J) => {
      const Y = document.createElement(X);
      return Y.setAttribute("part", ne), Y.style.cssText = wi(Object.assign({}, ...J)), Y;
    }, G = (X) => {
      const ne = X.style.cssText;
      X.addEventListener("focus", () => {
        X.matches(":focus-visible") && (X.style.cssText = `${ne} ${wi(be.linkFocus)}`);
      }), X.addEventListener("blur", () => {
        X.style.cssText = ne;
      });
    }, te = (X, ne, J) => {
      const Y = z("a", "message-link", be.link);
      Y.href = X, Y.target = "_blank", Y.rel = "noopener noreferrer";
      const le = J === X ? cl(J) : J;
      Y.textContent = le;
      const Ue = Ko(ne, X, le);
      if (Ue && (Y.title = Ue), ne === "ftp") {
        const Ye = z("span", "message-link-badge", be.badge);
        Ye.textContent = "FTP", Y.appendChild(Ye);
      }
      return G(Y), Y;
    }, Se = (X, ne) => {
      const J = z("a", "message-contact", be.contact);
      J.href = X, J.title = Ko(ne, X, X);
      const Y = z("span", "message-contact-glyph", be.contactGlyph);
      Y.innerHTML = ts(ne);
      const le = document.createElement("span");
      return le.textContent = Fn(X), J.append(Y, le), G(J), J;
    }, ee = (X) => {
      let ne = "";
      try {
        ne = new URL(X).host;
      } catch {
      }
      const J = z("a", "message-file-card", be.fileCard);
      J.href = X, J.target = "_blank", J.rel = "noopener noreferrer", J.title = X;
      const Y = z("span", "message-file-icon", be.fileIcon);
      Y.textContent = Tg(X);
      const le = document.createElement("span");
      le.style.cssText = wi(be.fileBody);
      const Ue = z("span", "message-file-name", be.fileName);
      Ue.textContent = _r(X);
      const Ye = z("span", "message-file-meta", be.fileMeta);
      return Ye.textContent = `${ne} · Opens in a new tab`, le.append(Ue, Ye), J.append(Y, le), G(J), J;
    }, ie = (X) => {
      const ne = e.linkPreviewResolver, J = document.createComment("site-card");
      return ne && Pg(ne, X).then((Y) => {
        if (!Eg(Y) || !J.parentNode) return;
        const le = z("a", "message-site-card", be.siteCard);
        le.href = X, le.target = "_blank", le.rel = "noopener noreferrer";
        const Ue = document.createElement("span");
        Ue.style.cssText = wi(be.siteHeader);
        const Ye = Ig(Y, X);
        if (Ye) {
          const Te = z("img", "message-site-favicon", be.siteFavicon);
          Te.src = Ye, Te.alt = "", Te.addEventListener("error", () => Te.remove()), Ue.appendChild(Te);
        }
        const Vt = z("span", "message-site-name", be.siteName);
        if (Vt.textContent = Rg(Y, X), Ue.appendChild(Vt), le.appendChild(Ue), Y.title) {
          const Te = z("span", "message-site-title", be.siteTitle);
          Te.textContent = Y.title, le.appendChild(Te);
        }
        if (Y.description) {
          const Te = z("span", "message-site-description", be.siteDescription);
          Te.textContent = Y.description, le.appendChild(Te);
        }
        if (Y.image) {
          const Te = z("img", "message-site-image", be.siteImage);
          Te.src = Y.image, Te.alt = "", Te.loading = "lazy", Te.addEventListener("error", () => Te.remove()), le.appendChild(Te);
        }
        G(le), J.replaceWith(le);
      }), J;
    }, ke = (X, ne) => {
      const J = z("span", "message-media-unavailable", be.unavailable);
      return J.textContent = `Preview unavailable — ${Hs(X)}${ne ? " (insecure URL)" : ""}`, J;
    }, qe = (X, ne, J) => {
      const Y = document.createDocumentFragment();
      if (Cg(X))
        return Y.appendChild(ke(X, !0)), Y;
      const le = z("span", "message-media-card", be.card, J === "image" ? be.cardButton : {}), Ue = J === "image" ? Object.assign(document.createElement("img"), { src: X, alt: ne, loading: "lazy" }) : Object.assign(document.createElement("video"), { src: X, controls: !0, preload: "metadata" });
      Ue.setAttribute("part", "message-media"), Ue.style.cssText = wi(
        Object.assign({}, be.media, J === "video" ? be.videoMedia : {}, { opacity: 0 })
      );
      const Ye = z("span", "message-media-skeleton", be.skeleton);
      Ye.setAttribute("aria-hidden", "true"), Ye.dataset.convaiSkeleton = "";
      const Vt = z("span", "message-media-caption", be.caption);
      Vt.textContent = Hs(X);
      const Te = () => {
        clearTimeout(bn), le.replaceWith(ke(X, !1)), Vt.remove();
      }, fi = () => {
        if (clearTimeout(bn), Ue.style.opacity = "1", Ye.remove(), J === "image") {
          const ii = z("span", "message-media-zoom", be.zoom);
          ii.innerHTML = ts("zoom"), le.appendChild(ii);
        }
      }, bn = setTimeout(Te, Ng);
      if (Ue.addEventListener(J === "image" ? "load" : "loadedmetadata", fi), Ue.addEventListener("error", Te), J === "image") {
        le.setAttribute("role", "button"), le.tabIndex = 0, le.setAttribute("aria-label", `Open image: ${_r(X)}`);
        const ii = () => Bg({
          src: X,
          alt: ne,
          caption: Hs(X),
          href: X,
          root: t,
          returnFocusTo: le
        });
        le.addEventListener("click", ii), le.addEventListener("keydown", (Hi) => {
          (Hi.key === "Enter" || Hi.key === " ") && (Hi.preventDefault(), ii());
        });
      }
      return le.append(Ue, Ye), Y.append(le, Vt), Y;
    }, st = (X) => {
      const ne = [];
      for (const J of vg(X))
        switch (J.kind) {
          case "strong": {
            const Y = document.createElement("strong");
            Y.textContent = J.text, Y.style.cssText = `
                font-weight: 600;
                color: var(--convai-panel-fg, ${q.colors.text.primary});
              `, ne.push(Y);
            break;
          }
          case "em": {
            const Y = document.createElement("em");
            Y.textContent = J.text, Y.style.cssText = "font-style: italic;", ne.push(Y);
            break;
          }
          case "blocked": {
            const Y = z("span", "message-link-blocked", be.blocked);
            Y.textContent = J.label, Y.title = `Link blocked: ${J.href}`, ne.push(Y);
            break;
          }
          case "image": {
            V && M.cards < zs ? (M.cards++, ne.push(qe(J.src, J.alt, "image"))) : ne.push(te(J.src, "image", J.alt || J.src));
            break;
          }
          case "link": {
            const Y = kg(J.href);
            if (Y === "email" || Y === "phone" || Y === "sms") {
              ne.push(V ? Se(J.href, Y) : te(J.href, Y, J.label));
              break;
            }
            if (ne.push(te(J.href, Y, J.label)), V && Y === "web" && !!e.linkPreviewResolver && M.cards < zs) {
              M.cards++, ne.push(ie(J.href));
              break;
            }
            if (!(V && (Y === "image" || Y === "video" || Y === "document") && M.cards < zs)) break;
            M.cards++, ne.push(Y === "document" ? ee(J.href) : qe(J.href, J.label, Y));
            break;
          }
          default:
            ne.push(document.createTextNode(J.text));
        }
      return ne;
    };
    j.forEach((X, ne) => {
      if (X.trim() === "" && ne > 0) {
        _.appendChild(document.createElement("br"));
        return;
      }
      const J = st(X);
      J.length > 0 ? J.forEach((Y) => _.appendChild(Y)) : _.appendChild(document.createTextNode(X)), ne < j.length - 1 && _.appendChild(document.createElement("br"));
    });
  }, ps = () => {
    if (!$) return;
    const y = Rl();
    if ($.innerHTML = "", y.length === 0) {
      const _ = document.createElement("div");
      _.style.cssText = `
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: ${q.colors.text.secondary};
            text-align: center;
            padding: 32px;
        `, _.innerHTML = `
            <p style="font-weight: 500; margin-bottom: 8px;">Start a conversation</p>
            <p style="font-size: 12px;">Type a message below to begin chatting</p>
        `, $.appendChild(_);
      return;
    }
    y.forEach((_) => {
      const V = document.createElement("div");
      V.style.cssText = `
        display: flex;
        flex-direction: column;
        max-width: ${_.isUser, "70%"};
        margin-left: ${_.isUser ? "auto" : "0"};
        width: 100%;
        isolation: isolate;
        contain: layout style paint;
      `;
      const j = document.createElement("div");
      j.setAttribute("part", _.isUser ? "message message-user" : "message message-bot"), _.isUser && j.setAttribute("data-message-type", "user");
      const M = "rgba(252, 252, 253, 0.95)";
      if (j.style.cssText = `
        padding: 12px;
        border-radius: ${_.isUser ? "12px 12px 4px 12px" : "12px 12px 12px 4px"};
        background: ${M};
        background-color: ${M};
        backdrop-filter: blur(20px) saturate(180%);
        border: 1px solid rgba(0, 0, 0, 0.06);
        box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.8) inset, 0 2px 8px rgba(0, 0, 0, 0.08);
        color: var(--convai-panel-fg, ${q.colors.text.primary});
        font-family: var(--convai-font, ${q.typography.fontFamily.body});
        font-size: 14px;
        line-height: 1.5;
        word-wrap: break-word;
        max-width: 100%;
        display: flex;
        flex-direction: column;
        font-synthesis: none;
        text-rendering: optimizeLegibility;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        -webkit-text-size-adjust: 100%;
        isolation: isolate;
        contain: layout style paint;
      `, j.style.setProperty("background", M, "important"), j.style.setProperty(
        "background-color",
        M,
        "important"
      ), _.sender) {
        const G = document.createElement("div");
        G.style.cssText = `
          display: flex;
          align-items: center;
          gap: ${q.spacing.xs};
          margin-bottom: ${q.spacing.xs};
          isolation: isolate;
          contain: layout style paint;
        `;
        const te = document.createElement("div");
        if (te.style.cssText = `
          width: 16px;
          height: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          isolation: isolate;
          contain: layout style paint;
        `, _.isUser) {
          const ee = Ce.User("sm");
          ee.style.width = "16px", ee.style.height = "16px", ee.style.color = q.colors.convai.dark, te.appendChild(ee);
        } else {
          const ee = Ce.ConvaiLogo("sm", "connected");
          ee.style.width = "16px", ee.style.height = "16px", ee.style.color = "#10b981", te.appendChild(ee);
        }
        const Se = document.createElement("span");
        Se.textContent = _.sender === "User" ? "You" : _.sender, Se.style.cssText = `
          font-size: 12px;
          color: ${_.isUser ? q.colors.convai.dark : "#10b981"};
          font-weight: 500;
          font-family: var(--convai-font, ${q.typography.fontFamily.body});
          isolation: isolate;
          contain: layout style paint;
        `, G.appendChild(te), G.appendChild(Se), j.appendChild(G);
      }
      const z = document.createElement("div");
      if (z.style.cssText = `
        white-space: pre-wrap;
        word-wrap: break-word;
      `, El(_.text, z, { media: !_.isUser }), j.appendChild(z), V.appendChild(j), _.timestamp) {
        const G = document.createElement("span");
        G.textContent = _.timestamp, G.style.cssText = `
          font-size: 12px;
          color: ${q.colors.text.secondary};
          margin-top: 4px;
          align-self: ${_.isUser ? "flex-end" : "flex-start"};
          font-family: var(--convai-font, ${q.typography.fontFamily.body});
        `, V.appendChild(G);
      }
      $.appendChild(V);
    }), $.scrollTop = $.scrollHeight;
  }, fa = () => i.state.isConnected ? i.state.isConnecting || !i.isBotReady ? { color: "#f59e0b", label: "Connecting" } : i.state.isListening ? { color: "#3b82f6", label: "Listening" } : { color: "#10b981", label: "Connected" } : { color: "#ef4444", label: "Disconnected" }, Rl = () => i.chatMessages.filter(
    (_) => (_.type === "user-transcription" || _.type === "user-llm-text" || _.type === "bot-llm-text" || _.type === "bot-output" || _.type === "bot-emotion") && _.content && _.content.trim().length > 0
  ).map((_) => ({
    id: _.id,
    text: _.content,
    isUser: _.type.includes("user"),
    timestamp: new Date(_.timestamp).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit"
    }),
    sender: _.type.includes("user") ? "You" : g,
    showLogo: _.type.includes("bot")
  })), Il = () => {
    N.register(
      (y) => i.on("stateChange", y),
      () => {
        i.connectionType === "text" && (C && (C = !1, w = !0, mi()), ti()), Mt(), i.state.isConnecting ? B.style.animation = "convai-pulse 2s ease-in-out infinite" : B.style.animation = "none", i.state.isSpeaking ? ji || (ji = Date.now()) : ji && !i.state.isSpeaking && (ji = 0), !i.state.isConnected && !i.state.isConnecting && (b && vn(!1), T = !1, C = !1, P = !1, w = !1, Mt(), qi()), i.state.isConnected && o && b && !w && !C && setTimeout(async () => {
          try {
            await i.audioControls.unmuteAudio(), C = !0, w = !0, await mi();
          } catch (y) {
            _i(i, "Failed to enter voice mode:", y);
          }
        }, 100);
      }
    ), N.register(
      (y) => i.videoControls.on("videoStateChange", y),
      (y) => {
        if (y.isVideoEnabled !== void 0) {
          P = y.isVideoEnabled, qi();
          const _ = ce.settingsVideoBtn;
          if (_) {
            const V = P;
            _.style.backgroundColor = V ? "rgba(16, 185, 129, 0.15)" : "transparent", _.style.color = V ? "#10b981" : `var(--convai-panel-fg, ${q.colors.text.primary})`;
            const j = _.querySelector("div");
            if (j) {
              j.innerHTML = "";
              const M = V ? Ce.Video("md") : Ce.VideoOff("md");
              M.style.width = "18px", M.style.height = "18px", j.appendChild(M);
            }
          }
        }
      }
    ), i.screenShareControls.on(
      "screenShareStateChange",
      (y) => {
        if (y.isScreenShareActive !== void 0) {
          const _ = y.isScreenShareActive, V = ce.settingsShareBtn;
          if (V) {
            const j = _;
            V.style.backgroundColor = j ? "rgba(16, 185, 129, 0.15)" : "transparent", V.style.color = j ? "#10b981" : `var(--convai-panel-fg, ${q.colors.text.primary})`;
            const M = V.querySelector("div");
            if (M) {
              M.innerHTML = "";
              const z = j ? Ce.StopScreenShare("md") : Ce.ScreenShare("md");
              z.style.width = "18px", z.style.height = "18px", M.appendChild(z);
            }
          }
        }
      }
    ), N.register(
      (y) => i.on("messagesChange", y),
      () => {
        ps();
      }
    ), N.register(
      (y) => i.on("botReady", y),
      () => {
        Mt(), ti();
      }
    ), N.register(
      (y) => i.on("connect", y),
      () => {
        D = !0, i.room && !k && (k = new Go(i.room, { container: L })), de(), l && l();
      }
    ), N.register(
      (y) => i.on("disconnect", y),
      () => {
        k && (k.destroy(), k = null), ps(), u && u();
      }
    ), N.register(
      (y) => i.on("message", y),
      (y) => {
        const _ = y;
        h && _ && h(_);
      }
    ), N.register(
      (y) => i.screenShareControls.on("screenShareStateChange", y),
      (y) => {
        if (y.isScreenShareActive !== void 0) {
          const _ = y.isScreenShareActive, V = document.getElementById("convai-settings-share-btn");
          if (V) {
            const j = _;
            V.style.backgroundColor = j ? "rgba(16, 185, 129, 0.15)" : "transparent", V.style.color = j ? "#10b981" : q.colors.text.primary;
            const M = V.querySelector("div");
            if (M) {
              M.innerHTML = "";
              const z = j ? Ce.StopScreenShare("md") : Ce.ScreenShare("md");
              z.style.width = "18px", z.style.height = "18px", M.appendChild(z);
            }
          }
        }
      }
    );
  };
  return Ge(), Il(), na(), ti(), o && qi(), i.state.isConnected && i.room && (k = new Go(i.room, { container: L }), de()), {
    element: L,
    client: i,
    // `isOpen` reports *requested* state, which on a warm client is the same
    // thing as rendered state: `setIsOpen()` runs synchronously. The one case
    // where they differ is the first open on a disconnected client, where the
    // panel is committed only after `connect()` resolves; reporting `false`
    // for those seconds would tell an embed reconciling its own
    // convai-open/convai-close events that a widget it just opened is closed.
    // `pendingOpen` is cleared by every cancellation path, so this never
    // reports open for a request that was called off.
    get isOpen() {
      return b || A;
    },
    // Drives the exact same path the launcher click does: `handleToggle`
    // (connect-on-first-open, then `setIsOpen(true)`). Idempotent against an
    // in-flight open as well as an open panel, so repeat calls never start a
    // second connect.
    open: () => {
      b || A || us();
    },
    // Drives the same path the header's close button does: `handleClose` ->
    // `setIsOpen(false)`. Also cancels an open that is still waiting on
    // `connect()`; a redundant `close()` is a no-op.
    close: () => {
      !b && !A || gn();
    },
    toggle: () => {
      b || A ? gn() : us();
    },
    // Pushes a synthetic ChatMessage straight onto `client.chatMessages` and
    // re-renders via the widget's existing `updateMessageList()`. It never
    // calls a client send method (e.g. `sendUserTextMessage`), so the
    // message never reaches the character and is never billed as an LLM
    // turn. The `local-` id keeps it from colliding with a server-issued id.
    appendMessage: (y) => {
      if (typeof i.appendMessage == "function")
        i.appendMessage(y);
      else {
        const _ = {
          id: `local-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`,
          type: y.sender === "user" ? "user-llm-text" : "bot-llm-text",
          content: y.content,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        };
        i.chatMessages.push(_);
      }
      ps();
    },
    destroy: () => {
      O = !0, k && (k.destroy(), k = null), B.removeEventListener("click", oa), L.parentElement && L.remove(), _e.parentElement && _e.remove(), N.unsubscribeAll();
    }
  };
}
function Er(n) {
  return n.publicationId ? "publication" : n.tokenEndpoint ? "token" : n.connectEndpoint ? "proxy" : n.apiKey ? "key" : null;
}
const Jg = "https://realtime-api.convai.com", Yg = "https://docs.convai.com/embed#auth", Xo = { keyWarned: !1 };
function Qg() {
  if (!Xo.keyWarned) {
    Xo.keyWarned = !0;
    try {
      console.warn(
        `[convai-widget] api-key is visible in page source and can be used by anyone who views it. Use token-endpoint (recommended) or connect-endpoint in production. ${Yg}`
      );
    } catch {
    }
  }
}
const Xg = 3e4;
function Zg(n) {
  const e = /[zZ]$|[+-]\d{2}:?\d{2}$/.test(n);
  return Date.parse(e ? n : `${n}Z`);
}
function ev(n) {
  if (!n) return !1;
  const e = Zg(n.expirationTime);
  return Number.isNaN(e) ? !1 : e - Xg > Date.now();
}
async function ul(n, e, t) {
  let i;
  try {
    i = await fetch(n, e);
  } catch (s) {
    return { ok: !1, code: "network", message: `request failed: ${String(s)}` };
  }
  if (!i.ok) {
    const s = i.status >= 400 && i.status < 500 ? "auth" : "network";
    let r = `HTTP ${i.status}`;
    if (t)
      try {
        const o = await i.text();
        o && (r = `${r}: ${o.slice(0, 200)}`);
      } catch {
      }
    else
      r = `${r} (add the \`debug\` attribute to include the response body)`;
    return { ok: !1, code: s, message: r };
  }
  try {
    return { ok: !0, json: await i.json() };
  } catch {
    return { ok: !1, code: "network", message: "response was not valid JSON" };
  }
}
async function tv(n, e) {
  var r;
  if (ev((r = e == null ? void 0 : e.current) != null ? r : null)) {
    const o = e.current;
    return { ok: !0, authToken: o.token, expirationTime: o.expirationTime };
  }
  const t = await ul(
    n.tokenEndpoint,
    {
      method: "POST",
      // A bodyless, header-less POST is well-formed but is also exactly the
      // shape some frameworks/WAFs/gateways reject outright — and this is the
      // recommended path, so "auth doesn't work" would land on the customer's
      // side of the boundary with nothing pointing back here. An explicit
      // JSON content type and an empty object body is accepted everywhere and
      // costs a handful of bytes.
      headers: { "Content-Type": "application/json" },
      body: "{}"
    },
    n.debug
  );
  if (!t.ok) return t;
  const i = t.json;
  if (typeof (i == null ? void 0 : i.apiAuthToken) != "string" || !i.apiAuthToken)
    return { ok: !1, code: "network", message: "token response had no apiAuthToken" };
  const s = typeof i.expirationTime == "string" ? i.expirationTime : (/* @__PURE__ */ new Date(0)).toISOString();
  return e && (e.current = { token: i.apiAuthToken, expirationTime: s }), { ok: !0, authToken: i.apiAuthToken, expirationTime: s };
}
async function iv(n, e, t) {
  const i = Er(n);
  if (i === "publication")
    return {
      ok: !1,
      code: "config",
      message: "a published session resolves its own launch grant and must not reach resolveConnection"
    };
  if (i === "token")
    return tv(n, t);
  if (i === null)
    return {
      ok: !1,
      code: "config",
      message: "no token-endpoint, connect-endpoint, or api-key"
    };
  const s = i === "proxy" ? n.connectEndpoint : `${Jg}/connect`, r = { "Content-Type": "application/json" };
  i === "key" && (Qg(), r["X-API-Key"] = n.apiKey);
  const o = await ul(
    s,
    { method: "POST", headers: r, body: JSON.stringify(e) },
    n.debug
  );
  if (!o.ok) return o;
  const a = o.json;
  return a != null && a.room_url ? { ok: !0, data: a } : { ok: !1, code: "network", message: "connect response had no room_url" };
}
const nv = 32, sv = 512, rv = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i, hl = /^[A-Za-z0-9_-]{16,128}$/, Zo = "convai.published-chat-client-id.v1";
let Cn;
const av = "https://api.convai.com";
function ov() {
  var e, t;
  const n = (t = (e = globalThis.crypto) == null ? void 0 : e.randomUUID) == null ? void 0 : t.call(e);
  if (!n)
    throw new Error("Published chat requires a secure browser random source");
  return n;
}
function cv() {
  var e, t;
  if (Cn) return Cn;
  try {
    const i = (e = globalThis.localStorage) == null ? void 0 : e.getItem(Zo);
    if (i && hl.test(i))
      return Cn = i, i;
  } catch {
  }
  const n = ov();
  Cn = n;
  try {
    (t = globalThis.localStorage) == null || t.setItem(Zo, n);
  } catch {
  }
  return n;
}
function dv(n) {
  if (typeof window == "undefined")
    throw new Error("Server callers must provide a caller-scoped published chat requester ID");
  return cv();
}
function ia(n, e) {
  let t;
  try {
    t = new URL(n);
  } catch {
    throw new Error(`${e} must be an absolute URL`);
  }
  if (t.protocol !== "https:" && t.protocol !== "http:")
    throw new Error(`${e} must use HTTP or HTTPS`);
  if (t.username || t.password)
    throw new Error(`${e} must not include credentials`);
  return t;
}
function lv(n, e = av) {
  if (!rv.test(n))
    throw new Error("publication-id must be a UUID");
  const t = ia(e, "publication-api-url");
  t.pathname = `${t.pathname.replace(/\/+$/, "")}/`;
  const i = `chat-publications/${encodeURIComponent(n)}`;
  return {
    descriptorUrl: new URL(i, t),
    launchGrantUrl: new URL(`${i}/launch-grants`, t)
  };
}
async function pl(n, e) {
  var s, r;
  const t = await n.json().catch(() => null), i = (r = (s = t == null ? void 0 : t.detail) != null ? s : t == null ? void 0 : t.message) != null ? r : t == null ? void 0 : t.error;
  return typeof i == "string" && i.trim() ? i.trim().slice(0, 240) : e;
}
async function uv(n, e = fetch, t) {
  const i = ia(n, "descriptor-url"), s = await e(i, {
    method: "GET",
    cache: "no-store",
    credentials: "omit",
    headers: { Accept: "application/json" },
    signal: t
  });
  if (!s.ok)
    throw new Error(await pl(s, `Unable to load published chat (${s.status})`));
  const r = await s.json();
  if (typeof (r == null ? void 0 : r.publication_id) != "string" || typeof (r == null ? void 0 : r.display_name) != "string" || typeof (r == null ? void 0 : r.description) != "string" && (r == null ? void 0 : r.description) !== null || typeof (r == null ? void 0 : r.image_url) != "string" && (r == null ? void 0 : r.image_url) !== null || (r == null ? void 0 : r.mode) !== "text")
    throw new Error("Published chat returned an invalid descriptor");
  return r;
}
async function hv(n, e = fetch, t, i) {
  const s = dv();
  if (!hl.test(s))
    throw new Error("Published chat browser identifier is invalid");
  const r = ia(n, "launch-grant-url"), o = await e(r, {
    method: "POST",
    cache: "no-store",
    credentials: "omit",
    headers: {
      Accept: "application/json",
      "X-Convai-Publication-Client": s
    },
    signal: t
  });
  if (!o.ok)
    throw new Error(await pl(o, `Unable to start published chat (${o.status})`));
  const a = await o.json(), c = a == null ? void 0 : a.launch_token;
  if (typeof c != "string" || c.length < nv || c.length > sv)
    throw new Error("Published chat returned an invalid launch grant");
  return c;
}
const pv = /* @__PURE__ */ new Set([
  "user",
  "convai",
  "user-transcription",
  "user-llm-text",
  "bot-llm-text",
  "bot-output"
]);
var ai;
class mv extends Ve {
  constructor() {
    super(...arguments);
    ya(this, ai);
    this.startConnect = () => {
    }, fs(this, ai, !1);
  }
  /**
   * `isConnecting` is reported as true while the embed's own flow is in
   * flight, so the SDK widget can render its connecting state over that
   * window. Deliberately only additive, and only when the client itself has
   * nothing to say: once the real connect starts, `super.state` is the truth
   * and this stops interfering.
   */
  get state() {
    const t = super.state;
    return !ms(this, ai) || t.isConnected || t.isConnecting ? t : { ...t, isConnecting: !0, agentState: t.agentState };
  }
  /**
   * `stateChange` is what the widget re-renders on, and nothing else emits it
   * during this window — the client is idle, so without this the flag would
   * be invisible until some later event happened to repaint.
   */
  setResolving(t) {
    if (ms(this, ai) !== t) {
      fs(this, ai, t);
      try {
        this.emit("stateChange", this.state);
      } catch {
      }
    }
  }
  connect() {
    return this.startConnect(), Promise.resolve();
  }
}
ai = new WeakMap();
function fv(n, e) {
  const t = n.element;
  let i = n.isOpen, s = !1, r = !1;
  const o = () => {
    s = !1, !(r || n.isOpen === i) && (i = n.isOpen, e(i ? "convai-open" : "convai-close"));
  }, a = () => {
    s || r || (s = !0, setTimeout(o, 0));
  };
  return t.addEventListener("click", a, !0), {
    schedule: a,
    dispose: () => {
      r = !0, t.removeEventListener("click", a, !0);
    }
  };
}
function gv(n) {
  return new Promise((e, t) => {
    let i = !1, s, r;
    const o = () => {
      if (!i) {
        i = !0, s !== void 0 && cancelAnimationFrame(s), r !== void 0 && clearTimeout(r);
        try {
          n(), e();
        } catch (a) {
          t(a instanceof Error ? a : new Error(String(a)));
        }
      }
    };
    if (typeof requestAnimationFrame != "function") return o();
    s = requestAnimationFrame(o), r = setTimeout(o, vv);
  });
}
const vv = 100;
function bv(n) {
  return typeof n == "object" && n !== null && n.code === "mic-permission";
}
function yv(n, e) {
  const t = document.createElement("div");
  t.className = "convai-retry", t.setAttribute("role", "alert"), t.style.cssText = `
    position: fixed;
    top: 16px;
    left: 50%;
    transform: translateX(-50%);
    z-index: calc(var(--convai-z-index, 1040) + 1);
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    border-radius: var(--convai-radius, 12px);
    background: var(--convai-panel-bg, rgba(255, 255, 255, 0.95));
    color: var(--convai-panel-fg, #1f2937);
    box-shadow: var(--convai-shadow, 0 8px 32px rgba(0, 0, 0, 0.1));
    font-family: var(--convai-font, "Noto Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif);
    font-size: 13px;
  `, n.accent && t.style.setProperty("--convai-accent", n.accent);
  const i = document.createElement("span");
  i.textContent = "Connection failed.";
  const s = document.createElement("button");
  return s.type = "button", s.className = "convai-retry__button", s.textContent = "Retry", s.style.cssText = `
    border: none;
    border-radius: var(--convai-radius, 8px);
    padding: 4px 10px;
    background: var(--convai-accent, #1EB453);
    color: #fff;
    cursor: pointer;
    font: inherit;
  `, s.addEventListener("click", e), t.append(i, s), t;
}
const Sv = Object.freeze({
  open() {
  },
  close() {
  },
  toggle() {
  },
  sendMessage() {
  },
  destroy() {
  },
  client: null
});
async function Ev(n) {
  const e = [];
  try {
    return await kv(n, e);
  } catch (t) {
    n.emitError("runtime", `mount failed: ${String(t)}`);
    for (const i of e.reverse())
      try {
        i();
      } catch {
      }
    return Sv;
  }
}
async function kv(n, e) {
  const { root: t, config: i, launcher: s, emit: r, emitError: o, engaged: a } = n, c = document.createElement("div");
  i.accent && c.style.setProperty("--convai-accent", i.accent);
  const d = Er(i) === "publication";
  let l, u;
  if (d) {
    const K = lv(i.publicationId, i.publicationApiUrl);
    if (u = K.launchGrantUrl.toString(), l = await uv(K.descriptorUrl.toString()), l.publication_id.toLowerCase() !== i.publicationId.toLowerCase())
      throw new Error("Published chat descriptor does not match publication-id");
  }
  const h = new mv({
    // Omitted entirely in publication mode rather than passed as undefined:
    // `connectWithPublicationGrant` nulls all four of these on the client as
    // it establishes the session, so anything set here is both useless and
    // misleading to anyone reading `element.client`.
    ...d ? {} : {
      characterId: i.characterId,
      endUserId: i.endUserId,
      endUserMetadata: i.endUserMetadata
    },
    startWithAudioOn: i.startWithAudio,
    // The SDK defaults this to true, which console.logs every decoded RTVI
    // frame onto the customer's page. An embed must be quiet unless asked.
    logRtviMessages: i.debug,
    // Not used to connect — `ensureConnected()` owns that, and in this mode it
    // posts `/connect` itself with an `X-API-Key` header. This is here so the
    // SDK widget can read a credential off the client for its own
    // `POST /character/get`, which is what fills the panel header with the
    // character's real name and avatar. Without it `fetchCharacterInfo()`
    // returns at its first line and the header keeps the hardcoded
    // "Character" fallback.
    //
    // Only in `api-key` mode, and it gives nothing away: the key is already
    // in the page's own markup, which is why that mode is documented as
    // development-only. `token-endpoint` mode gets the same behaviour for
    // free — `ensureConnected()` stores a minted token on the client, and the
    // SDK prefers `authToken` over `apiKey` for exactly this request.
    // `connect-endpoint` mode holds no browser-side credential by design, so
    // the header stays on the fallback there; see the note in
    // docs/convai_embed.md.
    ...Er(i) === "key" ? { apiKey: i.apiKey } : {}
  });
  e.push(() => void h.disconnect().catch(() => {
  }));
  const p = { current: null };
  let b = null;
  const v = () => {
    const K = p.current;
    K && (b === K.token ? (p.current = null, b = null) : b = K.token);
  };
  let C = !1, T = null;
  const P = (K) => {
    if (!C) {
      if (bv(K)) {
        o("mic-permission", String(K));
        return;
      }
      o("runtime", `sdk error: ${String(K)}`);
    }
  };
  let R = null;
  const g = () => {
    R && (R.remove(), R = null);
  }, f = () => {
    R || C || (R = yv(i, O), t.appendChild(R));
  };
  e.push(g);
  let k = null, w = !1, D = !1;
  const A = () => C ? Promise.resolve() : (k && !w || k && !D || (D = !1, w = !1, k = (async () => {
    h.setResolving(!0);
    const K = await iv(
      i,
      {
        character_id: i.characterId,
        end_user_id: i.endUserId,
        end_user_metadata: i.endUserMetadata
      },
      p
    );
    if (C) return;
    if (!K.ok) {
      o(K.code, K.message), (K.code === "auth" || K.code === "network") && f();
      return;
    }
    let xe, Ie = !1;
    T = [];
    try {
      "authToken" in K ? await Ve.prototype.connect.call(h, {
        characterId: i.characterId,
        authToken: K.authToken,
        endUserId: i.endUserId,
        endUserMetadata: i.endUserMetadata,
        startWithAudioOn: i.startWithAudio,
        logRtviMessages: i.debug
      }) : await h.connectWithConnectionData(K.data), C ? h.disconnect().catch(() => {
      }) : (b = null, g());
    } catch ($) {
      xe = $, Ie = !0, v(), C || (o("network", `connect failed: ${String($)}`), f());
    } finally {
      const $ = T != null ? T : [];
      T = null;
      for (const $e of $)
        Ie && $e === xe || P($e);
    }
  })().finally(() => {
    w = !0, h.setResolving(!1);
  })), k), O = () => {
    D = !0, A();
  };
  d || (h.startConnect = () => {
    A();
  });
  const N = Gg(c, {
    convaiClient: h,
    // Load-bearing. Without it the SDK derives its style target from
    // `container.getRootNode()` at construction time, and this container is
    // still detached — the handoff below is what attaches it. The derivation
    // would see `document`, put the widget's stylesheet and its `popIn`
    // keyframes in `document.head`, and leave the shadow content unstyled
    // with no error anywhere. `test/unit/runtime.test.ts` asserts the
    // stylesheet lands in the root and not in the head.
    styleTarget: t,
    // Without this the widget snaps to bottom-right regardless of the
    // `placement` attribute the loader's launcher just honoured.
    placement: i.placement,
    // The SDK defaults this to true, i.e. it unmutes the microphone as soon
    // as the panel opens. `start-with-audio` is the attribute that opts into
    // that; it must not happen by default. `readConfig` already pins this to
    // false for a publication, which is text-only.
    defaultVoiceMode: i.startWithAudio,
    // The published-chat lifecycle, which the SDK widget owns end to end:
    // on every open with no live session it calls `requestPublicationGrant`,
    // then `client.connectWithPublicationGrant(token, …)`, and holds the
    // composer disabled until Core's bot-ready handshake lands. That is why
    // this mode needs no `ensureConnected`: handing over these three options
    // replaces the whole credential path, and the SDK widget's own
    // `isPublishedChatSession` checks hide the controls a credential-free
    // text session cannot honour.
    ...d ? {
      // A fresh single-use grant per session — see the descriptor note
      // above for why this is not minted at mount time.
      requestPublicationGrant: () => hv(u),
      ...i.coreUrl ? { publishedChatConnectOptions: { url: i.coreUrl } } : {},
      // The panel header's name and avatar. Without this the widget
      // falls back to the literal "Character", because its usual source
      // is a `POST /character/get` that needs a credential this page
      // deliberately does not have.
      publishedChatDescriptor: {
        display_name: l.display_name,
        image_url: l.image_url
      }
    } : {}
  });
  e.push(() => N.destroy(), () => c.remove());
  const L = fv(N, r);
  e.push(L.dispose);
  const B = () => {
    N.open(), L.schedule();
  }, Q = () => {
    N.close(), L.schedule();
  }, ae = () => {
    N.toggle(), L.schedule();
  }, re = [
    h.on("message", (K) => {
      !K || !pv.has(K.type) || K.isStreaming || K.content && r("convai-message", {
        sender: K.type.includes("user") ? "user" : "bot",
        content: K.content
      });
    }),
    h.on("connect", () => r("convai-connect")),
    // Detail-less, per the frozen event contract in docs/spec.md — the
    // LiveKit disconnect reason stays on `element.client` for hosts that
    // want it.
    h.on("disconnect", () => {
      r("convai-disconnect"), L.schedule(), D = !0;
    }),
    // Not redundant with the line above. The widget auto-collapses from its
    // *own* `stateChange` handler ("Auto-collapse when disconnected", which
    // calls `setIsOpen(false)` with no click involved), and `stateChange`
    // fires for transitions that never produce a `disconnect` event — a
    // failed connect attempt among them. Without this the panel visibly
    // closes with no `convai-close`, and `reported` goes stale so the next
    // re-open emits no `convai-open` either.
    h.on("stateChange", () => L.schedule()),
    h.on("error", (K) => {
      if (T) {
        T.push(K);
        return;
      }
      P(K);
    })
  ];
  if (e.push(() => {
    for (const K of re) K();
  }), a && !d && A(), await gv(() => {
    t.appendChild(c);
    try {
      s.remove();
    } catch (K) {
      o("runtime", `launcher removal failed: ${String(K)}`);
    }
  }), a)
    try {
      B();
    } catch (K) {
      o("runtime", `opening the panel failed: ${String(K)}`);
    }
  if (i.greeting)
    try {
      N.appendMessage({ sender: "bot", content: i.greeting });
    } catch (K) {
      o("runtime", `rendering the greeting failed: ${String(K)}`);
    }
  return {
    open: B,
    close: Q,
    toggle: ae,
    sendMessage: (K) => h.sendUserTextMessage(K),
    destroy: () => {
      C = !0, L.dispose();
      for (const K of re)
        try {
          K();
        } catch {
        }
      try {
        N.destroy();
      } catch {
      }
      try {
        h.disconnect().catch(() => {
        });
      } catch {
      }
      g(), c.remove();
    },
    get client() {
      return h;
    }
  };
}
export {
  Ev as mount
};
