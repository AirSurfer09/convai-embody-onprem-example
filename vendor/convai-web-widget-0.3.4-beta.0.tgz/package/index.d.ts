/**
 * `@convai/web-widget` for bundlers.
 *
 * The package's other two artifacts are for a script tag: `v1.js` registers
 * `<convai-widget>` on the page, and `runtime.js` is the chunk it fetches. Both
 * bundle `@convai/web-sdk`, because a copy/paste embed's whole value is that
 * the host page installs nothing.
 *
 * This entry is the opposite trade. It treats the SDK as **external**, so an
 * application that already depends on it links one copy rather than two, and
 * has no side effects, so a bundler can drop whatever is unused. Nothing here
 * touches `document` or registers an element at import time.
 *
 * Importing it does not define `<convai-widget>`. That is deliberate: a
 * bundler consumer composes the pieces, and a custom element registered as a
 * side effect of an import is exactly the kind of thing tree-shaking cannot
 * reason about.
 */
export type { ErrorCode, ErrorDetail, MessageDetail, Placement, Preload, WidgetConfig, } from './types';
/**
 * The version this build came from, for a consumer reporting a bug.
 *
 * Injected from package.json at build time by Vite's `define`, so it cannot
 * drift from the published version the way a hand-written constant would.
 */
export declare const VERSION: string;
