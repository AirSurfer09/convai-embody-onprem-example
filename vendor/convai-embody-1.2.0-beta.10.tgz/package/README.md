# @convai/embody

**Give a Convai character a body.**

[![npm](https://img.shields.io/npm/v/@convai/embody/latest?label=npm&color=blue)](https://www.npmjs.com/package/@convai/embody)
[![TypeScript](https://img.shields.io/badge/TypeScript-first-3178C6)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/license-Apache--2.0-green)](./LICENSE)

Resolves ready-to-use 3D characters by `characterId` and drives them with
lipsync, gaze, breathing and blink. Layered on
[`@convai/web-sdk`](https://www.npmjs.com/package/@convai/web-sdk).

---

> **Branch: `main`** — this branch defaults to the production backend and
> publishes the `latest` tag. `stg` targets staging, which has its own
> character database.
>
> **Status: early release.** The front door — a credential plus a
> `characterId` — is settled; what is still moving is listed in
> [Roadmap](#roadmap).

> **Which backend a build talks to is fixed at publish time.** The `latest`
> and `beta` tags point at `https://api.convai.com`; the `stg` tag points at
> `https://api-stg.convai.com`. Character ids are per-environment and not
> interchangeable — a staging id against production returns *"Character not
> found or doesn't belong to user"*, which reads like a permissions problem
> and is a wrong-host one. Override with `baseUrl` only if you know why.

## Install

```bash
pnpm add @convai/embody @convai/web-sdk three
# React consumers also need:
pnpm add @react-three/fiber react
```

`@convai/web-sdk` and `three` are peer dependencies. `react` and
`@react-three/fiber` are optional peers — the root `@convai/embody` entry
point needs neither. Node.js 18 or later.

A character renders only if its avatar has a published web body, or a default
body applies to it. Otherwise loading fails with *"Character has no 3D
embodiment configured"* — a data problem, not a code one.

## Quick start

```bash
npm install @convai/embody @convai/web-widget @convai/web-sdk three @react-three/fiber
```

```tsx
import { useState } from 'react'
import ConvaiCharacter from '@convai/embody/react'
import { ConvaiWidget } from '@convai/web-widget/react'

export default function App() {
  const [client, setClient] = useState(null)
  return (
    <>
      <ConvaiCharacter apiKey={apiKey} characterId={characterId}
        onReady={(character) => setClient(character.client)} />
      {client && <ConvaiWidget convaiClient={client} />}
    </>
  )
}
```

That renders the character and lets you talk to it. Nothing else is needed —
no `<Canvas>`, no lights, no camera, no `ConvaiClient`, no resolver, no frame
loop. embody resolves the body, opens the `@convai/web-sdk` connection, renders
its audio, and drives lipsync, gaze, breathing and blink. The chat widget is
part of the setup, not an extra: it takes the character's own client, so chat
and lip sync share one connection (see "Talking to the character" below).
Step by step, from an empty folder: [Get started](https://docs.convai.com/api-docs/plugins-and-integrations/web-plugins/convai-embody/get-started).

If the character has **Long-Term Memory** turned on, the connection also needs
an end-user id, so the character can tell your users apart. Pass a stable id
for the person using your app:

```tsx
<ConvaiCharacter apiKey={apiKey} characterId={characterId} session={{ endUserId: user.id }} />
```

Without it, connecting fails with *"Missing end_user_id"*.

### Credentials

`apiKey` is the fastest way to see something on screen, and it is what the
demo uses. It is a **workspace-wide** credential, so treat a build that ships
it as trusted-only.

For anything user-facing, mint a short-lived auth token server-side and pass
`token` instead — same component, one prop different:

```tsx
<ConvaiCharacter token={token} characterId={characterId} />
```

### Moving the camera

Drag to turn the character, scroll to move in and out. On by default — a 3D
character you cannot walk around is a picture of one.

```tsx
<ConvaiCharacter apiKey={apiKey} characterId={characterId} orbit={false} />
```

Pass an object to tune the limits instead of turning it off:

```tsx
<ConvaiCharacter
  apiKey={apiKey}
  characterId={characterId}
  orbit={{ maxDistance: 6, autoRotate: true, autoRotateSpeed: 0.8 }}
/>
```

`minDistance`, `maxDistance`, `minPolarAngle`, `maxPolarAngle`, `enablePan`,
`enableZoom`, `autoRotate`, `autoRotateSpeed`. Anything you leave out keeps its
default, and the defaults are exported as `ORBIT_DEFAULTS` so you can read or
extend them:

```tsx
import { ConvaiCharacter, ORBIT_DEFAULTS } from '@convai/embody/react'

<ConvaiCharacter apiKey={apiKey} characterId={characterId}
  orbit={{ ...ORBIT_DEFAULTS, maxDistance: 3 }} />
```

The defaults are tuned for a conversation with one standing human, not for a
general scene viewer. The camera orbits the character's eyes, and the limits
are set about that point: the vertical sweep runs from 30° above eye level
(a glance down, never the crown of the head from above) to 10° below (a slight
up-angle, never under the floor and into the inside of a head); the dolly from
a face close-up at 0.9 m out to the whole body at 4.5 m; panning is off because
it only ever slides the character out of frame. Polar angles are radians from
straight up, as three's `OrbitControls` has them: `Math.PI / 2` is level.

### In a scene you already have

`ConvaiCharacter` brings its own canvas. When the character should join a
scene you are composing yourself, use `CharacterModel` inside your `<Canvas>`:

```tsx
import { CharacterModel } from '@convai/embody/react'

<Canvas>
  <MyLights />
  <CharacterModel apiKey={apiKey} characterId={characterId} />
  <MyProps />
</Canvas>
```

### Talking to the character

`character.client` is the `@convai/web-sdk` client — the same connection, not
a second one. Lift it out with `onReady`; chat UI is DOM, so it lives outside
the canvas:

```tsx
import { ConvaiCharacter, type ConvaiClient } from '@convai/embody/react'
import { ConvaiWidget } from '@convai/web-widget/react'

function App() {
  const [client, setClient] = useState<ConvaiClient | null>(null)
  return (
    <>
      <ConvaiCharacter
        apiKey={apiKey}
        characterId={characterId}
        onReady={(c) => setClient(c.client)}
      />
      {client && <ConvaiWidget convaiClient={client} />}
    </>
  )
}
```

embody is the 3D character only; the chat panel is
[`@convai/web-widget`](https://www.npmjs.com/package/@convai/web-widget)
(`npm install @convai/web-widget`, 0.3.0 or later). Hand it the character's own
client — the widget subscribes to it, so chat and lip-sync share one
connection. Do not use the SDK's `useConvaiClient` for this: it *constructs a
second client*, and so opens a second connection, which is exactly what embody
exists to avoid.

`useWidgetClient` is still exported for `@convai/web-widget` before 0.3.0,
whose `ConvaiWidget` accepted only `useConvaiClient`'s result; on 0.3.0 and
later it is unnecessary.

### Voice and lipsync in step

By default the character's voice arrives as a WebRTC audio track. With
`@convai/web-sdk` 2.1 or later, ask for it over the data channel instead, next
to the lipsync frames:

```tsx
<ConvaiCharacter
  token={token}
  characterId={characterId}
  session={{ audioRouting: 'data_only' }}
/>
```

The SDK then plays the voice itself, and only audio whose lipsync has also
arrived: a reply starts once 0.9 s of voice-plus-lipsync is in hand and plays
as one continuous stream. On a slow network it pauses between words to refill
rather than playing sound the face has no motion for. embody follows the
SDK's player: the mouth is clocked from what is actually heard and holds
through any pause. `session.dataAudioBufferSeconds` sets that buffer: larger
values give fewer, longer pauses on a slow connection, and only delay the start
of a reply slightly on a fast one.

On either path the mouth is always drawn at least one frame ahead of the sound
it belongs to, and a reply's first movement is timed to the first audible
sample of its voice, so speech never plays over still lips.

## Without React

The root entry is framework-free — it pulls in neither React nor
`@react-three/fiber`, so a vanilla three.js app can use it directly:

```ts
import { createCharacter } from '@convai/embody'

const character = await createCharacter({ apiKey, characterId })

scene.add(character.root)
character.camera = camera
character.client?.sendUserTextMessage('hello')

renderer.setAnimationLoop(() => {
  character.update(clock.getDelta())
  renderer.render(scene, camera)
})
```

`character.dispose()` releases the model, its materials and textures, the
mixer, and the reduced-motion listener, and closes the connection embody
opened. A client you passed in yourself is left alone.

## What it does

Eight systems run in an explicit, ordered frame pipeline. The order is
load-bearing, not incidental:

| Stage | System | Why here |
|---|---|---|
| 0 prepare | gaze restore | undoes last frame's gaze turn on bones the clip will not rewrite (scale is measured once at load) |
| 1 mixer → ground | animation clips, then grounding | clips drive the skeleton, then that pose's soles are put on the floor |
| 2 gaze | `GazeSystem` | eyes-then-neck-then-torso turns **added** to the clip's pose, so its sway and gestures stay |
| 3 additive | `BreathingSystem` | added *after* the mixer so nothing accumulates |
| 4 ik / 5 attach | *(reserved)* | |
| 6 morph | lipsync → `EyeGazeSystem` → `BlinkSystem` → `MorphNormals` | blink must run after lipsync to win the eyelid channels; the normals of what the morphs moved are recomputed last |

- **Gaze** — eyes, then neck, then body: the eyes take small changes, the head
  follows smoothly beyond a few degrees (or shifts quickly, eye-led, on a large
  jump), and the torso comes round only when the neck has been twisted far for a
  moment. Added to the clip's pose, with its fast head sway steadied while
  fixating, and brief glances away while listening.
- **Breathing** — asymmetric waveform, chest leading the waist, composed onto
  whatever the mixer wrote.
- **Blink** — a recorded passage, not a switch: one of 36 captured blinks,
  both lids on their own curves, played by time at the recording's 60 Hz so
  30/60/120 Hz draw the same shape; embody's own schedule, partial and double
  blinks, resting droop that wanders rather than loops, lids following
  downward gaze (`blink.envelope: 'procedural'` for the sine/cosine envelope).
- **Eye gaze** — morph-only on `convai-mha-1`, which has no eye bones. Each eye
  is aimed at the gaze point from the body's own measured eye shapes, with
  micro-saccades while holding eye contact.
  With no camera, or when not attending, the eyes keep their world direction
  through head motion and settle on the head's forward (0.46 s half-life),
  rather than riding the head.
- **`prefers-reduced-motion`** damps every additive layer and suppresses
  look-away shifts, while leaving lipsync and clip playback untouched.
- **Lip sync on the voice's clock** — mouth frames arrive paced for the wall
  clock, the voice is played by WebRTC; the mouth follows the audio track's own
  clock, anchors each reply on its first sound and the stream's first mouth
  movement, closes once at the end, stays on the sound across stalls between a
  chunked voice's pieces, and never leaves the voice playing on a still face.
- **Surfaces** — skin, hair, eyes and teeth are re-shaded to take the app's
  lights: physically based skin with light wrap and pores, hair drawn as
  coverage with depth toward the scalp and hair-coloured highlights, living
  eyes with a measured iris and a catchlight, lit teeth shaded by the mouth.
  A body whose manifest says `gender: 'male'` gets a male look (lashes at the
  texture's own alpha, a tighter and less pink skin response, a `steady`
  resting mood); every value is overridable through `surfaces` and `mouth`.
- **Normals for morphed faces** — exports that ship blend-shape positions
  without blend-shape normals are lit with their bind-pose normals, so a
  closed eyelid shaded black; `MorphNormals` recomputes them where the shapes
  move, sparsely (`morphNormals: false` to turn it off).
- **Model inspection** — `inspectModel(url)` and `character.report` say what a
  GLB can and cannot do (face naming and the `morphMap` in effect, blink and
  eye movement, skeleton, every clip), each problem with the config or export
  change that fixes it; `diagnostics` prints it when something is wrong.

## Rigs

`convai-mha-1` (the UE MetaHuman rig) is the registered profile. `CC4_LEGACY`
ships but is deliberately not registered. Bone and morph names are data on the
profile, so a new rig is a value rather than a code change.

### Full and Lite bodies

A body can ship two GLBs of the same rig: **Full**, with all 251 MetaHuman
blendshapes, and **Lite**, with a reduced set (the art team's Lite exports
carry 103; keep it at 192 or fewer). Phones need Lite. three.js spends one
vertex-shader uniform per blendshape, many mobile GPUs allow 256 in all, and
past that the head fails to compile and is not drawn.

embody picks the file per device (`modelVariant: 'auto'`, the default):
phones and tablets get Lite, and so does any GPU whose
`MAX_VERTEX_UNIFORM_VECTORS` cannot hold Full's blendshapes. Everything else
gets Full. Pass `modelVariant: 'full'` or `'lite'` to force one;
`character.model` reports which file loaded. A body with one GLB loads that
file everywhere. Blendshapes Lite drops are skipped by lipsync, blink and
eye gaze rather than erroring.

## Your own animations and models

**Animations.** `animations` maps a clip name to a GLB holding an animation of
that name, merged over the body's clips by name (the key must equal the
animation's name inside the file). `character.animations` then plays them:

```ts
const character = await createCharacter({
  token, characterId,
  animations: { Wave: '/animations/gestures.glb' },
})
character.animations.crossfadeTo('Wave', { once: true, thenBackTo: 'Idle' })

// embody moves the mouth while the character speaks, never the body clip:
character.client?.on('speakingChange', (s) => character.animations.crossfadeTo(s ? 'Talk' : 'Idle'))
```

Clips authored on the MetaHuman skeleton play as they are. A clip from a
Mixamo or Rigify skeleton (GLB, glTF or FBX) is retargeted onto the body at
load, and tracks for bones the model lacks are dropped and reported in
`character.report`.

**Models.** A `resolver` returning a `CharacterBundle` for files you host
replaces the body while the conversation still comes from the character's
Convai session. Gaze and breathing need the MetaHuman bones (`head`,
`neck_01`, `neck_02`, `spine_02`, `spine_04`, …); the face is mapped by name
(`morphMap: 'auto'`) from MetaHuman, Character Creator or ARKit shapes, so an
ARKit or CC head lip syncs and blinks, and `character.report` lists whatever
the model cannot do.

Step-by-step guides: [Add your own animations](./docs/site/convai-embody/add-your-own-animations.md),
[Use your own 3D model](./docs/site/convai-embody/use-your-own-3d-model.md).

## Escape hatches

The defaults cover the normal case; each of these exists for a specific one.

| Option | For |
|---|---|
| `resolver` | A private asset backend, a fixture in tests, or a pre-fetched manifest. Anything returning a `CharacterBundle` works — the demo ships an offline fixture resolver for backend-free development. `httpResolver` (the default) talks to `GET /character/{id}/embodiment`. |
| `client` | An SDK client your app already created and connected. embody drives lipsync from it and never disconnects it. |
| `connect: false` | A body with no mind — thumbnails, previews, asset review tools. `character.client` is then `null`. |
| `session` | Extra SDK options (voice, memory, transport, `endUserId`). Credentials and `characterId` are not repeated here. |
| `baseUrl` | A different backend environment. Defaults per release channel. |
| `modelVariant` | Force the Full or Lite GLB (`'full'` / `'lite'`) instead of choosing per device, e.g. to preview Lite on a desktop. |
| `queue` on `update()` | One client driving several bodies, when you are deciding which owns the current turn. |
| `correctiveMap` | A table fitted from the body's MetaHuman DNA (`compileCorrectiveMap(json)`) that re-weights each lipsync frame toward what the full rig shows: PSD correctives and joint arcs that one-morph-per-control bodies lack. Off by default. Changing the prop, or `character.lipsync.correctiveMap`, swaps it live. In `pnpm dev`, the demo lists `*.map.json` tables from `../open-rig-dna/maps` (or `$EMBODY_CORRECTIVE_MAPS`) for A/B: **C** toggles, **F** frames the face. |

### Swapping the body under a fixed character id

`resolver` is how an authoring tool previews a body that is not published — or
not even saved. Its **identity is part of the rebuild contract**: memoize it,
and change it exactly when the body should change.

```tsx
const resolver = useMemo(
  () => ({ async resolve() { return bundle } }),
  [bundle],
)

<ConvaiCharacter characterId={avatarId} resolver={resolver} connect={false} />
```

Changing the resolver rebuilds the character; keeping it stable does not. A
resolver rebuilt inline on every render would reload the GLB on every render.

## Documentation

**User documentation** is published on docs.convai.com under *Web Plugins →
Convai Embody*. Its source is [`docs/site/`](./docs/site) in this repository:

| | |
|---|---|
| [Add a 3D character to a React app](./docs/site/convai-embody/add-a-3d-character-to-a-react-app.md) | install, render, verify, troubleshoot |
| [Add a 3D character to a three.js scene](./docs/site/convai-embody/add-a-3d-character-to-a-three-js-scene.md) | the framework-free API |
| [Add a chat widget to a character](./docs/site/convai-embody/add-a-chat-widget-to-a-character.md) | one connection for body and chat |
| [Add your own animations to a character](./docs/site/convai-embody/add-your-own-animations.md) | load, crossfade, talking clip, runtime clips |
| [Use your own 3D model](./docs/site/convai-embody/use-your-own-3d-model.md) | a MetaHuman GLB you host, Full and Lite, rig requirements |
| [React API reference](./docs/site/convai-embody/react-api-reference.md) | every prop and default |
| [createCharacter reference](./docs/site/convai-embody/createcharacter-reference.md) | every option, the handle, the errors |
| [How Convai Embody works](./docs/site/convai-embody/how-convai-embody-works.md) | resolution, the frame pipeline, environments |

Edit those pages here, not in the documentation repository. **Docs are part of every change:** CI runs the same sync into a throwaway checkout of Convai-Documentation and lints every page with that repository's `check_page.py`, so a page that would fail the docs gate fails the PR. Section path, version variable and sidebar placement live in [`docs/site/docs.config.json`](./docs/site/docs.config.json); page order, including nested groups, in [`docs/site/sidebar.json`](./docs/site/sidebar.json). Every publish to
npm `latest` runs [`docs-sync.yml`](./.github/workflows/docs-sync.yml), which
opens a pull request against `Conv-AI/Convai-Documentation` (`staging`) with
the pages, their sidebar entries, `last_reviewed`, and the `embody_version`
GitBook variable. Merging that pull request publishes to the GitBook **Staging**
Space for review; the pages reach docs.convai.com only when a human then merges
`staging` into `main` in that repository. Run the workflow by hand for a
docs-only fix. The pages follow that repository's authoring rules, recorded for
this package in [`docs/site/pack.md`](./docs/site/pack.md).

**Design, plan and decision history** live in [`docs/`](./docs):

| | |
|---|---|
| [motion-design.md](./docs/motion-design.md) | the approved design — the binding authority |
| [motion-implementation-plan.md](./docs/motion-implementation-plan.md) | the 12-task TDD plan |
| [motion-decisions.md](./docs/motion-decisions.md) | 73 rulings, each with its cost if wrong |
| [motion-execution-ledger.md](./docs/motion-execution-ledger.md) | the full execution record |
| [testing-spec.md](./docs/testing-spec.md) | standing policy: the module → test manifest CI enforces |

## Release channels

The backend host is a source constant, `DEFAULT_BASE_URL` in
`src/resolve/resolver.ts`, pinned per release branch — the same shape
`@convai/web-sdk` uses for its connect host.

| Branch | Host | npm tag |
|---|---|---|
| `main` / `prod` | `https://api.convai.com` | `latest` |
| `beta` | `https://api.convai.com` | `beta` |
| `stg` | `https://api-stg.convai.com` | `stg` |

Beta points at **production** — it is the first line of testing against real
infrastructure, not a staging channel. Only `stg` targets staging, which has
its own character database. Character IDs belong to one environment: a staging
ID against production returns a not-found error that reads like a permissions
problem.

Promotion has a silent failure mode: merging `stg` into `main` carries the
staging `DEFAULT_BASE_URL` across with no conflict, because only `stg` ever
edits that line. `pnpm check:hosts` is what catches it.

`scripts/check-hosts.mjs` enforces this. Each channel build asserts the policy
for the release it claims to be, so a staging artifact cannot be cut from
prod-host source:

```bash
pnpm build:stg     # refuses unless DEFAULT_BASE_URL is the staging host
pnpm build:beta    # refuses unless it is production
pnpm build:prod    # refuses unless it is production
pnpm check:hosts   # auto-detects the current branch
```

## Development

```bash
pnpm install
pnpm test         # vitest
pnpm typecheck
pnpm check:tests  # every src/ module has a named test — see docs/testing-spec.md
pnpm build        # emits dist/ with .d.ts
pnpm verify       # hosts + test manifest + typecheck + test + build
pnpm dev          # the demo (see demo/verify.md)
```

Every module in `src/` has a row in [`docs/testing-spec.md`](./docs/testing-spec.md)
naming its test and what that test must prove, and `pnpm check:tests` enforces
it in CI. A new file under `src/` with no row fails the build, so adding a
feature and adding its test are the same commit.

## Roadmap

- **Zero requests of our own.** Return the body manifest from the connection
  the SDK already opens, so embody makes no API call at all. Designed in
  [`docs/manifest-in-connect.md`](./docs/manifest-in-connect.md); the work is
  mostly in `core-service`.
- **Retry on expired asset URLs** — re-resolve and retry once on a 403.
- **More rigs.** `convai-mha-1` is the only registered profile, so a character
  on any other rig has no body.
- **Compressed assets.** The default bodies are ~30 MB; the manifest already
  has `lod` and `encodings` fields that nothing fills in.
- Foot lock, locomotion, hair physics, idle gestures.
- Eye saccades and the speech lock.

## License

Licensed under the [Apache License 2.0](./LICENSE). Copyright 2026 Convai.
