# @convai/embody

## 1.2.0-beta.10

### Patch Changes

- b835934: Lipsync: on the amplitude anchor the mouth's lead over the voice is grown from zero instead of granted at once. Granting it at the voice's onset skipped 12–15 frames of the first syllable in one tick, because the stream moves from its first frame; a reply opening on "Oh!" snapped open. The first frame is now drawn as the voice is heard and the full 0.2 s lead is in hand ~0.8 s in.
- 53c25d5: Lipsync: each reply is anchored once on the voice's amplitude — the stream's first moving frame is drawn at the voice's first audible sample, whatever the server's speaking events do (early, late or never). Silent leading packets no longer start the mouth. Without a sample-level read of the voice, or when nothing is heard within a second, frame 0 is anchored at the reply's first packet as before. `character.lipsync.onset` reports how each reply was anchored.
- 04a9f11: Voice over the data channel: pass `session: { audioRouting: 'data_only' }` (with @convai/web-sdk 2.1+) and the SDK plays the character's voice from the data channel, holding each reply until its audio and lipsync are both in hand. embody then attaches no audio renderer and clocks the mouth from the SDK's player (its heard position and level), so lipsync follows exactly what is heard, through any pause to refill on a slow link. The default WebRTC path is unchanged.
- 266c7d2: Lipsync: the frown (mouthCornerDepress / mouthCornerDown) is capped at 0.4 and follows the stream over ~0.12 s instead of snapping to it. The stream sends it as one- or two-frame spikes on exclamations ("Oh!"), which pulled the mouth corners down far too fast. Articulation channels are untouched. Tune with `mouth: { frownCap, frownSmoothing }`; `frownCap: 1, frownSmoothing: 0` plays it as sent.
- b5b9362: Hair: a hair texture whose strands never reach full alpha is raised to read as full hair, measured from the texture itself (`hairAlphaGain`), so a thin export no longer shows the scalp through the crown and parting. Clean exports are unchanged. Beards and moustaches get the same treatment, and a MetaHuman's bare `Stach` layer is now recognised as facial hair. Brows are left as shipped.
- 151dc8e: Lipsync: the mouth is always drawn at least one frame ahead of the voice it follows — at a reply's onset, while the lead builds, and when frames run short — whatever `voiceLeadSeconds` is set to. A mouth level with its sound read as speech over still lips.
- 419d51f: The tongue rests fully down by default (`tongueDown` held at 1 from the moment the body loads, through every reply and after it), so an open mouth shows the mouth cavity instead of the tongue sitting high behind the teeth. `lipsync.tongueRest` sets a different floor; 0 plays the tongue as the stream sends it.

## 1.2.0-beta.9

### Patch Changes

- aeba326: `ConvaiCharacter`'s `fallback` is removed once the body is ready. It stayed over the character for good, so an app's loading message never went away.
- 820add2: A reply's lipsync starts when its frames are in hand and its voice is audible, instead of waiting for the server's speaking flag, and plays through even when that flag never comes. On an on-prem install the flag arrived 0.4–1.3 s after the voice (worst on the first reply after connecting), so the mouth sat still and then ran that far behind for the whole reply. On Convai's SaaS the flag leads the voice and nothing changes.

## 1.2.0-beta.8

### Patch Changes

- The first words of a reply are mouthed on time. The voice clock starts where the voice already is when the speaking flag arrives after the voice began, the mouth's lead is granted at the first packet instead of grown from zero, frames are read as the stream has them (not through the SDK's fade-in), and a clock-placed stream is shown at once instead of held until the level says the voice is heard. The voice level is the RMS over 11 ms, the scale the mouth finish's pause thresholds were tuned on. When the queue skips a lost chunk, the turn index follows it, so the mouth no longer runs ahead of the voice after a dropout.

## 1.2.0-beta.7

### Minor Changes

- `onPrem` takes an on-prem install's Middleman URL (`https://api-<env>.<domain>`) and points the embodiment manifest, the character info and the Web SDK connection (realtime `live-<env>`, Character API `character-apis-<env>`) at that install; the chat widget follows the client. Values named in `session` or `baseUrl` win over what is derived. `onPremHosts` is exported.

### Patch Changes

- Lipsync on the voice clock plays the stream by index from the turn's first packet, one mapping for the whole reply, as the Unreal plugin plays a face sequence against its audio: the clock starts on the turn's first packet (the stream's frame 0) rather than at an audible onset read from stats 0.3–0.6 s late; nothing is re-anchored mid-reply (the lead-in search, the dry-spell restart at the next onset, the late-frame grace and the break-time anchor shift are gone, each had moved the mouth); late frames are skipped up to where the voice is; a stall holds and resumes from the same frame; a queue restarted under it starts a new turn. The mouth's lead is earned gradually and never past the frames in hand, so it never snaps. The level comes from the voice's own samples through an analyser resumed on the page's gesture. Measured against the voice: every frame used, at most two frames a tick, no dry time, pause-to-speech onsets within ±120 ms.

## 1.2.0-beta.6

### Minor Changes

- `ConvaiCharacter`'s default camera sits at the character's own eye level, looks straight at the point between its eyes and orbits around it, 2.2 m back for a hips-to-head medium shot, with the view lifted so the eyes sit on the upper third (a lens rise, not a tilt). The eye line is measured from the loaded body (`eyeLevel`, new) or taken as 93 % of standing height without an eye mesh. An app's own `camera.target` or `camera.position` is kept as given. `EYE_RISE` is exported.
- Standard orbit limits about the eyes, exported as `ORBIT_DEFAULTS` from `@convai/embody/react` so an app can read and extend them: the vertical sweep runs from 30° above eye level to 10° below, the dolly from a 0.9 m face close-up to 4.5 m, panning off. Every field is still overridable through `orbit={{ … }}` and `orbit={false}` fixes the camera.

### Patch Changes

- Opaque clothing keeps a fabric's floor of albedo (`ALBEDO_FLOOR`, under 1 % linear), and a texel that is black has its roughness lifted to matte cloth (`BLACK_ROUGHNESS`). A garment exported with a zero albedo (the default female body's hoodie) had no diffuse at all, so its roughness map's clouds read as grey smears of specular over black holes; it is now black cloth with its folds. Painted texels keep their own colour and gloss.
- 9015480: The eyes meet the lens. Each eye's neutral frame was built from its own eye cap's facing, and the published heads' caps splay a few degrees, so a component of the gaze direction leaked into each eye's "left" axis with opposite signs: a camera straight ahead asked the left eye for 6° and the right for 14°, and the character read as wall-eyed, never quite looking at the viewer. Both eyes now share one forward (the mean of the caps' facings, as a resting pair looks parallel), measured on any body at load.
- d57d710: Hair keeps the export's alpha multiplier (opacity above 1) on the material. Since 1.1.0 it was clamped to 1 and fullness relied on the WebGL coverage shader patch, which cannot run on WebGPU or node materials (no `onBeforeCompile`) or on a canvas without MSAA, so there the strands drew at their raw thin alpha and a long cut's crown and parting showed scalp. The multiplier is now undone only inside that WebGL patch, where it would make a flat cap; every other renderer draws the hair as the export meant it, as the studio films were. The export's blended copy of the cards is hidden as before, and a layer without a twin is never hidden.
- 61931c7: No grey patch on the cheek beside hanging hair. The scalp-under-hair shade stops at the eye line, and the eye line was taken from a mesh named exactly "Eyes", so a published head whose eyeballs are "EyeSofia" had no eye line and every skin vertex near hair was shaded, cheek and temple included, a flat grey veil from temple to jaw. The eyeballs are now recognised by any eye-ish name that is not the occlusion film, tear line or lashes, and a body with no eye mesh at all takes its eye line from the lids its blink shape moves.
- On three before r182 the shadow receiver read only the red byte of an RGBA-packed depth map, quantising depth to about 4 cm: the key light's nose shadow fell across the cheek as a hard wedge that moved with the bias. The receiver now reads the texel the way the loaded three wrote it (unpacked before r182, the red channel from r182), proven against three's own r160/r170/r182/r187 chunks.
- ff0463d: Shadows on hair and clothing are shade, not black marks. three has no bounce light, so under a portrait rig's near-zero ambient a cap's shadow on hair, or a collar's on a shirt, went to pure black with an edge and read as a mark painted on the texture. Skin already kept a warm floor of the light in its shadow; hair now keeps a neutral floor (0.16, a little warm, over a wider 5-texel edge) and clothing a lower one (0.10), on any body and under any lighting. Apps lose nothing: a fully lit surface is unchanged.
- 6e8bca8: Skin is less glossy. The published heads ship no roughness map, so the face took one roughness value, and at 0.52 with specular 0.6 the forehead, nose and cheekbones carried wet highlights under a hard key and a full-face veneer under an environment map, reading as plastic next to the Unreal look. Roughness without a map is now 0.62 (0.58 on a male record), specular 0.4 (0.35 male), sheen 0.03 (0.02 male). Apps that pass their own `skin` tuning are unchanged.

## 1.2.0-beta.5

### Patch Changes

- The head follows the viewer through one continuous filter. The planned "quick shift" on a large camera jump is gone: a camera that kept moving produced a chain of moves with pauses between them. A jump now starts from rest and lands short without overshoot in about half a second, and a jumping camera is followed without a pause. `GazeConfig.headRate` (default 9) replaces `followTime` and `shiftZone`, which are ignored; `torso.rate` (default 2) replaces `torso.hold`.

## 1.2.0-beta.4

### Patch Changes

- Lipsync comes back from a hidden tab on the voice, however long the tab was hidden. The whole render gap is caught up (the 30 s cap is gone) and the voice clock trusts the voice's own RTP step across the gap, so a tab hidden for a minute no longer returns 30 s behind for the rest of the reply.

## 1.2.0-beta.3

### Patch Changes

- Gaze is continuous: a glance away eases out and back instead of darting, and the fixation drifts instead of micro-saccading. The largest per-frame eye step falls from 12° to about 1° on a glance.

## 1.2.0-beta.2

### Patch Changes

- A glance away while listening moves the eyes alone; the head keeps pursuing the viewer. Before, the head followed every glance out and back, and a glance ending while the camera moved could trip a quick 20° head shift.

## 1.2.0-beta.1

### Minor Changes

- Hair keeps its own colour where its texture turns another one. One ponytail ships opaque brown strands whose thinner texels go green and whose fringe is cyan; drawn as coverage, the strands took those colours and the highlight and sheen were tinted by them. The hair's colour is now measured from its opaque strands, trusted per texel only from the alpha where the texture agrees with them (a clean texture is left exactly as it was), and that colour also tints the highlight, sheen and the scalp under the hair.

## 1.2.0-beta.0

### Minor Changes

- e1cd3b9: Eyes that are not bolted to the head, and blinks from a recording.

  - **Untargeted gaze settles instead of slipping.** With no camera, or while the character is not attending, the eyes used to ride the head: every nod and turn dragged the gaze with it. They now keep the world direction they last looked along — a head turn is countered on the same frame — and recentre on the head's forward with a 0.46 s half-life, the same at any frame rate. Reduced motion still homes them.
  - **Recorded blink envelopes.** A blink is now one of 36 recorded passages (both lids, their own asymmetry, a double blink kept whole), played by time at the recording's 60 Hz so 30/60/120 Hz draw the same shape, scaled so the fullest closes a lid, and blended over 0.1 s from and back to the channel's zero, with 0.3 of the recording's left/right difference kept (`blink.asymmetry`), so the lids are neither identical nor out of step. Embody's own schedule, partial/double rolls and resting droop are unchanged. `blink.envelope: 'procedural'` keeps the previous sine/cosine envelope.

## 1.1.1

### Patch Changes

- fe6304e: Characters render on every three in the supported range again. 1.1.0's shadow receiver declared its PCF overload for the `sampler2DShadow` maps three uses from r182, so on three r160–r181 (the demo's 0.170, for one) every lit material failed to compile and the character rendered black, with no error thrown. The receiver now follows the loaded three: the sampler type comes from the chunk's own uniform, and three before r168, whose `getShadow` has no `shadowIntensity`, gets a matching overload.

  A head the export marks double-sided no longer shadows itself: a solid double-sided surface casts from its back faces, as three does for single-sided ones. Hair cards still cast from both.

## 1.1.1-beta.0

### Patch Changes

- fe6304e: Characters render on every three in the supported range again. 1.1.0's shadow receiver declared its PCF overload for the `sampler2DShadow` maps three uses from r182, so on three r160–r181 (the demo's 0.170, for one) every lit material failed to compile and the character rendered black, with no error thrown. The receiver now follows the loaded three: the sampler type comes from the chunk's own uniform, and three before r168, whose `getShadow` has no `shadowIntensity`, gets a matching overload.

  A head the export marks double-sided no longer shadows itself: a solid double-sided surface casts from its back faces, as three does for single-sided ones. Hair cards still cast from both.

## 1.1.0

### Minor Changes

- 62874a4: Characters at the studio films' quality under any app lighting, lip sync that stays on the voice, and a check of any model at load.

  **Lip sync**

  - The mouth follows the voice's own clock. Each reply anchors on the voice's first sound and the stream's first mouth movement (any mouth channel, so a reply opening on rounded or closed lips no longer runs a second early), with one consistent lead on every reply.
  - A reply ends with one smooth close: no pop after the last word, and a stream held under the voice's tail is not mistaken for a stall.
  - Voices that arrive in chunks with stalls between them (OpenAI voices) keep their lips on the sound: after a stall the mouth advances only over frames that were waiting, and frames that arrive after a dry spell start at the voice's next onset instead of a catch-up burst.
  - No voice plays on a still mouth: when the stream runs dry mid-reply the voice level drives the mouth until frames return, eased in and out.
  - The voice level is read from inbound-rtp stats when RTP carries none, and ignored until the voice is actually played out (autoplay-blocked pages no longer flutter the mouth).

  **Rendering**

  - Skin, hair, eyes and teeth take the app's lights: physically based skin with light wrap and pores, hair drawn as coverage with faint hair-coloured highlights and depth toward the scalp, living eyes with a measured iris and a catchlight, lit teeth shaded by the mouth, shadows on skin that read as shade.
  - The scalp under the hair is shaded in the hair's colour; no band under the hairline, no bare parting, no grey patch at a high hairline.
  - `PortraitLights` for `ConvaiCharacter`'s own canvas and `createPortraitRig` / `placePortraitRig` for plain three.js scenes: a portrait rig that follows the camera.
  - A male record (the body manifest's `gender`) gets a male look: lashes at the texture's own alpha, a tighter and less pink skin response with more pore, less light wrap, and a `steady` resting mood. Every value is overridable (`SurfaceTuning.gender`, `lashOpacity`, `SkinTuning.roughness`/`sheen`/`sheenColor`/`specular`/`tint`, `mouth.expression`).
  - Normals for morphed faces that ship no blend-shape normals (`morphNormals`, on by default): closed eyelids no longer shade black.
  - Hair never moves into the body; hair physics was removed in favour of resting hair on the shoulders.

  **Models and motion**

  - `inspectModel(url, options)` and `character.report` check any GLB at load: morph naming and mapping (`morphMap`, auto for MetaHuman, Character Creator and ARKit), what the face cannot do, the skeleton, and every animation clip, each problem with the config or export change that fixes it. `diagnostics` prints it.
  - Mixamo and Rigify clips are retargeted onto the body at load (`animations`).
  - Gaze moves the eyes, then the neck, then the torso, added to the clip pose; each eye is aimed from the body's own eye shapes.
  - Scale is measured once and the soles are grounded, not the ankle.

## 1.1.0-beta.0

### Minor Changes

- 62874a4: Characters at the studio films' quality under any app lighting, lip sync that stays on the voice, and a check of any model at load.

  **Lip sync**

  - The mouth follows the voice's own clock. Each reply anchors on the voice's first sound and the stream's first mouth movement (any mouth channel, so a reply opening on rounded or closed lips no longer runs a second early), with one consistent lead on every reply.
  - A reply ends with one smooth close: no pop after the last word, and a stream held under the voice's tail is not mistaken for a stall.
  - Voices that arrive in chunks with stalls between them (OpenAI voices) keep their lips on the sound: after a stall the mouth advances only over frames that were waiting, and frames that arrive after a dry spell start at the voice's next onset instead of a catch-up burst.
  - No voice plays on a still mouth: when the stream runs dry mid-reply the voice level drives the mouth until frames return, eased in and out.
  - The voice level is read from inbound-rtp stats when RTP carries none, and ignored until the voice is actually played out (autoplay-blocked pages no longer flutter the mouth).

  **Rendering**

  - Skin, hair, eyes and teeth take the app's lights: physically based skin with light wrap and pores, hair drawn as coverage with faint hair-coloured highlights and depth toward the scalp, living eyes with a measured iris and a catchlight, lit teeth shaded by the mouth, shadows on skin that read as shade.
  - The scalp under the hair is shaded in the hair's colour; no band under the hairline, no bare parting, no grey patch at a high hairline.
  - `PortraitLights` for `ConvaiCharacter`'s own canvas and `createPortraitRig` / `placePortraitRig` for plain three.js scenes: a portrait rig that follows the camera.
  - A male record (the body manifest's `gender`) gets a male look: lashes at the texture's own alpha, a tighter and less pink skin response with more pore, less light wrap, and a `steady` resting mood. Every value is overridable (`SurfaceTuning.gender`, `lashOpacity`, `SkinTuning.roughness`/`sheen`/`sheenColor`/`specular`/`tint`, `mouth.expression`).
  - Normals for morphed faces that ship no blend-shape normals (`morphNormals`, on by default): closed eyelids no longer shade black.
  - Hair never moves into the body; hair physics was removed in favour of resting hair on the shoulders.

  **Models and motion**

  - `inspectModel(url, options)` and `character.report` check any GLB at load: morph naming and mapping (`morphMap`, auto for MetaHuman, Character Creator and ARKit), what the face cannot do, the skeleton, and every animation clip, each problem with the config or export change that fixes it. `diagnostics` prints it.
  - Mixamo and Rigify clips are retargeted onto the body at load (`animations`).
  - Gaze moves the eyes, then the neck, then the torso, added to the clip pose; each eye is aimed from the body's own eye shapes.
  - Scale is measured once and the soles are grounded, not the ankle.

## 1.0.1

### Patch Changes

- c779ffd: Fix: `ConvaiCharacter` and `CharacterModel` call `onReady` (and `onError`) once per character. An inline `onReady={(c) => …}` used to run again on every parent re-render, repeating whatever setup the app did there, such as adding a `speakingChange` listener.

  Docs: two new guides, "Add your own animations to a character" (the `animations` option, `idleClip`, `crossfadeTo`, a talking clip on `speakingChange`, `register` at runtime) and "Use your own 3D model" (a resolver for a MetaHuman GLB you host, the rig requirements, Full and Lite files, `connect: false` previews). The `createCharacter` reference gains `modelVariant`, `character.model`, and sections for `AnimationController` and the `CharacterBundle` manifest; the React reference says which props reload the character. The README's Lite count no longer says 113.

## 1.0.1-beta.0

### Patch Changes

- Fix: `ConvaiCharacter` and `CharacterModel` call `onReady` (and `onError`) once per character. An inline `onReady={(c) => …}` used to run again on every parent re-render, repeating whatever setup the app did there, such as adding a `speakingChange` listener.

  Docs: two new guides, "Add your own animations to a character" (the `animations` option, `idleClip`, `crossfadeTo`, a talking clip on `speakingChange`, `register` at runtime) and "Use your own 3D model" (a resolver for a MetaHuman GLB you host, the rig requirements, Full and Lite files, `connect: false` previews). The `createCharacter` reference gains `modelVariant`, `character.model`, and sections for `AnimationController` and the `CharacterBundle` manifest; the React reference says which props reload the character. The README's Lite count no longer says 113.

## 1.0.0

### Major Changes

- 078036f: **1.0.0: embody is the 3D character only, and it works with `@convai/web-sdk` 2.x.** This is the first `latest` release since 0.4.2. It carries everything from 0.5.0 and 0.6.0, which were staging-only builds.

  Migration from 0.4.2:

  | Was (0.4.2)                                                          | Now (1.0.0)                                                                                                                                                                                      |
  | -------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
  | `import { ConvaiWidget } from '@convai/embody/react'`                | `import { ConvaiWidget } from '@convai/web-widget/react'` (install `@convai/web-widget`), fed by `useWidgetClient(character.client)` so the chat and the body share one connection               |
  | `import { AudioRenderer, AudioContext } from '@convai/embody/react'` | Gone. `ConvaiCharacter` and `createCharacter` play the character's audio themselves. For custom playback, `@convai/web-sdk/vanilla` has a headless `AudioRenderer` class (not a React component) |
  | `@convai/web-sdk` peer `>=1.8.0-beta.4`                              | `>=2.0.1 <3`: web-sdk 2.x. 1.9.x is no longer maintained; upgrade the SDK with embody                                                                                                            |
  | `react` / `@react-three/fiber` / `three` peers unbounded             | `react >=18 <20`, `@react-three/fiber >=8 <10`, `three >=0.160 <1`                                                                                                                               |

  Nothing else needs a code change: every other export and option is unchanged or new (corrective maps, Full/Lite bodies, default-body face fixes).

### Minor Changes

- 6527d85: Full and Lite bodies: when a body ships both GLBs, embody loads Lite (113 blendshapes) on phones, on tablets and on GPUs too small for Full's 251, and Full everywhere else. The new `modelVariant` option (`'auto'` | `'full'` | `'lite'`) forces a choice, and `character.model` reports which file loaded. `pickModelVariant` and `detectDevice` are exported for apps that build their own loader. Bodies with one GLB behave as before.

### Patch Changes

- 86a6659: Face fixes for the convai-mha-1 default bodies (Formal Women, Activity Convai):

  - Lipsync: the bilabial seal is off by default (it held the lips half shut on most speaking frames of the MHA stream), lower-lip gain is the SDK's 0.45, teeth follow a rest offset plus a share of the jaw, frames are consumed against the wall clock so the lips cannot fall behind the voice, and a stalled stream relaxes the mouth instead of freezing it. `teethLowerTuck` is deprecated and read as `teethLowerRest`.
  - Gaze: the eye ease no longer speeds up on high-refresh displays.
  - Materials: export defects are repaired by pattern: self-lit skin, hair and clothes lose the emissive copy of their base colour (eyes keep a quarter), out-of-range roughness and specular are clamped, the head loses its glossy scalp-edge roughness map and its alpha mask, and `Hide` helpers are hidden. `ConvaiCharacter` adds a neutral room environment for the now physically shaded skin and eyes.

- 0a8ce1b: Docs: the quick start and both guides now say that a character with Long-Term Memory needs `session.endUserId`; without it, connecting fails with "Missing end_user_id".
- 298e121: `@convai/web-sdk` peer is now `>=2.0.1 <3`. web-sdk 1.9.x is no longer maintained, so embody 1.0 targets 2.x only.

## 1.0.0-beta.2

### Patch Changes

- Docs: the quick start and both guides now say that a character with Long-Term Memory needs `session.endUserId`; without it, connecting fails with "Missing end_user_id".

## 1.0.0-beta.1

### Patch Changes

- `@convai/web-sdk` peer is now `>=2.0.1 <3`. web-sdk 1.9.x is no longer maintained, so embody 1.0 targets 2.x only.

## 1.0.0-beta.0

### Major Changes

- **1.0.0: embody is the 3D character only, and it works with `@convai/web-sdk` 2.x.** This is the first `latest` release since 0.4.2. It carries everything from 0.5.0 and 0.6.0, which were staging-only builds.

  Migration from 0.4.2:

  | Was (0.4.2)                                                          | Now (1.0.0)                                                                                                                                                                                      |
  | -------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
  | `import { ConvaiWidget } from '@convai/embody/react'`                | `import { ConvaiWidget } from '@convai/web-widget/react'` (install `@convai/web-widget`), fed by `useWidgetClient(character.client)` so the chat and the body share one connection               |
  | `import { AudioRenderer, AudioContext } from '@convai/embody/react'` | Gone. `ConvaiCharacter` and `createCharacter` play the character's audio themselves. For custom playback, `@convai/web-sdk/vanilla` has a headless `AudioRenderer` class (not a React component) |
  | `@convai/web-sdk` peer `>=1.8.0-beta.4`                              | `>=1.9.4 <3`: 1.9.4 or any 2.x                                                                                                                                                                   |
  | `react` / `@react-three/fiber` / `three` peers unbounded             | `react >=18 <20`, `@react-three/fiber >=8 <10`, `three >=0.160 <1`                                                                                                                               |

  Nothing else needs a code change: every other export and option is unchanged or new (corrective maps, Full/Lite bodies, default-body face fixes).

### Minor Changes

- 6527d85: Full and Lite bodies: when a body ships both GLBs, embody loads Lite (113 blendshapes) on phones, on tablets and on GPUs too small for Full's 251, and Full everywhere else. The new `modelVariant` option (`'auto'` | `'full'` | `'lite'`) forces a choice, and `character.model` reports which file loaded. `pickModelVariant` and `detectDevice` are exported for apps that build their own loader. Bodies with one GLB behave as before.

### Patch Changes

- 86a6659: Face fixes for the convai-mha-1 default bodies (Formal Women, Activity Convai):

  - Lipsync: the bilabial seal is off by default (it held the lips half shut on most speaking frames of the MHA stream), lower-lip gain is the SDK's 0.45, teeth follow a rest offset plus a share of the jaw, frames are consumed against the wall clock so the lips cannot fall behind the voice, and a stalled stream relaxes the mouth instead of freezing it. `teethLowerTuck` is deprecated and read as `teethLowerRest`.
  - Gaze: the eye ease no longer speeds up on high-refresh displays.
  - Materials: export defects are repaired by pattern: self-lit skin, hair and clothes lose the emissive copy of their base colour (eyes keep a quarter), out-of-range roughness and specular are clamped, the head loses its glossy scalp-edge roughness map and its alpha mask, and `Hide` helpers are hidden. `ConvaiCharacter` adds a neutral room environment for the now physically shaded skin and eyes.

> 0.5.0 and 0.6.0 were published only to the `stg` npm tag, as staging-backend builds. Their changes reach `latest` in 1.0.0.

## 0.6.0

### Minor Changes

- b9b1e4c: **embody is the 3D character only.** `@convai/embody/react` no longer re-exports `ConvaiWidget`, `AudioRenderer` or `AudioContext`: `@convai/web-sdk` 2.0 moved its chat UI to `@convai/web-widget`, so import them from `@convai/web-widget/react` and install it next to embody. `useWidgetClient` stays: hand its result to the widget so the chat and the character share one connection.

  ```diff
  - import { ConvaiCharacter, ConvaiWidget, useWidgetClient } from '@convai/embody/react'
  + import { ConvaiCharacter, useWidgetClient } from '@convai/embody/react'
  + import { ConvaiWidget } from '@convai/web-widget/react'
  ```

  The `@convai/web-sdk` peer range now also admits the 2.0 prereleases (`>=1.8.0-beta.4 || >=2.0.0-beta.0`); `>=1.8.0-beta.4` alone made npm refuse `2.0.0-beta.x` with ERESOLVE.

## 0.5.0

### Minor Changes

- 249a96f: Optional corrective map for one-morph-per-control bodies. A table fitted from the body's MetaHuman DNA re-weights each lipsync frame toward the full rig (PSD correctives, joint arcs). Pass `correctiveMap` (from `compileCorrectiveMap`) to `createCharacter` or the React components; it is off by default and swaps live through the prop or `character.lipsync.correctiveMap`.

## 0.4.2

### Patch Changes

- 532c49e: Swapping the body under a fixed character id now reaches the screen.

  `useCharacter` rebuilt the character only when the character id, credentials
  or base url changed. The **resolver** was not among them, and the effect read
  its options from a ref — so an authoring tool that holds one avatar id and
  swaps the block underneath (preview release 3, then release 4) got nothing:
  the old GLB stayed on the canvas and it read as a stubborn cache. Nothing was
  cached. The loader was never asked for the new url.

  The resolver decides WHICH body a character id resolves to, so it belongs in
  the rebuild set, and now is.

  This makes the resolver's identity part of the contract: **memoize it**, and
  change it exactly when the body should change. A resolver rebuilt inline on
  every render would rebuild the character on every render. The README's new
  "Swapping the body under a fixed character id" section shows the shape.

  Also documented, unchanged in behaviour: the `orbit` prop (shipped in 0.4.0
  and previously absent from the README), which backend each npm tag talks to,
  and the correct release-branch names — the table named three branches that do
  not exist.

## 0.4.1

### Patch Changes

- 62deba9: `useWidgetClient` hides the server's `user-transcription` echo of a typed message, so `<ConvaiWidget/>` shows each sent message once instead of twice.

## 0.4.0

### Minor Changes

- 8bfb1ab: Drag to turn the character, scroll to move in and out — on by default.

  A 3D character you cannot walk around is a picture of one, and
  `<ConvaiCharacter />` exists to be the batteries-included view. Until now
  every consumer that wanted to look at the side of a head had to drop to
  `CharacterModel` and build its own `Canvas`, which is most of what the
  component was there to spare them.

  `orbit` accepts `false` for a fixed camera, or an object to tune the limits:
  `minDistance`, `maxDistance`, `minPolarAngle`, `maxPolarAngle`, `enablePan`,
  `enableZoom`, `autoRotate`, `autoRotateSpeed`.

  The defaults are tuned for one subject — a standing human — rather than for a
  general scene viewer. Panning is off, because it only ever slides the
  character off screen, and the vertical sweep stops a few degrees below eye
  level, because orbiting under the floor shows the inside of a head. It uses
  three's own `OrbitControls` rather than `@react-three/drei`, so it costs no
  new dependency: `three` is already a peer and the `dependencies` block stays
  empty.

  Minor rather than patch because a character that did not move now moves with
  no code change on the consumer's side.

## 0.3.0

### Minor Changes

- f9d8f06: Characters now look at you, and their mouths move by default.

  Four fixes, all of which change what a character does with no code change on
  the consumer's side. Minor rather than patch because default behaviour moves
  and one interface gained a member.

  **Lipsync worked only if you brought your own client.** `createSession` never
  set `enableLipsync`, and the server sends no blendshape frames unless asked —
  so the zero-config path, `<ConvaiCharacter apiKey characterId />`, connected,
  replied, played audio and never moved its mouth. It worked when an app built
  its own `ConvaiClient` and passed `client`, because then the app supplied the
  flag. That asymmetry was recorded for weeks as "staging emits no blendshapes";
  it was never the environment. `createSession` now defaults `enableLipsync:
true` and `blendshapeConfig: { format: 'mha' }`, with your config spread last
  so you can still disable it or choose another format.

  **The head aimed past its target by the rig's rest tilt.** The look angle was
  solved in the head's parent frame but applied composed onto the head's rest
  pose — two different frames. On a rig whose bones rest at identity they
  coincide, which is why no test caught it; on a real MetaHuman the head settled
  17–20° above a level camera, chin up, while reporting itself on target.

  **The eyes tracked the head's own turn instead of the target.**
  `EyeGazeSystem` read `GazeSystem.direction`, which is how far the head has
  turned from neutral, when the eyes need how far the head is _still_ off target.
  Those diverge exactly when the head is aimed at you — so the eyes rolled
  further the way the head had already gone, and a character looking straight at
  you stared past you. Measured on a live body, `eyeLookUp` sat pinned at 0.203
  for ever.

  **New:** a face material pass, on by default. The defect it fixes is in the
  exports rather than in any app: the teeth material arrives with its albedo
  unbound, so glTF loaders never materialise the `Teeth` image the file ships and
  the mouth renders as one flat white slab. The pass fetches it through the glTF
  parser, tags it sRGB, makes the mouth unlit so it reads the same in sun and
  shade, and adds a catchlight to eyeballs that have a lighting model. Pass
  `faceMaterials: false` to leave every material exactly as the GLB shipped it.

  ### Breaking

  `GazeSource` gained a required `residual` member. If you implement that
  interface yourself — rather than consuming `GazeSystem` — you now need to
  supply it. `direction` is unchanged, and `BlinkSystem` still reads it: lids
  follow the head's deflection from neutral, eyes follow the residual, and one
  field could not serve both.

## 0.2.1

### Patch Changes

- Add a `default` condition to the package exports map.

  The map previously declared only `types` and `import`, so any resolver using
  CommonJS semantics could not resolve the package at all — Jest's default
  resolver failed to resolve `@convai/embody/react` even to mock it, and
  Next.js's `next/dynamic` build transform (which resolves its target via
  `require.resolveWeak`) failed with "Package path './react' is not exported".
  The first real consumer needed three separate workarounds for this one
  omission. `default` points at the same ESM files; resolvers that only need
  resolution now succeed, and runtimes with `require(esm)` can load them.

## 0.2.0

### Minor Changes

- 32ea2de: **Breaking.** The front door is now a credential and a character id. Everything
  else has a working default.

  ```tsx
  import ConvaiCharacter from "@convai/embody/react";

  <ConvaiCharacter apiKey={apiKey} characterId={characterId} />;
  ```

  That renders the character: no `<Canvas>`, no lights, no camera, no
  `ConvaiClient`, no resolver, no frame loop, no lipsync queue. embody resolves
  the body, opens the `@convai/web-sdk` connection, renders its audio and drives
  lipsync, gaze, breathing and blink.

  Previously an app had to build a resolver, hand it in, construct its _own_
  `ConvaiClient` with the same credentials, connect it, attach an
  `AudioRenderer`, and thread `client.blendshapeQueue` through every frame —
  two connections and two copies of the credentials for one character.

  - `createCharacter` takes `apiKey` / `token` / `authToken` and builds the
    resolver itself. `character.client` is the SDK client, and `update(delta)`
    no longer needs a queue argument.
  - `ConvaiCharacter` (default export of `/react`) brings its own canvas.
    `CharacterModel` is the in-scene form for apps composing their own scene.
  - The SDK's conversational surface is re-exported, so `@convai/embody` is the
    only import an app needs. `useWidgetClient` adapts embody's client to
    `<ConvaiWidget/>` — the SDK's `useConvaiClient` would construct a second
    client, and so a second connection.
  - Escape hatches for everything the old API required: `resolver`, `client`,
    `connect: false`, `session`, and an explicit `queue` on `update()`.

  Fixes, all found by running it rather than by typechecking it:

  - **Draco assets could not load.** A GLB declaring
    `KHR_draco_mesh_compression` failed outright with "No DRACOLoader instance
    provided", which took out the entire default male body. A decoder is now
    wired; `dracoDecoderPath` overrides where its wasm comes from.
  - **Characters loaded in their bind pose**, arms out, until the app called
    `play()`. An idle clip now starts automatically; `idleClip` overrides it.
  - **Auth tokens were being dropped.** The resolver sent
    `Authorization: Bearer`, which the backend ignores, silently downgrading the
    request. It now sends `API-AUTH-TOKEN`, matching the SDK.
  - **A missing credential is refused** before any request. There is no
    anonymous access to Convai, and the SDK does not use the backend's guest
    path either.
  - `CharacterBundle.fallback` is typed. The backend has always returned it;
    without it no consumer could tell a placeholder body from the character's
    own.
  - Resolver failures now carry the backend's message. "Character has no 3D
    embodiment configured" points at the avatar config; a bare `HTTP 404` sends
    people to check the character id.

- 266904e: `httpResolver`'s `baseUrl` is now optional, defaulting to `DEFAULT_BASE_URL` —
  a source constant pinned per release branch, mirroring how `@convai/web-sdk`
  pins its connect host.

  `stable-release` and `beta-release` target production; `stg-release` targets
  staging. `scripts/check-hosts.mjs` enforces it, and `build:stg` / `build:beta` /
  `build:prod` each assert the policy for the release they claim to be, so a
  staging artifact cannot be cut from prod-host source.

- f972846: Initial motion slice: rig abstraction, staged frame pipeline, and the behaviours
  that make a character read as alive.

  - `RigProfile` / `resolveRig` — bone and morph roles as data, `convai-mha-1` registered
  - `Pipeline` — explicit six-stage frame order (normalize, mixer, gaze, additive, ik, attach, morph);
    intra-stage order is the contract that puts blink after lipsync
  - `GazeSystem` — head/neck solve, idle drift, look-away shifts, turn banking,
    camera lock and clip deviation pull-back
  - `BreathingSystem`, `BlinkSystem`, `EyeGazeSystem`
  - `prefers-reduced-motion` support across every additive layer
  - Thin React binding: `<ConvaiCharacter/>` and `useCharacter()`, with the
    create/cancel/dispose lifecycle extracted framework-free

All notable changes are recorded here. Versions are managed with
[changesets](https://github.com/changesets/changesets); add one with
`pnpm changeset` and the release flow writes this file.
